CREATE DATABASE  IF NOT EXISTS `ACSServer` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `ACSServer`;
-- MySQL dump 10.16  Distrib 10.1.26-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ACSServer
-- ------------------------------------------------------
-- Server version	10.1.26-MariaDB-0+deb9u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `changed_value`
--

DROP TABLE IF EXISTS `changed_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changed_value` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `changed_value_time` datetime NOT NULL,
  `param` varchar(45) NOT NULL,
  `old_value` varchar(45) DEFAULT NULL,
  `new_value` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `changedValue_fk1` (`device_id`),
  CONSTRAINT `changedValue_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changed_value`
--

LOCK TABLES `changed_value` WRITE;
/*!40000 ALTER TABLE `changed_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `changed_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `sur_name` varchar(50) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `patronymic_name` varchar(50) DEFAULT NULL,
  `contract_number` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_client_1` (`status_id`),
  CONSTRAINT `fk_client_1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model_id` int(11) unsigned NOT NULL,
  `config_path` varchar(200) NOT NULL,
  `config_name` varchar(150) NOT NULL,
  `file_size` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modelID` (`model_id`),
  CONSTRAINT `config_fk1` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config`
--

LOCK TABLES `config` WRITE;
/*!40000 ALTER TABLE `config` DISABLE KEYS */;
/*!40000 ALTER TABLE `config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `connection_type`
--

DROP TABLE IF EXISTS `connection_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `connection_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `connection_type`
--

LOCK TABLES `connection_type` WRITE;
/*!40000 ALTER TABLE `connection_type` DISABLE KEYS */;
INSERT INTO `connection_type` VALUES (1,'PPPoE'),(2,'Static'),(3,'DHCP'),(4,'PPTP'),(5,'L2TP'),(6,'Wi-Fi'),(7,'PPPoE_v6'),(8,'Static_v6'),(9,'DHCP_v6');
/*!40000 ALTER TABLE `connection_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_params`
--

DROP TABLE IF EXISTS `custom_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `memory_total` varchar(45) DEFAULT NULL,
  `memory_free` varchar(45) DEFAULT NULL,
  `cpu_usage` varchar(45) DEFAULT NULL,
  `up_time` varchar(45) DEFAULT NULL,
  `duplex_mode` varchar(45) DEFAULT NULL,
  `max_bit_rate` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_params_fk1` (`device_id`),
  CONSTRAINT `custom_params_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_params`
--

LOCK TABLES `custom_params` WRITE;
/*!40000 ALTER TABLE `custom_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `def_params`
--

DROP TABLE IF EXISTS `def_params`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `def_params` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `value` varchar(45) DEFAULT NULL,
  `web_task` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `def_params`
--

LOCK TABLES `def_params` WRITE;
/*!40000 ALTER TABLE `def_params` DISABLE KEYS */;
/*!40000 ALTER TABLE `def_params` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `default_descriptor`
--

DROP TABLE IF EXISTS `default_descriptor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `default_descriptor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_type_id` int(10) unsigned NOT NULL,
  `path` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `device_type_id_UNIQUE` (`device_type_id`),
  KEY `default_descriptor_fk1` (`device_type_id`),
  CONSTRAINT `default_descriptor_fk1` FOREIGN KEY (`device_type_id`) REFERENCES `device_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `default_descriptor`
--

LOCK TABLES `default_descriptor` WRITE;
/*!40000 ALTER TABLE `default_descriptor` DISABLE KEYS */;
INSERT INTO `default_descriptor` VALUES (1,1,'/var/ACS/description/def.ini');
/*!40000 ALTER TABLE `default_descriptor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `descriptor`
--

DROP TABLE IF EXISTS `descriptor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `descriptor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `path` varchar(200) NOT NULL,
  `model_id` int(10) unsigned DEFAULT NULL,
  `firmware` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `device_descriptor_fk1` (`model_id`),
  CONSTRAINT `device_descriptor_fk1` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `descriptor`
--

LOCK TABLES `descriptor` WRITE;
/*!40000 ALTER TABLE `descriptor` DISABLE KEYS */;
/*!40000 ALTER TABLE `descriptor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_ports`
--

DROP TABLE IF EXISTS `device_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_ports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `port_name` varchar(45) NOT NULL,
  `port_index` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `device_ports_fk1` (`device_id`),
  CONSTRAINT `device_ports_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_ports`
--

LOCK TABLES `device_ports` WRITE;
/*!40000 ALTER TABLE `device_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `device_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `device_type`
--

DROP TABLE IF EXISTS `device_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `device_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `device_type`
--

LOCK TABLES `device_type` WRITE;
/*!40000 ALTER TABLE `device_type` DISABLE KEYS */;
INSERT INTO `device_type` VALUES (1,'router');
/*!40000 ALTER TABLE `device_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `serial_number` varchar(45) NOT NULL,
  `manufacture` varchar(45) DEFAULT NULL,
  `model_id` int(11) unsigned DEFAULT NULL,
  `oui` varchar(45) DEFAULT NULL,
  `ip` varchar(45) NOT NULL,
  `port` int(11) DEFAULT NULL,
  `dev_username` varchar(45) DEFAULT NULL,
  `dev_password` varchar(45) DEFAULT NULL,
  `client_id` int(11) unsigned DEFAULT NULL,
  `profile_id` int(11) unsigned DEFAULT NULL,
  `last_inform_time` datetime NOT NULL,
  `dump` int(11) DEFAULT '0',
  `group_id` int(10) unsigned DEFAULT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `firmware` varchar(45) NOT NULL,
  `template_id` int(10) unsigned DEFAULT NULL,
  `default_gateway` varchar(45) DEFAULT NULL,
  `conn_index` int(11) NOT NULL DEFAULT '1',
  `igmp` varchar(50) DEFAULT NULL,
  `mac` varchar(45) DEFAULT NULL,
  `req_path` varchar(50) DEFAULT NULL,
  `last_status` int(11) DEFAULT '0',
  `stun_status` int(11) DEFAULT '0',
  `udp_port` int(11) DEFAULT '0',
  `udp_ip` varchar(45) DEFAULT NULL,
  `conn_type` varchar(40) DEFAULT NULL,
  `up_time` int(11) NOT NULL DEFAULT '0',
  `tr_version` varchar(80) DEFAULT NULL,
  `conn_index_lte` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `serialNumber_UNIQUE` (`serial_number`),
  KEY `modelID` (`model_id`),
  KEY `devices_fk2` (`client_id`),
  KEY `devices_fk3` (`profile_id`),
  KEY `devices_fk4` (`group_id`),
  KEY `devices_fk5` (`status_id`),
  KEY `devices_fk6` (`template_id`),
  CONSTRAINT `devices_fk1` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_fk2` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_fk3` FOREIGN KEY (`profile_id`) REFERENCES `profiles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_fk4` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_fk5` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `devices_fk6` FOREIGN KEY (`template_id`) REFERENCES `template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diagnostics_domain`
--

DROP TABLE IF EXISTS `diagnostics_domain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diagnostics_domain` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diagnostics_domain`
--

LOCK TABLES `diagnostics_domain` WRITE;
/*!40000 ALTER TABLE `diagnostics_domain` DISABLE KEYS */;
/*!40000 ALTER TABLE `diagnostics_domain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `download_diagnostics`
--

DROP TABLE IF EXISTS `download_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `download_diagnostics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) DEFAULT NULL,
  `rom_time` varchar(45) DEFAULT NULL,
  `bom_time` varchar(45) DEFAULT NULL,
  `eom_time` varchar(45) DEFAULT NULL,
  `test_bytes_received` varchar(40) NOT NULL,
  `total_bytes_received` varchar(40) NOT NULL,
  `tcp_open_request_time` varchar(45) DEFAULT NULL,
  `tcp_open_response_time` varchar(45) DEFAULT NULL,
  `num_index` int(10) unsigned NOT NULL,
  `type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `download_diagnostics`
--

LOCK TABLES `download_diagnostics` WRITE;
/*!40000 ALTER TABLE `download_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `download_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `error_type`
--

DROP TABLE IF EXISTS `error_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `error_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `error_type`
--

LOCK TABLES `error_type` WRITE;
/*!40000 ALTER TABLE `error_type` DISABLE KEYS */;
INSERT INTO `error_type` VALUES (1,'template not found'),(2,'descriptor not found'),(3,'template type not found');
/*!40000 ALTER TABLE `error_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errors`
--

DROP TABLE IF EXISTS `errors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errors` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `error_type_id` int(11) unsigned NOT NULL,
  `create_date` datetime NOT NULL,
  `device_id` int(11) unsigned NOT NULL,
  `details` text,
  PRIMARY KEY (`id`),
  KEY `errors_fk1` (`error_type_id`),
  KEY `errors_fk2` (`device_id`),
  CONSTRAINT `errors_fk1` FOREIGN KEY (`error_type_id`) REFERENCES `error_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `errors_fk2` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errors`
--

LOCK TABLES `errors` WRITE;
/*!40000 ALTER TABLE `errors` DISABLE KEYS */;
/*!40000 ALTER TABLE `errors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `firmware`
--

DROP TABLE IF EXISTS `firmware`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firmware` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `model_id` int(11) unsigned NOT NULL,
  `firmware_path` varchar(200) NOT NULL,
  `file_size` varchar(10) NOT NULL,
  `version` varchar(40) NOT NULL,
  `firmware_name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `modelID` (`model_id`),
  CONSTRAINT `firmware_fk1` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `firmware`
--

LOCK TABLES `firmware` WRITE;
/*!40000 ALTER TABLE `firmware` DISABLE KEYS */;
/*!40000 ALTER TABLE `firmware` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group`
--

DROP TABLE IF EXISTS `group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group`
--

LOCK TABLES `group` WRITE;
/*!40000 ALTER TABLE `group` DISABLE KEYS */;
/*!40000 ALTER TABLE `group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hosts`
--

DROP TABLE IF EXISTS `hosts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hosts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `interface_type` varchar(256) DEFAULT NULL,
  `host_name` varchar(256) DEFAULT NULL,
  `mac_address` varchar(256) DEFAULT NULL,
  `address_source` varchar(256) DEFAULT NULL,
  `ip` varchar(256) DEFAULT NULL,
  `type` varchar(256) DEFAULT NULL,
  `num_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hosts_fk1` (`device_id`),
  CONSTRAINT `hosts_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hosts`
--

LOCK TABLES `hosts` WRITE;
/*!40000 ALTER TABLE `hosts` DISABLE KEYS */;
/*!40000 ALTER TABLE `hosts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ip_ping_diagnostics`
--

DROP TABLE IF EXISTS `ip_ping_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ip_ping_diagnostics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sent` int(11) DEFAULT NULL,
  `received` int(11) DEFAULT NULL,
  `lost` varchar(45) DEFAULT NULL,
  `minimum` varchar(45) DEFAULT NULL,
  `maximum` varchar(45) DEFAULT NULL,
  `average` varchar(45) DEFAULT NULL,
  `device_id` int(10) unsigned NOT NULL,
  `type` int(11) DEFAULT NULL,
  `num_index` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `diagnostic_fk1` (`device_id`),
  CONSTRAINT `diagnostic_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ip_ping_diagnostics`
--

LOCK TABLES `ip_ping_diagnostics` WRITE;
/*!40000 ALTER TABLE `ip_ping_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `ip_ping_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ipoe`
--

DROP TABLE IF EXISTS `ipoe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ipoe` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `max_mtu_size` int(11) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `external_ip_address` varchar(50) DEFAULT NULL,
  `subnet_mask` varchar(50) DEFAULT NULL,
  `default_gateway` varchar(50) DEFAULT NULL,
  `dns_servers` varchar(50) DEFAULT NULL,
  `dns_enabled` int(11) DEFAULT NULL,
  `nat_enabled` int(11) DEFAULT NULL,
  `device_id` int(10) unsigned NOT NULL,
  `num_index` int(10) unsigned NOT NULL,
  `byte_received` varchar(40) NOT NULL,
  `byte_sent` varchar(40) NOT NULL,
  `enable` int(11) DEFAULT NULL,
  `value_change` int(11) DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `igmp_multicast` int(11) DEFAULT NULL,
  `default_connection` int(10) unsigned DEFAULT '0',
  `connection_type_id` int(11) unsigned NOT NULL,
  `tr_default_connection` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT NULL,
  `ping_enabled` int(11) DEFAULT NULL,
  `slaac` int(10) DEFAULT NULL,
  `ethernet_errors_received` varchar(40) DEFAULT NULL,
  `ethernet_errors` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ipoe_1` (`device_id`),
  KEY `fk_ipoe_2` (`connection_type_id`),
  CONSTRAINT `fk_ipoe_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ipoe_2` FOREIGN KEY (`connection_type_id`) REFERENCES `connection_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ipoe`
--

LOCK TABLES `ipoe` WRITE;
/*!40000 ALTER TABLE `ipoe` DISABLE KEYS */;
/*!40000 ALTER TABLE `ipoe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lan`
--

DROP TABLE IF EXISTS `lan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `dhcp_server_configurable` int(11) DEFAULT NULL,
  `dhcp_server_enable` int(11) DEFAULT NULL,
  `dhcp_relay` int(11) DEFAULT NULL,
  `min_address` varchar(45) DEFAULT NULL,
  `max_address` varchar(45) DEFAULT NULL,
  `reserved_addresses` varchar(45) DEFAULT NULL,
  `subnet_mask` varchar(45) DEFAULT NULL,
  `dns_servers` varchar(45) DEFAULT NULL,
  `domain_name` varchar(45) DEFAULT NULL,
  `ip_routers` varchar(45) DEFAULT NULL,
  `dhcp_lease_time` int(11) DEFAULT NULL,
  `enable` int(11) DEFAULT NULL,
  `mac_address` varchar(45) DEFAULT NULL,
  `mac_address_control_enabled` int(11) DEFAULT NULL,
  `max_bit_rate` int(11) DEFAULT NULL,
  `duplex_mode` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `ext_dhcp_server_ip` varchar(45) DEFAULT NULL,
  `value_change` int(11) DEFAULT '0',
  `numberOfEntries` int(11) NOT NULL DEFAULT '0',
  `remote_access_enable` int(11) DEFAULT '0',
  `remote_access_port` int(11) DEFAULT '0',
  `errors_received` varchar(40) DEFAULT NULL,
  `errors_sent` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lan_fk1` (`device_id`),
  CONSTRAINT `lan_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lan`
--

LOCK TABLES `lan` WRITE;
/*!40000 ALTER TABLE `lan` DISABLE KEYS */;
/*!40000 ALTER TABLE `lan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lan_ipv6`
--

DROP TABLE IF EXISTS `lan_ipv6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lan_ipv6` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `ip_v6` varchar(45) DEFAULT NULL,
  `dhcp_mode` varchar(45) DEFAULT NULL,
  `dhcp_lease_time` int(11) DEFAULT NULL,
  `min_address` varchar(45) DEFAULT NULL,
  `max_address` varchar(45) DEFAULT NULL,
  `dhcp_enable` int(11) DEFAULT NULL,
  `dhcp_enable_pd` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_lan_ipv6_1_idx` (`device_id`),
  CONSTRAINT `fk_lan_ipv6_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lan_ipv6`
--

LOCK TABLES `lan_ipv6` WRITE;
/*!40000 ALTER TABLE `lan_ipv6` DISABLE KEYS */;
/*!40000 ALTER TABLE `lan_ipv6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_password`
--

DROP TABLE IF EXISTS `login_password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_password` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` varchar(50) NOT NULL,
  `connection_type_id` int(11) unsigned NOT NULL,
  `connection_name` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `log_pass_fk1` (`connection_type_id`),
  CONSTRAINT `log_pass_fk1` FOREIGN KEY (`connection_type_id`) REFERENCES `connection_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_password`
--

LOCK TABLES `login_password` WRITE;
/*!40000 ALTER TABLE `login_password` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_password` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lte`
--

DROP TABLE IF EXISTS `lte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lte` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `imei` varchar(45) DEFAULT NULL,
  `signal_level` int(11) DEFAULT NULL,
  `modes` varchar(45) DEFAULT NULL,
  `rsrp` int(11) DEFAULT NULL,
  `rsrq` int(11) DEFAULT NULL,
  `tac` int(11) DEFAULT NULL,
  `range_of` varchar(45) DEFAULT NULL,
  `rscp` int(11) DEFAULT NULL,
  `ecio` int(11) DEFAULT NULL,
  `cinr` int(11) DEFAULT NULL,
  `identity_cell` int(11) DEFAULT NULL,
  `auto_connect` int(11) DEFAULT NULL,
  `cell_index` int(11) DEFAULT NULL,
  `lac` int(11) DEFAULT '0',
  `mnc` int(11) DEFAULT '0',
  `mcc` int(11) DEFAULT '0',
  `imsi` varchar(150) DEFAULT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `enable` int(11) DEFAULT '0',
  `rssi` int(11) DEFAULT '0',
  `dev_index` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lte_fk1` (`device_id`),
  CONSTRAINT `lte_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lte`
--

LOCK TABLES `lte` WRITE;
/*!40000 ALTER TABLE `lte` DISABLE KEYS */;
/*!40000 ALTER TABLE `lte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `hw_version` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_type`
--

DROP TABLE IF EXISTS `operation_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `operation_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_type`
--

LOCK TABLES `operation_type` WRITE;
/*!40000 ALTER TABLE `operation_type` DISABLE KEYS */;
INSERT INTO `operation_type` VALUES (1,'firmware'),(2,'config'),(3,'set'),(4,'getAllParams'),(5,'logUp'),(6,'configUp'),(7,'reset'),(8,'reboot'),(9,'refresh'),(10,'addConnection'),(11,'deleteConnection'),(12,'ipPingDiagnostics'),(13,'restoreConfig'),(14,'valueChange'),(15,'autoRefresh'),(16,'createBridge'),(17,'createPort'),(18,'selectInterface'),(19,'untaggedBridge'),(20,'taggedNat'),(21,'traceRouteDiagnostics'),(22,'defConnection'),(23,'deleteVlan'),(24,'addVlanPort'),(25,'deleteVlanPort'),(26,'uploadDiagnostics'),(27,'downloadDiagnostics'),(28,'schedulerTask'),(29,'taggedNatParam'),(30,'addFilter'),(31,'addMark'),(32,'customlogUp'),(33,'getSelectedParams');
/*!40000 ALTER TABLE `operation_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `port_forward`
--

DROP TABLE IF EXISTS `port_forward`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `port_forward` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `num_index` int(10) unsigned NOT NULL,
  `type` varchar(256) DEFAULT NULL,
  `port_mapping_description` varchar(256) DEFAULT NULL,
  `internal_client` varchar(256) DEFAULT NULL,
  `port_mapping_protocol` varchar(256) DEFAULT NULL,
  `internal_port` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `port_forward_fk1` (`device_id`),
  CONSTRAINT `port_forward_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `port_forward`
--

LOCK TABLES `port_forward` WRITE;
/*!40000 ALTER TABLE `port_forward` DISABLE KEYS */;
/*!40000 ALTER TABLE `port_forward` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ppp`
--

DROP TABLE IF EXISTS `ppp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ppp` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `max_mtu_size` int(11) DEFAULT NULL,
  `mac_address` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `ppp_authentication_protocol` varchar(50) DEFAULT NULL,
  `max_mru_size` int(11) DEFAULT NULL,
  `ppplcp_echo` int(11) DEFAULT NULL,
  `ppplcp_echo_retry` int(11) DEFAULT NULL,
  `nat_enabled` int(11) DEFAULT NULL,
  `device_id` int(10) unsigned NOT NULL,
  `num_index` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  `service_name` varchar(50) DEFAULT NULL,
  `byte_received` varchar(40) NOT NULL,
  `byte_sent` varchar(40) NOT NULL,
  `enable` int(11) DEFAULT NULL,
  `default_gateway` varchar(50) DEFAULT NULL,
  `external_ip_address` varchar(50) DEFAULT NULL,
  `dns_servers` varchar(50) DEFAULT NULL,
  `value_change` int(11) DEFAULT '0',
  `ping_enabled` int(11) DEFAULT NULL,
  `default_connection` int(10) unsigned DEFAULT '0',
  `connection_type_id` int(11) unsigned NOT NULL,
  `tr_default_connection` int(11) DEFAULT '0',
  `vlan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ppp_1` (`device_id`),
  KEY `fk_ppp_2` (`connection_type_id`),
  CONSTRAINT `fk_ppp_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_ppp_2` FOREIGN KEY (`connection_type_id`) REFERENCES `connection_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ppp`
--

LOCK TABLES `ppp` WRITE;
/*!40000 ALTER TABLE `ppp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ppp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profiles`
--

DROP TABLE IF EXISTS `profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `firmware_id` int(11) unsigned DEFAULT NULL,
  `config_id` int(11) unsigned DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `profiles_fk1` (`firmware_id`),
  KEY `profiles_fk2` (`config_id`),
  CONSTRAINT `profiles_fk1` FOREIGN KEY (`firmware_id`) REFERENCES `firmware` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `profiles_fk2` FOREIGN KEY (`config_id`) REFERENCES `config` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profiles`
--

LOCK TABLES `profiles` WRITE;
/*!40000 ALTER TABLE `profiles` DISABLE KEYS */;
/*!40000 ALTER TABLE `profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_hops`
--

DROP TABLE IF EXISTS `route_hops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route_hops` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hop_host` varchar(256) DEFAULT NULL,
  `hop_host_address` varchar(256) DEFAULT NULL,
  `hop_error_code` int(11) DEFAULT NULL,
  `hop_rt_times` varchar(256) DEFAULT NULL,
  `trace_route_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `route_hops_fk1` (`trace_route_id`),
  CONSTRAINT `route_hops_fk1` FOREIGN KEY (`trace_route_id`) REFERENCES `trace_route_diagnostics` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_hops`
--

LOCK TABLES `route_hops` WRITE;
/*!40000 ALTER TABLE `route_hops` DISABLE KEYS */;
/*!40000 ALTER TABLE `route_hops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `route_table`
--

DROP TABLE IF EXISTS `route_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `route_table` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `conn_index` int(10) NOT NULL,
  `fw_metric` int(11) DEFAULT '0',
  `interface` varchar(45) DEFAULT NULL,
  `gateway` varchar(45) DEFAULT NULL,
  `address_dest` varchar(45) DEFAULT NULL,
  `mask_dest` varchar(45) DEFAULT NULL,
  `address_source` varchar(45) DEFAULT NULL,
  `mask_source` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `enable` int(10) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `static_route` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_route_table_1_idx` (`device_id`),
  CONSTRAINT `fk_route_table_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `route_table`
--

LOCK TABLES `route_table` WRITE;
/*!40000 ALTER TABLE `route_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `route_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_type`
--

DROP TABLE IF EXISTS `service_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_type` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_type`
--

LOCK TABLES `service_type` WRITE;
/*!40000 ALTER TABLE `service_type` DISABLE KEYS */;
INSERT INTO `service_type` VALUES (1,'P','PPPoE'),(2,'E','IPoE'),(3,'V','VoIP');
/*!40000 ALTER TABLE `service_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `set`
--

DROP TABLE IF EXISTS `set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `set` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `xml` varchar(20000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `set`
--

LOCK TABLES `set` WRITE;
/*!40000 ALTER TABLE `set` DISABLE KEYS */;
/*!40000 ALTER TABLE `set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `settings_name` varchar(50) NOT NULL,
  `settings_value` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'db_version','1.0.1'),(2,'web_port','8080'),(3,'web_ip','192.168.249.121'),(5,'client_insert','default');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'active'),(2,'deleted');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switch`
--

DROP TABLE IF EXISTS `switch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `switch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` varchar(45) NOT NULL,
  `name` varchar(100) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `port_count` int(11) NOT NULL,
  `uptime` varchar(100) NOT NULL,
  `temp_status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switch`
--

LOCK TABLES `switch` WRITE;
/*!40000 ALTER TABLE `switch` DISABLE KEYS */;
/*!40000 ALTER TABLE `switch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switch_condev`
--

DROP TABLE IF EXISTS `switch_condev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `switch_condev` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mac` varchar(45) NOT NULL,
  `switch_interface_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `switch_condev_fk1` (`switch_interface_id`),
  CONSTRAINT `switch_condev_fk1` FOREIGN KEY (`switch_interface_id`) REFERENCES `switch_interface` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switch_condev`
--

LOCK TABLES `switch_condev` WRITE;
/*!40000 ALTER TABLE `switch_condev` DISABLE KEYS */;
/*!40000 ALTER TABLE `switch_condev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `switch_interface`
--

DROP TABLE IF EXISTS `switch_interface`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `switch_interface` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `switch_id` int(10) unsigned NOT NULL,
  `interface` int(10) NOT NULL,
  `status` int(11) NOT NULL,
  `outoctets` bigint(11) NOT NULL,
  `inoctets` bigint(11) NOT NULL,
  `outbroadcast` bigint(11) NOT NULL,
  `inbroadcast` bigint(11) NOT NULL,
  `outmulticast` bigint(11) NOT NULL,
  `inmulticast` bigint(11) NOT NULL,
  `outunicast` bigint(11) NOT NULL,
  `inunicast` bigint(11) NOT NULL,
  `outerror` bigint(11) NOT NULL,
  `inerror` bigint(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `switch_interface_fk1` (`switch_id`),
  CONSTRAINT `switch_interface_fk1` FOREIGN KEY (`switch_id`) REFERENCES `switch` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `switch_interface`
--

LOCK TABLES `switch_interface` WRITE;
/*!40000 ALTER TABLE `switch_interface` DISABLE KEYS */;
/*!40000 ALTER TABLE `switch_interface` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task_scheduler`
--

DROP TABLE IF EXISTS `task_scheduler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_scheduler` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_name` varchar(256) DEFAULT NULL,
  `date_time` datetime NOT NULL,
  `operation_type_id` int(11) unsigned NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL,
  `device_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `schedule_fk1` (`operation_type_id`),
  CONSTRAINT `schedule_fk1` FOREIGN KEY (`operation_type_id`) REFERENCES `operation_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task_scheduler`
--

LOCK TABLES `task_scheduler` WRITE;
/*!40000 ALTER TABLE `task_scheduler` DISABLE KEYS */;
/*!40000 ALTER TABLE `task_scheduler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `path` varchar(200) NOT NULL,
  `name` varchar(45) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template_mapping`
--

DROP TABLE IF EXISTS `template_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `template_mapping` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `service_type_id` int(11) unsigned NOT NULL,
  `model_id` int(11) unsigned NOT NULL,
  `template_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `temp_map_fk1` (`model_id`),
  KEY `temp_map_fk2` (`service_type_id`),
  KEY `temp_map_fk3` (`template_id`),
  CONSTRAINT `temp_map_fk1` FOREIGN KEY (`model_id`) REFERENCES `model` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `temp_map_fk2` FOREIGN KEY (`service_type_id`) REFERENCES `service_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `temp_map_fk3` FOREIGN KEY (`template_id`) REFERENCES `template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template_mapping`
--

LOCK TABLES `template_mapping` WRITE;
/*!40000 ALTER TABLE `template_mapping` DISABLE KEYS */;
/*!40000 ALTER TABLE `template_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trace_route_diagnostics`
--

DROP TABLE IF EXISTS `trace_route_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trace_route_diagnostics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `response_time` int(11) DEFAULT NULL,
  `route_hops_number_of_entries` int(11) DEFAULT NULL,
  `device_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `trace_route_diagnostics_fk1` (`device_id`),
  CONSTRAINT `trace_route_diagnostics_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trace_route_diagnostics`
--

LOCK TABLES `trace_route_diagnostics` WRITE;
/*!40000 ALTER TABLE `trace_route_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `trace_route_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unregister_devices`
--

DROP TABLE IF EXISTS `unregister_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unregister_devices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `serial_number` varchar(45) DEFAULT NULL,
  `mac` varchar(45) DEFAULT NULL,
  `hw_version` varchar(50) DEFAULT NULL,
  `profile_id` int(10) unsigned DEFAULT NULL,
  `client_id` int(10) unsigned DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `last_inform_time` datetime DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `template_id` int(10) unsigned DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `req_path` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mac_UNIQUE` (`mac`),
  KEY `unregisterdevices_fk1` (`hw_version`),
  KEY `unregisterdevices_fk2` (`profile_id`),
  KEY `unregisterdevices_fk3` (`client_id`),
  KEY `unregister_devices_fk4` (`group_id`),
  KEY `unregister_devices_fk5` (`template_id`),
  CONSTRAINT `unregister_devices_fk4` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `unregister_devices_fk5` FOREIGN KEY (`template_id`) REFERENCES `template` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `unregisterdevices_fk2` FOREIGN KEY (`profile_id`) REFERENCES `profiles` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `unregisterdevices_fk3` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unregister_devices`
--

LOCK TABLES `unregister_devices` WRITE;
/*!40000 ALTER TABLE `unregister_devices` DISABLE KEYS */;
/*!40000 ALTER TABLE `unregister_devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `upload_diagnostics`
--

DROP TABLE IF EXISTS `upload_diagnostics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `upload_diagnostics` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) DEFAULT NULL,
  `rom_time` varchar(45) DEFAULT NULL,
  `bom_time` varchar(45) DEFAULT NULL,
  `eom_time` varchar(45) DEFAULT NULL,
  `test_file_length` int(11) DEFAULT NULL,
  `total_bytes_sent` int(11) DEFAULT NULL,
  `tcp_open_request_time` varchar(45) DEFAULT NULL,
  `tcp_open_response_time` varchar(45) DEFAULT NULL,
  `num_index` int(10) unsigned NOT NULL,
  `type` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `upload_diagnostics`
--

LOCK TABLES `upload_diagnostics` WRITE;
/*!40000 ALTER TABLE `upload_diagnostics` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload_diagnostics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `status_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username_UNIQUE` (`username`),
  KEY `user_fk1` (`status_id`),
  KEY `user_fk2` (`group_id`),
  CONSTRAINT `user_fk1` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_fk2` FOREIGN KEY (`group_id`) REFERENCES `user_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','21232F297A57a5a743894A0E4a801Fc3',NULL,1,1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group`
--

DROP TABLE IF EXISTS `user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `default_language` varchar(80) DEFAULT NULL,
  `time_out` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group`
--

LOCK TABLES `user_group` WRITE;
/*!40000 ALTER TABLE `user_group` DISABLE KEYS */;
INSERT INTO `user_group` VALUES (1,'Administrator',NULL,NULL),(2,'Sell manager',NULL,NULL),(3,'Manager',NULL,NULL),(4,'Viewer',NULL,NULL),(5,'Group manager',NULL,NULL);
/*!40000 ALTER TABLE `user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_group_permission`
--

DROP TABLE IF EXISTS `user_group_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_group_permission` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type_id` int(11) unsigned NOT NULL,
  `user_group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_permission_fk1` (`user_type_id`),
  KEY `user_permission_fk2` (`user_group_id`),
  KEY `user_group_permission_fk1` (`user_type_id`),
  CONSTRAINT `user_group_permission_fk1` FOREIGN KEY (`user_type_id`) REFERENCES `user_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_permission_fk2` FOREIGN KEY (`user_group_id`) REFERENCES `user_group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_group_permission`
--

LOCK TABLES `user_group_permission` WRITE;
/*!40000 ALTER TABLE `user_group_permission` DISABLE KEYS */;
INSERT INTO `user_group_permission` VALUES (1,1,1),(2,2,1),(3,3,1),(4,4,1),(5,5,1),(6,3,2),(7,4,2),(8,5,4),(9,4,3),(10,2,3),(11,4,5),(12,2,5);
/*!40000 ALTER TABLE `user_group_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_groups`
--

DROP TABLE IF EXISTS `user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_groups_fk1` (`user_id`),
  KEY `user_groups_fk2` (`group_id`),
  CONSTRAINT `user_groups_fk1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_groups_fk2` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_groups`
--

LOCK TABLES `user_groups` WRITE;
/*!40000 ALTER TABLE `user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_type`
--

DROP TABLE IF EXISTS `user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_type` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_type`
--

LOCK TABLES `user_type` WRITE;
/*!40000 ALTER TABLE `user_type` DISABLE KEYS */;
INSERT INTO `user_type` VALUES (1,'user_administration',NULL),(2,'device_administration',NULL),(3,'client_administration',NULL),(4,'group_administration',NULL),(5,'monitoring',NULL);
/*!40000 ALTER TABLE `user_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan`
--

DROP TABLE IF EXISTS `vlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vlan_name` varchar(45) NOT NULL,
  `vlan_id` int(11) NOT NULL,
  `bridge_status` varchar(45) NOT NULL,
  `bridge_index` int(11) NOT NULL,
  `device_id` int(11) unsigned NOT NULL,
  `vlan_type` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_vlan_1` (`device_id`),
  CONSTRAINT `fk_vlan_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan`
--

LOCK TABLES `vlan` WRITE;
/*!40000 ALTER TABLE `vlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vlan_ports`
--

DROP TABLE IF EXISTS `vlan_ports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vlan_ports` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vlan_port_name` varchar(45) NOT NULL,
  `vlan_port_number` int(11) NOT NULL,
  `vlan_id` int(10) unsigned NOT NULL,
  `num_index` int(11) NOT NULL DEFAULT '0',
  `marking_id` int(11) NOT NULL DEFAULT '0',
  `filter_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_vlan_ports_1` (`vlan_id`),
  CONSTRAINT `fk_vlan_ports_1` FOREIGN KEY (`vlan_id`) REFERENCES `vlan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vlan_ports`
--

LOCK TABLES `vlan_ports` WRITE;
/*!40000 ALTER TABLE `vlan_ports` DISABLE KEYS */;
/*!40000 ALTER TABLE `vlan_ports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voip`
--

DROP TABLE IF EXISTS `voip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voip` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `enable` varchar(256) DEFAULT NULL,
  `proxy_server` varchar(256) DEFAULT NULL,
  `registrar_server` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `voip_fk1` (`device_id`),
  CONSTRAINT `voip_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voip`
--

LOCK TABLES `voip` WRITE;
/*!40000 ALTER TABLE `voip` DISABLE KEYS */;
/*!40000 ALTER TABLE `voip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voip_line`
--

DROP TABLE IF EXISTS `voip_line`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `voip_line` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `voip_id` int(10) unsigned NOT NULL,
  `enable` varchar(256) DEFAULT NULL,
  `username` varchar(256) DEFAULT NULL,
  `password` varchar(256) DEFAULT NULL,
  `uri` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `voip_line_fk1` (`voip_id`),
  CONSTRAINT `voip_line_fk1` FOREIGN KEY (`voip_id`) REFERENCES `voip` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voip_line`
--

LOCK TABLES `voip_line` WRITE;
/*!40000 ALTER TABLE `voip_line` DISABLE KEYS */;
/*!40000 ALTER TABLE `voip_line` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `web_task`
--

DROP TABLE IF EXISTS `web_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `web_task` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `operation_type_id` int(11) unsigned NOT NULL,
  `operation_status` int(10) unsigned NOT NULL,
  `device_id` int(11) unsigned NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `create_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `webTask_fk1` (`device_id`),
  KEY `webTask_fk2` (`operation_type_id`),
  KEY `webTask_fk3` (`operation_status`),
  KEY `web_task_fk1` (`device_id`),
  KEY `web_task_fk2` (`operation_type_id`),
  CONSTRAINT `web_task_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `web_task_fk2` FOREIGN KEY (`operation_type_id`) REFERENCES `operation_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `web_task`
--

LOCK TABLES `web_task` WRITE;
/*!40000 ALTER TABLE `web_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `web_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wlan`
--

DROP TABLE IF EXISTS `wlan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wlan` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `device_id` int(10) unsigned NOT NULL,
  `enable` int(11) DEFAULT '0',
  `bssid` varchar(45) DEFAULT NULL,
  `ssid` varchar(45) DEFAULT NULL,
  `channel` varchar(45) DEFAULT NULL,
  `standard` varchar(45) DEFAULT NULL,
  `beacon_type` varchar(45) DEFAULT NULL,
  `pre_shared_key` varchar(45) DEFAULT NULL,
  `total_psk_failures` int(11) DEFAULT NULL,
  `network_authentication` varchar(45) NOT NULL,
  `value_change` int(11) DEFAULT '0',
  `max_associated_clients` int(11) DEFAULT NULL,
  `AutoChannelEnable` int(11) DEFAULT '0',
  `wpaEncryptionModes` varchar(50) DEFAULT NULL,
  `numberOfEntries` int(11) NOT NULL DEFAULT '0',
  `num_index` int(11) DEFAULT NULL,
  `frequencyBand` varchar(50) DEFAULT NULL,
  `transmit_power` int(11) DEFAULT NULL,
  `transmit_power_supported` varchar(50) DEFAULT NULL,
  `possible_channels` varchar(80) DEFAULT NULL,
  `bssid_status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `wlan_fk1` (`device_id`),
  CONSTRAINT `wlan_fk1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wlan`
--

LOCK TABLES `wlan` WRITE;
/*!40000 ALTER TABLE `wlan` DISABLE KEYS */;
/*!40000 ALTER TABLE `wlan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wlan_standard`
--

DROP TABLE IF EXISTS `wlan_standard`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wlan_standard` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wlan_standard`
--

LOCK TABLES `wlan_standard` WRITE;
/*!40000 ALTER TABLE `wlan_standard` DISABLE KEYS */;
INSERT INTO `wlan_standard` VALUES (1,'802.11 B','2.4 GHz'),(2,'802.11 B/G mixed','2.4 GHz'),(3,'802.11 B/G/N mixed','2.4 GHz'),(4,'802.11 G','2.4 GHz'),(5,'802.11 G/N mixed','2.4 GHz'),(6,'802.11 A','5 GHz'),(7,'802.11 A/N mixed','5 GHz'),(8,'802.11 N','5 GHz'),(9,'802.11 AC','5 GHz'),(10,'802.11 AC/N mixed','5 GHz'),(11,'802.11 AC/A/N mixed','5 GHz');
/*!40000 ALTER TABLE `wlan_standard` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wlan_standard_supported`
--

DROP TABLE IF EXISTS `wlan_standard_supported`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wlan_standard_supported` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wlan_id` int(10) DEFAULT NULL,
  `standard_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wlan_standard_supported`
--

LOCK TABLES `wlan_standard_supported` WRITE;
/*!40000 ALTER TABLE `wlan_standard_supported` DISABLE KEYS */;
INSERT INTO `wlan_standard_supported` VALUES (16,2,1),(17,2,1),(18,2,2),(19,2,3),(20,2,4),(21,2,5);
/*!40000 ALTER TABLE `wlan_standard_supported` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ACSServer'
--
/*!50106 SET @save_time_zone= @@TIME_ZONE */ ;
/*!50106 DROP EVENT IF EXISTS `update_task` */;
DELIMITER ;;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;;
/*!50003 SET character_set_client  = utf8 */ ;;
/*!50003 SET character_set_results = utf8 */ ;;
/*!50003 SET collation_connection  = utf8_general_ci */ ;;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;;
/*!50003 SET @saved_time_zone      = @@time_zone */ ;;
/*!50003 SET time_zone             = 'SYSTEM' */ ;;
/*!50106 CREATE*/ /*!50117 DEFINER=`root`@`localhost`*/ /*!50106 EVENT `update_task` ON SCHEDULE EVERY 5 MINUTE STARTS '2018-07-26 15:15:12' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
	 UPDATE `web_task` set operation_status=4  WHERE create_date < DATE_SUB(NOW(),INTERVAL 5 MINUTE) AND operation_status=0 AND (operation_type_id =8 OR operation_type_id =4 OR operation_type_id = 9 OR operation_type_id = 12 OR operation_type_id =14 OR operation_type_id = 15 OR operation_type_id = 21 OR operation_type_id =26 OR operation_type_id =27 OR operation_type_id =33);
	 UPDATE `web_task` set operation_status=5  WHERE create_date < DATE_SUB(NOW(),INTERVAL 10 MINUTE) AND operation_status=1;
    END */ ;;
/*!50003 SET time_zone             = @saved_time_zone */ ;;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;;
/*!50003 SET character_set_client  = @saved_cs_client */ ;;
/*!50003 SET character_set_results = @saved_cs_results */ ;;
/*!50003 SET collation_connection  = @saved_col_connection */ ;;
DELIMITER ;
/*!50106 SET TIME_ZONE= @save_time_zone */ ;

--
-- Dumping routines for database 'ACSServer'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-26 15:16:39
