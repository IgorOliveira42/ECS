<?php
require_once "centra/main/Application.php";

use Centra\Main\Application;

$app = new Application(__DIR__);
$app->config();
$app->run();
