<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 18.10.18
 * Time: 14:30
 */

require_once "centra/main/Loader.php";
require_once "centra/main/helpers/functions.php";

\Centra\Main\Loader::collect(__DIR__);

Centra\Log4p\Main\Agent::rotate();