<?php

namespace Centra\Http\Main;

use Centra\Main\Interfaces\ExceptionInterface;
use Centra\Main\Traits\Configurable;

class Response
{
  use Configurable;

  const SUCCESS = 1;
  const FAILED = 0;
  const CONTENT_TYPE_JSON = 'Content-type: application/json; charset=UTF-8';
  const CONTENT_TYPE_TEXT = 'Content-type: text/plain; charset=UTF-8';
  const CONTENT_TYPE_XML = 'Content-type: application/xml; charset=UTF-8';
  const ACCESS_CONTROL_ALLOW_ORIGIN = 'Access-Control-Allow-Methods: GET, POST, PATCH, DELETE';
  const CODE_SUCCESS = 200;
  const CODE_UNAUTHORIZED = 401;
  const CODE_ERROR = 500;
  public $result = null;
  public $status = self::SUCCESS;
  public $code = self::CODE_SUCCESS;
  public $headers = [];

  public function write()
  {
    foreach ($this->getHeaders() as $header)
      \header($header);
    if($this->getStatus() == self::SUCCESS){
      $response = [
        'success' => self::SUCCESS,
        'data'    => $this->getResult(),
      ];
      echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
    if($this->getStatus() == self::FAILED){
      /** @var ExceptionInterface $exception */
      $exception = $this->getResult();
      $response = [
        'success' => self::FAILED,
        'message' => $exception->getMessage(),
      ];
      if ($exception instanceof ExceptionInterface)
        $response['errors'] = $exception->getErrors();
      echo json_encode($response, JSON_UNESCAPED_UNICODE);
    }
  }

  /**
   * @return mixed
   */
  public function getResult()
  {
    return $this->result;
  }

  /**
   * @param null $result
   * @return Response $this;
   */
  public function setResult($result)
  {
    $this->result = $result;
    return $this;
  }

  /**
   * @return int
   */
  public function getStatus()
  {
    return $this->status;
  }

  /**
   * @param int $status
   * @return Response $this;
   */
  public function setStatus($status)
  {
    $this->status = $status;
    return $this;
  }

  /**
   * @return array
   */
  public function getHeaders()
  {
    return $this->headers;
  }

  /**
   * @param array $headers
   * @return Response $this;
   */
  public function setHeaders($headers)
  {
    $this->headers = $headers;
    return $this;
  }

}