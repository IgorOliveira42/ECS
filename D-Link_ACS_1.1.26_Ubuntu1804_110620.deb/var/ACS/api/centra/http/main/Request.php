<?php

namespace Centra\Http\Main;

class Request
{
  public $params = [];
  public $queryParams = [];

  public function __construct()
  {
    $params = $_REQUEST;
    if(!empty($params)){
      $this->setParams($params);
    } else {
      $request = urldecode(file_get_contents("php://input"));
      if(empty($request))
        return [];
      foreach (explode("&", $request) as $item) {
        list($key, $value) = explode("=", $item);
        $params[$key] = $value;
      }
      $this->setParams($params);
    }
  }

  /**
   * Возвращяет значение параметра
   * @param $key - ключ в массиве
   * @return array|bool
   */
  public function get($key = null)
  {
    $params = $this->getParams();
    if(!is_null($key))
      return $params[$key];
    return $params;
  }

  public function getQuery($key = null)
  {
    $params = $this->getQueryParams();
    if(!is_null($key))
      return $params[$key];
    return $params;
  }

  public function getUserIp()
  {
    $ip = $_SERVER['REMOTE_ADDR'];
    return $ip;
  }

  public function getUri()
  {
    $query = preg_replace("/\/[A-z0-9_]+\.[A-z0-9]+$/", "", $_SERVER['REQUEST_URI']);
    return $query;
  }

  public static function getServer()
  {
    return $_SERVER;
  }

  /**
   * @return array
   */
  public function getParams()
  {
    return $this->params;
  }

  /**
   * @param array $params
   * @return $this
   */
  public function setParams($params)
  {
    $this->params = $params;
    return $this;
  }

  /**
   * @return array
   */
  public function getQueryParams()
  {
    return $this->queryParams;
  }

  /**
   * @param array $queryParams
   * @return $this
   */
  public function setQueryParams($queryParams)
  {
    $this->queryParams = $queryParams;
    return $this;
  }
  
}