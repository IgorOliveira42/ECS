<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

/**
 * Прокси функция для шаблона Singleton
 * @param $classname
 * @param mixed $params
 * @return mixed
 * @throws \Centra\Main\Exceptions\ClassException
 */
function store($classname, $params = null)
{
  if(is_null($params))
    return \Centra\Main\Store::init()->make($classname);
  else
    return \Centra\Main\Store::init()->make($classname, $params);
}

/**
 * Прокcи для методе запросов
 * @param string $key
 * @return mixed
 * @throws \Centra\Main\Exceptions\ClassException
 */
function request($key = null)
{
  /** @var \Centra\Http\Main\Request $request */
  $request = store(\Centra\Http\Main\Request::class);
  if(empty($key))
    return $request->get();
  return $request->get($key);
}

/**
 * Прокси для параметрок запроса
 * @param null $key
 * @return mixed
 * @throws \Centra\Main\Exceptions\ClassException
 */
function query($key = null)
{
  /** @var \Centra\Http\Main\Request $request */
  $request = store(\Centra\Http\Main\Request::class);
  if(empty($key))
    return $request->getQuery();
  return $request->getQuery($key);
}