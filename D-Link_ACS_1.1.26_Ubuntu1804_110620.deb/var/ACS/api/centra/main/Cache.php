<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 14.10.18
 * Time: 16:40
 */

namespace Centra\Main;

use Centra\Main\Exceptions\ProcessException;

class Cache
{
  const CONTAINER_EXTENSION = 'json';
  public $path = null;
  public $container = 'cache.json';
  public $config = [];
  public $expire = null;
  public $changed = false;

  public function __construct($params = null)
  {
    if(is_array($params))
      foreach ($params as $key => $value)
        $this->$key = $value;
  }

  /**
   * Сохраняет запрос
   * @throws ProcessException
   */
  public function __destruct()
  {
    $this->save();
  }

  /**
   * Получает новый нистанс
   * @param null $container
   * @return Cache
   */
  public static function getInstance($container = null)
  {
    $model = new self();
    if(!is_null($container))
      $model->setContainer($container);
    return $model;
  }

  /**
   * Получает значение из кеша
   * @param null $key
   * @return array|null
   * @throws ProcessException
   */
  public function get($key = null)
  {
    if(empty($this->getConfig()))
      $this->readConfig();
    if(empty($this->getConfig()))
      return null;
    $config = $this->getConfig();
    if(is_null($key))
      return $config['data'];
    if(!isset($config['data'][$key]))
      return null;
    return $config['data'][$key];
  }

  /**
   * Записывает несколько значений в кеш.
   * @param array $params
   */
  public function setArray(array $params)
  {
    $config = $this->getConfig();
    foreach ($params as $key => $value)
      $config['data'][$key] = $value;
    $config['expire'] = $this->getExpire();
  }

  /**
   * Записывает значение в кеш
   * @param $key
   * @param $value
   * @throws ProcessException
   */
  public function set($key, $value)
  {
    $this->setChanged(true);
    $config = $this->getConfig();
    $config['data'][$key] = $value;
    $config['expire'] = $this->getExpire();
    $this->setConfig($config);
  }

  /**
   * Сохраняет кеш в файл
   * @throws ProcessException
   */
  public function save()
  {
    $config = $this->getConfig();
    $fillPath = $this->getPath() . '/' . $this->getContainer();
    if($this->isChanged())
      if(!file_put_contents($fillPath, json_encode($config, JSON_UNESCAPED_UNICODE)))
        throw new ProcessException("Не удалось сохранить запись кеша");
  }

  /**
   * Удаляет запись из кеша
   * @param $key
   * @throws ProcessException
   */
  public function delete($key)
  {
    $this->setChanged(true);
    $config = $this->getConfig();
    unset($config['data'][$key]);
    $this->setConfig($config);
  }

  /**
   * Очищает кеш
   * @throws ProcessException
   */
  public function clear()
  {
    $this->setChanged(true);
    $this->setConfig([]);
    $this->save();
  }

  /**
   * Проверяет не устарели ли данные кеша
   * @throws ProcessException
   */
  private function checkExpire()
  {
    if(!is_null($this->getExpire()))
      if($this->getExpire()->getTimestamp() < (new \DateTime())->getTimestamp())
        $this->clear();
  }

  /**
   * Считывает содержимое кеша
   * @throws ProcessException
   */
  private function readConfig()
  {
    $fillPath = $this->getPath() . '/' . $this->getContainer();
    if(!file_exists($fillPath))
      return null;
    $data = json_decode(file_get_contents($fillPath), true);
    if($data['expire'] != null)
      $data['expire'] = new \DateTime($data['expire']);
    $this->setConfig($data);
    $this->checkExpire();
  }

  /**
   * @return null
   */
  public function getPath()
  {
    return $this->path;
  }

  /**
   * @param null $path
   * @return Cache $this;
   */
  public function setPath($path)
  {
    $this->path = $path;
    return $this;
  }

  /**
   * @return string
   */
  public function getContainer()
  {
    return $this->container;
  }

  /**
   * @param string $container
   * @return Cache $this;
   */
  public function setContainer($container)
  {
    $this->container = $container . '.' . self::CONTAINER_EXTENSION;
    return $this;
  }

  /**
   * @return array
   */
  public function getConfig()
  {
    if(!isset($this->config))
      return [];
    return $this->config;
  }

  /**
   * @param array $config
   * @return Cache $this;
   */
  public function setConfig($config)
  {
    $this->config = $config;
    return $this;
  }

  /**
   * @return \DateTime
   */
  public function getExpire()
  {
    return $this->expire;
  }

  /**
   * @param \DateTime $expire
   * @return Cache $this;
   */
  public function setExpire(\DateTime $expire)
  {
    $this->setChanged(true);
    $config = $this->getConfig();
    $config['expire'] = $expire->format("Y-m-d H:i:s");
    $this->setConfig($config);
    return $this;
  }

  /**
   * @return bool
   */
  public function isChanged()
  {
    return $this->changed;
  }

  /**
   * @param bool $changed
   * @return $this
   */
  public function setChanged($changed)
  {
    $this->changed = $changed;
    return $this;
  }

}