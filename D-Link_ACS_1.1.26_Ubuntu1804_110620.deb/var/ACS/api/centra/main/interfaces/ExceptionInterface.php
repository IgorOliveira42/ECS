<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 11:25
 */

namespace Centra\Main\Interfaces;

interface ExceptionInterface
{
  public function getErrors();
  public function setErrors(array $errors);
  public function getMessage();
}