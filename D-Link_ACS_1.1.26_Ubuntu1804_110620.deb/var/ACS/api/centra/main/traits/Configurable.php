<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 13.10.18
 * Time: 20:23
 */
namespace Centra\Main\Traits;

trait Configurable
{
  public function __construct($params = null)
  {
    if(is_array($params))
      foreach ($params as $key => $value)
        $this->$key = $value;
  }

}