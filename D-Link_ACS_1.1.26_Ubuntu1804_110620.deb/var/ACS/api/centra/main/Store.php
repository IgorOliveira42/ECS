<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.04.18
 * Time: 11:55
 */

namespace Centra\Main;

use \Centra\Main\Exceptions\ClassException;
use \Centra\Main\Utils\StringBuilder;

class Store
{
  public static $entry = null;
  public $models = [];

  public static function init()
  {
    if (is_null(self::$entry))
      self::$entry = new self();
    return self::$entry;
  }


  /**
   * Создать модель
   * @param $class
   * @param mixed $params
   * @return mixed
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function make($class, $params = null)
  {
    return !$this->has($class) ? $this->set($class, $params) : $this->models[$class];
  }

  /**
   * Получает текущую модель или ее реализацию
   * @param $class
   * @param bool $new
   * @param array|null $params
   * @return mixed
   */
  public function get($class, $new = false, array $params = [])
  {
    $item = $this->models[$class];
    if($new){
      $class = get_class($item);
      $item = new $class($params);
    }
    return $item;
  }

  /**
   * Сохраняте класс или параметры
   * @param $class
   * @param mixed $params
   * @return mixed
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function set($class, $params = null)
  {
    if(class_exists($class, true) || interface_exists($class, true) || trait_exists($class, true))
      $this->models[$class] =  new $class($params);
    if(empty($this->models[$class]))
      throw new ClassException('Не удалось создать модель ' . $class);
    return $this->models[$class];
  }

  public function save($alias, $params = [])
  {
    $this->models[$alias] = $params;
    return $this->models[$alias];
  }

  /**
   * Присваивает интерфейс модели
   * @param $interface
   * @param $class
   * @param array $params
   * @return mixed
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function bind($interface, $class, $params = [])
  {
    if(class_exists($class, true) && interface_exists($interface, true))
      $this->models[$interface] = new $class($params);
    $stringBuilder = (new StringBuilder())
      ->add('Не удалось присвоить интерфейс ')
      ->add($interface)
      ->add(' модели ')
      ->add($class);
    if(empty($this->models[$interface]))
      throw new ClassException($stringBuilder->get());
    return $this->models[$interface];
  }

  public function clear($class)
  {
    unset($this->models[$class]);
  }

  public function copy($class)
  {
    return clone $this->get($class);
  }

  public function has($class)
  {
    return isset($this->models[$class]);
  }
}