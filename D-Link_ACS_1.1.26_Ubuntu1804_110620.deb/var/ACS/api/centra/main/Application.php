<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 17.11.17
 * Time: 10:12
 */

namespace Centra\Main;

use Centra\Configs\RoutesConfig;
use Centra\Configs\DatabaseConfig;
use Centra\Configs\Log4pConfig;
use Centra\Configs\AcsWorkerConfig;
use Centra\Configs\ResponseConfig;
use Centra\Configs\ApplicationConfig;
use Centra\Api\Models\Router;
use Centra\Log4p\Main\Log;

class Application
{
  const LOG_CONTEXT = 'api';
  public $basePath = __DIR__ ;

  public function __construct($basePath)
  {
    $this->setBasePath($basePath);
    require_once "Loader.php";
    Loader::collect($this->getBasePath());
  }

  /**
   * Производит первоначальную настройку приложения
   */
  public function config()
  {
    try {
      require_once "helpers/functions.php";
      Log::getInstance(self::LOG_CONTEXT);
      \store(Log4pConfig::class);
      \store(RoutesConfig::class);
      \store(DatabaseConfig::class);
      \store(AcsWorkerConfig::class);
      \store(ResponseConfig::class);
      \store(ApplicationConfig::class);
    } catch (\Exception $e){
      echo $e->getMessage();
    }
  }

  public function run()
  {
    /** @var RoutesConfig $routers */
    $routers = \store(RoutesConfig::class);
    /** @var Router $router */
    $router = \store(Router::class, $routers);
    $router->make();
  }

  /**
   * @return string
   */
  public function getBasePath()
  {
    return $this->basePath;
  }

  /**
   * @param string $basePath
   * @return $this
   */
  public function setBasePath($basePath)
  {
    $this->basePath = $basePath;
    return $this;
  }

}