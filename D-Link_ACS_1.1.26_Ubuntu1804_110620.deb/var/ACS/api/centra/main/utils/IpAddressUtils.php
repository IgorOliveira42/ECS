<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 16.05.17
 * Time: 11:51
 * Вспомогательный обработчик массивов
 */

namespace Centra\Main\Utils;

use Centra\Http\Models\IpNetwork;

class IpAddressUtils
{
  public static function isIpInNetwork($ip, IpNetwork $net)
  {
    return $net->getIpLong() >= ip2long($ip) && $net->getLastIpAddress() <= ip2long($ip);
  }
}