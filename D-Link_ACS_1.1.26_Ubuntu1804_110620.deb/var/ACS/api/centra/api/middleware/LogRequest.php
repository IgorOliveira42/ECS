<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;

use Centra\Http\Main\Request;
use Centra\Api\Models\Router;
use Centra\Api\Models\RouterMiddleware;
use Centra\Main\Utils\StringBuilder;
use Centra\Log4p\Main\Log;

class LogRequest extends RouterMiddleware
{

  /**
   * Записывает в журнал базовый запрос
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $ip = (\store(Request::class))->getUserIp();
    /** @var StringBuilder $stringBuilder */
    $stringBuilder = \store(StringBuilder::class);
    /** @var Router $router */
    $router = \store(Router::class);
    $stringBuilder->clear()
      ->add("Запрос ")
      ->add($router->getMethod())
      ->add(" от ")
      ->add($ip)
      ->add(" к ")
      ->add($router->getRoute())
      ->add(" c параметрами: ")
      ->add(json_encode($router->getParams(), JSON_UNESCAPED_UNICODE));
    Log::info($stringBuilder->get());
  }

}