<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;

use Centra\Http\Main\Response;
use Centra\Api\Models\RouterMiddleware;
use Centra\Main\Traits\Configurable;
use Centra\Database\Utils\DatabaseUtils;
use Centra\Database\Main\ActiveRecord;

class FormatResponse extends RouterMiddleware
{

  /**
   * Записывает в журнал базовый запрос
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    /** @var Response $response */
    $response = \store(Response::class);
    if($response->getStatus() == Response::SUCCESS){
      $result = $response->getResult();
      if(is_array($result) && !empty($result[0])){
        $resultItem = $result[0];
        if(is_object($resultItem) && get_parent_class($resultItem) == ActiveRecord::class)
          $result = DatabaseUtils::modelToArray($result);
      }
      if(is_object($result) && get_parent_class($result) == ActiveRecord::class)
        $result = $result->getAttributes();
      if(is_object($result) && in_array(Configurable::class, class_uses($result)))
        $result = get_object_vars($result);
      $response->setResult($result);
    }
  }

}