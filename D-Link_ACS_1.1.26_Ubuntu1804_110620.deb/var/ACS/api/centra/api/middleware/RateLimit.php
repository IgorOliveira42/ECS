<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 22.05.18
 * Time: 11:13
 */

namespace Centra\Api\Middleware;

use Centra\Http\Main\Request;
use Centra\Api\Models\RouterMiddleware;
use Centra\Main\Cache;
use Centra\Main\Exceptions\ClassException;
use Centra\Main\Exceptions\ProcessException;
use Centra\Main\Exceptions\ValidException;

/**
 * Class CheckRateLimit
 * @package Centra\Portal\Api\Middleware
 */
class RateLimit extends RouterMiddleware
{
  const LIMIT_COUNT = 300;
  const LIMIT_PERIOD = 600;
  const COUNT_KEY = 'count';
  const EXPIRE_KEY = 'last_request_date';
  const CONTAINER_PATH = '/var/ACS/api/runtime/cache';

  /** Выполняет проверку
   * @throws ValidException
   * @throws ClassException
   * @throws ProcessException
   */
  public function run()
  {
    $ip = (\store(Request::class))->getUserIp();
    /** @var Cache $cache */
    $cache = \store(Cache::class);
    $cache->setContainer($ip);
    $cache->setPath(self::CONTAINER_PATH);
    $expireDate = new \DateTime($cache->get(self::EXPIRE_KEY));
    $expireStamp = $expireDate->getTimestamp() + self::LIMIT_PERIOD;
    $count = $cache->get("count");
    $now = new \DateTime();
    if($expireStamp < $now->getTimestamp()){
      $count = 0;
      $cache->set(self::EXPIRE_KEY, $now->format("Y-m-d H:i:s"));
    } else {
      $cache->set(self::EXPIRE_KEY, $expireDate->format("Y-m-d H:i:s"));
    }
    if($count > self::LIMIT_COUNT)
      throw new ValidException("Превышено число попыток запроса. Попробуйте обратиться позднее");
    $cache->set("count", ++$count);
    $cache->save();
  }



}