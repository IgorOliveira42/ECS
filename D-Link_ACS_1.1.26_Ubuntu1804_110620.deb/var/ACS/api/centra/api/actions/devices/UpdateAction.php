<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Devices;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;

class UpdateAction extends RouterAction
{
  /**
   * @return array|Devices
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Devices $item */
    $item = Devices::find()->byId(\query("id"));
    if(empty($item))
      throw new ValidException("Устройство по id:" . \query("id") . " не найден");
    $item->setScenario(Devices::SCENARIO_UPDATE)->load(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при обновлении устройства", $item->getErrors());
    $item->save();
    return $item;
  }
}