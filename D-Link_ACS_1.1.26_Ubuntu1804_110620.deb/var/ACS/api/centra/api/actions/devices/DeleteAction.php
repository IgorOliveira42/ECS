<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Devices;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;

class DeleteAction extends RouterAction
{
  /**
   * @return array|Devices
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Devices $client */
    $client = Devices::find()->byId(\query("id"));
    if(empty($client))
      throw new ValidException("Устройство по id:" . \query("id") . " не найден");
    $client->delete();
    return ['id' => \query("id")];
  }
}