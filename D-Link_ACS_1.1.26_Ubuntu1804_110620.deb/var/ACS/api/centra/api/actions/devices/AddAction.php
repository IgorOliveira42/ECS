<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Devices;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;

class AddAction extends RouterAction
{
  /**
   * @return array|Devices
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Devices $client */
    $item = new Devices();
    $item->setScenario(Devices::SCENARIO_CREATE)->load(\request());
    $item->check();
    if($client->hasError())
      throw new ValidException("Ошибка при создании устройства", $item->getErrors());
    $item->save();
    return $item;
  }
}