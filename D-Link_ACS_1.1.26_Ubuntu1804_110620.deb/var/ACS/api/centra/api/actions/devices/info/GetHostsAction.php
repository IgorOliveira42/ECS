<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices\Info;

use Centra\Acs\Main\DeviceParamsReader;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Configs\ApplicationConfig;

class GetHostsAction extends RouterAction
{
  const SECTION_PATTERN = '/InternetGatewayDevice.LANDevice.[0-9]+.Hosts.Host.([0-9]+)/';
  const IP_PATTERN = '/(IPAddress)$/';
  const MAC_PATTERN = '/(MACAddress)$/';
  const LEASE_TIME_PATTERN = '/(LeaseTimeRemaining)$/';
  const ACTIVE_PATTERN = '/(Active)$/';
  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ValidException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Devices $devices */
    $device = Devices::find()->byId($id);
    if(empty($device))
      throw new ValidException("Устройство по id:" . $id . ' не найдено');
    /** @var ApplicationConfig $config */
    $config = \store(ApplicationConfig::class);
    $serial = $device->getSerialNumber();
    $path = $config->getParamsPath() . $serial . "_value.xml";
    /** @var DeviceParamsReader $deviceParams */
    $deviceParams = \store(DeviceParamsReader::class, $path);
    $result = [
      'date' => $deviceParams->getDate(),
      'hosts' => [],
    ];
    foreach ($deviceParams->grep(self::SECTION_PATTERN) as $key => $value){
      preg_match(self::SECTION_PATTERN, $key, $match);
      $itemKey = '';
      if(preg_match(self::IP_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::MAC_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::LEASE_TIME_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::ACTIVE_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(!empty($itemKey) && !empty($match[1]))
        $result['hosts'][$match[1]][$itemKey] = $value;
    }
    $result['hosts'] = array_values($result['hosts']);
    return $result;
  }
}