<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;

class GetAllAction extends RouterAction
{
  /**
   * @return array
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    return Devices::find()->all();
  }
}