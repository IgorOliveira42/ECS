<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Devices\Info;

use Centra\Acs\Main\DeviceParamsReader;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Devices;
use Centra\Main\Exceptions\ValidException;
use Centra\Configs\ApplicationConfig;

class GetWifiAction extends RouterAction
{
  const SECTION_PATTERN = '/InternetGatewayDevice.LANDevice.1.WLANConfiguration.([0-9]+)/';
  const NAME_PATTERN = '/(Name)$/';
  const ENABLE_PATTERN = '/(Enable)$/';
  const STATUS_PATTERN = '/(Status)$/';
  const SSID_PATTERN = '/\.(SSID)$/';
  const STANDART_PATTERN = '/(Standard)$/';
  const AUTO_CHANNEL_PATTERN = '/(AutoChannelEnable)$/';
  const CHANNEL_PATTERN = '/(Channel)$/';
  const FREQUENCY_PATTERN = '/(X_DLINK_FrequencyBand)$/';
  const BANDWIDTH_PATTERN = '/(X_DLINK_OperatingChannelBandwidth)$/';
  const POWER_PATTERN = '/(TransmitPower)$/';
  const BYTES_RECEIVED_PATTERN = '/(TotalBytesReceived)$/';
  const BYTES_SEND_PATTERN = '/(TotalBytesSent)$/';


  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ValidException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Devices $devices */
    $device = Devices::find()->byId($id);
    if(empty($device))
      throw new ValidException("Устройство по id:" . $id . ' не найдено');
    /** @var ApplicationConfig $config */
    $config = \store(ApplicationConfig::class);
    $serial = $device->getSerialNumber();
    $path = $config->getParamsPath() . $serial . "_value.xml";
    /** @var DeviceParamsReader $deviceParams */
    $deviceParams = \store(DeviceParamsReader::class, $path);
    $result = [
      'date' => $deviceParams->getDate(),
      'wifi' => [],
    ];
    foreach ($deviceParams->grep(self::SECTION_PATTERN) as $key => $value){
      preg_match(self::SECTION_PATTERN, $key, $match);
      $itemKey = '';
      if(preg_match(self::NAME_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::ENABLE_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::STATUS_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::SSID_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::STANDART_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::AUTO_CHANNEL_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::CHANNEL_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::FREQUENCY_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BANDWIDTH_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::POWER_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_RECEIVED_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(preg_match(self::BYTES_SEND_PATTERN, $key, $itemMatch))
        $itemKey = $itemMatch[1];
      if(!empty($itemKey) && !empty($match[1]))
        $result['wifi'][$match[1]][$itemKey] = $value;
    }
    $result['wifi'] = array_values($result['wifi']);
    return $result;
  }
}