<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Clients;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Clients;

class GetAllAction extends RouterAction
{
  /**
   * @return array
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    return Clients::find()->all();
  }
}