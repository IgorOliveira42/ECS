<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Clients;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Clients;
use Centra\Main\Exceptions\ValidException;

class UpdateAction extends RouterAction
{
  /**
   * @return array|Clients
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Clients $item */
    $item = Clients::find()->byId(\query("id"));
    if(empty($item))
      throw new ValidException("Клиент по id:" . \query("id") . " не найден");
    $item->setScenario(Clients::SCENARIO_UPDATE)->load(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при обновлении клиента", $item->getErrors());
    $item->save();
    return $item;
  }
}