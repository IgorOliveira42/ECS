<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Tasks;

use Centra\Database\Models\WebTasks;
use Centra\Main\Exceptions\ValidException;
use Centra\Api\Models\RouterAction;

class GetByParams extends RouterAction
{

  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   * @throws \Centra\Main\Exceptions\ValidException
   */
  public function run()
  {
    $item = new WebTasks(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при поиске задачи", $item->getErrors());
    if(empty($item->getAttributes()))
      return [];
    return $item::find()->where($item->getAttributes())->all();
  }
}