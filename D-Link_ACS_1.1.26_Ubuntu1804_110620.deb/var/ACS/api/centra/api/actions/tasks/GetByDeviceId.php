<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Tasks;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\OperationTypes;
use Centra\Database\Models\WebTasks;

class GetByDeviceId extends RouterAction
{
  /**
   * @return mixed
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $deviceId = \query("id");
    $webTasks = WebTasks::find()->where(['device_id' => $deviceId])->all();
    /** @var WebTasks $task */
    foreach ($webTasks as $task){
      /** @var OperationTypes $type */
      $type = $task->getOperationType();
      $task->setAttribute("task_name", $type->getTypeName());
    }
    return $webTasks;
  }
}