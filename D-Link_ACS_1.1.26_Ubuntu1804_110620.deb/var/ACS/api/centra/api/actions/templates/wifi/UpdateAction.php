<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates\Wifi;

use Centra\Acs\Templates\TemplateWifiBlank;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;
use Centra\Main\Store;
use Centra\Acs\Templates\TemplateFileConfig;

class UpdateAction extends RouterAction
{
  const BEACON_BASIC = 'Basic';
  /**
   * @return array
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Templates $template */
    $template = Templates::find()->byId($id);
    if(empty($template))
      throw new ValidException("Шаблон по id:" . $id . ' не найден');
    /** @var TemplateFileConfig $config */
    $config = Store::init()->make(TemplateFileConfig::class, ['path' => $template->getPath()]);
    $params = \request("params");
    if(empty($params))
      throw new ValidException("Не указан обязательный параметр");
    $json = json_decode($params, true);
    if(empty($json))
      throw new ValidException("Ожидает конфигурация в формате json");
    foreach ($json as $key => $item){
      $wifi = new TemplateWifiBlank();
      if($item['beacon_type'] == self::BEACON_BASIC)
        $wifi->setScenario(TemplateWifiBlank::SCENARIO_BASIC)->load($item);
      else
        $wifi->setScenario(TemplateWifiBlank::SCENARIO_11I)->load($item);
      $wifi->check();
      if($wifi->hasError())
        throw new ValidException("Ошибка при обновлении шаблона wifi", $wifi->getErrors());
      $config->setWifi($wifi, $key);
    }
    $config->save();
    return $json;
  }
}