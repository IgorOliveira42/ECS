<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates;

use Centra\Acs\Templates\TemplateFileConfig;

use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;

class AddAction extends RouterAction
{
  /**
   * @return array|Templates
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var Templates $item */
    $item = new Templates();
    $item->setScenario(Templates::SCENARIO_CREATE)->load(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при создании шаблона", $item->getErrors());
    $item->save();
    if(!empty(\request("params"))){
      $params = \request("params");
      $json = json_decode($params, true);
      if(empty($json))
        throw new ValidException("Ожидается конфиграция в формете json");
      $config = new TemplateFileConfig(['path' => $item->getPath()]);
      $config->setFromParams($json);
      $config->save();
    }
    return $item;
  }

}