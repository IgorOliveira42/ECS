<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\Templates;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;
use Centra\Acs\Templates\TemplateFileConfig;

class UpdateAction extends RouterAction
{
  /**
   * @return array|Templates
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Templates $item */
    $item = Templates::find()->byId($id);
    if(empty($item))
      throw new ValidException("Шаблон по id:" . \query("id") . " не найден");
    $item->setScenario(Templates::SCENARIO_UPDATE)->load(\request());
    $item->check();
    if($item->hasError())
      throw new ValidException("Ошибка при обновлении шаблона", $item->getErrors());
    $item->save();
    if(!empty(\request("params"))){
      $params = \request("params");
      $json = json_decode($params, true);
      if(empty($json))
        throw new ValidException("Ожидается конфиграция в формете json");
      $config = new TemplateFileConfig(['path' => $item->getPath()]);
      $config->setFromParams($json);
      $config->save();
    }
    return $item;
  }
}