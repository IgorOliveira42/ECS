<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Templates\DynamicIp;



use Centra\Api\Models\RouterAction;
use Centra\Database\Models\Templates;
use Centra\Main\Exceptions\ValidException;
use Centra\Acs\Templates\TemplateFileConfig;
use Centra\Main\Store;

class GetAllAction extends RouterAction
{

  /**
   * @return array
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    $id = \query("id");
    /** @var Templates $template */
    $template = Templates::find()->byId($id);
    if(empty($template))
      throw new ValidException("Шаблон по id:" . $id . ' не найден');
    /** @var TemplateFileConfig $config */
    $config = Store::init()->make(TemplateFileConfig::class, ['path' => $template->getPath()]);
    $lan = $config->getDynamicIp();
    return $lan;
  }
}