<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:38
 */

namespace Centra\Api\Actions\Models;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\DeviceModels;
use Centra\Database\Models\Devices;

class GetByIdAction extends RouterAction
{
  /**
   * @return array|null|static
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    return DeviceModels::find()->byId(\query("id"));
  }
}