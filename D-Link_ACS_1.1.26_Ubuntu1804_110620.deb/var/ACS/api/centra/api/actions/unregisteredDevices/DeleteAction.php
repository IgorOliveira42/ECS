<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 12:01
 */

namespace Centra\Api\Actions\UnregisteredDevices;


use Centra\Api\Models\RouterAction;
use Centra\Database\Models\UnregisteredDevices;
use Centra\Main\Exceptions\ValidException;

class DeleteAction extends RouterAction
{
  /**
   * @return array|UnregisteredDevices
   * @throws ValidException
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function run()
  {
    /** @var UnregisteredDevices $item */
    $item = UnregisteredDevices::find()->byId(\query("id"));
    if(empty($item))
      throw new ValidException("Шаблон по id:" . \query("id") . " не найден");
    $item->delete();
    return ['id' => \query("id")];
  }
}