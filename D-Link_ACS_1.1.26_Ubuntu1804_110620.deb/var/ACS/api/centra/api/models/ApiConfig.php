<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 04.05.18
 * Time: 9:58
 */

namespace Centra\Api\Models;

use Centra\Api\Interfaces\ConfigInterface;
use Centra\Main\Traits\Configurable;

/**
 * Class ApiConfig
 * @package Centra\Api\Models
 * @property string url
 * @property integer timeout
 * @property integer retries
 */
abstract class ApiConfig implements ConfigInterface
{

  use Configurable;
  /**
   * @return string
   */
  public function getUrl()
  {
    return $this->url;
  }

  /**
   * @param string $url
   * @return ApiConfig $this;
   */
  public function setUrl($url)
  {
    $this->url = $url;
    return $this;
  }

  /**
   * @return int
   */
  public function getTimeout()
  {
    return $this->timeout;
  }

  /**
   * @param int $timeout
   * @return ApiConfig $this;
   */
  public function setTimeout($timeout)
  {
    $this->timeout = $timeout;
    return $this;
  }

  /**
   * @return int
   */
  public function getRetries()
  {
    return $this->retries;
  }

  /**
   * @param int $retries
   * @return ApiConfig $this;
   */
  public function setRetries($retries)
  {
    $this->retries = $retries;
    return $this;
  }

}