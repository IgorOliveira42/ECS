<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

namespace Centra\Api\Models;

use Centra\Api\Interfaces\RouterActionInterface;

class RouterRule
{
  const GET = 'GET';
  const POST = 'POST';
  const PATCH = 'PATCH';
  const DELETE = 'DELETE';
  const OPTIONS = 'OPTIONS';
  const DIRECTION_BEFORE = 'before';
  const DIRECTION_AFTER = 'after';

  public $method = null;
  public $beforeMiddleware = null;
  public $afterMiddleware = null;
  public $route = null;
  public $action = null;

  public function __construct($method, $route, $action)
  {
    $this->setMethod($method);
    $this->setRoute($route);
    $this->setAction($action);
    return $this;
  }

  /**
   * @return null
   */
  public function getMethod()
  {
    return $this->method;
  }

  /**
   * @param null $method
   * @return $this
   */
  public function setMethod($method)
  {
    $this->method = $method;
    return $this;
  }

  /**
   * @return null
   */
  public function getRoute()
  {
    return $this->route;
  }

  /**
   * @param null $route
   * @return $this
   */
  public function setRoute($route)
  {
    $this->route = $route;
    return $this;
  }

  /**
   * @return RouterActionInterface
   */
  public function getAction()
  {
    return $this->action;
  }

  /**
   * @param null $action
   * @return $this
   */
  public function setAction($action)
  {
    $this->action = $action;
    return $this;
  }

   /**
   * Создает GET маршрут
   * @param string $route
   * @param string $action
   * @return RouterRule
   */
  public static function get($route, $action)
  {
    return new self(self::GET, $route, $action);
  }

  /**
   * Создает POST маршрут
   * @param string $route
   * @param string $action
   * @return RouterRule
   */
  public static function post($route, $action)
  {
    return new self(self::POST, $route, $action);
  }

  /**
   * Создает PATCH маршрут
   * @param string $route
   * @param string $action
   * @return RouterRule
   */
  public static function patch($route, $action)
  {
    return new self(self::PATCH, $route, $action);
  }

  /**
   * Создает DELETE маршрут
   * @param string $route
   * @param string $action
   * @return RouterRule
   */
  public static function delete($route, $action)
  {
    return new self(self::DELETE, $route, $action);
  }

  /**
   * Добавляет посредника
   * @param array $items
   * @param string $direction
   * @return $this
   */
  public function middleware(array $items, $direction = self::DIRECTION_BEFORE)
  {
    if($direction == self::DIRECTION_BEFORE)
      $this->setBeforeMiddleware($items);
    if($direction== self::DIRECTION_AFTER)
      $this->setAfterMiddleware($items);
    return $this;
  }

  /**
   * @return null
   */
  public function getBeforeMiddleware()
  {
    return $this->beforeMiddleware;
  }

  /**
   * @param null $beforeMiddleware
   * @return $this
   */
  public function setBeforeMiddleware($beforeMiddleware)
  {
    $this->beforeMiddleware = $beforeMiddleware;
    return $this;
  }

  /**
   * @return null
   */
  public function getAfterMiddleware()
  {
    return $this->afterMiddleware;
  }

  /**
   * @param null $afterMiddleware
   * @return $this
   */
  public function setAfterMiddleware($afterMiddleware)
  {
    $this->afterMiddleware = $afterMiddleware;
    return $this;
  }
}