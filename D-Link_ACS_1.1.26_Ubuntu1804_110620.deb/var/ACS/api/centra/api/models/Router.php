<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 21.05.18
 * Time: 15:23
 */

namespace Centra\Api\Models;

use Centra\Log4p\Main\Log;
use Centra\Main\Exceptions\ClassException;
use Centra\Main\Exceptions\ProcessException;
use Centra\Api\Interfaces\RouterRulesInterface;
use Centra\Api\Interfaces\RouterActionInterface;
use Centra\Api\Interfaces\RouterMiddlewareInterface;
use Centra\Http\Main\Request;
use Centra\Http\Main\Response;

class Router
{
  const BASE_ROUTE_PREFFIX = '/api/';
  /** @var RouterRulesInterface $rulesItems */
  private $rulesItems = null;
  private $route = null;
  private $method = null;
  private $params = null;

  /**
   * Router constructor.
   * @param RouterRulesInterface $rules
   * @throws ClassException
   */
  public function __construct(RouterRulesInterface $rules)
  {
    $route = str_replace(self::BASE_ROUTE_PREFFIX, "", $_SERVER['REDIRECT_URL']);
    $this->setRoute($route);
    $this->setParams(\request());
    $this->setRulesItems($rules);
    $this->setMethod($_SERVER['REQUEST_METHOD']);
  }

  /**
   * @throws ClassException
   */
  public function make()
  {
    $rule = $this->getRuleRoute();
    try{
      $beforeMiddlewareItems = $this->getRulesItems()->getBeforeMiddleware();
      if(!empty($beforeMiddlewareItems))
        $this->makeGlobalMiddleware($beforeMiddlewareItems);
      if(empty($rule))
        throw new ProcessException("Маршрут для запроса не указан");
      $classname = $rule->getAction();
      if(!class_exists($classname, true))
        throw new ProcessException("Маршрут для запроса указан неверно");
      if(!empty($rule->getBeforeMiddleware()))
        $this->makeMiddleware($rule);
      /** @var RouterAction $model */
      $model = new $classname();
      $result = $model->run();
      /** @var Response $response */
      $response = \store(Response::class);
      $response->setStatus(Response::SUCCESS)->setResult($result);
    } catch (\Exception $e) {
      /** @var Response $response */
      $response = \store(Response::class);
      $response->setStatus(Response::FAILED)->setResult($e);
    } catch (\TypeError $e){
      /** @var Response $response */
      $response = \store(Response::class);
      $response->setStatus(Response::FAILED)->setResult($e);
    } finally {
      $afterMiddlewareItems = $this->getRulesItems()->getAfterMiddleware();
      if(!empty($afterMiddlewareItems))
        $this->makeGlobalMiddleware($afterMiddlewareItems);
      if(!is_null($rule) && !empty($rule->getAfterMiddleware()))
        $this->makeMiddleware($rule);
      /** @var Response $response */
      $response = \store(Response::class);
      $response->write();
    }
  }

  private function makeMiddleware(RouterRule $rule)
  {
    /** @var RouterActionInterface $model */
    foreach ($rule->getBeforeMiddleware() as $middlewareClassname){
      /** @var RouterMiddlewareInterface $middleware */
      $middleware = new $middlewareClassname($this->getParams());
      $middleware->run();
    }
  }

  private function makeGlobalMiddleware(array $middlewareItems)
  {
    /** @var RouterMiddleware $middlewareClassname */
    foreach ($middlewareItems as $middlewareClassname){
      /** @var RouterMiddlewareInterface $middleware */
      $middleware = new $middlewareClassname($this->getParams());
      $middleware->run();
    }
  }

  /**
   * Получает доступный маршрут для запроса
   * @return RouterRule|null
   * @throws ClassException
   */
  public function getRuleRoute()
  {
    $findRule = null;
    /** @var RouterRule $rule */
    foreach ($this->getRulesItems()->getRules() as $rule){
      if($this->getMethod() != $rule->getMethod())
        continue;
      $rulePath = explode("/", $rule->getRoute());
      $routePath = explode("/", $this->getRoute());
      if(count($rulePath) != count($routePath))
        continue;
      $routeParam = [];
      $valid = true;
      foreach ($routePath as $key => $routePathItem){
        $rulePathItem = $rulePath[$key];
        if(preg_match("/{([0-9A-z]+)}/", $rulePathItem))
          continue;
        if($routePathItem != $rulePathItem)
          $valid = false;
      }
      if(!$valid)
        continue;
      foreach ($rulePath as $key => $rulePathItem)
        if(preg_match("/{([0-9A-z]+)}/", $rulePathItem, $match))
          $routeParam[$match[1]] = $routePath[$key];
      /** @var Request $request */
      $request = \store(Request::class);
      $request->setQueryParams($routeParam);
      $findRule = $rule;
    }
    return $findRule;
  }

  /**
   * @return RouterRulesInterface
   */
  public function getRulesItems()
  {
    return $this->rulesItems;
  }

  /**
   * @param RouterRulesInterface $rules
   * @return $this
   */
  public function setRulesItems(RouterRulesInterface $rules)
  {
    $this->rulesItems = $rules;
    return $this;
  }

  /**
   * @return null
   */
  public function getRoute()
  {
    return $this->route;
  }

  /**
   * @param null $route
   * @return $this
   */
  public function setRoute($route)
  {
    $this->route = $route;
    return $this;
  }

  /**
   * @return array
   */
  public function getParams()
  {
    return $this->params;
  }

  /**
   * @param array $params
   * @return $this
   */
  public function setParams(array $params)
  {
    $this->params = $params;
    return $this;
  }

  /**
   * @return null
   */
  public function getMethod()
  {
    return $this->method;
  }

  /**
   * @param null $method
   * @return $this
   */
  public function setMethod($method)
  {
    $this->method = $method;
    return $this;
  }

}