<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 9:55
 */

namespace Centra\Acs\Templates;

use Centra\Database\Main\Model;
use Centra\Main\Utils\Validator;

/**
 * Class TemplateLanBlank
 * @package centra\acs
 * @property string ip_address
 * @property string netmask
 * @property integer mode
 * @property string start_ip
 * @property string end_ip
 * @property integer lease_time
 */
class TemplateLanBlank extends Model
{
  public static function rules()
  {
    return [
      ['ip_address' => [
        'required' => true,
        'message' => 'Ip адрес не указан'
      ]],
      ['netmask' => [
        'required' => true,
        'message' => 'Маска ip адреса не указана'
      ]],
      ['mode' => [
        'required' => true,
        'message' => 'Режим не указан'
      ]],
      ['start_ip' => [
        'required' => true,
        'message' => 'Начальный ip адрес аренды ip не указан'
      ]],
      ['end_ip' => [
        'required' => true,
        'message' => 'Завершающий ip адрес аренды ip не указан'
      ]],
      ['lease_time' => [
        'required' => true,
        'message' => 'Время аренды ip адреса не указано'
      ]],
      ['ip_address' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Ip адрес указан неверно'
      ]],
      ['netmask' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Маска ip адреса указана неверно'
      ]],
      ['mode' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Режим указан неверно'
      ]],
      ['start_ip' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Начальный ip адрес аренды ip не указан'
      ]],
      ['end_ip' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Завершающий ip адрес аренды ip не указан'
      ]],
      ['lease_time' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Время аренды ip адреса не указано'
      ]],
    ];
  }

  /**
   * @return string
   */
  public function getIpAddress()
  {
    return $this->getAttribute("ip_address");
  }

  /**
   * @param string $ip_address
   * @return $this
   */
  public function setIpAddress($ip_address)
  {
    $this->setAttribute("ip_address", $ip_address);
    return $this;
  }

  /**
   * @return string
   */
  public function getNetmask()
  {
    return $this->getAttribute("netmask");
  }

  /**
   * @param string $netmask
   * @return $this
   */
  public function setNetmask($netmask)
  {
    $this->setAttribute("netmask", $netmask);
    return $this;
  }

  /**
   * @return int
   */
  public function getMode()
  {
    return $this->getAttribute("mode");
  }

  /**
   * @param int $mode
   * @return $this
   */
  public function setMode($mode)
  {
    $this->setAttribute("mode", $mode);
    return $this;
  }

  /**
   * @return string
   */
  public function getStartIp()
  {
    return $this->getAttribute("start_ip");
  }

  /**
   * @param string $start_ip
   * @return $this
   */
  public function setStartIp($start_ip)
  {
    $this->setAttribute("start_ip", $start_ip);
    return $this;
  }

  /**
   * @return string
   */
  public function getEndIp()
  {
    return $this->getAttribute("end_ip");
  }

  /**
   * @param string $end_ip
   * @return $this
   */
  public function setEndIp($end_ip)
  {
    $this->setAttribute("end_ip", $end_ip);
    return $this;
  }

  /**
   * @return int
   */
  public function getLeaseTime()
  {
    return $this->getAttribute("lease_time");
  }

  /**
   * @param int $lease_time
   * @return $this
   */
  public function setLeaseTime($lease_time)
  {
    $this->setAttribute("lease_time", $lease_time);
    return $this;
  }
}