<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 9:55
 */

namespace Centra\Acs\Templates;

use Centra\Database\Main\Model;
use Centra\Main\Utils\Validator;

/**
 * Class TemplateWifi24Blank
 * @package Centra\Acs\Templates
 * @property integer enable
 * @property string frequency_band
 * @property string ssid
 * @property integer auto_enable
 * @property integer channel
 * @property string standard
 * @property integer transmit_power
 * @property integer max_associated_clients
 * @property string beacon_type
 * @property string basic_mode
 * @property string wpa_psk2
 * @property string key_psk
 * @property string wpa_encrypt
 * @property integer wpa_reneval
 */
class TemplateWifiBlank extends Model
{
  const SCENARIO_BASIC = 'basic';
  const SCENARIO_11I = '11i';

  public static function rules()
  {
    return [
      ['enable' => [
        'required' => true,
        'message'  => 'Маркер активности wifi не указан',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['frequency_band' => [
        'required' => true,
        'message'  => 'Частота сети wifi не указана',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['ssid' => [
        'required' => true,
        'message'  => 'Имя сети wifi не указано',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['standard' => [
        'required' => true,
        'message'  => 'Стандарт сети wifi не указано',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['transmit_power' => [
        'required' => true,
        'message'  => 'Можность передатчика сети wifi не указано',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['max_associated_clients' => [
        'required' => true,
        'message'  => 'Максимальное количество пользователей сети wifi не указано',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['beacon_type' => [
        'required' => true,
        'message'  => 'Тип вещяния сети wifi не указан',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['basic_mode' => [
        'required' => true,
        'message'  => 'Режим авторизации сети wifi не указан',
        'on' => [self::SCENARIO_BASIC]
      ]],
      ['wpa_psk2' => [
        'required' => true,
        'message'  => 'Режим авторизации сети wifi не указан',
        'on' => [self::SCENARIO_11I]
      ]],
      ['key_psk' => [
        'required' => true,
        'message'  => 'Ключ авторизации сети wifi не указан',
        'on' => [self::SCENARIO_11I]
      ]],
      ['wpa_encrypt' => [
        'required' => true,
        'message'  => 'Тип шифрования сети wifi не указан',
        'on' => [self::SCENARIO_11I]
      ]],
      ['wpa_reneval' => [
        'required' => true,
        'message'  => 'Время обновления сети wifi не указано',
        'on' => [self::SCENARIO_11I]
      ]],
      ['enable' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер активности wifi указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['frequency_band' => [
        'regexp' => Validator::PATTERN_FREQUENCY_BAND,
        'message'  => 'Частота сети wifi указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['ssid' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message'  => 'Имя сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['auto_enable' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер автоматического выбора канала сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['channel' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'Имя сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['standard' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message'  => 'Стандарт сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['transmit_power' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'Можность передатчика сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['max_associated_clients' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'Максимальное количество пользователей сети wifi указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['beacon_type' => [
        'regexp' => Validator::PATTERN_BEACON_TYPE,
        'message'  => 'Тип вещяния сети wifi указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_BASIC, self::SCENARIO_11I]
      ]],
      ['basic_mode' => [
        'regexp' => Validator::PATTERN_BASIC_MODE,
        'message'  => 'Режим авторизации сети wifi указан неверно',
        'on' => [self::SCENARIO_BASIC]
      ]],
      ['wpa_psk2' => [
        'required' => Validator::PATTERN_WPA_PSK2,
        'message'  => 'Режим авторизации сети wifi указан неверно',
        'on' => [self::SCENARIO_11I]
      ]],
      ['key_psk' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message'  => 'Ключ авторизации сети wifi указан неверно',
        'on' => [self::SCENARIO_11I]
      ]],
      ['key_psk' => [
        'min' => 8,
        'max' => 63,
        'message'  => 'Длинна ключ авторизации сети wifi должна быть меньше 64 и больше 7 символов',
        'on' => [self::SCENARIO_11I]
      ]],
      ['wpa_encrypt' => [
        'regexp' => Validator::PATTERN_WPA_ENCRYPT,
        'message'  => 'Тип шифрования сети wifi указан неверно',
        'on' => [self::SCENARIO_11I]
      ]],
      ['wpa_reneval' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'Время обновления сети wifi указано неверно',
        'on' => [self::SCENARIO_11I]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getEnable()
  {
    return $this->getAttribute("enable");
  }

  /**
   * @param int $enable
   * @return $this
   */
  public function setEnable($enable)
  {
    $this->setAttribute("enable", $enable);
    return $this;
  }

  /**
   * @return string
   */
  public function getFrequencyBand()
  {
    return $this->getAttribute("frequency_band");
  }

  /**
   * @param string $frequency_band
   * @return $this
   */
  public function setFrequencyBand($frequency_band)
  {
    $this->setAttribute("frequency_band", $frequency_band);
    return $this;
  }

  /**
   * @return string
   */
  public function getSsid()
  {
    return $this->getAttribute("ssid");
  }

  /**
   * @param string $ssid
   * @return $this
   */
  public function setSsid($ssid)
  {
    $this->setAttribute("ssid", $ssid);
    return $this;
  }

  /**
   * @return int
   */
  public function getAutoEnable()
  {
    return $this->getAttribute("auto_enable");
  }

  /**
   * @param int $auto_enable
   * @return $this
   */
  public function setAutoEnable($auto_enable)
  {
    $this->setAttribute("auto_enable", $auto_enable);
    return $this;
  }

  /**
   * @return int
   */
  public function getChannel()
  {
    return $this->getAttribute("channel");
  }

  /**
   * @param int $channel
   * @return $this
   */
  public function setChannel($channel)
  {
    $this->setAttribute("channel", $channel);
    return $this;
  }

  /**
   * @return string
   */
  public function getStandard()
  {
    return $this->getAttribute("standard");
  }

  /**
   * @param string $standard
   * @return $this
   */
  public function setStandard($standard)
  {
    $this->setAttribute("standard", $standard);
    return $this;
  }

  /**
   * @return int
   */
  public function getTransmitPower()
  {
    return $this->getAttribute("transmit_power");
  }

  /**
   * @param int $transmit_power
   * @return $this
   */
  public function setTransmitPower($transmit_power)
  {
    $this->setAttribute("transmit_power", $transmit_power);
    return $this;
  }

  /**
   * @return int
   */
  public function getMaxAssociatedClients()
  {
    return $this->getAttribute("max_associated_clients");
  }

  /**
   * @param int $max_associated_clients
   * @return $this
   */
  public function setMaxAssociatedClients($max_associated_clients)
  {
    $this->setAttribute("max_associated_clients", $max_associated_clients);
    return $this;
  }

  /**
   * @return string
   */
  public function getBeaconType()
  {
    return $this->getAttribute("beacon_type");
  }

  /**
   * @param string $beacon_type
   * @return $this
   */
  public function setBeaconType($beacon_type)
  {
    $this->setAttribute("beacon_type", $beacon_type);
    return $this;
  }

  /**
   * @return string
   */
  public function getBasicMode()
  {
    return $this->getAttribute("basic_mode");
  }

  /**
   * @param string $basic_mode
   * @return $this
   */
  public function setBasicMode($basic_mode)
  {
    $this->setAttribute("basic_mode", $basic_mode);
    return $this;
  }

  /**
   * @return string
   */
  public function getWpaPsk2()
  {
    return $this->getAttribute("wpa_psk2");
  }

  /**
   * @param string $wpa_psk2
   * @return $this
   */
  public function setWpaPsk2($wpa_psk2)
  {
    $this->setAttribute("wpa_psk2", $wpa_psk2);
    return $this;
  }

  /**
   * @return string
   */
  public function getKeyPsk()
  {
    return $this->getAttribute("key_psk");
  }

  /**
   * @param string $key_psk
   * @return $this
   */
  public function setKeyPsk($key_psk)
  {
    $this->setAttribute("key_psk", $key_psk);
    return $this;
  }

  /**
   * @return string
   */
  public function getWpaEncrypt()
  {
    return $this->getAttribute("wpa_encrypt");
  }

  /**
   * @param string $wpa_encrypt
   * @return $this
   */
  public function setWpaEncrypt($wpa_encrypt)
  {
    $this->setAttribute("wpa_encrypt", $wpa_encrypt);
    return $this;
  }

  /**
   * @return int
   */
  public function getWpaReneval()
  {
    return $this->getAttribute("wpa_reneval");
  }

  /**
   * @param int $wpa_reneval
   * @return $this
   */
  public function setWpaReneval($wpa_reneval)
  {
    $this->setAttribute("wpa_reneval", $wpa_reneval);
    return $this;
  }

}