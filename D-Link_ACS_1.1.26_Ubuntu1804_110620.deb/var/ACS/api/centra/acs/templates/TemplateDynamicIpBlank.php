<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 9:55
 */

namespace Centra\Acs\Templates;

use Centra\Database\Main\Model;
use Centra\Main\Utils\Validator;

/**
 * Class TemplateStaticIpBlank
 * @package Centra\Acs\Templates
 * @property string name
 * @property integer mtu
 * @property integer dns
 * @property integer nat
 * @property integer enable
 * @property string dns_servers
 * @property integer def_connection
 */
class TemplateDynamicIpBlank extends Model
{
  public static function rules()
  {
    return [
      ['name' => [
        'required' => true,
        'message'  => 'Имя соединения не указано'
      ]],
      ['mtu' => [
        'required' => true,
        'message'  => 'MTU соединения не указано'
      ]],
      ['dns' => [
        'required' => true,
        'message'  => 'Маркер DNS соединения не указан'
      ]],
      ['nat' => [
        'required' => true,
        'message'  => 'Маркер NAT соединения не указан'
      ]],
      ['enable' => [
        'required' => true,
        'message'  => 'Активность соединения не указана'
      ]],
      ['dns_servers' => [
        'required' => true,
        'message'  => 'Перечень dns серверов соединения не указан'
      ]],
      ['def_connection' => [
        'required' => true,
        'message'  => 'Маркер по умолчанию соединения не указан'
      ]],
      ['name' => [
        'regexp' => Validator::PATTERN_STRING,
        'message'  => 'Имя соединения не указано'
      ]],
      ['mtu' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message'  => 'MTU соединения не указано'
      ]],
      ['dns' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер DNS соединения не указан'
      ]],
      ['nat' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер NAT соединения не указан'
      ]],
      ['enable' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Активность соединения не указана'
      ]],
      ['dns_servers' => [
        'regexp' => Validator::PATTERN_IP_LIST,
        'message'  => 'Перечень dns серверов соединения не указан'
      ]],
      ['def_connection' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message'  => 'Маркер по умолчанию соединения не указан'
      ]],
    ];
  }

  /**
   * @return string
   */
  public function getName()
  {
    return $this->getAttribute("name");
  }

  /**
   * @param string $name
   * @return $this
   */
  public function setName($name)
  {
    $this->setAttribute("name", $name);
    return $this;
  }

  /**
   * @return int
   */
  public function getMtu()
  {
    return $this->getAttribute("mtu");
  }

  /**
   * @param int $mtu
   * @return $this
   */
  public function setMtu($mtu)
  {
    $this->setAttribute("mtu", $mtu);
    return $this;
  }

  /**
   * @return int
   */
  public function getDns()
  {
    return $this->getAttribute("dns");
  }

  /**
   * @param int $dns
   * @return $this
   */
  public function setDns($dns)
  {
    $this->setAttribute("dns", $dns);
    return $this;
  }

  /**
   * @return int
   */
  public function getNat()
  {
    return $this->getAttribute("nat");
  }

  /**
   * @param int $nat
   * @return $this
   */
  public function setNat($nat)
  {
    $this->setAttribute("nat", $nat);
    return $this;
  }

  /**
   * @return int
   */
  public function getEnable()
  {
    return $this->getAttribute("enable");
  }

  /**
   * @param int $enable
   * @return $this
   */
  public function setEnable($enable)
  {
    $this->setAttribute("enable", $enable);
    return $this;
  }

  /**
   * @return string
   */
  public function getDnsServers()
  {
    return $this->getAttribute("dns_servers");
  }

  /**
   * @param string $dns_servers
   * @return $this
   */
  public function setDnsServers($dns_servers)
  {
    $this->setAttribute("dns_servers", $dns_servers);
    return $this;
  }

  /**
   * @return int
   */
  public function getDefConnection()
  {
    return $this->getAttribute("def_connection");
  }

  /**
   * @param int $def_connection
   * @return $this
   */
  public function setDefConnection($def_connection)
  {
    $this->setAttribute("def_connection", $def_connection);
    return $this;
  }
}