<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 12.10.18
 * Time: 15:27
 */
namespace Centra\Acs\Main;

use Centra\Acs\Utils\XmlBuilder;
use Centra\Http\Main\RequestAgent;

/**
 * Class AcsWorker
 * @package Centra\Acs\Main
 * @property AcsWorker $config
 */
class AcsWorker extends RequestAgent
{
  /**
   * Отправляет запрос на обновление конфиграции согласно шаблона
   * @param $deviceId
   * @return bool|mixed
   * @throws \Centra\Main\Exceptions\HttpException
   */
  public function setTemplate($deviceId)
  {
    $xml = XmlBuilder::get("setTemplate", $deviceId);
    $result = $this->post($this->getConfig()->getUrl(), $xml);
    return $result;
  }

  /**
   * Перезагрузает устройство
   * @param $deviceId
   * @return bool|mixed
   * @throws \Centra\Main\Exceptions\HttpException
   */
  public function reboot($deviceId)
  {
    $xml = XmlBuilder::get("reboot", $deviceId);
    $result = $this->post($this->getConfig()->getUrl(), $xml);
    return $result;
  }

  /**
   * Сохраняет все параметры в каталог tmp/
   * @param $deviceId
   * @return bool|mixed
   * @throws \Centra\Main\Exceptions\HttpException
   */
  public function getAllParams($deviceId)
  {
    $xml = XmlBuilder::get("getAllParams", $deviceId);
    $result = $this->post($this->getConfig()->getUrl(), $xml);
    return $result;
  }
}