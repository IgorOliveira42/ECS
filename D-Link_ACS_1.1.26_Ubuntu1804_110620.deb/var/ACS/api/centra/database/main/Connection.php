<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 15:44
 */

namespace Centra\Database\Main;

use Centra\Database\Interfaces\ConfigInterface;
use Centra\Main\Exceptions\ProcessException;

class Connection
{
  /** @var ConfigInterface $config */
  private $config;
  /** @var \PDO */
  public $connection = null;

  /**
   * Connection constructor.
   * @param ConfigInterface $config
   * @throws ProcessException
   */
  public function __construct(ConfigInterface $config)
  {
    $this->setConfig($config);
    $this->make();
    $this->get()->exec("set names utf8");
  }

  /**
   * Создает соединение
   * @throws ProcessException
   */
  private function make()
  {
    $dns = "mysql:host=" . $this->getConfig()->getHost() . ":" . $this->getConfig()->getPort() . ";dbname=" . $this->getConfig()->getDatabase();
    $connection = new \PDO($dns, $this->getConfig()->getUsername(), $this->getConfig()->getPassword());
    if (empty($connection))
      throw new ProcessException("Не удалось подключиться к DB");
    $this->set($connection);
    return $connection;
  }

  /**
   * @return ConfigInterface
   */
  public function getConfig()
  {
    return $this->config;
  }

  /**
   * @param ConfigInterface $config
   * @return $this
   */
  public function setConfig($config)
  {
    $this->config = $config;
    return $this;
  }

  /**
   * @return \PDO
   */
  public function get()
  {
    return $this->connection;
  }

  /**
   * @param \PDO $connection
   * @return $this
   */
  public function set(\PDO $connection)
  {
    $this->connection = $connection;
    return $this;
  }
}