<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 08.10.18
 * Time: 14:21
 */

namespace Centra\Database\Main;

/**
 *
 * Class ActiveRecord
 * @package Centra\Database
 * @property integer id
 */
class ActiveRecord extends Model
{
  /** @var QueryBuilder $_builder*/
  private $_builder = null;

  public function table()
  {
    return null;
  }

  public static function find()
  {
    $model = new static();
    $queryBuilder = QueryBuilder::getInstance($model->table());
    $model->setBuilder($queryBuilder);
    return $model;
  }

  public function select(array $select)
  {
    $this->getBuilder()->select($select);
    return $this;
  }

  public function join($table, $relation)
  {
    $this->getBuilder()->join($table, $relation);
    return $this;
  }

  /**
   * @param array $where
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function where(array $where)
  {
    $this->getBuilder()->where($where);
    return $this;
  }

  /**
   * @param array $where
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function andWhere(array $where)
  {
    $this->getBuilder()->andWhere($where);
    return $this;
  }

  /**
   * @param array $where
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public function orWhere(array $where)
  {
    $this->getBuilder()->orWhere($where);
    return $this;
  }

  public function group(array $group)
  {
    $this->getBuilder()->group($group);
    return $this;
  }

  public function having(array $having)
  {
    $this->getBuilder()->having($having);
    return $this;
  }

  public function order(array $order)
  {
    $this->getBuilder()->order($order);
    return $this;
  }

  public function limit(array $limit)
  {
    $this->getBuilder()->limit($limit);
    return $this;
  }

  /**
   * @param $id
   * @return null|static
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function byId($id)
  {
    $item = $this->getBuilder()->byId($id);
    if(empty($item))
      return null;
    return new static($item);
  }

  /**
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function all()
  {
    $items = [];
    foreach ($this->getBuilder()->all() as $item){
      $model = new static($item);
      $items[] = $model;
    }
    return $items;
  }

  /**
   * @return null|static
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function first()
  {
    $item = $this->getBuilder()->first();
    if(empty($item))
      return null;
    return new static($item);
  }

  /**
   * @return null|static
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function last()
  {
    $item = $this->getBuilder()->last();
    if(empty($item))
      return null;
    return new static($item);
  }

  /**
   * @return $this
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function save()
  {
    $queryBuilder = QueryBuilder::getInstance($this->table());
    $this->setBuilder($queryBuilder);
    if ($this->getId() == null){
      $this->add();
      $item = $queryBuilder->last();
      $item = $this->parseInteger($item);
      $this->setAttributes($item);
    } else {
      $this->update();
    }
    $this->setOldAttributes($this->getAttributes());
    $this->setBuilder(null);
    return $this;
  }

  /**
   * @return mixed
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  public function delete()
  {
    $queryBuilder = QueryBuilder::getInstance($this->table());
    $this->setBuilder($queryBuilder);
    $this->getBuilder()->delete($this->getId());
    $this->setBuilder(null);
    return $this->getId();
  }

  /**
   * @return int
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  protected function add()
  {
    return $this->getBuilder()->insert($this->getAttributes());
  }

  /**
   * @return int
   * @throws \Centra\Main\Exceptions\ClassException
   * @throws \Centra\Main\Exceptions\ProcessException
   */
  protected function update()
  {
    $diff = array_diff_assoc($this->getAttributes(), $this->getOldAttributes());
    if(empty($diff))
      return false;
    return $this->getBuilder()->update($this->getId(), $diff);
  }

  /**
   * @return QueryBuilder
   */
  public function getBuilder()
  {
    return $this->_builder;
  }

  /**
   * @param QueryBuilder $builder
   * @return $this
   */
  public function setBuilder($builder)
  {
    $this->_builder = $builder;
    return $this;
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

}