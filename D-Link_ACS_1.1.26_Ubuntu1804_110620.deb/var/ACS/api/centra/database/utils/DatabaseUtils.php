<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 10.10.18
 * Time: 9:48
 */

namespace Centra\Database\Utils;

use Centra\Database\Main\ActiveRecord;

class DatabaseUtils
{
  public static function modelToArray(array $models)
  {
    $items = [];
    /** @var ActiveRecord $model */
    foreach ($models as $model)
      $items[] = $model->getAttributes();
    return $items;
  }
}