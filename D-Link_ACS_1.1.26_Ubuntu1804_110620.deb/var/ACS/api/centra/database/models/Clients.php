<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class Clients
 * @package Centra\Database\Models
 * @property integer id
 * @property string first_name
 * @property string sur_name
 * @property string patronymic_name
 * @property string address
 * @property string email
 * @property integer status_id
 * @property string contract_number
 */
class Clients extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'client';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp'  => Validator::PATTERN_INTEGER,
        'message' => 'Id клиента указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['first_name' => [
        'regexp'  => Validator::PATTERN_STRING,
        'message' => 'Имя клиента указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['sur_name' => [
        'regexp'  => Validator::PATTERN_STRING,
        'message' => 'Фамилия клиента указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['patronymic_name' => [
        'regexp'  => Validator::PATTERN_STRING,
        'message' => 'Отчетство клиента указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['address' => [
        'empty' => true,
        'regexp'  => Validator::PATTERN_STRING,
        'message' => 'Адрес клиента указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['email' => [
        'empty' => true,
        'regexp'  => Validator::PATTERN_EMAIL,
        'message' => 'Email клиента указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['status_id' => [
        'regexp'  => Validator::PATTERN_INTEGER,
        'empty' => true,
        'message' => 'Статус клиента указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['contract_number' => [
        'regexp'  => Validator::PATTERN_CONTRACT_TITLE,
        'message' => 'Номер договора клиента указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['id' => [
        'message'  => 'Id клиента не указан',
        'required' => true,
        'on' => [self::SCENARIO_UPDATE]
      ]],
      ['first_name' => [
        'message' => 'Имя клиента не указано',
        'required' => true,
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['sur_name' => [
        'message' => 'Фамилия клиента не указана',
        'required' => true,
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['patronymic_name' => [
        'message' => 'Отчетство клиента не указано',
        'required' => true,
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['contract_number' => [
        'regexp'  => Validator::PATTERN_CONTRACT_TITLE,
        'message' => 'Номер договора клиента указан неверно',
        'required' => true,
        'on' => [self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['status_id' => [
        'default'  => 1,
        'on' => [self::SCENARIO_CREATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getFirstName()
  {
    return $this->getAttribute("first_name");
  }

  /**
   * @param string $first_name
   * @return $this
   */
  public function setFirstName($first_name)
  {
    $this->setAttribute("first_name", $first_name);
    return $this;
  }

  /**
   * @return string
   */
  public function getSurName()
  {
    return $this->getAttribute("sur_name");
  }

  /**
   * @param string $sur_name
   * @return $this
   */
  public function setSurName($sur_name)
  {
    $this->setAttribute("sur_name", $sur_name);
    return $this;
  }

  /**
   * @return string
   */
  public function getPatronymicName()
  {
    return $this->getAttribute("patronymic_name");
  }

  /**
   * @param string $patronymic_name
   * @return $this
   */
  public function setPatronymicName($patronymic_name)
  {
    $this->setAttribute("patronymic_name", $patronymic_name);
    return $this;
  }

  /**
   * @return string
   */
  public function getAddress()
  {
    return $this->getAttribute("address");
  }

  /**
   * @param string $address
   * @return $this
   */
  public function setAddress($address)
  {
    $this->setAttribute("address", $address);
    return $this;
  }

  /**
   * @return string
   */
  public function getEmail()
  {
    return $this->getAttribute("email");
  }

  /**
   * @param string $email
   * @return $this
   */
  public function setEmail($email)
  {
    $this->setAttribute("email", $email);
    return $this;
  }

  /**
   * @return int
   */
  public function getStatusId()
  {
    return $this->getAttribute("status_id");
  }

  /**
   * @param int $status_id
   * @return $this
   */
  public function setStatusId($status_id)
  {
    $this->setAttribute("status_id", $status_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getContractNumber()
  {
    return $this->getAttribute("contract_number");
  }

  /**
   * @param string $contract_number
   * @return $this
   */
  public function setContractNumber($contract_number)
  {
    $this->setAttribute("contract_number", $contract_number);
    return $this;
  }

}