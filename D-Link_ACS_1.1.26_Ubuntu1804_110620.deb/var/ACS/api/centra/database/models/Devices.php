<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class UnregisteredDevices
 * @package Centra\Database\Models\Devices
 * @property integer id
 * @property string serial_number
 * @property string manufacture
 * @property integer model_id
 * @property string oui
 * @property string ip
 * @property integer port
 * @property string dev_username
 * @property string dev_password
 * @property integer client_id
 * @property integer profile_id
 * @property string last_inform_time
 * @property string dump
 * @property integer group_id
 * @property integer status_id
 * @property string firmware
 * @property integer template_id
 * @property string default_gateway
 * @property integer conn_index
 * @property integer igmp
 * @property string mac
 * @property string req_path
 * @property integer last_status
 * @property integer stun_status
 * @property integer udp_port
 * @property string udp_ip
 * @property string conn_type
 * @property string up_time
 * @property string tr_version
 * @property integer conn_index_lte
 */
class Devices extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'devices';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['serial_number' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Серийный номер устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['manufacture' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Изготовитель устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['model_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id модели устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['oui' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'OUI устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['ip' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Ip адрес устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['port' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Порт устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['port' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Порт устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['dev_username' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Имя пользователя устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['dev_password' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Пароль пользователя устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['client_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id клиента устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['profile_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id клиента устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['last_inform_time' => [
        'regexp' => Validator::PATTERN_DATETIME,
        'message' => 'Дата опроса устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['dump' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Дамп устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['group_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id группы устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['status_id' => [
        'regexp' => Validator::PATTERN_ON_OFF,
        'message' => 'Id статуса устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['firmware' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Название прошивки устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['template_id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id шаблона устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['default_gateway' => [
        'regexp' => Validator::PATTERN_IP,
        'message' => 'Ip шлюза устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['conn_index' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Индекс соединения устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['igmp' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Версия IGMP устройства указана неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['mac' => [
        'regexp' => Validator::PATTERN_MAC,
        'message' => 'Мак адрес устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['req_path' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Путь запроса к устройству указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['last_status' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Последний статус устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['stun_status' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Статус STUN устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['udp_port' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'UDP порт устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['conn_type' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Тип соединения устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['up_time' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Время жизни устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['tr_version' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Версия протокола TR устройства указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['conn_index_lte' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Индекс lte устройства указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getSerialNumber()
  {
    return $this->getAttribute("serial_number");
  }

  /**
   * @param string $serial_number
   * @return $this
   */
  public function setSerialNumber($serial_number)
  {
    $this->setAttribute("serial_number", $serial_number);
    return $this;
  }

  /**
   * @return string
   */
  public function getManufacture()
  {
    return $this->getAttribute("manufacture");
  }

  /**
   * @param string $manufacture
   * @return $this
   */
  public function setManufacture($manufacture)
  {
    $this->setAttribute("manufacture", $manufacture);
    return $this;
  }

  /**
   * @return int
   */
  public function getModelId()
  {
    return $this->getAttribute("model_id");
  }

  /**
   * @param int $model_id
   * @return $this
   */
  public function setModelId($model_id)
  {
    $this->setAttribute("model_id", $model_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getOui()
  {
    return $this->getAttribute("oui");
  }

  /**
   * @param string $oui
   * @return $this
   */
  public function setOui($oui)
  {
    $this->setAttribute("oui", $oui);
    return $this;
  }

  /**
   * @return string
   */
  public function getIp()
  {
    return $this->getAttribute("ip");
  }

  /**
   * @param string $ip
   * @return $this
   */
  public function setIp($ip)
  {
    $this->setAttribute("ip", $ip);
    return $this;
  }

  /**
   * @return int
   */
  public function getPort()
  {
    return $this->getAttribute("port");
  }

  /**
   * @param int $port
   * @return $this
   */
  public function setPort($port)
  {
    $this->setAttribute("port", $port);
    return $this;
  }

  /**
   * @return string
   */
  public function getDevUsername()
  {
    return $this->getAttribute("dev_username");
  }

  /**
   * @param string $dev_username
   * @return $this
   */
  public function setDevUsername($dev_username)
  {
    $this->setAttribute("dev_username", $dev_username);
    return $this;
  }

  /**
   * @return string
   */
  public function getDevPassword()
  {
    return $this->getAttribute("dev_password");
  }

  /**
   * @param string $dev_password
   * @return $this
   */
  public function setDevPassword($dev_password)
  {
    $this->setAttribute("dev_password", $dev_password);
    return $this;
  }

  /**
   * @return int
   */
  public function getClientId()
  {
    return $this->getAttribute("client_id");
  }

  /**
   * @param int $client_id
   * @return $this
   */
  public function setClientId($client_id)
  {
    $this->setAttribute("client_id", $client_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getProfileId()
  {
    return $this->getAttribute("profile_id");
  }

  /**
   * @param int $profile_id
   * @return $this
   */
  public function setProfileId($profile_id)
  {
    $this->setAttribute("profile_id", $profile_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getLastInformTime()
  {
    return $this->getAttribute("last_inform_time");
  }

  /**
   * @param string $last_inform_time
   * @return $this
   */
  public function setLastInformTime($last_inform_time)
  {
    $this->setAttribute("last_inform_time", $last_inform_time);
    return $this;
  }

  /**
   * @return string
   */
  public function getDump()
  {
    return $this->getAttribute("dump");
  }

  /**
   * @param string $dump
   * @return $this
   */
  public function setDump($dump)
  {
    $this->setAttribute("dump", $dump);
    return $this;
  }

  /**
   * @return int
   */
  public function getGroupId()
  {
    return $this->getAttribute("group_id");
  }

  /**
   * @param int $group_id
   * @return $this
   */
  public function setGroupId($group_id)
  {
    $this->setAttribute("group_id", $group_id);
    return $this;
  }

  /**
   * @return int
   */
  public function getStatusId()
  {
    return $this->getAttribute("status_id");
  }

  /**
   * @param int $status_id
   * @return $this
   */
  public function setStatusId($status_id)
  {
    $this->setAttribute("status_id", $status_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getFirmware()
  {
    return $this->getAttribute("firmware");
  }

  /**
   * @param string $firmware
   * @return $this
   */
  public function setFirmware($firmware)
  {
    $this->setAttribute("firmware", $firmware);
    return $this;
  }

  /**
   * @return int
   */
  public function getTemplateId()
  {
    return $this->getAttribute("template_id");
  }

  /**
   * @param int $template_id
   * @return $this
   */
  public function setTemplateId($template_id)
  {
    $this->setAttribute("template_id", $template_id);
    return $this;
  }

  /**
   * @return string
   */
  public function getDefaultGateway()
  {
    return $this->getAttribute("default_gateway");
  }

  /**
   * @param string $default_gateway
   * @return $this
   */
  public function setDefaultGateway($default_gateway)
  {
    $this->setAttribute("default_gateway", $default_gateway);
    return $this;
  }

  /**
   * @return int
   */
  public function getConnIndex()
  {
    return $this->getAttribute("conn_index");
  }

  /**
   * @param int $conn_index
   * @return $this
   */
  public function setConnIndex($conn_index)
  {
    $this->setAttribute("conn_index", $conn_index);
    return $this;
  }

  /**
   * @return int
   */
  public function getIgmp()
  {
    return $this->getAttribute("igmp");
  }

  /**
   * @param int $igmp
   * @return $this
   */
  public function setIgmp($igmp)
  {
    $this->setAttribute("igmp", $igmp);
    return $this;
  }

  /**
   * @return string
   */
  public function getMac()
  {
    return $this->getAttribute("mac");
  }

  /**
   * @param string $mac
   * @return $this
   */
  public function setMac($mac)
  {
    $this->setAttribute("mac", $mac);
    return $this;
  }

  /**
   * @return string
   */
  public function getReqPath()
  {
    return $this->getAttribute("req_path");
  }

  /**
   * @param string $req_path
   * @return $this
   */
  public function setReqPath($req_path)
  {
    $this->setAttribute("req_path", $req_path);
    return $this;
  }

  /**
   * @return int
   */
  public function getLastStatus()
  {
    return $this->getAttribute("last_status");
  }

  /**
   * @param int $last_status
   * @return $this
   */
  public function setLastStatus($last_status)
  {
    $this->setAttribute("last_status", $last_status);
    return $this;
  }

  /**
   * @return int
   */
  public function getStunStatus()
  {
    return $this->getAttribute("stun_status");
  }

  /**
   * @param int $stun_status
   * @return $this
   */
  public function setStunStatus($stun_status)
  {
    $this->setAttribute("stun_status", $stun_status);
    return $this;
  }

  /**
   * @return int
   */
  public function getUdpPort()
  {
    return $this->getAttribute("udp_port");
  }

  /**
   * @param int $udp_port
   * @return $this
   */
  public function setUdpPort($udp_port)
  {
    $this->setAttribute("udp_port", $udp_port);
    return $this;
  }

  /**
   * @return string
   */
  public function getUdpIp()
  {
    return $this->getAttribute("udp_ip");
  }

  /**
   * @param string $udp_ip
   * @return $this
   */
  public function setUdpIp($udp_ip)
  {
    $this->setAttribute("udp_ip", $udp_ip);
    return $this;
  }

  /**
   * @return string
   */
  public function getConnType()
  {
    return $this->getAttribute("conn_type");
  }

  /**
   * @param string $conn_type
   * @return $this
   */
  public function setConnType($conn_type)
  {
    $this->setAttribute("conn_type", $conn_type);
    return $this;
  }

  /**
   * @return string
   */
  public function getUpTime()
  {
    return $this->getAttribute("up_time");
  }

  /**
   * @param string $up_time
   * @return $this
   */
  public function setUpTime($up_time)
  {
    $this->setAttribute("up_time", $up_time);
    return $this;
  }

  /**
   * @return string
   */
  public function getTrVersion()
  {
    return $this->getAttribute("tr_version");
  }

  /**
   * @param string $tr_version
   * @return $this
   */
  public function setTrVersion($tr_version)
  {
    $this->setAttribute("tr_version", $tr_version);
    return $this;
  }

  /**
   * @return int
   */
  public function getConnIndexLte()
  {
    return $this->getAttribute("conn_index_lte");
  }

  /**
   * @param int $conn_index_lte
   * @return $this
   */
  public function setConnIndexLte($conn_index_lte)
  {
    $this->setAttribute("conn_index_lte", $conn_index_lte);
    return $this;
  }


}