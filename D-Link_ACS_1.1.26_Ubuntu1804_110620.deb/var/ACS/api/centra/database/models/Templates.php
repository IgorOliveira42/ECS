<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class Templates
 * @package Centra\Database\Models
 * @property integer id
 * @property string path
 * @property string name
 * @property string description
 */
class Templates extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'template';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id шаблона указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['path' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Путь конфигурации указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['name' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Название шаблона указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['description' => [
        'regexp' => Validator::PATTERN_STRING,
        'message' => 'Описание шаблона указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['path' => [
        'required' => true,
        'message' => 'Путь конфигурации не указано',
        'on' => [self::SCENARIO_CREATE]
      ]],
      ['name' => [
        'required' => true,
        'message' => 'Название шаблона не указано',
        'on' => [self::SCENARIO_CREATE]
      ]],
      ['id' => [
        'required' => true,
        'message' => 'Id шаблона не указано',
        'on' => [self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getPath()
  {
    return $this->getAttribute("path");
  }

  /**
   * @param string $path
   * @return $this
   */
  public function setPath($path)
  {
    $this->setAttribute("path", $path);
    return $this;
  }

  /**
   * @return string
   */
  public function getName()
  {
    return $this->getAttribute("name");
  }

  /**
   * @param string $name
   * @return $this
   */
  public function setName($name)
  {
    $this->setAttribute("name", $name);
    return $this;
  }

  /**
   * @return string
   */
  public function getDescription()
  {
    return $this->getAttribute("description");
  }

  /**
   * @param string $description
   * @return $this
   */
  public function setDescription($description)
  {
    $this->setAttribute("description", $description);
    return $this;
  }

}