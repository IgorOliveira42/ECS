<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class OperationType
 * @package Centra\Database\Models\Devices
 * @property integer id
 * @property string type_name
 */
class OperationTypes extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'operation_type';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id операции указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['type_name' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Название операции указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getTypeName()
  {
    return $this->getAttribute("type_name");
  }

  /**
   * @param string $type_name
   * @return $this
   */
  public function setTypeName($type_name)
  {
    $this->setAttribute("type_name", $type_name);
    return $this;
  }

}