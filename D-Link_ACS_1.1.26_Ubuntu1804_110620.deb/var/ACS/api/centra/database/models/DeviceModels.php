<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:16
 */

namespace Centra\Database\Models;

use Centra\Database\Main\ActiveRecord;
use Centra\Main\Utils\Validator;

/**
 * Class DeviceModels
 * @package Centra\Database\Models\DeviceModels
 * @property integer id
 * @property string name
 * @property string hw_version
 */
class DeviceModels extends ActiveRecord
{
  const SCENARIO_CREATE = 'create';
  const SCENARIO_UPDATE = 'update';

  public function table()
  {
    return 'model';
  }

  public static function rules()
  {
    return [
      ['id' => [
        'regexp' => Validator::PATTERN_INTEGER,
        'message' => 'Id модели указано неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['name' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Название модели указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
      ['hw_version' => [
        'regexp' => Validator::PATTERN_LATIN_STRING,
        'message' => 'Hw версия модели указан неверно',
        'on' => [self::SCENARIO_DEFAULT, self::SCENARIO_CREATE, self::SCENARIO_UPDATE]
      ]],
    ];
  }

  /**
   * @return int
   */
  public function getId()
  {
    return $this->getAttribute("id");
  }

  /**
   * @param int $id
   * @return $this
   */
  public function setId($id)
  {
    $this->setAttribute("id", $id);
    return $this;
  }

  /**
   * @return string
   */
  public function getName()
  {
    return $this->getAttribute("name");
  }

  /**
   * @param string $name
   * @return $this
   */
  public function setName($name)
  {
    $this->setAttribute("name", $name);
    return $this;
  }

  /**
   * @return string
   */
  public function getHwVersion()
  {
    return $this->getAttribute("hw_version");
  }

  /**
   * @param string $hw_version
   * @return $this
   */
  public function setHwVersion($hw_version)
  {
    $this->setAttribute("hw_version", $hw_version);
    return $this;
  }

}