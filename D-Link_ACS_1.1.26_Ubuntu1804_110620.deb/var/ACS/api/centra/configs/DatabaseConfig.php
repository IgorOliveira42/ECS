<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 05.10.18
 * Time: 18:01
 */

namespace Centra\Configs;

use Centra\Database\Interfaces\ConfigInterface;
use Centra\Main\Traits\Configurable;

class DatabaseConfig implements ConfigInterface
{
  use Configurable;

  public $host = "127.0.0.1";
  public $port = 3306;
  public $username = "root";
  public $password = "123";
  public $database = "ACSServer";

//    public $host;
//    public $port;
//    public $username;
//    public $password;
//    public $database;
    /*-------------------------------------------------*/
    function __construct() {
        if (!defined('HTTPD_CONF')) {
            define('HTTPD_CONF', '/etc/acs/config/acs.conf');
        }
        $lines = file(HTTPD_CONF);
        $config = array();
        foreach ($lines as $l) {
            preg_match("/^(?P<key>\w+)+(?P<value>.*)/", $l, $matches);
            if (isset($matches['key'])) {
                $config[$matches['key']] = $matches['value'];
            }
        }
//        $this->database =  DatabaseConfig::getThePart($config["DatabaseName"],'=');
//        $this->username =  DatabaseConfig::getThePart($config["username"],'=');
//        $this->password =  DatabaseConfig::getThePart($config["password"],'=');
//        $this->port =  DatabaseConfig::getThePart($config["DatabasePort"],'=');
//        $this->host =  DatabaseConfig::getThePart($config["host"],'=');
    }

  /**
   * @return null
   */
  public function getHost()
  {
    return $this->host;
  }

  /**
   * @param null $host
   * @return $this
   */
  public function setHost($host)
  {
    $this->host = $host;
    return $this;
  }

  /**
   * @return null
   */
  public function getPort()
  {
    return $this->port;
  }

  /**
   * @param null $port
   * @return $this
   */
  public function setPort($port)
  {
    $this->port = $port;
    return $this;
  }

  /**
   * @return null
   */
  public function getUsername()
  {
    return $this->username;
  }

  /**
   * @param null $username
   * @return $this
   */
  public function setUsername($username)
  {
    $this->username = $username;
    return $this;
  }

  /**
   * @return null
   */
  public function getPassword()
  {
    return $this->password;
  }

  /**
   * @param null $password
   * @return $this
   */
  public function setPassword($password)
  {
    $this->password = $password;
    return $this;
  }

  /**
   * @return null
   */
  public function getDatabase()
  {
    return $this->database;
  }

  /**
   * @param null $database
   * @return $this
   */
  public function setDatabase($database)
  {
    $this->database = $database;
    return $this;
  }

    static function getThePart($str,$delimiter) {
        $str = str_replace(" ","",$str);
        $delimPos = strpos($str,$delimiter);
        return substr($str,$delimPos+1,strlen($str));
    }

}