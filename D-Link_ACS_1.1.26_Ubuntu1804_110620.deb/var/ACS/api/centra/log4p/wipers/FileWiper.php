<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 28.08.18
 * Time: 10:00
 */

namespace Centra\Log4p\Wipers;

use Centra\Log4p\Interfaces\PrinterInterface;
use Centra\Log4p\Interfaces\WiperInterface;
use Centra\Log4p\Printers\FilePrinter;
use Centra\Main\Exceptions\IOException;
use Centra\Main\Exceptions\ProcessException;
use Centra\Main\Traits\Configurable;

/**
 * Class FileWiper
 * @package Centra\Log4p\Wipers
 * @property string max_size
 * @property integer max_parts
 */
class FileWiper implements WiperInterface
{
  use Configurable;

  const SIZE_GIGABYTES = 1073741824;
  const SIZE_MEGABYTES = 1048576;
  const SIZE_KILOBYTES = 1024;
  const GIGABYTES_SUFFIX = 'G';
  const MEGABYTES_SUFFIX = 'M';
  const KILOBYTES_SUFFIX = 'K';
  public $max_size = null;
  public $max_parts = null;

  /**
   * Выполняет очистку принтеров
   * @param PrinterInterface $printer
   * @return bool
   * @throws IOException
   * @throws ProcessException
   */
  public function clean(PrinterInterface $printer)
  {
    $path = $printer->getDirectory() . FilePrinter::DIRECTORY_DELIMITER . $printer->getName();
    if(!file_exists($path))
     return false;
    $maxSize = $this->getMaxFileSize();
    $fileInfo = pathinfo($path);
    if(filesize($path) > $maxSize){
      $this->moveOldParts($fileInfo);
      $this->moveFile($path);
      $this->checkOldParts($fileInfo);
      $this->makeNew($path);
    }
    return true;
  }

  /**
   * Создает новый файл после ротации
   * @param $path
   * @throws IOException
   */
  private function makeNew($path){
    if(!file_put_contents($path, ''))
      throw new IOException("не удалось создать файл " . $path);
  }

  /**
   * Перемещает файл в новый чанк.
   * @param $path
   * @throws IOException
   */
  private function moveFile($path)
  {
    $originalPath = $path;
    $iterate = 0;
    while(file_exists($path)){
      $iterate++;
      $path =  $originalPath . '.' . $iterate;
    }
    if(!rename($originalPath, $path))
      throw new IOException("не удалось переименовать файл " . $originalPath);
  }

  /**
   * Переносит логи смещая итератор названия файла
   * @param $fileInfo
   * @throws IOException
   */
  private function moveOldParts($fileInfo)
  {
    $directory = $fileInfo['dirname'];
    $filename = $fileInfo['basename'];
    foreach (scandir($fileInfo['dirname'], SCANDIR_SORT_DESCENDING) as $item)
      if(preg_match("/($filename\.)([0-9]+)$/", $item, $match)){
        list($name, $tinyName, $index) = $match;
        $oldPath = $directory . FilePrinter::DIRECTORY_DELIMITER . $name;
        $newPath = $directory . FilePrinter::DIRECTORY_DELIMITER . $tinyName . ++$index;
        if(!rename($oldPath, $newPath))
          throw new IOException("не удалось переименовать файл " . $oldPath);
      }
  }

  /**
   * Проверяет наличие файлов для данного принтера
   * @param $fileInfo
   */
  private function checkOldParts($fileInfo)
  {
    foreach (scandir($fileInfo['dirname']) as $item)
      $this->deleteOldPart($fileInfo, $item);
  }

  /**
   * Удаляет старый файл с индеском
   * @param $fileInfo
   * @param $item
   */
  private function deleteOldPart($fileInfo, $item)
  {
    $filename = $fileInfo['basename'];
    if(preg_match("/($filename\.)([0-9]+)$/", $item, $match)){
      list($name, $tail, $index) = $match;
      if($index > $this->getMaxParts())
        unlink($fileInfo['dirname'] . FilePrinter::DIRECTORY_DELIMITER . $name);
    }
  }

  /**
   * Получает максимальное значение для файла
   * @return float|int
   * @throws ProcessException
   */
  private function getMaxFileSize()
  {
    $suffix = implode("|", [self::KILOBYTES_SUFFIX, self::MEGABYTES_SUFFIX, self::GIGABYTES_SUFFIX]);
    if(preg_match("/^([0-9]+)($suffix)$/", $this->getMaxSize(), $match)){
      list($tail, $size, $suffix) = $match;
      if($suffix == self::KILOBYTES_SUFFIX)
        return $size * self::SIZE_KILOBYTES;
      if($suffix == self::MEGABYTES_SUFFIX)
        return $size * self::SIZE_MEGABYTES;
      if($suffix == self::GIGABYTES_SUFFIX)
        return $size * self::SIZE_GIGABYTES;
    }
    throw new ProcessException("Значение maxSize указано неверно.");
  }

  /**
   * @return string
   */
  public function getMaxSize()
  {
    return $this->max_size;
  }

  /**
   * @param string $max_size
   * @return FileWiper $this;
   */
  public function setMaxSize($max_size)
  {
    $this->max_size = $max_size;
    return $this;
  }

  /**
   * @return int
   */
  public function getMaxParts()
  {
    return $this->max_parts;
  }

  /**
   * @param int $max_parts
   * @return FileWiper $this;
   */
  public function setMaxParts($max_parts)
  {
    $this->max_parts = $max_parts;
    return $this;
  }
}