<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:56
 */

namespace Centra\Log4p\Interfaces;

interface ConfigInterface
{
  public function getPrinter();
  public function getFilter();
  public function getWiper();
  public function setPrinter(PrinterInterface $printer);
  public function setFilter(FilterInterface $filter);
  public function setWiper(WiperInterface $wiper);
}