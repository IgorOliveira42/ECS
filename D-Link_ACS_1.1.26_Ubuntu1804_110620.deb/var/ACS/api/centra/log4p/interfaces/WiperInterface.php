<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:56
 */

namespace Centra\Log4p\Interfaces;

interface WiperInterface
{
  public function clean(PrinterInterface $printer);
  public function getMaxSize();
  public function getMaxParts();
  public function setMaxSize($size);
  public function setMaxParts($parts);

}