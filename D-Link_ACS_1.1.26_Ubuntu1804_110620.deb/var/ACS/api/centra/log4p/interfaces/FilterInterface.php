<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:56
 */

namespace Centra\Log4p\Interfaces;

interface FilterInterface
{
  public function match(MessageInterface $message);
  public function getChannel();
  public function getType();
  public function isSpecific();
  public function getClassMatchLength(MessageInterface $message);
  public function setChannel($channel);
  public function setType($type);
  public function setSpecific($unique);
}