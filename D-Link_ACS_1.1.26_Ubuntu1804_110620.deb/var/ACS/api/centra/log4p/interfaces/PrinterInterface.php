<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:56
 */

namespace Centra\Log4p\Interfaces;

interface PrinterInterface
{

  public function write(MessageInterface $message);
  public function getDirectory();
  public function getName();
  public function isEcho();
  public function isTimestamp();
  public function getPermission();
  public function isSkip();
  public function getMessageLength();
  public function getEndLengthMessage();
  public function isTrace();
  public function isRequest();
  public function isServer();
  public function setDirectory($directory);
  public function setName($name);
  public function setEcho($set);
  public function setTimestamp($set);
  public function setPermission($permission);
  public function setSkipLength($set);
  public function setMessageLength($length);
  public function setEndLengthMessage($message);
  public function setTrace($set);
  public function setRequest($set);
  public function setServer($set);
  public function setSkip($set);
}