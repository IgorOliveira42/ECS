<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 11:30
 */

namespace Centra\Log4p\Printers;

use Centra\Log4p\Interfaces\MessageInterface;
use Centra\Log4p\Interfaces\PrinterInterface;
use Centra\Main\Exceptions\ClassException;
use Centra\Main\Exceptions\IOException;
use Centra\Http\Main\Request;
use Centra\Main\Traits\Configurable;
use Centra\Main\Utils\StringBuilder;

/**
 * Class FilePrinter
 * @package Centra\Log4p\Printers
 * @property string $directory
 * @property string $name
 * @property bool $echo
 * @property bool $timestamp
 * @property string $permission
 * @property string $skipLength
 * @property integer $messageLength
 * @property bool $trace
 * @property bool $request
 * @property bool $server
 * @property bool $skip
 */
class FilePrinter implements PrinterInterface
{
  use Configurable;

  const DIRECTORY_DELIMITER = "/";
  const PERMISSION_START = -4;
  const PERMISSION_FORMAT = '%o';
  const STRING_DELIMITER = "\n";
  const COLUMN_DELIMITER = "\t";
  const PAIR_DELIMITER = " => ";
  const SERVER_TITLE = "\n---SERVER_VARIABLES---\n";
  const REQUEST_TITLE = "\n---REQUEST_VARIABLES---\n";
  const TRACE_TITLE = "\n---TRACE---\n";
  public $directory = null;
  public $name = null;
  public $echo = null;
  public $timestamp = null;
  public $permission = null;
  public $skipLength = null;
  public $messageLength = null;
  public $endLengthMessage = "\n---Обрезано---";
  public $trace = null;
  public $request = null;
  public $server = null;
  public $skip = null;

  /**
   * Производит запись в файл.
   * @param MessageInterface $message
   * @return bool
   * @throws IOException
   * @throws ClassException
   */
  public function write(MessageInterface $message)
  {
    if($this->isSkip())
      return true;
    $this->checkDirectory();
    $text = $this->getString($message);
    $text = $this->addDate($text);
    $text = $this->addEcho($text);
    $text = $this->trimLength($text);
    if($this->isTrace())
      $text = $this->addTrace($text, $message);
    if($this->isRequest())
      $text = $this->addRequest($text);
    if($this->isServer())
      $text = $this->addServer($text);
    $text .= self::STRING_DELIMITER;
    $fillPath = $this->getDirectory() . self::DIRECTORY_DELIMITER . $this->getName();
    if (!file_put_contents($fillPath, $text, FILE_APPEND))
      throw new IOException("Не удалось записать в файл" . $fillPath);
    return true;
  }

  /**
   * Добавляет дату время
   * @param $text
   * @return string
   */
  private function addDate($text)
  {
    $date = (new \Datetime())->format("Y-m-d H:i:s");
    return $this->isTimestamp() ? ($date . self::COLUMN_DELIMITER . $text) : $text;
  }

  /**
   * Выводит сообщение в stdout
   * @param $text
   * @return mixed
   */
  private function addEcho($text)
  {
    if ($this->isEcho())
      echo $text;
    return $text;
  }

  /**
   * Добавляет трассировку от исключения
   * @param $text
   * @param MessageInterface $message
   * @return string
   */
  private function addTrace($text, MessageInterface $message)
  {
    $text .= self::TRACE_TITLE;
    foreach ($message->getTrace() as $trace){
      /** @var StringBuilder $stringBuilder */
      $stringBuilder = new StringBuilder();
      $stringBuilder
        ->add($text)
        ->add($trace['line'])
        ->add(self::COLUMN_DELIMITER)
        ->add($trace['class'])
        ->add($trace['type'])
        ->add($trace['function'])
        ->add('(')->add($trace['file'])->add(')')
        ->next();
      $text = $stringBuilder->get();
    }
    return $text;
  }

  /**
   * Добавляет данные запроса
   * @param $text
   * @return string
   * @throws ClassException
   */
  private function addRequest($text)
  {
    /** @var StringBuilder $stringBuilder */
    $stringBuilder = new StringBuilder();
    $stringBuilder->add($text)->add(self::REQUEST_TITLE);
    foreach (\request() as $key => $value)
      if(!empty($key))
        $stringBuilder->add($key)->add(self::PAIR_DELIMITER)->add($value)->next();
    return $stringBuilder->get();
  }

  /**
   * Добавляет данные сервера
   * @param $text
   * @return string
   */
  private function addServer($text)
  {
    /** @var StringBuilder $stringBuilder */
    $stringBuilder = new StringBuilder();
    $stringBuilder->add($text)->add(self::SERVER_TITLE);
    foreach (Request::getServer() as $key => $value)
      if(!empty($key))
        $stringBuilder->add($key)->add(self::PAIR_DELIMITER)->add($value)->next();
    return $stringBuilder->get();
  }

  /**
   * Производит обрезку длинных сообщений до указанной длинны
   * @param string $text
   * @return string
   */
  private function trimLength($text)
  {
    $needTrim = ($this->getSkipLength() > 0 && mb_strlen($text) > $this->getSkipLength());
    $text =  $needTrim ? mb_substr($text, 0, $this->getSkipLength()) . $this->getEndLengthMessage() : $text;
    return $text;
  }

  /**
   * Проверяет сущестование директорий и создает необходимые
   * @throws IOException
   */
  private function checkDirectory()
  {
    $result = null;
    if(!file_exists($this->getDirectory()))
      if(!mkdir($this->getDirectory(), $this->getPermission(), true))
        throw new IOException("Не удалось создать директорию: " . $this->getDirectory());
  }


  /**
   * Форматирует сообшение в логе в строку
   * @param MessageInterface $message
   * @return string
   */
  private function getString(MessageInterface $message)
  {
    $text = !empty($message->getChannel())  ? $message->getChannel() : $message->getClass();
    $text .= self::COLUMN_DELIMITER;
    $messageObject = $message->getMessage();
    if (is_array($messageObject))
      $text .= json_encode($messageObject, JSON_UNESCAPED_UNICODE);
    else if (is_object($messageObject))
      $text .= json_encode(get_object_vars($messageObject), JSON_UNESCAPED_UNICODE);
    else
      $text .= $messageObject;
    return $text;
  }

  /**
   * @return string
   */
  public function getDirectory()
  {
    return $this->directory;
  }

  /**
   * @param string $directory
   * @return FilePrinter $this;
   */
  public function setDirectory($directory)
  {
    $this->directory = $directory;
    return $this;
  }

  /**
   * @return string
   */
  public function getName()
  {
    return $this->name;
  }

  /**
   * @param string $name
   * @return FilePrinter $this;
   */
  public function setName($name)
  {
    $this->name = $name;
    return $this;
  }

  /**
   * @return bool
   */
  public function isEcho()
  {
    return $this->echo;
  }

  /**
   * @param bool $echo
   * @return FilePrinter $this;
   */
  public function setEcho($echo)
  {
    $this->echo = $echo;
    return $this;
  }

  /**
   * @return bool
   */
  public function isTimestamp()
  {
    return $this->timestamp;
  }

  /**
   * @param bool $timestamp
   * @return FilePrinter $this;
   */
  public function setTimestamp($timestamp)
  {
    $this->timestamp = $timestamp;
    return $this;
  }

  /**
   * @return string
   */
  public function getPermission()
  {
    return $this->permission;
  }

  /**
   * @param string $permission
   * @return FilePrinter $this;
   */
  public function setPermission($permission)
  {
    $this->permission = $permission;
    return $this;
  }

  /**
   * @return string
   */
  public function getSkipLength()
  {
    return $this->skipLength;
  }

  /**
   * @param string $skipLength
   * @return FilePrinter $this;
   */
  public function setSkipLength($skipLength)
  {
    $this->skipLength = $skipLength;
    return $this;
  }

  /**
   * @return int
   */
  public function getMessageLength()
  {
    return $this->messageLength;
  }

  /**
   * @param int $messageLength
   * @return FilePrinter $this;
   */
  public function setMessageLength($messageLength)
  {
    $this->messageLength = $messageLength;
    return $this;
  }

  /**
   * @return string
   */
  public function getEndLengthMessage()
  {
    return $this->endLengthMessage;
  }

  /**
   * @param string $endLengthMessage
   * @return FilePrinter $this;
   */
  public function setEndLengthMessage($endLengthMessage)
  {
    $this->endLengthMessage = $endLengthMessage;
    return $this;
  }

  /**
   * @return bool
   */
  public function isTrace()
  {
    return $this->trace;
  }

  /**
   * @param bool $trace
   * @return FilePrinter $this;
   */
  public function setTrace($trace)
  {
    $this->trace = $trace;
    return $this;
  }

  /**
   * @return bool
   */
  public function isRequest()
  {
    return $this->request;
  }

  /**
   * @param bool $request
   * @return FilePrinter $this;
   */
  public function setRequest($request)
  {
    $this->request = $request;
    return $this;
  }

  /**
   * @return bool
   */
  public function isServer()
  {
    return $this->server;
  }

  /**
   * @param bool $server
   * @return FilePrinter $this;
   */
  public function setServer($server)
  {
    $this->server = $server;
    return $this;
  }

  /**
   * @return bool
   */
  public function isSkip()
  {
    return $this->skip;
  }

  /**
   * @param bool $skip
   * @return FilePrinter $this;
   */
  public function setSkip($skip)
  {
    $this->skip = $skip;
    return $this;
  }
}