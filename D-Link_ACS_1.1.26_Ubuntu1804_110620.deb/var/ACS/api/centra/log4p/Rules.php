<?php

namespace Centra\Log4p;

use Centra\Log4p\Configs\InfoApiFileConfig;
use Centra\Log4p\Configs\DebugApiFileConfig;
use Centra\Main\Store;
use Centra\Log4p\Interfaces\MessageInterface;
use Centra\Log4p\Interfaces\FilterInterface;
use Centra\Log4p\Interfaces\PrinterInterface;
use Centra\Log4p\Interfaces\WiperInterface;
use Centra\Log4p\Main\Message;
use Centra\Log4p\Main\ConfigItems;
use Centra\Log4p\Main\Parser;
use Centra\Log4p\Filters\Filter;
use Centra\Log4p\Printers\FilePrinter;
use Centra\Log4p\Wipers\FileWiper;
use Centra\Log4p\Configs\InfoFileConfig;
use Centra\Log4p\Configs\DebugFileConfig;

class Rules
{

  /**
   * Собирает правила маршрутизации для апи
   * Rules constructor.
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function init()
  {
    Store::init()->bind(MessageInterface::class, Message::class);
    Store::init()->bind(FilterInterface::class, Filter::class);
    Store::init()->bind(PrinterInterface::class, FilePrinter::class);
    Store::init()->bind(WiperInterface::class, FileWiper::class);

    /** @var ConfigItems $configs */
    $configs = Store::init()->make(ConfigItems::class);
    $configs->setConfig(new InfoFileConfig());
    $configs->setConfig(new DebugFileConfig());
    $configs->setConfig(new InfoApiFileConfig());
    $configs->setConfig(new DebugApiFileConfig());
    Store::init()->make(Parser::class, $configs);
  }
}
