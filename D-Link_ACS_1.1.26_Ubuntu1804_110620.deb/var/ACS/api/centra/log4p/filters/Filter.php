<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 11:30
 */

namespace Centra\Log4p\Filters;

use Centra\Log4p\Interfaces\FilterInterface;
use Centra\Log4p\Interfaces\MessageInterface;
use Centra\Main\Traits\Configurable;

/**
 * Class Filter
 * @package Centra\Log4p\Filters
 * @property string $type
 * @property string $channel
 * @property bool specific
 */
class Filter implements FilterInterface
{
  use Configurable;

  public $type = null;
  public $channel = '.';
  public $specific = true;

  public function match(MessageInterface $message)
  {
    $filterChannel = $this->getChannel();
    $messageChannel = !empty($message->getChannel()) ? $message->getChannel() : $message->getClass();
    if(is_array($filterChannel))
      $match = $this->arrayCheck($filterChannel, $message, $messageChannel);
    else
      $match = $message->getType() == $this->getType() && preg_match("/$filterChannel/u", $messageChannel);
    return $match;
  }

  private function arrayCheck($pattern, MessageInterface $message, $messagePattern)
  {
    $match = false;
    foreach ($pattern as $item)
      if($message->getType() == $this->getType() && preg_match("/$item/u", $messagePattern))
        $match = true;
    return $match;
  }

  public function getClassMatchLength(MessageInterface $message)
  {
    $filterChannel = $this->getChannel();
    $messagePattern = !empty($message->getChannel()) ? $message->getChannel() : $message->getClass();
    $length = 0;
    if(is_array($filterChannel)){
      foreach ($filterChannel as $item){
        preg_match("/$item/u", $messagePattern, $match);
        $newLength = mb_strlen(array_pop($match));
        $length = $newLength > $length ? $newLength : $length;
      }
    } else {
      preg_match("/$filterChannel/u", $messagePattern, $match);
      $length = mb_strlen(array_pop($match));
    }
    return $length;
  }

  /**
   * @return string
   */
  public function getType()
  {
    return $this->type;
  }

  /**
   * @param string $type
   * @return Filter $this;
   */
  public function setType($type)
  {
    $this->type = $type;
    return $this;
  }

  /**
   * @return string
   */
  public function getChannel()
  {
    return $this->channel;
  }

  /**
   * @param string $channel
   * @return Filter $this;
   */
  public function setChannel($channel)
  {
    $this->channel = $channel;
    return $this;
  }

  /**
   * @return bool
   */
  public function isSpecific()
  {
    return $this->specific;
  }

  /**
   * @param bool $specific
   * @return Filter $this;
   */
  public function setSpecific($specific)
  {
    $this->specific = $specific;
    return $this;
  }
}