<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 11:07
 */

namespace Centra\Log4p\Main;

use Centra\Log4p\Interfaces\ConfigInterface;

class ConfigItems
{
  public $configs = [];

  public function getConfigs()
  {
    return $this->configs;
  }

  public function setConfig(ConfigInterface $config)
  {
    $this->configs[] = $config;
  }

  public function clear()
  {
    $this->configs = [];
  }
}