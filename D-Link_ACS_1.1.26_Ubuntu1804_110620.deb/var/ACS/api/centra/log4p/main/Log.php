<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 9:52
 */

namespace Centra\Log4p\Main;

use Centra\Main\Store;
use Centra\Main\Traits\Configurable;
use Centra\Main\Utils\StringUtils;
use Centra\Log4p\Interfaces\MessageInterface;

class Log
{
  use Configurable;
  const TYPE_INFO = 'info';
  const TYPE_ERROR = 'error';
  const TYPE_DEBUG = 'debug';
  const TYPE_TRACE = 'trace';
  const TRACE_METHOD_INDEX = 4;
  const CLASS_DELIMITER = "\\";
  const EXCEPTION_MESSAGE = 'Ошибка: ';
  protected static $instance = null;
  protected $channel = null;

  /**
   * Получает сообщение информации
   * @param string|array|object|\Exception $message
   * @param string $channel
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function info($message, $channel = null)
  {
    /** @var Log $model */
    $model = self::$instance;
    if (is_null($channel) && !is_null($model))
      $channel = $model->getChannel();
    /** @var MessageInterface $messageItem */
    $messageItem = Store::init()->get(MessageInterface::class, true);
    $messageItem->setType(self::TYPE_INFO);
    $messageItem->setMessage($message);
    $messageItem->setChannel($channel);
    self::make($messageItem);
  }

  /**
   * Получает сообщение ошибки
   * @param string|array|object $message
   * @param string $channel
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function error($message, $channel = null)
  {
    /** @var Log $model */
    $model = self::$instance;
    if (is_null($channel) && !is_null($model))
      $channel = $model->getChannel();
    /** @var MessageInterface $messageItem */
    $messageItem = Store::init()->get(MessageInterface::class, true);
    $messageItem->setType(self::TYPE_ERROR);
    $messageItem->setMessage($message);
    $messageItem->setChannel($channel);
    self::make($messageItem);
  }

  /**
   * Получает сообщение дебага
   * @param string|array|object $message
   * @param string $channel
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function debug($message, $channel = null)
  {
    /** @var Log $model */
    $model = self::$instance;
    if (is_null($channel) && !is_null($model))
      $channel = $model->getChannel();
    /** @var MessageInterface $messageItem */
    $messageItem = Store::init()->get(MessageInterface::class, true);
    $messageItem->setType(self::TYPE_DEBUG);
    $messageItem->setMessage($message);
    $messageItem->setChannel($channel);
    self::make($messageItem);
  }

  /**
   * Получает сообщение трасировки
   * @param string|array|object $message
   * @param string $channel
   * @throws \Centra\Main\Exceptions\ClassException
   */
  public static function trace($message, $channel = null)
  {
    /** @var Log $model */
    $model = self::$instance;
    if (is_null($channel) && !is_null($model))
      $channel = $model->getChannel();
    /** @var MessageInterface $messageItem */
    $messageItem = Store::init()->get(MessageInterface::class, true);
    $messageItem->setType(self::TYPE_TRACE);
    $messageItem->setMessage($message);
    $messageItem->setChannel($channel);
    self::make($messageItem);
  }

  /**
   * Собирает данные для обработки сообщения
   * @param MessageInterface $messageItem
   * @param \Exception|null $exception
   * @throws \Centra\Main\Exceptions\ClassException
   */
  private static function make(MessageInterface $messageItem)
  {
    self::addTrace($messageItem);
    self::addClass($messageItem);
    self::save($messageItem);
  }

  /**
   * В случае если сообщение являеться исключением добавить трасировку
   * @param MessageInterface $messageItem
   * @param \Exception|null $exception
   */
  private static function addTrace(MessageInterface $messageItem)
  {
    /** @var \Exception $exception */
    $exception = $messageItem->getMessage();
    if ($messageItem->getMessage() instanceof \Exception) {
      $messageItem->setMessage(self::EXCEPTION_MESSAGE . $exception->getMessage());
      $trace = array_merge([
        [
          'file'     => $exception->getFile(),
          'line'     => $exception->getLine(),
          'function' => ''
        ]
      ], $exception->getTrace());
      $messageItem->setTrace($trace);
    }
  }

  /**
   * Добавляет класс вызывавший сообщение
   * @param MessageInterface $messageItem
   */
  private static function addClass(MessageInterface $messageItem)
  {
    $traces = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, self::TRACE_METHOD_INDEX);
    $trace = array_pop($traces);
    if (!empty($trace)) {
      $classname = !empty($trace['class']) ? $trace['class'] . '.' . $trace['function'] : $trace['function'];
      $classname = mb_strtolower($classname);
      $classname = StringUtils::changeDelimiter($classname, self::CLASS_DELIMITER);
      $messageItem->setClass($classname);
    }
  }

  /**
   * Отправляем сообщение на обработку
   * @param MessageInterface $messageItem
   * @throws \Centra\Main\Exceptions\ClassException
   */
  private static function save(MessageInterface $messageItem)
  {
    /** @var Parser $parser */
    $parser = \store(Parser::class);
    $parser->send($messageItem);
  }

  public static function getInstance($channel = null)
  {
    self::$instance = new self(['channel' => $channel]);
    return self::$instance;
  }

  /**
   * @return null
   */
  public function getChannel()
  {
    return $this->channel;
  }

  /**
   * @param null $channel
   * @return $this
   */
  public function setChannel($channel)
  {
    $this->channel = $channel;
    return $this;
  }

}