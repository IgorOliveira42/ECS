<?php
/**
 * Created by PhpStorm.
 * User: iseed
 * Date: 27.08.18
 * Time: 12:22
 */

namespace Centra\Log4p\Main;

use Centra\Log4p\Interfaces\ConfigInterface;
use Centra\Log4p\Interfaces\FilterInterface;
use Centra\Log4p\Interfaces\MessageInterface;
use Centra\Log4p\Interfaces\PrinterInterface;

class Parser
{
  private $configs = [];

  /**
   * Получим правила маршрутизации на вход
   * Parser constructor.
   * @param ConfigItems $configs
   */
  public function __construct(ConfigItems $configs)
  {
    $this->setConfigs($configs->getConfigs());
  }

  /**
   * Отправил на печать на нужные конфиги сообщение
   * @param MessageInterface $message
   */
  public function send(MessageInterface $message)
  {
    $configs = $this->getActiveConfigs($message);
    /** @var ConfigInterface $config */
    foreach ($configs as $config){
      /** @var PrinterInterface $printer */
      $printer = $config->getPrinter();
      $printer->write($message);
    }
  }

  /**
   * Поулчил все конфиги котоыре проходят фильтр
   * @param MessageInterface $message
   * @return array
   */
  public function getActiveConfigs(MessageInterface $message)
  {
    $activeItems = [];
    /** @var ConfigInterface $config */
    foreach ($this->getConfigs() as $config){
      /** @var FilterInterface $filter */
      $filter = $config->getFilter();
      if(!$filter->match($message))
        continue;
      $activeItems[] = $config;
    }
    $configItems = $this->getSpecifics($activeItems, $message);
    return $configItems;
  }

  /**
   * Проверяет на более специфичный фильтр
   * @param $activeItems
   * @param MessageInterface $message
   * @return array
   */
  private function getSpecifics($activeItems, MessageInterface $message)
  {
    $configItems = [];
    $length = 0;
    /** @var ConfigInterface $config */
    foreach ($activeItems as $config){
      /** @var FilterInterface $filter */
      $filter = $config->getFilter();
      $matchLength = $filter->getClassMatchLength($message);
      if(!$filter->isSpecific()){
        $oldFilter = $filter;
        $configItems = [$config];
      } else if(empty($oldFilter)){
        $oldFilter = $filter;
        $configItems = [$config];
      } else if($matchLength > $length){
        $length = $matchLength;
        $configItems = [$config];
      }
    }
    return $configItems;
  }


  /**
   * @return array
   */
  public function getConfigs()
  {
    return $this->configs;
  }

  /**
   * @param array $configs
   * @return $this
   */
  public function setConfigs(array $configs)
  {
    $this->configs = $configs;
    return $this;
  }

}