function initPopoverActivity() {
    if ($('.container_activity .popover').hasClass('in')) {
        ishidden = false;
    } else {        ishidden = true;    }

    if (ishidden == true) {
        var content = $('.container_activity .popover-content');
        var html = content.html();

        $('.activitySettingPopover').html(html);

        $('.activitySettingPopover select').each(function (i) {
            var sel = $('.container_activity .popover-content select').eq(i).val();
            $(this).val(sel);
        });
        $("#demo1-1").addClass("for_all_display_none");
        $("#demo1-1").html('');

    } else {
        var language = '';
        var KalendarLang = $("input[name='KalendarLanguage']").val();
        if (KalendarLang == 'ru') {
            language = 'de';
        } else {
            language = 'en';
        }

        function logEvent(type, date) {
            $("<div class='log__entry'/>").hide().html("<strong>" + type + "</strong>: " + date).prependTo($('#eventlog')).show(200);
        }

        $('#clearlog').click(function () {
            $('#eventlog').html('');
        });
        $('#demo1-1').datetimepicker({
            language: language,
            //date: new Date(),
            viewMode: 'YMDHMS',
            onDisplayUpdate: function () {
                logEvent('onDisplayUpdate', this.getDisplayDate());
            },
            //date selection event
            onDateChange: function () {
                logEvent('onDateChange', this.getValue());
                $('#datetimepicker_mask').val(this.getText('yyyy-MM-dd HH:mm:ss'));
                if ($("#datetimepicker_mask").val() != '') {
                    $(".selectTimeForActivity").show();
                } else {
                    $(".selectTimeForActivity").hide();
                }
            },
            //clear button click event
            onClear: function () {
                logEvent('onClear', this.getValue());
            },
            //ok button click event
            onOk: function () {
                logEvent('onOk', this.getValue());
            },
            //close button click event
            onClose: function () {
                logEvent('onClose', this.getValue());
            },
            //today button click event
            onToday: function () {
                logEvent('onToday', this.getValue());
            },
        });

        $('.container_activity .popover-content select').each(function (i) {
            var sel = $('.activitySettingPopover select').eq(i).val();
            $(this).val(sel);
        })

        //$('.activitySettingPopover').empty();

    }
}


$(document).ready(function () {
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });

    $('#activityPopover').popover({
        html: true,
        content: function () {
            html = $('.activitySettingPopover').html();
            return html;
        }
    });

    $('#activityPopover').on('click', function (e) {
        initPopoverActivity();
    });

    $(window).resize(function () {
        $(".popover").each(function () {
            var popover = $(this);
            if (popover.is(":visible")) {
                var ctrl = $(popover.context);
                ctrl.popover('hide');
                initPopoverActivity();
            }
        });
    });

    $('#activityPopover').popover().on('hide.bs.popover', function () {
        if ($(".popover").is(":visible")) {
            $("#demo1-1").addClass("for_all_display_none");
            $("#demo1-1").html('');
            var content = $('.container_activity .popover-content');
            var html = content.html();
            $('.activitySettingPopover').html(html);

            $('.activitySettingPopover select').each(function (i) {
                var sel = $('.container_activity .popover-content select').eq(i).val();
                $(this).val(sel);
            });
        }
    });

    $(document).on("input", "#datetimepicker_mask", function () {
        if ($("#datetimepicker_mask").val() != '') {
            $(".selectTimeForActivity").show();
        } else {
            $(".selectTimeForActivity").hide();
        }
    });


    /*
        $('#activityPopover').popover({
            html : true,
            content: function() {
                return $('.activitySettingPopover').html();
            }
        });

        $('#activityPopover').click(function (e) {
             e.stopPropagation();
        });

        $('#activityPopover').on('show.bs.popover', function () {
            var macVal = $("input[name='macVal']").val();
            var modelVal = $("input[name='modelVal']").val();
            var taskVal = $("input[name='taskVal']").val();
            var statusVal = $("input[name='statusVal']").val();
            $('.macType option').removeAttr('selected').filter('[value="'+macVal+'"]').attr('selected', true);
            $('.modelTypeActivity option').removeAttr('selected').filter('[value="'+modelVal+'"]').attr('selected', true);
            $('.taskType option').removeAttr('selected').filter('[value="'+taskVal+'"]').attr('selected', true);
            $('.statusType option').removeAttr('selected').filter('[value="'+statusVal+'"]').attr('selected', true);
        });

        $('#activityPopover').popover().on('hide.bs.popover', function () {
            $("input[name='macVal']").val($(".macType option:selected").val());
            $("input[name='modelVal']").val($(".modelTypeActivity option:selected").val());
            $("input[name='taskVal']").val($(".taskType option:selected").val());
            $("input[name='statusVal']").val($(".statusType option:selected").val());
        });
    */


    function isCompletedConfigOrLogDownload(actType,status){
        if((actType.trim().indexOf("logUp") == 0 && actType.trim().length == 5 || actType.trim().indexOf("configUp") == 0 && actType.trim().length == 8 ) && status==2) {
            return true;
        } else {
            return false;
        }
    }
    function isUpdateConfigOrFW(actType){
        if(actType.trim().indexOf("config") == 0 && actType.trim().length == 6 || actType.trim().indexOf("firmware") == 0 && actType.trim().length == 8 ) {
            return true;
        } else {
            return false;
        }
    }
    $(document).on("click", ".activityDev", function () {
        $("body").css("cursor", "wait");
        var th = $(this);
        var actType = $(this).closest('td').find("input[name='activityTypeName']").val();
        var actStatus = $(this).parent().find("input[name='activityTypeStatus']").val();
        var deviceID = $(this).parent().find("input[name='devID']").val();
        var activityID = $(this).parent().find("input[name='activityID']").val();

        if (actType.trim().indexOf("set") == 0 && actType.trim().length == 3 || isCreateVlan(actType) || isDeleteVlanOrPort(actType) ) {

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getAllParamsValuesByActivityID.php",
                data: {
                    'activityID': activityID,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        th.closest('tr').next('tr').find('.activityValue').html(result);
                        if (actStatus == 0) {
                            th.closest('tr').next('tr').find('#repeatTask').show();
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 1) {
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 401) {
                            th.closest('tr').next('tr').find("#refreshMsg").show();
                            th.closest('tr').next('tr').find("#refreshTask").show();
                        }
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if (isCompletedConfigOrLogDownload(actType,actStatus) || isUpdateConfigOrFW(actType) ){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getFileNameByActivityID.php",
                data: {
                    'activityID': activityID,
                    'activityType':actType,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        th.closest('tr').next('tr').find('.activityValue').html(result);
                        if (actStatus == 0) {
                            th.closest('tr').next('tr').find('#repeatTask').show();
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 1) {
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 401) {
                            th.closest('tr').next('tr').find("#refreshMsg").show();
                            th.closest('tr').next('tr').find("#refreshTask").show();
                        }
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if(actType.trim().indexOf("deleteConnection") == 0 && actType.trim().length == 16 ){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getDeleteParamsByActivityID.php",
                data: {
                    'activityID': activityID,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    alert(result);
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        th.closest('tr').next('tr').find('.activityValue').html(result);
                        if (actStatus == 0) {
                            th.closest('tr').next('tr').find('#repeatTask').show();
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 1) {
                            th.closest('tr').next('tr').find('#removeTask').show();
                        } else if (actStatus == 401) {
                            th.closest('tr').next('tr').find("#refreshMsg").show();
                            th.closest('tr').next('tr').find("#refreshTask").show();
                        }
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else if (actStatus == 0 || actStatus == 4) {
            th.closest('tr').next('tr').find('#repeatTask').show();
            th.closest('tr').next('tr').find('#removeTask').show();
            $("body").css("cursor", "default");
        } else if (actStatus == 1) {
            th.closest('tr').next('tr').find('#removeTask').show();
            $("body").css("cursor", "default");
        } else if (actStatus == 401) {
            th.closest('tr').next('tr').find("#refreshMsg").show();
            th.closest('tr').next('tr').find("#refreshTask").show();
            $("body").css("cursor", "default");
        } else {
            th.closest('tr').next('tr').css('display', 'none');
            $("body").css("cursor", "default");
        }
    });

    $(document).on("click", ".selectTime", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    $(document).on("click", ".eachActivityPage", function () {
        var page = $(this).find("input[name='page']").val();
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    $(document).on("change", ".modelTypeActivity", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    $(document).on("change", ".macType", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    $(document).on("change", ".taskType", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    $(document).on("change", ".statusType", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime);
    });

    function filterActivities(model, mac, task, status, page, infoTask, searchType, createTime, selectTime) {
        if (mac == undefined) {
            mac = 0;
        }
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredActivitiesByPage.php",
            data: {
                'model': model,
                'mac': mac,
                'task': task,
                'status': status,
                'createTime': createTime,
                'selectTime': selectTime,
                'page': page,
                'taskInfo': infoTask,
                'searchType': searchType,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#forActivities").empty();
                    $("#forActivities").html(result);
                    if (mac == '0' && model == '0' && task == '0' && status == '-1' && createTime == '' && selectTime == 0) {
                        $('.deleteAll').html('<i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>' + getMssg['delete_all']);
                    } else {
                        $('.deleteAll').html('<i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>' + getMssg['delete_filtered']);
                    }
                    if (mac == 0 && model == 0 && task == 0 && status == -1 && createTime == '' && selectTime == 0) {
                        $("#resetActivity").css("display", "none");
                    } else {
                        $("#resetActivity").css("display", "block");
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("click", "#removeTask", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            var activID = $(this).parent().find("input[name='activityID']").val();
            $("body").css("cursor", "wait");

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'activityID': activID,
                    'actionName': 'deleteTask',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if (result == 'true') {
                        th.attr("disabled", "disabled");
                        th.css("opacity", "0.5");
                        th.css("cursor", "default");
                        var success = getMssg['action_succeed'];
                        $("#resActivity").removeClass("errorMessage");
                        $("#resActivity").addClass("infoMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(success);
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                    } else if (result == 'false') {
                        $("body").css("cursor", "default");
                        var failed = getMssg['dev_unavailable'];
                        $("#resActivity").removeClass("infoMessage");
                        $("#resActivity").addClass("errorMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(failed);
                        setTimeout(function () {
                            $("#resActivity").empty();
                        }, 10000);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", "#repeatTask", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            var devID = $(this).parent().find("input[name='devID']").val();
            var activID = $(this).parent().find("input[name='activityID']").val();
            $("body").css("cursor", "wait");

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devID,
                    'activityId': activID,
                    'actionName': 'repeatTask',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if (result == 'true') {
                        th.attr("disabled", "disabled");
                        th.css("opacity", "0.5");
                        th.css("cursor", "default");
                        var success = getMssg['action_succeed'];
                        $("#resActivity").removeClass("errorMessage");
                        $("#resActivity").addClass("infoMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(success);
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                    } else if (result == 'false') {
                        $("body").css("cursor", "default");
                        location.reload(true);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result = 'cannotSend') {
                        location.reload(true);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", "#refreshTask", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            var devID = $(this).parent().find("input[name='devID']").val();
            $("body").css("cursor", "wait");

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devID,
                    'actionName': "refresh",
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        th.attr("disabled", "disabled");
                        th.css("opacity", "0.5");
                        th.css("cursor", "default");
                        var success = getMssg['action_succeed'];
                        $("#resActivity").removeClass("errorMessage");
                        $("#resActivity").addClass("infoMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(success);
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                    } else if (result == 'false') {
                        $("body").css("cursor", "default");
                        var failed = getMssg['dev_unavailable'];
                        $("#resActivity").removeClass("infoMessage");
                        $("#resActivity").addClass("errorMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(failed);
                        setTimeout(function () {
                            $("#resActivity").empty();
                        }, 10000);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });


    $(document).on("click", "#resetActivity", function () {
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/resetAllFilteredActivities.php",
            data: {
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forActivities").empty();
                    $("#forActivities").html(result);
                    location.reload(true);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#searchTaskForActivity", function () {
        $("body").css("cursor", "wait");
        var infoTask = $('#searchForActivityDiv').find("input[name='taskInfo']").val().trim();
        var searchType = $(".searchType option:selected").val();
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var mac = $(".macType option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();

        if (mac == undefined) {
            mac = 0;
        }
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredActivitiesByPage.php",
            data: {
                'taskInfo': infoTask,
                'searchType': searchType,
                'page': page,
                'model': model,
                'mac': mac,
                'task': task,
                'status': status,
                'createTime': createTime,
                'selectTime': selectTime,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forActivities").empty();
                    $("#forActivities").html(result);
                }
                $("body").css("cursor", "default");
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });


    //added by Seda

    $(document).on("click", ".removeTask", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {

            th.attr("disabled", "disabled");

            var msg = getMssg['remove_activity_msg'];
            var titleMsg = getMssg['title_msg'];
            var rmMsg = getMssg['remove_msg'];
            var cancelMsg = getMssg['cancel'];
            var activityID = $(this).parent().find("input[name='activityID']").val();
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    removeActivities(activityID, this);
                } else {
                    th.removeAttr("disabled");
                }

            });
        }
    });

    function removeActivities(e, element) {

        $("body").css("cursor", "wait");


        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'activityID': e,
                'actionName': "deleteTask",
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    // var success = getMssg['action_succeed'];
                    // $("#resActivity").removeClass("errorMessage");
                    // $("#resActivity").addClass("infoMessage");
                    // $("#resActivity").empty();
                    // $("#resActivity").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000);
                    element.attr("disabled", "");
                } else if (result == 'false') {
                    var failed = getMssg['dev_unavailable'];
                    $("#resActivity").removeClass("infoMessage");
                    $("#resActivity").addClass("errorMessage");
                    $("#resActivity").empty();
                    $("#resActivity").html(failed);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        $("#resActivity").empty();
                    }, 10000);

                    element.attr("disabled", "");
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("click", ".repeatTask", function () {

        var th = $(this);
        var taskStatus = $(this).parent().find("input[name='taskStatus']").val();
        if (th.attr("disabled") != "disabled" || taskStatus == 1) {
            th.attr("disabled", "disabled");
            var activityID = $(this).parent().find("input[name='activityID']").val();
            var devID = $(this).parent().find("input[name='devID']").val();
            if (taskStatus == 0 || taskStatus == 4 || taskStatus == 1) {

                $("body").css("cursor", "wait");
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'activityId': activityID,
                    'deviceID': devID,
                    'actionName': 'repeatTask',
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        var success = getMssg['action_succeed'];
                        $("#resActivity").removeClass("errorMessage");
                        $("#resActivity").addClass("infoMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(success);
                        $("body").css("cursor", "default");
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                        th.removeAttr("disabled");
                    } else if (result == 'false') {
                        var failed = getMssg['dev_unavailable'];
                        $("#resActivity").removeClass("infoMessage");
                        $("#resActivity").addClass("errorMessage");
                        $("#resActivity").empty();
                        $("#resActivity").html(failed);
                        $("body").css("cursor", "default");
                        setTimeout(function () {
                            $("#resActivity").empty();
                        }, 10000);
                        th.removeAttr("disabled");
                    } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            }
        }

    });

});