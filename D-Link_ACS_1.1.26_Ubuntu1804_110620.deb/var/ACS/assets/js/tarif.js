function isNumber(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

function saveTarifInFile(confs,tarifName,desc){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/saveTarif.php",
        data: {
            'configs': confs,
            'tarifName':tarifName,
            'description':desc,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = 'login';
            } else {
                var msg = getMssg['changed_saved'];
                $("#errTarif").removeClass('errorMessage');
                $("#errTarif").addClass('mainColor');
                $("#errTarif").html(msg);
                // document.location.href = $basepath + 'template/show';
//                location.reload(true);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

function editTarif(tarifId,confs,tarifName,desc){
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/editTarif.php",
        data: {
            'tarifID':tarifId,
            'configs': confs,
            'tarifName':tarifName,
            'description':desc,
            'fromApp':true
        },
        async: true,
        success: function (result) {
            if (result == 'logged_out') {
                document.location.href = 'login';
            } else {
                var msg = getMssg['changed_saved'];
                $("#errTarif").removeClass('errorMessage');
                $("#errTarif").addClass('mainColor');
                $("#errTarif").html(msg);
                // document.location.href = $basepath + 'template/show';
//                location.reload(true);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
}

function buildTableRows(i, name, type,wanId){
        var table = $(".tempalteWanShow");
        var tr = $("<tr></tr>");
        $("<td></td>").html(i).appendTo(tr);
        $("<td></td>").html(name).appendTo(tr);
        $("<td></td>").html(type).appendTo(tr);
        $("<td></td>").html("<div id='donate'>\n\
                                <label><input type='radio' name='defaultGat'/>\n\
                                    <div class='blueCircle'></div></label>  </div>").appendTo(tr);
        $("<td></td>").html("<div class='actStatic'>\n\
                                <a class='config wanParam'><i class='fa fa-sun-o'></i></a>\n\
                                    <input type='hidden' name='wanID' value='"+wanId+"'/></div>").appendTo(tr);

        $(tr).appendTo(table);
    if (wanConnects.length == 1){
        $("input[name=defaultGat]").prop( "checked", true );
    }
 }

function buildTableRowsForWifi(i, name, type,wanId){
    var table = $(".WifiTable");
    var tr = $("<tr></tr>");
    $("<td></td>").html(i).appendTo(tr);
    $("<td></td>").html(name).appendTo(tr);
    $("<td></td>").html(type).appendTo(tr);
    $("<td></td>").html("<div class='actStatic'>\n\
                                <a class='config wifiParam'><i class='fa fa-sun-o'></i></a>\n\
                                <a class='config delWifiParam'><i class='fa fa-trash-o delWifiTempl'></i></a>\n\
                                    <input type='hidden' name='wifiID' value='"+wanId+"'/></div>").appendTo(tr);

    $(tr).appendTo(table);
}
 
function checkDefaultConnection(){
    for(var i = 0; i < wanConnects.length; i++){
        if($.inArray('def_connection', wanConnects[i].names) > -1){
            $("input[name=defaultGat]").each(function() {
                var connectionTypeId = $(this).closest('tr').find('input[name=wanID]').val();
                if(wanConnects[i]['id'] == connectionTypeId){
                    $(this).attr('checked','checked');
                }
            });
        }
    }
}

function getWifiTable() {
    $(".WifiTable tr").not(':first').remove();
    for(var ii = 0; ii < wifiConnects.length; ii++) {
        var ssid_index = wifiConnects[ii].names.indexOf('ssid');
        var basic_mode_index = wifiConnects[ii].names.indexOf('basic_mode');
        var ssid = wifiConnects[ii].values[ssid_index];
        var basic_mode = wifiConnects[ii].values[basic_mode_index];
        var wpa_psk_index = wifiConnects[ii].names.indexOf('wpa_psk');
        var wpa_psk2_index = wifiConnects[ii].names.indexOf('wpa_psk2');
        var wpa_psk = wifiConnects[ii].values[wpa_psk_index];
        var wpa_psk2 = wifiConnects[ii].values[wpa_psk2_index];
        var netAuth = '';

        if(wpa_psk != undefined && wpa_psk2 != undefined) {
            netAuth = 'WPA-PSK/WPA2-PSK mixed';
        } else if (wpa_psk != undefined && wpa_psk2 == undefined) {
            netAuth = 'WPA-PSK';
        } else if(wpa_psk2 != undefined && wpa_psk == undefined) {
            netAuth = 'WPA2-PSK';
        } else if(wpa_psk2 == undefined && wpa_psk == undefined) {
            netAuth = 'OPEN';
        }
        buildTableRowsForWifi(ii+1, wifiConnects[ii].values[wifiConnects[ii].names.indexOf('ssid')], netAuth, wifiConnects[ii]['id']);
    }
}

function getWanConnectionTable(name,type){
    $(".tempalteWanShow tr").not(':first').remove();
    for(var ii = 0; ii < wanConnects.length; ii++){
        if(wanConnects[ii]['conT'] == 'static'){
            if(type != 'static'){
                var connectioName = '';
                if($.inArray('name', wanConnects[ii].names) > -1){
                    var index = wanConnects[ii].names.indexOf('name');
                    connectioName = wanConnects[ii].values[index];
                }
            }

            buildTableRows((ii+1),type != 'static' ? connectioName : name,'STATIC IP',wanConnects[ii]['id']);

        } else if(wanConnects[ii]['conT'] == 'dynamic'){
            if(type != 'dynamic'){
                var connectioName = '';
                if($.inArray('name', wanConnects[ii].names) > -1){
                    var index = wanConnects[ii].names.indexOf('name');
                    connectioName = wanConnects[ii].values[index];
                }
            }

            buildTableRows((ii+1),type != 'dynamic' ? connectioName : name,'DYNAMIC IP',wanConnects[ii]['id']);

        } else  if(wanConnects[ii]['conT'] == 'ppp'){
            var connectioName = '';
            if($.inArray('name', wanConnects[ii].names) > -1){
                var index = wanConnects[ii].names.indexOf('name');
                connectioName = wanConnects[ii].values[index];
            }

            var connectionType = '';
            if($.inArray('conn_type', wanConnects[ii].names) > -1){
                var index = wanConnects[ii].names.indexOf('conn_type');
                connectionType = wanConnects[ii].values[index];
                if(connectionType == 'L2TP_Relay'){
                    buildTableRows((ii+1),connectioName,'L2TP + DYNAMIC IP',wanConnects[ii]['id']);
                }else {
                    buildTableRows((ii+1),connectioName,'PPTP + DYNAMIC IP',wanConnects[ii]['id']);
                }

            }else{
                buildTableRows((ii+1),connectioName,'PPPOE',wanConnects[ii]['id']);
            }
        }
//                    else if(wanConnects[ii]['conT'] == 'l2tp'){
//                        var connectioName = '';
//                        if($.inArray('name', wanConnects[ii].names) > -1){
//                            var index = wanConnects[ii].names.indexOf('name');
//                            connectioName = wanConnects[ii].values[index];
//                        }
//                        buildTableRows((ii+1),connectioName,'L2TP',wanConnects[ii]['id']);
//                    }
    }
}

var allConnects = [];
var wanConnects = [];
var wifiConnects = [];

$(document).ready(function(){
    
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
//
//------------------------------- pagination -----------------------------------

    $(document).on("click", ".eachTemplatePage", function () {
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/filteredTemplatesByPage.php",
            data: {
                'page': page,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#forTemplates").empty();
                    $("#forTemplates").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
    $(document).on("click", ".eachDescriptorPage", function () {
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/addTemplateAction.php",
            data: {
                'action' : 'showDescritors',
                'page': page,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#forTemplates").empty();
                    $("#forTemplates").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#addTarif", function () {
        var th = $(this);
        var tarifId = th.parent().find("input[name='templateId']").val();
        var tarifChangeName = 'null';
        var tarifChangeDesc = 'null';
        var isValid = true;
        var tarifName = $(".nameDescTarif").find("input[name='tarifName']");
        var errMsg = getMssg["templName_empty"];

        if(tarifName.hasClass("required") && tarifName.val().trim() == ''){
            tarifName.addClass("invalidVal");
            $("#errTarif").addClass("errorMessage");
            $("#errTarif").html(errMsg);
            isValid = false;
        } else if(tarifName.hasClass("invalidVal") && tarifName.val().trim() != '') {
            isValid = false;
        } else {
            tarifName.removeClass("invalidVal");
            var oldTarifName = $(".nameDescTarif").find("input[name='oldTarifName']").val();

            if(tarifName.val() != oldTarifName){
                tarifChangeName = tarifName.val();
            }

            var desc = $(".nameDescTarif").find("textarea[name='tarifDesc']").val();
            var oldTarifDesc = $(".nameDescTarif").find("input[name='oldTarifDesc']").val();

            if($.trim(desc) != $.trim(oldTarifDesc)){
                tarifChangeDesc = desc;
            }
        }
        var ipAddr = $('.lanform').find("input[name='ipAddress']").val();
        var netmask = $('.lanform').find("input[name='netmask']").val();
        var startIP = $('.lanform').find("input[name='startIP']").val();
        var endIP = $('.lanform').find("input[name='endIP']").val();
        var leaseTime = $('.lanform').find("input[name='leaseTime']").val();
        var modeType = $('.lanform').find(".modeType option:selected").val();

        var ssid = th.parent().parent().find("input[name='ssid']").val();
        var channel = th.parent().parent().find(".channelType option:selected").val();
        var standard = th.parent().parent().find(".standardType option:selected").val();
        var transmitPower = th.parent().parent().find(".transmitPower option:selected").val();
        var maxAssociatedClients = th.parent().parent().find("input[name='maxAssociatedClients']").val();
        var authVal = th.parent().parent().find(".netAuthType option:selected").val();
        var status = true;

        if (ipAddr != '' || netmask != '' || (modeType == '1' && (startIP != '' || endIP != '' || leaseTime != ''))
            || /*ssid!='' || channel != '0' || standard != 'n' || transmitPower != '100' || maxAssociatedClients != '0' || authVal != 'OPEN'
        ||*/ wanConnects.length!=0 || wifiConnects.length!=0) {
            status = true;
        } else {
            status = false;
            var msg = getMssg['not_saved'];
            // $("#errTarif").removeClass('errorMessage');
            $("#errTarif").addClass('errorMessage');
            $("#errTarif").html(msg);
            return false;
        }

        if(ipAddr != '' || netmask != '' || (modeType == '1' && (startIP != '' || endIP != '' || leaseTime != ''))) {
            status = formValidateLanPage();
            if(status == false) {
                showNextTab('templLan');
                formValidateLanPage();
                return false;
            }
        }

        // if (ssid!='' || channel != '0' || standard != 'n' || transmitPower != '100' || maxAssociatedClients != '0' || authVal != 'OPEN') {
        //     status = validateTarifWiFi(th);
        //     if(status == false) {
        //         showNextTab('templWifi');
        //         validateTarifWiFi(th);
        //         return false;
        //     } else {
        //         addTarifInWifi(th);
        //     }
        // }

        if(wanConnects.length!=0) {
            var status = wanPageValidation();
        }

        if(status && isValid){
            var msg = getMssg["msg_ok"];
            //var titleMsg = $('#msgTitle').val();
            var changMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['noChange'];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                if (th.hasClass('addTemplatePage')) {
                    saveTarifInFile(allConnects, tarifName.val(), desc);
                } else {
                    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                }
            });
        }
    });


//----------------------------- end pagination ---------------------------------

//    $(document).on("click","#addTemplate",function(){
//        $.ajax({
//            type: "POST",
//            url: $basepath + "secureFiles/actions/addTemplateAction.php",
//            data: {
//                'action': 'addTemplate',
//                'fromApp': true
//            },
//            async: false,
//            success: function (result) {
//                if (result == 'logged_out') {
//                    document.location.href = 'login';
//                } else {
//                    $(".template").empty();
//                    $("#forEditTempl").empty();
//                    $(".template").html(result);
//                }
//            },
//            error: function(xhr, status, error) {
//                document.location.href = $basepath + '500';
//            }
//        });
//    });
    
//    $(document).on("click","#showDescritors",function(){
//        $.ajax({
//            type: "POST",
//            url: $basepath + "secureFiles/actions/addTemplateAction.php",
//            data: {
//                'action': 'showDescritors',
//                'fromApp': true
//            },
//            async: false,
//            success: function (result) {
//                if (result == 'logged_out') {
//                    document.location.href = 'login';
//                } else {
//                    $("#backToTemplates").show();
//                    $("#addTemplate").hide();
//                    $("#forTemplates").empty();
//                    $("#forEditTempl").empty();
//                    $("#forTemplates").html(result);
//                }
//            },
//            error: function(xhr, status, error) {
//                document.location.href = $basepath + '500';
//            }
//        });
//    });
    
//    $(document).on("click","#backToTemplates",function(){
////        location.reload(true);
//        document.location.href = $basepath + 'template/show';
//    });

    function showInputs(th,id) {
        $(".forChange").hide();
        $(".defaultText").show();
        $(th).find(".forChange").show();
        $(th).find(".defaultText").hide();
        var currName = $(th).find(".defaultText").html();
        $(th).find("input").val(currName);
        $(th).find("textarea").val(currName);
        $(th).find("a").attr('id',id);
    }

    $(document).on("dblclick", ".templateName", function () {
        var th = $(this);
        showInputs(th,'changeTempName');
    });

    $(document).on("dblclick", ".templateDescription", function () {
        var th = $(this);
        showInputs(th,'changeTempDesc');
    });

    $(document).on("click",".changeData",function(e) {
        e.stopPropagation(); // watch out here...
    });

    $(document).on("click",".defaultText",function(e) {
        e.stopPropagation(); // watch out here...
    });


    $(document).on("click", "#resetTemplate", function (e){
        $('#changeTemplate').empty();
        var target = e.target?e.target:e.srcElement;
        if (target.id == 'changeClientImg'){
            return false;
        } else{
            $(".forChange").hide();
            $(".defaultText").show();
        }
    });

    $(document).on("click", "#changeTempName", function () {
        var th = $(this);
        var tempName = th.parent().find("input[name='newTemplateName']").val().trim();
        var tempOldName = th.parent().find("input[name='oldTemplateName']").val().trim();
        var tempId = th.closest('tr').find("input[name='templID']").val();
        var tarifChangeDesc = 'null';
        var msg = getMssg["teplate_file_exist"];
        // if(tempName != tempOldName){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkTarifNameExist.php",
                data: {
                    'templateName': tempName,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = 'login';
                    } else {
                        if(result!=''){
                            $("#changeTemplate").empty();
                            $("#changeTemplate").html(result);
                            $("#changeTemplate").addClass("errorMessage");
                            th.addClass("invalidVal");
                        } else {
                            th.removeClass("invalidVal");
                            $("#changeTemplate").empty();
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/editTarifNameDesc.php",
                                data: {
                                    'tarifID': tempId,
                                    'tarifName': tempName,
                                    'description': tarifChangeDesc,
                                    'fromApp': true
                                },
                                async: true,
                                success: function (result) {
                                    if (result == 'logged_out') {
                                        document.location.href = 'login';
                                    } else if (result == 'false') {
                                        $("#changeTemplate").empty();
                                        $("#changeTemplate").html(msg);
                                        $("#changeTemplate").addClass("errorMessage");
                                        th.addClass("invalidVal");
                                    } else {
                                        th.closest("td").find('.defaultText').html(tempName);
                                        $(".forChange").hide();
                                        $(".defaultText").show();
                                        $("body").css("cursor", "default");
                                        $("#changeTemplate").empty();
                                        var page = $("input[name='page']").val();
                                        if(!page) {
                                            page = 1;
                                        } else {
                                            page = Number(page);
                                            page = page + 1;
                                        }
                                        $("body").css("cursor", "wait");
                                        $.ajax({
                                            type: "POST",
                                            url: $basepath + "secureFiles/actions/ajaxActions/filteredTemplatesByPage.php",
                                            data: {
                                                'page': page,
                                                'fromApp':true
                                            },
                                            async: true,
                                            success: function (result) {
                                                if(result=='logged_out'){
                                                    document.location.href = $basepath + 'login';
                                                } else {
                                                    $("body").css("cursor", "default");
                                                    $("#forTemplates").empty();
                                                    $("#forTemplates").html(result);
                                                }
                                            },
                                            error: function(xhr, status, error) {
                                                document.location.href = $basepath + '500';
                                            }
                                        });
                                        // document.location.href = $basepath + 'template/show';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        // }
    });

    $(document).on("click", "#changeTempDesc", function () {
        var th = $(this);
        var tempDesc = th.parent().find("textarea").val();
        var tempId = th.closest('tr').find("input[name='templID']").val();
        $("body").css("cursor", "wait");
        var msg = getMssg["teplate_file_exist"];
        var tarifChangeName = 'null';

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/editTarifNameDesc.php",
            data: {
                'tarifID':tempId,
                'tarifName':tarifChangeName,
                'description':tempDesc,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = 'login';
                }else if (result == 'false') {
                    $("#changeTemplate").empty();
                    $("#changeTemplate").html(msg);
                    $("#changeTemplate").addClass("errorMessage");
                    th.addClass("invalidVal");
                } else {
                    th.closest("td").find('.defaultText').html(tempDesc);
                    $(".forChange").hide();
                    $(".defaultText").show();
                    $("body").css("cursor", "default");
                    $("#changeTemplate").empty();
                    // document.location.href = $basepath + 'template/show';
//                location.reload(true);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click",".remTempl",function(){
        var tempId = $(this).parent().find("input[name='templID']").val();
        var titleMsg = getMssg['title_msg'];
        var msg = getMssg['conf_rem_template'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/removeTemplate.php",
                data: {
                    'delete': 'template',
                    'templateId': tempId,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        location.reload(true);
                    } else {
                        var fail = getMssg['failed_remove_templ'];
                        $("#failResultMsgTemplate").empty();
                        $("#failResultMsgTemplate").html(fail);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        });
    });
    
    $(document).on("click",".remDescriptor",function(){
        var descId = $(this).parent().find("input[name='descriptorID']").val();
        var titleMsg = getMssg['title_msg'];
        var msg = getMssg['conf_rem_descriptor'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/removeTemplate.php",
                data: {
                    'delete': 'descriptor',
                    'templateId': descId,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        location.reload(true);
                    } else {
                        var fail = getMssg['action_failed'];
                        $("#failResultMsgTemplate").empty();
                        $("#failResultMsgTemplate").html(fail);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        });
    });
    
    $(document).on("click",".remDefaultDescriptor",function(){
        var descId = $(this).parent().find("input[name='defDescriptorID']").val();
        var titleMsg = getMssg['title_msg'];
        var msg = getMssg['conf_rem_Defdescriptor'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/removeTemplate.php",
                data: {
                    'delete': 'defDescriptor',
                    'templateId': descId,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        location.reload(true);
                    } else {
                        var fail = getMssg['action_failed'];
                        $("#failResultMsgTemplate").empty();
                        $("#failResultMsgTemplate").html(fail);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        });
    });
    
//    $(document).on("click",".templEdit",function(){
//        var tempId = $(this).parent().find("input[name='templID']").val();
//        $.ajax({
//            type: "POST",
//            url: $basepath + "secureFiles/actions/ajaxActions/showTemplate.php",
//            data: {
//                'templateId': tempId,
//                'fromApp':true
//            },
//            async: false,
//            success: function (result) {
//                if (result == 'logged_out') {
//                    document.location.href = 'login';
//                } else if(result == 'false') {
//                    var failed = $("#msgTemplateFile").val();
//                    swal({
//                        title: '',
//                        text: failed
//                    });
//                }else{
//                    $(".template").hide();
//                    $("#forEditTempl").empty();
//                    $("#forEditTempl").html(result);
//                }
//            },
//            error: function(xhr, status, error) {
//                document.location.href = $basepath + '500';
//            }
//        });
//    });
    
//     $(document).on("click",".downloadFile",function(){
//        var tempId = $(this).parent().find("input[name='templID']").val();
//        alert(tempId)
//    });
    
//-------------------------- editTemplate.php ----------------------------------

    $(document).on("click","#templLan",function(){
       if ($(".lanpage2").css("display") == "none") {
             showNextTab('templLan');
       }
    });

    $(document).on("click","#templWAN",function(){
       if ($(".wanpage1").css("display") == "none") {
             showNextTab('templWAN');
       }
    });

    $(document).on("click","#templWifi",function(){
       // if ($("#wifiPage").css("display") == "none") {
             showNextTab('templWifi');
       // }
    });

    $(document).on("click","#skipTamplate",function(){
        if ($(".lanpage2").css("display") == "block") {
            showNextTab('templWAN');
        } else if ($(".wanpage1").css("display") == "block") {
            showNextTab('templWifi');
        }
    });

    function showNextTab(id){
        $("#divForWifi").empty();
        $('#forResetWIFI').trigger('reset');
        $('.second-nav li a').removeClass('activeTabLi');
        $('.TempStyle li a').removeClass('activeTabLi');
        $('.general-settings').hide();
        $('.addStaticIp').hide();
        $('.addDynamicIp').hide();
        $('.addPPPIp').hide();
        $('.addL2TPIp').hide();
        $('.addPPTPIp').hide();
        $('#addNewWan').show();
        
        if(id == 'templLan'){
            $('#'+id).addClass('activeTabLi');
            $('.lanpage2').show();
            $('.wanpage1').hide();
            $('#wifiPage').hide();
            $('.saveTabs').hide();
            // $('.saveTabsOnlyWIFI').hide();
            $('.nextBtn').show();
            $('.backBtn').hide();
            $('.nextBtn').attr('id','saveLanAndNext');
            $('#skipTamplate').show();
            $('.resetTemplate').attr('id','resetAddTemplate');
            // $('.addTarif').attr('id','addTarifInLan');
            $('#divForWAN').empty();
            $("#errTarif").empty();
            $('#enterpasswordmsg').show();
            $('#enterpasswordmsgL2tp').show();
            $('#enterpasswordmsgPPTP').show();
            // resetAllForms();
            resetAllShowPassCheckboxes();
            //$('#forResetWIFI').trigger('reset');
            $("div.error_messageLan").remove(); 
            $(".error_messageLan").removeClass("error");
            // $("#forPSk").hide();
            // $('#forReneval').hide();

        }
        
        if(id == 'templWAN'){
            $('#'+id).addClass('activeTabLi');
            $('.lanpage2').hide();
            $('.wanpage1').show();
            $('#wifiPage').hide();

            $('.saveTabs').hide();
            // $('.saveTabsOnlyWIFI').hide();
            $('#divForAddWifi').hide();
            $('#divForAddWifi1').hide();
            $('.nextBtn').show();
            $('.nextBtn').attr('id','saveWanAndNext');
            $('#skipTamplate').show();
            $('.backBtn').show();
            $('.resetTemplate').attr('id','resetAddTemplateWAN');
            // $('.addTarif').attr('id','addTarifInWan');
            $('#divForWAN').empty();
            $('#enterpasswordmsg').hide();
            $('#enterpasswordmsgL2tp').show();
            $('#enterpasswordmsgPPTP').show();
            if ($("#forDNSServers").css('display') == 'none' ){$("#forDNSServers").show();}
            if(wanConnects.length > 0){ $("#shoeConnections").show();}
            if($('.lanform .error_messageLan').attr('id') && $.trim( $('.lanform .error_messageLan').text() ).length != 0){
                // $('.lanform').validate().resetForm();
            }
            //$('#forResetWIFI').trigger('reset');
            $("div.error_messageLan").remove(); 
            $(".error_messageLan").removeClass("error");
            // $("#forPSk").hide();
            // $('#forReneval').hide();
        }
        
        if(id == 'templWifi'){
            $('#'+id).addClass('activeTabLi');
            $('.lanpage2').hide();
            $('.wanpage1').hide();
            $('#wifiPage').show();
            $('#addNewWifi').show();
            $('.addNewWifiDiv').show();
            $('#divForAddWifi').hide();
            $('#divForAddWifi1').hide();
            $('#wifiPage1').hide();
            $('#wifiPage11').hide();
            $('.saveTabs').show();
            // $('.saveTabsOnlyWIFI').show();
            if(wifiConnects.length > 0){ $("#showWiFI").show();}
            $('.backBtn').show();
            $('.nextBtn').hide();
            $('#skipTamplate').hide();
            $('.resetTemplate').attr('id','resetAddTemplateWiFi');
            // $('.addTarif').attr('id','addTarifInWiFi');
            $('#divForWAN').empty();
            $("#errTarif").empty();
            $('#enterpasswordmsg').show();
            $('#enterpasswordmsgL2tp').show();
            $('#enterpasswordmsgPPTP').show();
            if($('.lanform .error_messageLan').attr('id') && $.trim( $('.lanform .error_messageLan').text() ).length != 0){
                // $('.lanform').validate().resetForm();
            }
            $("#divForWifi").empty();
            $('#forResetWIFI').trigger('reset');
            // if($(".netAuthType option:selected").val() != 'OPEN'){
            //     $("#forPSk").show();
            //     $('#forReneval').show();
            // }
            // resetAllForms();
            resetAllShowPassCheckboxes();
        }
    }
   
    function resetAllForms(){
        $('#forResetStatic').trigger('reset');
        $('#forResetDynamic').trigger('reset');
        $('#forResetPPPoE').trigger('reset');
        $('#forResetL2TP').trigger('reset');
        $('#forResetPPTP').trigger('reset');
        //$('#forResetStatic').validate().resetForm();
        //$('#forResetDynamic').validate().resetForm();
        //$('#forResetPPPoE').validate().resetForm();
        //$('#forResetL2TP').validate().resetForm();
        //$('#forResetPPTP').validate().resetForm();
    }


    $(document).on("click", "#resetAddTemplate", function (e) {
        e.preventDefault();
        $('.lanform').trigger('reset');
        $('.lanform').validate().destroy();
        var modeType = $(".modeType option:selected").val();
        if (modeType == '0') {
            $("#forEnableMode").hide();
        } else if(modeType == '1') {
            $("#forEnableMode").show();
        }
    });

    $(document).on("click", "#resetAddTemplateWiFi", function (e) {
        e.preventDefault();
        $('#forResetWIFI').trigger('reset');
        $('#forResetWIFI').validate().destroy();
        var authTypeVal = $(".netAuthType option:selected").val();

        if (authTypeVal == "OPEN") {
            $("#forPSk").css('display','none');
            $('#forReneval').css('display','none');
        } else if (authTypeVal != "WPA" && authTypeVal != "WPA2" && authTypeVal != "WPA/WPA2 mixed") {
            $("#forPSk").css("display","block");
            $('#forReneval').css('display','block');
        } else {
            $("#forPSk").css("display","none");
            $('#forReneval').css('display','block');
        }
    });

    $(document).on("click", "#resetAddTemplateWAN", function (e) {
        e.preventDefault();
        $('#forResetStatic').validate().destroy();
        $('#forResetDynamic').validate().destroy();
        $('#forResetPPPoE').validate().destroy();
        $('#forResetL2TP').validate().destroy();
        $('#forResetPPTP').validate().destroy();
        resetAllForms();
        resetAllShowPassCheckboxes();
    });

    $(document).on("click","#backTabTemplate",function(){
        var th = $(this);
        var titleMsg = getMssg['go_to_back'];
        var rmMsg = getMssg['change_msg'];
        var cancelMsg = getMssg['cancel'];
        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

        if ($(".wanpage1").css("display") == "block") {
            swal({
                title: "",
                text: titleMsg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    var status = wanPageValidation();
                    if(status){
                        showNextTab('templLan');
                    }
                } else {
                    showNextTab('templLan');
                }
            });

        } else if ($("#wifiPage").css("display") == "block") {
            swal({
                title: "",
                text: titleMsg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    var status = validateTarifWiFi(th);
                    if(status){
                        addTarifInWifi(th);
                        showNextTab('templWAN');
                    }
                } else {
                    showNextTab('templWAN');
                }
            });
        }
    });

    $(document).on("click","#saveTabs",function(){
        var th = $(this);
        var status = validateTarifWiFi(th);
        if(status){
            addTarifInWifi(th);
            $("#errTarif").removeClass("errorMessage");
            $("#errTarif").addClass("infoMessage");
            var msg1 = getMssg["changed_saved"];
            $("#errTarif").html(msg1);
        }

        return false;
    });

    $(document).on("click","#saveTabsOnlyWIFI",function(){
        if(allConnects.length === 0) {
            var msg = getMssg["not_saved"];
            $("#errTarif").addClass("errorMessage");
            $("#errTarif").html(msg);
            return false;
        } else {
            $("#errTarif").removeClass("errorMessage");
            $("#errTarif").addClass("infoMessage");
            var msg1 = getMssg["changed_saved"];
            $("#errTarif").html(msg1);
            return false;
        }

    });

    $(document).on("change",".netAuthType",function() {
        var authTypeVal = $(".netAuthType option:selected").val();
            
        if (authTypeVal == "OPEN") {
            $("#forPSk").css('display','none');
            $('#forReneval').css('display','none');
        } else if (authTypeVal != "WPA" && authTypeVal != "WPA2" && authTypeVal != "WPA/WPA2 mixed") {
            $("#forPSk").css("display","block");
            $('#forReneval').css('display','block');
        } else {
            $("#forPSk").css("display","none");
            $('#forReneval').css('display','block');
        }
        
    });

    $(document).on("change",".modeType",function() {
        var modeType = $(".modeType option:selected").val();
        if (modeType == '1') {
            $("#forEnableMode").show();
            // $(".lanpage1").show();
            // $(".modeType option:selected").attr("selected", "true");
        } else if (modeType == '0') {
            $("#forEnableMode").hide();
            // $(".lanpage1").hide();
            // $(".modeType option:selected").attr("selected", "true");
            $("div.error_messageLan").remove();
            $(".error_messageLan").removeClass("error");
            $('.lanform').find("input[name='startIP']").val('');
            $('.lanform').find("input[name='endIP']").val('');
            $('.lanform').find("input[name='leaseTime']").val('');

        } else if (modeType == '2') {
            $("#forEnableMode").hide();
            $(".lanpage1").hide();
            $(".modeType option:selected").attr("selected", "true");
        }
    });
    
    $(document).on("click","#addNewWan",function(){
        $(".gsConnType option[value='staticIP']").prop('selected', true);
        var selectedConType = $(".gsConnType option:selected").val();
        setDefaultConnection();
        
        if ($(".general-settings").css("display") == "none") {
            $('.general-settings').show();
            $(this).hide();
            $('#shoeConnections').hide();
            if (selectedConType == "staticIP") {
                $('.addStaticIp').show();
                $('.addDynamicIp').hide();
                $('.addPPPIp').hide();
                $('.addL2TPIp').hide();
                $('.addPPTPIp').hide();
            }else if(selectedConType == "dynamicIP"){
                $('.addStaticIp').hide();
                $('.addDynamicIp').show();
                $('.addPPPIp').hide();
                $('.addL2TPIp').hide();
                $('.addPPTPIp').hide();
            }else if(selectedConType == "l2tp"){
                $('.addStaticIp').hide();
                $('.addDynamicIp').hide();
                $('.addPPPIp').hide();
                $('.addL2TPIp').show();
                $('.addPPTPIp').hide();
            }else if(selectedConType == "pptp"){
                $('.addStaticIp').hide();
                $('.addDynamicIp').hide();
                $('.addPPPIp').hide();
                $('.addPPTPIp').show();
                $('.addL2TPIp').hide();
            }else{
                $('.addStaticIp').hide();
                $('.addDynamicIp').hide();
                $('.addPPPIp').show();
                $('.addL2TPIp').hide();
                $('.addPPTPIp').hide();
            }
        }
    });

    $(document).on("click","#addNewWifi",function(){
        $("#errTarif").empty();
        $('select option').removeAttr('selected');
        $('.transmitPower option').removeAttr('selected').filter('[value="100"]').attr('selected', true);

        for(var ii = 0; ii<wifiConnects.length; ii++){
            var frequency_band_index = wifiConnects[ii].names.indexOf('frequency_band');
            var frequency_band = wifiConnects[ii].values[frequency_band_index];
            $('.frequencyBand option').removeAttr('selected').filter('[value="'+frequency_band+'"]').attr('disabled', true);
        }

        if(wifiConnects.length >= 2) {
            $("#addNewWifi").prop( "disabled", true );
        } else {
            $('#forResetWIFI').trigger('reset');
            // $('#forResetWIFI').validate().resetForm();
            $('#showWiFI').hide();
            $('.addNewWifiDiv').hide();
            $('#wifiPage1').show();
            $('#divForAddWifi').show();
            $("#forPSk").hide();
            $("#forReneval").hide();
            $("#divForWifi").empty();
            $('#forResetWIFI').trigger('reset');
        }

        var frequencyBand = $(".frequencyBand option:selected").val();

        if (frequencyBand == "2.4GHz") {
            $(".standardType option[value='b,g,n']").remove();
            $(".standardType option[value='b']").remove();
            $(".standardType option[value='g-only']").remove();
            $(".standardType option[value='a']").remove();
            $(".standardType option[value='ac']").remove();
            $(".standardType option[value='ac,n']").remove();
            $(".standardType option[value='ac,a,n']").remove();
            $(".standardType option[value='a,n']").remove();
            $(".standardType").append('<option value=b,g,n>802.11 B/G/N mixed</option>');
            $(".standardType").append('<option value=b>802.11 B</option>');
            $(".standardType").append('<option value=g-only>802.11 G</option>');

            var i;
            for(i = 1; i <= 13; i=i+1) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 1; i <= 13; i=i+1) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 36; i <= 64; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 136; i <= 144; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 149; i <= 165; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }

        } else if(frequencyBand == "5GHz") {
            $(".standardType option[value='a']").remove();
            $(".standardType option[value='ac']").remove();
            $(".standardType option[value='ac,n']").remove();
            $(".standardType option[value='ac,a,n']").remove();
            $(".standardType option[value='b,g,n']").remove();
            $(".standardType option[value='b']").remove();
            $(".standardType option[value='g-only']").remove();
            $(".standardType").append('<option value=a>802.11 A</option>');
            $(".standardType").append('<option value=ac>802.11 AC</option>');
            $(".standardType").append('<option value=ac,n>802.11 AC/N mixed</option>');
            $(".standardType").append('<option value=ac,a,n>802.11 AC/A/N mixed</option>');
            $(".standardType").append('<option value="a,n">802.11 A/N mixed</option>');

            var i;
            for(i = 1; i <= 13; i=i+1) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 36; i <= 64; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 136; i <= 144; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 149; i <= 165; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 36; i <= 64; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 136; i <= 144; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 149; i <= 165; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
        }
    });


        $(document).on("change",".gsConnType",function() {
        var selectedConType = $(".gsConnType option:selected").val();
        $("div.error_messageLan").remove();
        
        if (selectedConType == "staticIP") {
            $('.addStaticIp').show();
            $('.addDynamicIp').hide();
            $('.addPPPIp').hide();
            $('.addL2TPIp').hide();
            $('.addPPTPIp').hide();
        }else if(selectedConType == "dynamicIP"){
            $('.addStaticIp').hide();
            $('.addDynamicIp').show();
            $('.addPPPIp').hide();
            $('.addL2TPIp').hide();
            $('.addPPTPIp').hide();
	}else if(selectedConType == "l2tp"){
	    $('.addStaticIp').hide();
	    $('.addDynamicIp').hide();
	    $('.addPPPIp').hide();
	    $('.addL2TPIp').show();
            $('.addPPTPIp').hide();
        }else if(selectedConType == "pptp"){
            $('.addStaticIp').hide();
            $('.addDynamicIp').hide();
            $('.addPPPIp').hide();
            $('.addPPTPIp').show();
            $('.addL2TPIp').hide();
        }else{
            $('.addStaticIp').hide();
            $('.addDynamicIp').hide();
            $('.addPPPIp').show();
            $('.addL2TPIp').hide();
            $('.addPPTPIp').hide();
        }
    });
    
    $(document).on("click","#cancelAddTemplate",function () {
        var th = $(this);
        var ipAddr = $('.lanform').find("input[name='ipAddress']").val();
        var netmask = $('.lanform').find("input[name='netmask']").val();
        var startIP = $('.lanform').find("input[name='startIP']").val();
        var endIP = $('.lanform').find("input[name='endIP']").val();
        var leaseTime = $('.lanform').find("input[name='leaseTime']").val();
        var modeType = $('.lanform').find(".modeType option:selected").val();

        var ssid = th.parent().parent().find("input[name='ssid']").val();
        var channel = th.parent().parent().find(".channelType option:selected").val();
        var standard = th.parent().parent().find(".standardType option:selected").val();
        var transmitPower = th.parent().parent().find(".transmitPower option:selected").val();
        var maxAssociatedClients = th.parent().parent().find("input[name='maxAssociatedClients']").val();
        var authVal = th.parent().parent().find(".netAuthType option:selected").val();
        var status = true;

        if((ipAddr != '' || netmask != '' || (modeType == '1' && (startIP != '' || endIP != '' || leaseTime != '')) ) || wifiConnects.length != 0
            || allConnects.length != 0 || wanConnects.length != 0) {
            var msg = getMssg["go_to_back"];
            var changMsg =  getMssg[''];
            var cancelMsg = getMssg[''];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(!isConfirm) {
                    allConnects.length = 0;
                    wanConnects.length = 0;
                    wifiConnects.length = 0;
                    document.location.href = $basepath + 'template/show';
                } else {
                    if(ipAddr != '' || netmask != '' || (modeType == '1' && (startIP != '' || endIP != '' || leaseTime != ''))) {
                        status = formValidateLanPage();
                        if(status == false) {
                            showNextTab('templLan');
                            formValidateLanPage();
                        }
                    } else if (wifiConnects.length!=0) {
                        // status = validateTarifWiFi(th);
                        // if(status == false) {
                            showNextTab('templWifi');
                            // validateTarifWiFi(th);
                            // addTarifInWifi(th);
                        // } else {
                        // }
                    } else if(wanConnects.length!=0){
                        showNextTab('templWAN');
                    }
                }
            });

        } else {
            allConnects.length = 0;
            wanConnects.length = 0;
            wifiConnects.length = 0;
            document.location.href = $basepath + 'template/show';
        }

//        location.reload(true);
    });

    $(document).on("click","#cancelEditTemplate",function () {
        var th = $(this);
        var ipAddr = $('.lanform').find("input[name='ipAddress']").val();
        var netmask = $('.lanform').find("input[name='netmask']").val();
        var startIP = $('.lanform').find("input[name='startIP']").val();
        var endIP = $('.lanform').find("input[name='endIP']").val();
        var leaseTime = $('.lanform').find("input[name='leaseTime']").val();
        var modeType = $('.lanform').find(".modeType option:selected").val();

        var ipAddrDefault = $('.lanform').find("input[name='ipAddressDefault']").val();
        var netmaskDefault = $('.lanform').find("input[name='netmaskDefault']").val();
        var startIPDefault = $('.lanform').find("input[name='startIPDefault']").val();
        var endIPDefault = $('.lanform').find("input[name='endIPDefault']").val();
        var leaseTimeDefault = $('.lanform').find("input[name='dhcpLeaseTimeValue']").val();

        var ssid = th.parent().parent().find("input[name='ssid']").val();
        var channel = th.parent().parent().find(".channelType option:selected").val().trim();
        var standard = th.parent().parent().find(".standardType option:selected").val();
        var transmitPower = th.parent().parent().find(".transmitPower option:selected").val();
        var maxAssociatedClients = th.parent().parent().find("input[name='maxAssociatedClients']").val();
        var authVal = th.parent().parent().find(".netAuthType option:selected").val();
        var presharedKey = th.parent().parent().find("input[name='presharedKey']").val();
        var encryption = th.parent().parent().find(".encryptionType option:selected").val();
        var wpaReneval = th.parent().parent().find("input[name='wpaReneval']").val().trim();
        var status = true;


        var ssidDefault = th.parent().parent().find("input[name='ssidDefault']").val();
        var channelDefault = th.parent().parent().find("input[name='channelDefault']").val().trim();
        var standardDefault = th.parent().parent().find("input[name='standardDefault']").val();
        var transmitPowerDefault = th.parent().parent().find("input[name='transmitPowerDefault']").val();
        var maxAssociatedClientsDefault = th.parent().parent().find("input[name='maxAssociatedClientsDefault']").val();
        var presharedKeyDefault =th.parent().parent().find("input[name='presharedKeyDefault']").val();
        var encryptionDefault = th.parent().parent().find("input[name='encryptionDefault']").val();
        var wpaRenevalDefault = th.parent().parent().find("input[name='wpaRenevalDefault']").val().trim();



        if(ipAddr != ipAddrDefault || netmask != netmaskDefault || startIP != startIPDefault || endIP != endIPDefault || leaseTime != leaseTimeDefault) {
            var msg = getMssg["go_to_back"];
            var changMsg =  getMssg[''];
            var cancelMsg = getMssg[''];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(!isConfirm) {
                    allConnects.length = 0;
                    wanConnects.length = 0;
                    document.location.href = $basepath + 'template/show';
                } else {
                    if(ipAddr != ipAddrDefault || netmask != netmaskDefault || (modeType == '1' && (startIP != startIPDefault || endIP != endIPDefault || leaseTime != leaseTimeDefault))) {
                        status = formValidateLanPage();
                        if (status == false) {
                            showNextTab('templLan');
                            formValidateLanPage();
                        }

                    } else if (wifiConnects.length!=0) {
                        // status = validateTarifWiFi(th);
                        // if(status == false) {
                            showNextTab('templWifi');
                            // validateTarifWiFi(th);
                            // addTarifInWifi(th);
                        // } else {
                        // }
                    } else if(wanConnects.length!=0){
                        showNextTab('templWAN');
                    }
                }
            });

        } else {
            allConnects.length = 0;
            wanConnects.length = 0;
            wifiConnects.length = 0;
            document.location.href = $basepath + 'template/show';
        }

//        location.reload(true);
    });


    $(document).on("click","#saveLanAndNext",function () {
        var status = formValidateLanPage();
        if(status){
            showNextTab('templWAN');
        }
    });
    
    function resetAllShowPassCheckboxes(){
        
        var pppoe = $('#forResetPPPoE').find("#chkShow").is(':checked');
        var l2tp = $('#forResetL2TP').find("#chkShowL2tp").is(':checked');
        var pptp = $('#forResetPPTP').find("#chkShowPPTP").is(':checked');
        
        if (pppoe) {
            $('#forResetPPPoE').find('#txtPassword').prop('type', 'text');
            $('#forResetPPPoE').find('#txtrePassword').prop('type', 'text');
            $('#hideShowPasswordPart').show();
        } else {
            $('#forResetPPPoE').find('#txtPassword').prop('type', 'password');
            $('#forResetPPPoE').find('#txtrePassword').prop('type', 'password');
            $('#hideShowPasswordPart').show();
            $('.txtPass').attr('readonly', 'readonly');
        }
        
        if (l2tp) {
            $('#forResetL2TP').find('#txtPasswordL2tp').prop('type', 'text');
            $('#forResetL2TP').find('#txtrePasswordL2tp').prop('type', 'text');
            $("#hideShowPasswordPartL2tp").show();
        } else {
            $('#forResetL2TP').find('#txtPasswordL2tp').prop('type', 'password');
            $('#forResetL2TP').find('#txtrePasswordL2tp').prop('type', 'password');
            $("#hideShowPasswordPartL2tp").hide();
            $('.txtPass').attr('readonly', 'readonly');
        }
        
        if (pptp) {
            $('#forResetPPTP').find('#txtPasswordPPTP').prop('type', 'text');
            $('#forResetPPTP').find('#txtrePasswordPPTP').prop('type', 'text');
            $("#hideShowPasswordPartPPTP").show();
        } else {
            $('#forResetPPTP').find('#txtPasswordPPTP').prop('type', 'password');
            $('#forResetPPTP').find('#txtrePasswordPPTP').prop('type', 'password');
            $("#hideShowPasswordPartPPTP").hide();
            $('.txtPass').attr('readonly', 'readonly');
        }
    } 
//-------------------------for show password-----------------------------------
    
    $(document).on("change","#chkShow",function() {
        if (this.checked) {
            $('#txtPassword').prop('type', 'text');
            $('#txtrePassword').prop('type', 'text');
        } else {
            $('#txtPassword').prop('type', 'password');
            $('#txtrePassword').prop('type', 'password');
            $('.txtPass').attr('readonly', 'readonly');
        }
    });
    
//-----------------------------------------------------------------------------

    //$(document).on("click","#txtPassword",function() {
    //    if($('#').is(":hidden")){
    //        $("#").show();
    //    }
    //});
    //
    //$(document).on('focus','#txtPassword', function(e){
    //    $(window).keyup(function (e) {
    //        var key = e.which;
    //        if (key  == 9) {
    //            if($('#').is(":hidden")){
    //                $("#").show();
    //            }
    //        }
    //    });
    //});

    $(document).on("click","#autoGenPas",function () {
        var th = $(this);

        //if($('#').is(":hidden")){
        //    $("#").show();
        //}
        $('.txtPass').attr('readonly', 'readonly');
        if ($(this).is(':checked')) {
            $('#hideShowPasswordPart').hide();
            $('#enterpasswordmsg').show();
            th.parents('div:eq(3)').find(".rePassDiv").show();
            //$(this).parents('div:eq(3)').find("input[name='password']").val('autoGenerate');
            //$(this).parents('div:eq(3)').find("input[name='rePassword']").val('autoGenerate');
            $(this).parents('div:eq(3)').find("input[name='password']").val('');
            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            th.parents('div:eq(3)').find("input[name='password']").removeClass("invalidVal");
        } else {
            $('#hideShowPasswordPart').show();
//            $(this).parents('div:eq(3)').find("input[name='password']").val('');
//            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            $('#enterpasswordmsg').hide();
            $('#txtrePassword-error').empty();
        }
    });

    //$(document).on("click","#txtPasswordL2tp",function() {
    //    if($('#L2tp').is(":hidden")){
    //        $("#L2tp").show();
    //    }
    //});

    //$(document).on('focus','#txtPasswordL2tp', function(e){
    //    $(window).keyup(function (e) {
    //        var key = e.which;
    //        if (key  == 9) {
    //            if($('#L2tp').is(":hidden")){
    //                $("#L2tp").show();
    //            }
    //        }
    //    });
    //});

    $(document).on("change","#chkShowL2tp",function() {
        if (this.checked) {
            $('#txtPasswordL2tp').prop('type', 'text');
            $('#txtrePasswordL2tp').prop('type', 'text');
        } else {
            $('#txtPasswordL2tp').prop('type', 'password');
            $('#txtrePasswordL2tp').prop('type', 'password');
        }
    });
    
    $(document).on("click","#autoGenPasL2tp",function () {
        var th = $(this);
        $('.txtPass').attr('readonly', 'readonly');
        $('#chkShowL2tp').change(function() {
            if (this.checked) {
                $('#txtPasswordL2tp').prop('type', 'text');
                $('#txtrePasswordL2tp').prop('type', 'text');
            } else {
                $('#txtPasswordL2tp').prop('type', 'password');
                $('#txtrePasswordL2tp').prop('type', 'password');
            }
        });

        //if($('#L2tp').is(":hidden")){
        //    $("#L2tp").show();
        //}

        if ($(this).is(':checked')) {
            $('#hideShowPasswordPartL2tp').hide();
            $('#enterpasswordmsgL2tp').show();
            $(this).parents('div:eq(3)').find(".rePassDiv").show();
            //$(this).parents('div:eq(3)').find("input[name='password']").val('autoGenerate');
            //$(this).parents('div:eq(3)').find("input[name='rePassword']").val('autoGenerate');
            $(this).parents('div:eq(3)').find("input[name='password']").val('');
            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            $(this).parents('div:eq(3)').find("input[name='password']").removeClass("invalidVal");
        } else {
            $('#hideShowPasswordPartL2tp').show();
//            $(this).parents('div:eq(3)').find("input[name='password']").val('');
//            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            $('#enterpasswordmsgL2tp').hide();
            $('#txtrePasswordL2tp-error').empty();
        }
    });
    
    $(document).on("click","#autoGenPasPPTP",function () {
        var th = $(this);
        $('.txtPass').attr('readonly', 'readonly');
        $('#chkShowPPTP').change(function() {
            if (this.checked) {
                $('#txtPasswordPPTP').prop('type', 'text');
                $('#txtrePasswordPPTP').prop('type', 'text');
            } else {
                $('#txtPasswordPPTP').prop('type', 'password');
                $('#txtrePasswordPPTP').prop('type', 'password');
            }
        });

        //if($('#PPTP').is(":hidden")){
        //    $("#PPTP").show();
        //}

        if ($(this).is(':checked')) {
            $('#hideShowPasswordPartPPTP').hide();
            $('#enterpasswordmsgPPTP').show();
            $(this).parents('div:eq(3)').find(".rePassDiv").show();
            //$(this).parents('div:eq(3)').find("input[name='password']").val('autoGenerate');
            //$(this).parents('div:eq(3)').find("input[name='rePassword']").val('autoGenerate');
            $(this).parents('div:eq(3)').find("input[name='password']").val('');
            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            $('#enterpasswordmsgPPTP').hide();
            $(this).parents('div:eq(3)').find("input[name='password']").removeClass("invalidVal");
        } else {
            $('#hideShowPasswordPartPPTP').show();
//            $(this).parents('div:eq(3)').find("input[name='password']").val('');
//            $(this).parents('div:eq(3)').find("input[name='rePassword']").val('');
            $('#enterpasswordmsgPPTP').hide();
            $('#txtrePasswordPPTP-error').empty();
        }
    });
    
    $(document).on("click","input[name='enableDns']",function (){
        if($(this).is(":checked")){
            $(this).parents('div:eq(3)').find("#forDNSServers").hide();
        } else {
            $(this).parents('div:eq(3)').find("#forDNSServers").show();
        }
    });
    
    $(document).on("click","#addTarifInLan",function () {
        var th = $(this);
        var tarifId = th.parent().find("input[name='templateId']").val();
        var tarifChangeName = 'null';
        var tarifChangeDesc = 'null';
        var isValid = true;
        var tarifName = $(".nameDescTarif").find("input[name='tarifName']");
        var errMsg = getMssg["templName_empty"];
        
        if(tarifName.hasClass("required") && tarifName.val().trim() == ''){
            tarifName.addClass("invalidVal");
            $("#errTarif").addClass("errorMessage");
            $("#errTarif").html(errMsg);
            isValid = false;
        } else if(tarifName.hasClass("invalidVal") && tarifName.val().trim() != ''){
            isValid = false;
        } else {
            tarifName.removeClass("invalidVal");
            var oldTarifName = $(".nameDescTarif").find("input[name='oldTarifName']").val();
            
            if(tarifName.val() != oldTarifName){
                tarifChangeName = tarifName.val();
            }
            
            var desc = $(".nameDescTarif").find("textarea[name='tarifDesc']").val();
            var oldTarifDesc = $(".nameDescTarif").find("input[name='oldTarifDesc']").val();

            if($.trim(desc) != $.trim(oldTarifDesc)){
                tarifChangeDesc = desc;
            }
        }
        var status = formValidateLanPage();

        if(status && isValid){
            var msg = getMssg["msg_ok"];
            //var titleMsg = $('#msgTitle').val();
            var changMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['noChange'];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                if (th.hasClass('addTemplatePage')) {
                    saveTarifInFile(allConnects, tarifName.val(), desc);
                } else {
                    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                }
            });
        }
    });
    
    function formValidateLanPage(){
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgStartIp = getMssg['error_message_startip'];
        var msgStartSubnetIps = getMssg['error_message_start_ip_based_on_netmask'];
        var msgEndSubnetIps = getMssg['error_message_end_ip_based_on_netmask'];
        var msgEndIp = getMssg['error_message_endip'];
        var msgLeaseTime = getMssg['error_message_lease_time'];
        var msgNumber =getMssg['error_message_number'];
        var msgNetAddress =getMssg['error_message_net_address'];
        var msgNetAddr = getMssg["error_message_ip_reange"];

        var modeType = $('.lanform').find(".modeType option:selected").val();
        if(modeType==1) {
            $(".lanform").validate({
                ignore: 'hidden',
                rules: {
                    ipAddress: {
                        required: true,
                        validateIpAddress: true,
                        validateNetworkAddress: {
                            ip: "#ipAddress",
                            netmask: "#netmask"
                        },
                        validateNetAddress: {
                            ip: "#ipAddress",
                            from: "#startIP",
                            to: "#endIP"
                        }

                    },
                    netmask: {
                        required: true,
                        validateIpAddress: true,
                        validateNetMask: true
                    },
                    startIP: {
                        required: true,
                        validateIpAddress: true,
                        validateNetworkAddress: {
                            ip: "#startIP",
                            netmask: "#netmask"
                        },
                        validateStartEndIP: {
                            from: "#startIP",
                            to: "#endIP"
                        },
                        validateStartEndIpBasedOnNetMask: {
                            from: "#startIP",
                            to: "#ipAddress",
                            netmask: "#netmask"
                        }
                    },
                    endIP: {
                        required: true,
                        validateIpAddress: true,
                        validateNetworkAddress: {
                            ip: "#endIP",
                            netmask: "#netmask"
                        },
                        validateStartEndIP: {
                            from: "#startIP",
                            to: "#endIP"
                        },
                        validateStartEndIpBasedOnNetMask: {
                            from: "#endIP",
                            to: "#ipAddress",
                            netmask: "#netmask"
                        }
                    },
                    leaseTime: {
                        required: true,
                        number: true,
                        validateLeaseTime: true,
                        digits: true
                    }
                },

                messages: {
                    ipAddress: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetworkAddress: msgNetAddress,
                        validateNetAddress: msgNetAddr
                    },
                    netmask: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetMask: msgNetmask
                    },
                    startIP: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetworkAddress: msgNetAddress,
                        validateStartEndIP: msgStartIp,
                        validateStartEndIpBasedOnNetMask: msgStartSubnetIps
                    },
                    endIP: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetworkAddress: msgNetAddress,
                        validateStartEndIP: msgEndIp,
                        validateStartEndIpBasedOnNetMask: msgEndSubnetIps
                    },
                    leaseTime: {
                        required: msgRequired,
                        number: msgNumber,
                        validateLeaseTime: msgLeaseTime,
                        digits: msgNumber
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function (error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });

            $('#startIP').on('input', function (e) {
                $("#ipAddress").valid();
                $("#endIP").valid();
                $("#netmask").valid();
            });
            $('#startIP').on('change', function (e) {
                $("#ipAddress").valid();
                $("#endIP").valid();
                $("#netmask").valid();
            });

            $('#endIP').on('input', function (e) {
                $("#ipAddress").valid();
                $("#startIP").valid();
                $("#netmask").valid();
            });
            $('#endIP').on('change', function (e) {
                $("#ipAddress").valid();
                $("#startIP").valid();
                $("#netmask").valid();
            });

            $('#netmask').on('input', function (e) {
                $("#ipAddress").valid();
                $("#startIP").valid();
                $("#endIP").valid();
            });
            $('#netmask').on('change', function (e) {
                $("#ipAddress").valid();
                $("#startIP").valid();
                $("#endIP").valid();
            });
            if(!($(".lanform").valid())) {
                return false;
            }
        } else {

            $(".lanform").validate({
                ignore: 'hidden',
                rules: {
                    ipAddress: {
                        required: true,
                        validateIpAddress: true,
                        validateNetworkAddress: {
                            ip: "#ipAddress",
                            netmask: "#netmask"
                        }

                    },
                    netmask: {
                        required: true,
                        validateIpAddress: true,
                        validateNetMask: true
                    }
                },

                messages: {
                    ipAddress: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetworkAddress: msgNetAddress,
                    },
                    netmask: {
                        required: msgRequired,
                        validateIpAddress: msgIp,
                        validateNetMask: msgNetmask
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function (error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
            if(!($(".lanform").valid())) {
                return false;
            }
        }

        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var ipAddr = $('.lanform').find("input[name='ipAddress']");
        isChanged = true;
        var realIpAddressName = $('.lanform').find("input[name='ipAddressName']").val();
        var realIpAddressType = $('.lanform').find("input[name='ipAddressType']").val();
        paramNames.push(realIpAddressName);
        paramValues.push(ipAddr.val());
        paramTypes.push(realIpAddressType);

        var netmask = $('.lanform').find("input[name='netmask']");
        var realNetmaskName = $('.lanform').find("input[name='netmaskName']").val();
        var realNetmaskType = $('.lanform').find("input[name='netmaskType']").val();
        paramNames.push(realNetmaskName);
        paramValues.push(netmask.val());
        paramTypes.push(realNetmaskType);

        var mode = $(".modeType option:selected").val();
        if (mode != -1) {
            isChanged = true;
            var realDhcpEnableName = $('.lanform').find("input[name='dhcpServerEnableName']").val();
            var realDhcpServerEnableType = $('.lanform').find("input[name='dhcpServerEnableType']").val();
            paramNames.push(realDhcpEnableName);
            paramValues.push(mode);
            paramTypes.push(realDhcpServerEnableType);
        } else {
            $(".modeType").addClass("invalidVal");
            isValid = false;
        }

        var needShowRes = true;
        if (mode == '1') {
            var startIP = $('.lanform').find("input[name='startIP']").val();
            var startIPName = $('.lanform').find("input[name='startIPName']").val();
            var endIP = $("input[name='endIP']").val();
            var endIPName = $("input[name='endIPName']").val();

            if (startIP != startIPName) {
                isChanged = true;
                var realEndIPName = $("input[name='startIPName']").val();
                var realStartIPType = $("input[name='startIPType']").val();
                paramNames.push(realEndIPName);
                paramTypes.push(startIPName);
                paramValues.push(startIP);

            }


            if (endIP != endIPName) {
            isChanged = true;
                var realEndIPName = $("input[name='endIPName']").val();
                var realEndIPType = $("input[name='endIPType']").val();
                paramNames.push(realEndIPName);
                paramTypes.push(endIPName);
                paramValues.push(endIP);

            }

//            $.ajax({
//                type: "POST",
//                url: $basepath + "secureFiles/actions/ajaxActions/checkStartEndIp.php",
//                data: {
//                    'checkedSIp': startIP.val(),
//                    'checkedEIp': endIP.val(),
//                    'ipAddress': ipAddr.val(),
//                    'netMask': netmask.val(),
//                    'fromApp':true
//                },
//                async: false,
//                success: function (res) {
//                    if (res == 'true'){
//                        //isChanged = true;
//                        startIP.removeClass("invalidVal");
//                        paramNames.push(startIPName);
//                        paramValues.push(startIP.val().trim());
//                        $("#messagestartip").empty();
//                    } else if (res == 'false') {
//                        var msg = getMssg["error_message_ip_reange"];
////                        $("#errTarif").html(msg);
////                        $("#errTarif").addClass("errorMessage");
//                        $('body').css("cursor","default");
//                        $("#messagestartip").html(msg);
//                        $("#messagestartip").addClass("errorMessage");
////                        startIP.addClass("invalidVal");
//                        isValid = false;
//                        needShowRes = false;
//                    } else if (res = 'logged_out') {
//                        document.location.href = 'login';
//                    }
//                }
//            });




//            $.ajax({
//                type: "POST",
//                url: $basepath + "secureFiles/actions/ajaxActions/checkStartEndIp.php",
//                data: {
//                    'checkedSIp': startIP.val(),
//                    'checkedEIp': endIP.val(),
//                    'ipAddress': ipAddr.val(),
//                    'netMask': netmask.val(),
//                    'fromApp':true
//                },
//                async: false,
//                success: function (res) {
//                    if (res == 'true'){
//                        isChanged = true;
//                        endIP.removeClass("invalidVal");
//                        paramNames.push(endIPName);
//                        paramValues.push(endIP.val().trim());
//                        $("#messageendip").empty();
//                    } else if (res == 'false') {
//                        var msg = getMssg["error_message_ip_reange"];
////                        $("#errTarif").html(msg);
////                        $("#errTarif").addClass("errorMessage");
//                        $("#messageendip").html(msg);
//                        $("#messageendip").addClass("errorMessage");
//                        $('body').css("cursor","default");
////                        endIP.addClass("invalidVal");
//                        isValid = false;
//                        needShowRes = false;
//                    } else if (res = 'logged_out') {
//                        document.location.href = 'login';
//                    }
//                }
//            });

            var leaseTime = $('.lanform').find("input[name='leaseTime']");
            var realLeaseTimeVal = $("input[name='dhcpLeaseTimeValue']").val().trim();
            if (leaseTime.val().trim() != realLeaseTimeVal) {
                isChanged = true;
                leaseTime.removeClass("invalidVal");
                var realLeaseTimeName = $('.lanform').find("input[name='dhcpLeaseTimeName']").val();
                var realDhcpLeaseTimeType = $('.lanform').find("input[name='dhcpLeaseTimeType']").val();
                paramNames.push(realLeaseTimeName);
                var leaseTimeVal = parseInt(leaseTime.val().trim());
                paramValues.push(leaseTimeVal);
                paramTypes.push(realDhcpLeaseTimeType);
            }else{
                var realLeaseTimeName = $('.lanform').find("input[name='dhcpLeaseTimeName']").val();
                var realDhcpLeaseTimeType = $('.lanform').find("input[name='dhcpLeaseTimeType']").val();
                paramNames.push(realLeaseTimeName);
                paramValues.push(realLeaseTimeVal);
                paramTypes.push(realDhcpLeaseTimeType);
            }
        }
        
        if(needShowRes){
            $('body').css("cursor", "wait");
            if (paramNames.length != 0 && isValid && isChanged) {
                var exst = false;
                var indx = 0;
                if(allConnects.length > 0){
                    for(var ii = 0; ii < allConnects.length; ii++){
                        if(allConnects[ii]['conType'] == 'lan'){
                            exst = true;
                            indx = ii;
                        }
                    }
                }
                if(!exst){
                    var lanConnects = {};
                    lanConnects['names'] = paramNames;
                    lanConnects['values'] = paramValues;
    //                lanConnects['types'] = paramTypes;

                    var connectObj = {};
                    connectObj['conType'] = "lan";
                    connectObj['conObj'] = lanConnects;
                    allConnects.push(connectObj);
                } else{
                    allConnects[indx]['conObj']['names'] = paramNames;
                    allConnects[indx]['conObj']['values'] = paramValues;
    //                allConnects[indx]['conObj']['types'] = paramTypes;
                }

                // $("#errTarif").empty();
                $('body').css("cursor", "default");
                $(".modeType").removeClass("invalidVal");
                return true;
            } else {
                $('body').css("cursor", "default");
                var msg = getMssg["sale_required_fields"];
                $("#errTarif").html(msg);
                $("#errTarif").addClass("errorMessage");
                return false;
            }
        }
        return false;
    }
    
    $(document).on("click","#saveWanAndNext",function(){
        var status = wanPageValidation();
        if(status){
            showNextTab('templWifi');
        }
    });
    
    $(document).on("click","#addTarifInWan",function(){
        var th = $(this);
        var tarifId = th.parent().find("input[name='templateId']").val();
        var tarifChangeName = 'null';
        var tarifChangeDesc = 'null';
        var isValid = true;
        var tarifName = $(".nameDescTarif").find("input[name='tarifName']");
        var errMsg = getMssg["templName_empty"];
        
        if(tarifName.hasClass("required") && tarifName.val().trim() == ''){
            tarifName.addClass("invalidVal");
            $("#errTarif").addClass("errorMessage");
            $("#errTarif").html(errMsg);
            isValid = false;
        } else if(tarifName.hasClass("invalidVal") && tarifName.val().trim() != '') {
            isValid = false;
        } else {
            tarifName.removeClass("invalidVal");
            var oldTarifName = $(".nameDescTarif").find("input[name='oldTarifName']").val();
            
            if(tarifName.val() != oldTarifName){
                tarifChangeName = tarifName.val();
            }
            
            var desc = $(".nameDescTarif").find("textarea[name='tarifDesc']").val();
            var oldTarifDesc = $(".nameDescTarif").find("input[name='oldTarifDesc']").val();
            
            if($.trim(desc) != $.trim(oldTarifDesc)){
                tarifChangeDesc = desc;
            }
        }
        
        var status = wanPageValidation();
        
        if(status && isValid){
            var msg = getMssg["msg_ok"];
            //var titleMsg = $('#msgTitle').val();
            var changMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['noChange'];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                if (th.hasClass('addTemplatePage')) {
                    saveTarifInFile(allConnects, tarifName.val(), desc);
                } else {
                    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                }
            });
        }
    });
    
    function setDefaultConnection(){
        var defaultConn = $('input[name=defaultGat]:checked');
        if(defaultConn.is(":checked")){
            var connectionTypeId = defaultConn.closest('tr').find('input[name=wanID]').val();
            for(var i = 0; i < wanConnects.length; i++){
                if(wanConnects[i]['id'] == connectionTypeId){
                    if($.inArray('def_connection', wanConnects[i].names) == -1){
                        if(wanConnects[i]['conT'] == 'ppp'){
                            wanConnects[i].names.push('def_connection');
                            wanConnects[i].values.push('1');
                        }

                        if(wanConnects[i]['conT'] == 'dynamic' || wanConnects[i]['conT'] == 'static'){
                            wanConnects[i].names.push('def_connection');
                            wanConnects[i].values.push('1');
                        }
                    }
                }
            }

            for(var i = 0; i < wanConnects.length; i++){
                if(wanConnects[i]['id'] != connectionTypeId && 
                        $.inArray('def_connection', wanConnects[i].names) > -1){
                    var index = wanConnects[i].names.indexOf('def_connection');
                    wanConnects[i].names.splice(index,1);
                    wanConnects[i].values.splice(index,1);
                }
            }
        }
    }
    
    function wanPageValidation(){
        if(wanConnects.length > 0){
            var exst = false;
            var indx = 0;
            
            setDefaultConnection();
         
            if(allConnects.length > 0){
                for(var ii = 0; ii < allConnects.length; ii++){
                    if(allConnects[ii]['conType'] == 'wan'){
                        exst = true;
                        indx = ii;
                    }
                }
            }
            if(!exst){
                var connectObj = {};
                connectObj['conType'] = "wan";
                connectObj['conObj'] = wanConnects;
                allConnects.push(connectObj);
            } else {
                allConnects[indx]['conObj'] = wanConnects;
            }
            return true;
        } else {
            var msg = getMssg["no_connection"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
    }
    
    $(document).on("click","input[name='netmask']",function(){
       if($(this).val() == ''){
           $(this).val('255.255.255.0');
       }
    });
    
    $(document).on("click","input[name='netmaskStatic']",function(){
       if($(this).val() == ''){
           $(this).val('255.255.255.0');
       }
    });
    
    $(document).on("click","#addStaticWan",function(e){
        e.preventDefault();
        var th = $(this);
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();
        
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber = getMssg['error_message_number'];
        var msgIpGatewayIps = getMssg['error_message_ip_gateway_based_on_netmask'];
        //var msgMac = getMssg['error_message_mac'];
        var msgDns = getMssg['error_message_dns'];
        var msgDNSEquality = getMssg['error_message_dns_equality'];
        var msgLe1500 = getMssg['error_message_le_1500'];
        var msgLe1550 = getMssg['error_message_le_1550'];
        var msgLe1540 = getMssg['error_message_le_1540'];
        var msgLe1400 = getMssg['error_message_le_1400'];
        var msgOnlyNum = getMssg['error_message_digit_number'];
        var msgNetAddress =getMssg['error_message_net_address'];
        var msgIpGateway = getMssg['error_message_ip_gateway'];
        var msgLe32 = getMssg['error_message_at_length_32'];
        var msgIpDNS = getMssg['error_message_ip_dns'];
        var msgGr1 = getMssg['error_message_ge_1'];

        $("#forResetStatic").validate({
            rules: {
                dWNameStatic: {
                    required: true,
                    validateConnectionNameLength: true
                },
                ip: {
                    required: true,
                    validateIpAddress : true,
                        validateStartEndIpBasedOnNetMask: {
                            from : "#ip",
                            to : "#gateway",
                            netmask: "#netmaskStatic"
                        },
                    validateNetworkAddress: {
                        ip : "#ip",
                        netmask: "#netmaskStatic"
                    }
                },
                netmaskStatic: {
                    required: true,
                    validateIpAddress : true,
                    validateNetMask : true
                },
                gateway:{
                    required: true,
                    validateIpAddress : true,
                        validateStartEndIpBasedOnNetMask: {
                            from : "#ip",
                            to : "#gateway",
                            netmask: "#netmaskStatic"
                        },
                    validateNetworkAddress: {
                        ip : "#gateway",
                        netmask: "#netmaskStatic"
                    },
                    ipAddressIsEqual: {
                        ip : "#ip",
                        gateway : "#gateway"
                    }
                },
                primaryDns:{
                    required: true,
                    validateIpAddress : true,
                    // validateDNS : true,
                    validateDNSEquality:{
                            primDns: "#primaryDns",
                            secondDns: "#secondaryDns"
                    }
                },
                secondaryDns:{
//                  required: true,
//                     validateDNS : true,
                    validateIpAddress : true,
//                  validateDNSEquality:{
//                     primDns: "#primaryDns",
//                     secondDns: "#secondaryDns"
//                  }
                },
                //mac:{
                //    validateMac : true
                //},
                mtu: {
                    required: true,
                    number: true,
                    digits: true,
                    //max: 1500,
                    // max: 1550,
                    // min: 1400,
                    max: 1540,
                    min: 1
                }
            },

            messages: {
                dWNameStatic: {
                    required: msgRequired,
                    validateConnectionNameLength: msgLe32
                },
                ip: {
                    required: msgRequired,
                    validateIpAddress: msgIp,
                    validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                    validateNetworkAddress: msgNetAddress
                },
                netmaskStatic: {
                    required: msgRequired,
                    validateIpAddress: msgIp,
                    validateNetMask: msgNetmask
                },
                gateway: {
                    required: msgRequired,
                    validateIpAddress: msgIp,
                    validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                    validateNetworkAddress: msgNetAddress,
                    ipAddressIsEqual: msgIpGateway
                },
                primaryDns: {
                    required: msgRequired,
                    validateIpAddress : msgIpDNS,
                    // validateDNS: msgDns,
                    validateDNSEquality: msgDNSEquality
                },
                secondaryDns: {
//                  required: msgRequired,
//                     validateDNS: msgDns,
                    validateIpAddress : msgIpDNS,
//                  validateDNSEquality: msgDNSEquality
                },
                //mac: {
                //    validateMac: msgMac
                //},
                mtu: {
                    required: msgRequired,
                    max: msgLe1540,
                    min: msgGr1,
                    // max: msgLe1500,
                    // max: msgLe1550,
                    digits: msgOnlyNum,
                    number: msgNumber,
                    // min: msgLe1400
                }
            },
            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });
        
        $('#ip').on('input',function(e){
            $("#gateway").valid();
            $("#netmaskStatic").valid();
        });
        
        $('#ip').on('change',function(e){
            $("#gateway").valid();
            $("#netmaskStatic").valid();
        });

        $('#gateway').on('input',function(e){
            $("#ip").valid();
            $("#netmaskStatic").valid();
        });
        
        $('#gateway').on('change',function(e){
            $("#ip").valid();
            $("#netmaskStatic").valid();
        });

        $('#netmaskStatic').on('input',function(e){
            $("#ip").valid();
            $("#gateway").valid();
        });

        $('#netmaskStatic').on('change',function(e){
            $("#ip").valid();
            $("#gateway").valid();
        });
           
        $('#primaryDns').on('input',function(e){
            $("#secondaryDns").valid();
        });

        $('#primaryDns').on('change',function(e){
            $("#secondaryDns").valid();
        });

        $('#secondaryDns').on('input',function(e){
            $("#primaryDns").valid();
        });

        $('#secondaryDns').on('change',function(e){
            $("#primaryDns").valid();
        });
        
        if(!($("#forResetStatic").valid())) {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            return false;
        }
        
        var wanName = document.getElementsByName("dWName")[0].value;
        var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
        var wanNameType = document.getElementsByName("dWNameType")[0].value;
        var wanNameNew = document.getElementsByName("dWNameStatic")[0].value;
        // if (wanNameOld !== wanNameNew) {
            paramNames.push(wanName);
            paramValues.push(wanNameNew);
            paramTypes.push(wanNameType);
            isChanged = true;
        // }
        
        var ipAddr = th.parent().parent().find("input[name='ip']");
        var realIpAddressName = th.parent().parent().find("input[name='ipName']").val();
        var realIpAddressType = th.parent().parent().find("input[name='ipType']").val();
        paramNames.push(realIpAddressName);
        paramValues.push(ipAddr.val());
        paramTypes.push(realIpAddressType);

        var netmask = th.parent().parent().find("input[name='netmaskStatic']");
        var realNetmaskName = th.parent().parent().find("input[name='netmaskName']").val();
        var realNetmaskType = th.parent().parent().find("input[name='netmaskType']").val();
        paramNames.push(realNetmaskName);
        paramValues.push(netmask.val());
        paramTypes.push(realNetmaskType);

        var mtu = th.parent().parent().find("input[name='mtu']");
        var mtuVal = mtu.val().trim();
        isChanged = true;
        var realStartIPName = th.parent().parent().find("input[name='mtuName']").val();
        var realStartIPType = th.parent().parent().find("input[name='mtuType']").val();
        paramNames.push(realStartIPName);
        paramValues.push(mtuVal);
        paramTypes.push(realStartIPType);

        //var mac = th.parent().parent().find("input[name='mac']");
        //if(mac.val().trim() != ''){
        //    isChanged = true;
        //    mac.removeClass("invalidVal");
        //    var realEndIPName = th.parent().parent().find("input[name='macName']").val();
        //    var realEndIPType = th.parent().parent().find("input[name='macType']").val();
        //    paramNames.push(realEndIPName);
        //    paramValues.push(mac.val().trim());
        //    paramTypes.push(realEndIPType);
        //}

        var gateway = th.parent().parent().find("input[name='gateway']");
        isChanged = true;
        gateway.removeClass("invalidVal");
        var realLeaseTimeName = th.parent().parent().find("input[name='gatewayName']").val();
        var realDhcpLeaseTimeType = th.parent().parent().find("input[name='gatewayType']").val();
        paramNames.push(realLeaseTimeName);
        paramValues.push(gateway.val().trim());
        paramTypes.push(realDhcpLeaseTimeType);

//        var dns = th.parent().parent().find("input[name='dns']");
//        var realDnsName = th.parent().parent().find("input[name='dnsName']").val();
//        var realDnsType = th.parent().parent().find("input[name='dnsType']").val();
//        paramNames.push(realDnsName);
//        paramValues.push(dns.val().trim());
//        paramTypes.push(realDnsType);
        
        var realDnsName = th.parent().parent().find("input[name='primaryDnsName']").val();
        var realDnsType = th.parent().parent().find("input[name='primaryDnsType']").val();
        var dns = th.parent().parent().find("input[name='primaryDns']").val().trim();
        var secondaryDns = th.parent().parent().find("input[name='secondaryDns']").val().trim();

        if(secondaryDns != ''){
            paramNames.push(realDnsName);
            paramValues.push(dns + ',' + secondaryDns);
            paramTypes.push(realDnsType);
        }else{
            paramNames.push(realDnsName);
            paramValues.push(dns);
            paramTypes.push(realDnsType);
        }
         
        var enableNat = th.parent().parent().find("input[name='enableNat']");
        var valenableNat = '';
        if(enableNat.is(":checked")){
            valenableNat = '1';
        } else {
            valenableNat = '0';
        }

        var realEnableNatName = th.parent().parent().find("input[name='enableNatName']").val();
        var realEnableNatType = th.parent().parent().find("input[name='enableNatType']").val();
        
        if(toAdd == 'true' && valenableNat == '1'){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }
        
        if(toAdd == 'false' && (valenableNat == '1' || valenableNat == '0')){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }
                    
        var enable = th.parent().parent().find("input[name='enable']");
        var valEnable = '';
        if(enable.is(":checked")){
            valEnable = '1';
        } else {
            valEnable = '0';
        }

        var realEnableName = th.parent().parent().find("input[name='enableName']").val();
        var realEnableType = th.parent().parent().find("input[name='enableType']").val();
        
        if(toAdd == 'true' && valEnable == '1'){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        if(toAdd == 'false' && (valEnable == '1' || valEnable == '0')){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }

        if(paramNames.length != 0 && isValid && isChanged) {
            var exst = false;
            var indx = 0;
            if(wanConnects.length > 0){
                for(var ii = 0; ii < wanConnects.length; ii++){
                    if(wanConnects[ii]['conT'] == 'static'){
                        exst = true;
                        indx = ii;
                    } else  if(wanConnects[ii]['conT'] == 'dynamic'){
                        wanConnects.splice(ii, 1);
                    }
                }
            }
            if(!exst){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "S";
                wanConnectsOBJ['conT'] = "static";
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wanConnects.push(wanConnectsOBJ);
                
                getWanConnectionTable(wanNameNew,"static");

            } else {
                if($.inArray('def_connection', wanConnects[indx].names) > -1){
                    var index = wanConnects[indx].names.indexOf('def_connection');
                    var connectioVal = wanConnects[indx].values[index];
                    paramNames.push('def_connection');
                    paramValues.push(connectioVal);
                }
                
                getWanConnectionTable(wanNameNew,"static");

                wanConnects[indx]['names'] = paramNames;
                wanConnects[indx]['values'] = paramValues;
                wanConnects[indx]['types'] = paramTypes;
            }
            $("#divForWAN").empty();
            $("#shoeConnections").show();
            $(".general-settings").hide();
            $(".addStaticIp").hide();
            $("#errTarif").empty();
            $("#addNewWan").show();
            $('#forResetStatic').trigger('reset');
            checkDefaultConnection();
            return false;

        } else {
            var msg = getMssg["sale_required_fields"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    });
    
    $(document).on("click","#cancelStaticWan",function(){
        if(wanConnects.length > 0){
            $("#shoeConnections").show();
        }
        $("#divForWAN").empty();
        $(".general-settings").hide();
        $(".addStaticIp").hide();
        $("#errTarif").empty();
        $("#addNewWan").show();
        $('#forResetStatic').validate().resetForm();
        checkDefaultConnection();
    });

    $(document).on("click","#cancelWifi",function(){

        if(wifiConnects.length > 0){
            $("#showWiFI").show();
        }
        $("#divForWifi").empty();
        $('#wifiPage').show();
        $('#addNewWifi').show();
        $('.addNewWifiDiv').show();
        $('#divForAddWifi').hide();
        $('#wifiPage1').hide();
        $('#forResetWIFI').validate().resetForm();
    });

    $(document).on("click",".wifiParam",function(){
        var wifiIDdd = $(this).parent().find("input[name='wifiID']").val();
        var paramNames = [];
        var paramValues = [];
        for(var iii = 0; iii < wifiConnects.length; iii++) {
            if (wifiConnects[iii]['id'] == wifiIDdd.trim()) {
                paramNames =  wifiConnects[iii]['names'];
                paramValues = wifiConnects[iii]['values'];

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/viewEachWifiForTarif.php",
                    data:{
                        'id':wifiIDdd,
                        'paramN':  paramNames,
                        'paramV':paramValues,
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = 'login';
                        } else {
                            $('#shoeConnections').hide();
                            $("#divForWifi").empty();
                            $("#divForWifi").html(result);
                            $("#divForWifi").show();
                            $("#showWiFI").hide();
                            $("#addNewWifi").hide();
                            $(".addNewWifiDiv").hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
//                console.log(wanConnects);
                return false;
            }
        }
    });

    $(document).on("click",".wanParam",function(){
        var wanIDdd = $(this).parent().find("input[name='wanID']").val();

        var paramNames = [];
        var paramValues = [];
//        var paramTypes=[];
        var conType = '';
        
        for(var iii = 0; iii < wanConnects.length; iii++){
            if(wanConnects[iii]['id'] == wanIDdd.trim()){
                paramNames =  wanConnects[iii]['names'];
                paramValues = wanConnects[iii]['values'];
//                paramTypes = wanConnects[iii]['types'];
                
                var connectionType = '';
                if($.inArray('conn_type', wanConnects[iii].names) > -1){
                    var index = wanConnects[iii].names.indexOf('conn_type');
                    connectionType = wanConnects[iii].values[index];
                    if(connectionType == 'L2TP_Relay'){
                        conType = "l2tp";
                    }else if(connectionType == 'PPTP_Relay'){
                        conType = "pptp";
                    }
                    
                }else{
                    conType = wanConnects[iii]['conT'];
                }
                
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/viewEachWanForTarif.php",
                    data:{
                        'id':wanIDdd,
                        'connType':conType,
                        'paramN':  paramNames,
                        'paramV':paramValues,
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = 'login';
                        } else {
                            $('#shoeConnections').hide();
                            $("#divForWAN").empty();
                            $("#divForWAN").html(result);
                            $("#divForWAN").show();
                            $(".forNewWan").css("display","block");
                            $("#addNewWan").hide();
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
//                console.log(wanConnects);
                return false;
            }
        }
    });
    
    $(document).on("click",".deleteWanTarif",function(){
        var wanId = $(this).parent().find("input[name='wanID']").val();
        for(var iii = 0; iii < wanConnects.length; iii++){
            if(wanConnects[iii]['id'] == wanId.trim()){
                wanConnects.splice(iii,1);
                if(wanConnects.length == 0){
                    $(".tempalteWanShow tr").not(':first').remove();
                    $("#shoeConnections").hide();
                } else {
                    $(".tempalteWanShow tr").not(':first').remove();
                    for(var ii = 0; ii < wanConnects.length; ii++){
                        if(wanConnects[ii]['conT'] == 'static'){
                            var connectioName = '';
                            if($.inArray('name', wanConnects[ii].names) > -1){
                                var index = wanConnects[ii].names.indexOf('name');
                                connectioName = wanConnects[ii].values[index];
                            }
                            buildTableRows((ii+1),connectioName,'STATIC IP',wanConnects[ii]['id']);
                            
                        } else if(wanConnects[ii]['conT'] == 'dynamic'){
                            var connectioName = '';
                            if($.inArray('name', wanConnects[ii].names) > -1){
                                var index = wanConnects[ii].names.indexOf('name');
                                connectioName = wanConnects[ii].values[index];
                            }
                            buildTableRows((ii+1),connectioName,'DYNAMIC IP',wanConnects[ii]['id']);
                            
                        } else  if(wanConnects[ii]['conT'] == 'ppp'){
                            var connectioName = '';
                            if($.inArray('name', wanConnects[ii].names) > -1){
                                var index = wanConnects[ii].names.indexOf('name');
                                connectioName = wanConnects[ii].values[index];
                            }
                            
                            var connectionType = '';
                            if($.inArray('conn_type', wanConnects[ii].names) > -1){
                                var index = wanConnects[ii].names.indexOf('conn_type');
                                connectionType = wanConnects[ii].values[index];
                                if(connectionType == 'L2TP_Relay'){
                                    buildTableRows((ii+1),connectioName,'L2TP',wanConnects[ii]['id']);
                                }else {
                                    buildTableRows((ii+1),connectioName,'PPTP',wanConnects[ii]['id']);
                                }
                                
                            }else{
                                buildTableRows((ii+1),connectioName,'PPPOE',wanConnects[ii]['id']);
                            }
                        }
//                        else if(wanConnects[ii]['conT'] == 'l2tp'){
//                            var connectioName = '';
//                            if($.inArray('name', wanConnects[ii].names) > -1){
//                                var index = wanConnects[ii].names.indexOf('name');
//                                connectioName = wanConnects[ii].values[index];
//                            }
//                            buildTableRows((ii+1),connectioName,'L2TP',wanConnects[ii]['id']);
//                        }
                    }
                    $("#shoeConnections").show();
                }
                $("#divForWAN").empty();
                $("#errTarif").empty();
                $("#addNewWan").show();
                return false;
            }
        }
    });
    
    $(document).on("click","#addDynamicWan",function(e){
        e.preventDefault();
        var th = $(this);
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();
            
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgIpDNS = getMssg['error_message_ip_dns'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber = getMssg['error_message_number'];
        //var msgMac = getMssg['error_message_mac'];
        var msgDns = getMssg['error_message_dns'];
        var msgEmpty = getMssg['error_message_empty'];
        var msgDNSEquality = getMssg['error_message_dns_equality'];
        //var msgLe1500 = getMssg['error_message_le_1500'];
        var msgLe1550 = getMssg['error_message_le_1550'];
        var msgLe1400 = getMssg['error_message_le_1400'];
        var msgOnlyNum = getMssg['error_message_digit_number'];
        var msgLe32 = getMssg['error_message_at_length_32'];
        var msgGr1 = getMssg['error_message_ge_1'];
        var msgLe1540 = getMssg['error_message_le_1540'];

        $("#forResetDynamic").validate({
            rules: {
                dWNameDynamic: {
                    required: true,
                    validateConnectionNameLength: true
                },
                primaryDnsDynamic:{
                    required: true,
                    // validateDNS : true,
                    validateIpAddress : true,
                    validateIsEmpty: true,
                    validateDNSEquality:{
                            primDns: "#primaryDnsDynamic",
                            secondDns: "#secondaryDnsDynamic"
                    }
                },
                secondaryDnsDynamic:{
//                  required: true,
//                     validateDNS : true,
                    validateIpAddress : true,
//                  validateDNSEquality:{
//                     primDns: "#primaryDns",
//                     secondDns: "#secondaryDns"
//                  }
                },
                //mac:{
                //    validateMac : true
                //},
                mtu: {
                    required: true,
                    number: true,
                    digits: true,
                    max: 1540,
                    min: 1
                    //max: 1500,
                    // max: 1550,
                    // min: 1400
                }
            },

            messages: {
                dWNameDynamic: {
                    required: msgRequired,
                    validateConnectionNameLength: msgLe32
                },
                primaryDnsDynamic: {
                    required: msgRequired,
                    // validateDNS: msgDns,
                    validateIpAddress: msgIpDNS,
                    validateIsEmpty: msgEmpty,
                    validateDNSEquality: msgDNSEquality
                },
                secondaryDnsDynamic: {
//                  required: msgRequired,
                    validateIpAddress : msgIpDNS,
//                     validateDNS: msgDns,
//                  validateDNSEquality: msgDNSEquality
                },
                //mac: {
                //    validateMac: msgMac
                //},
                mtu: {
                    required: msgRequired,
                    number: msgNumber,
                    digits: msgOnlyNum,
                    //max: msgLe1500,
                    // max: msgLe1550,
                    // min: msgLe1400
                    max: msgLe1540,
                    min: msgGr1
                }
            },
            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });
        
        $('#primaryDnsDynamic').on('input',function(e){
            $("#secondaryDnsDynamic").valid();
        });

        $('#primaryDnsDynamic').on('change',function(e){
            $("#secondaryDnsDynamic").valid();
        });

        $('#secondaryDnsDynamic').on('input',function(e){
            $("#primaryDnsDynamic").valid();
        });

        $('#secondaryDns').on('change',function(e){
            $("#primaryDnsDynamic").valid();
        });
        
        if(!($("#forResetDynamic").valid())) {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            return false;
        }
            
        var mtu = th.parent().parent().find("input[name='mtu']");
        var mtuVal = mtu.val().trim();
        isChanged = true;
        var realStartIPName = th.parent().parent().find("input[name='mtuName']").val();
        var realStartIPType = th.parent().parent().find("input[name='mtuType']").val();
        paramNames.push(realStartIPName);
        paramValues.push(mtuVal);
        paramTypes.push(realStartIPType);
        
        var wanName = document.getElementsByName("dWName")[0].value;
        var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
        var wanNameType = document.getElementsByName("dWNameType")[0].value;
        var wanNameNew = document.getElementsByName("dWNameDynamic")[0].value;

        // if (wanNameOld !== wanNameNew) {
            paramNames.push(wanName);
            paramValues.push(wanNameNew);
            paramTypes.push(wanNameType);
            isChanged = true;
        // }
        //
        //var mac = th.parent().parent().find("input[name='mac']");
        //if(mac.val().trim() != ''){
        //    isChanged = true;
        //    mac.removeClass("invalidVal");
        //    var realEndIPName = th.parent().parent().find("input[name='macName']").val();
        //    var realEndIPType = th.parent().parent().find("input[name='macType']").val();
        //    paramNames.push(realEndIPName);
        //    paramValues.push(mac.val().trim());
        //    paramTypes.push(realEndIPType);
        //}

        var enableNat = th.parent().parent().find("input[name='enableNat']");
        var valenableNat = '';
        if(enableNat.is(":checked")){
            valenableNat = '1';
        } else {
            valenableNat = '0';
        }

        var realEnableNatName = th.parent().parent().find("input[name='enableNatName']").val();
        var realEnableWirelessType = th.parent().parent().find("input[name='enableNatType']").val();
        
        if(toAdd == 'true' && valenableNat == '1'){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableWirelessType);
        }
        
        if(toAdd == 'false' && (valenableNat == '1' || valenableNat == '0')){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableWirelessType);
        }
        

        var enableDns = th.parent().parent().find("input[name='enableDns']");
        var valenableDns = '';
        if(enableDns.is(":checked")){
            valenableDns = '1';
        } else {
            valenableDns = '0';

            $("#forResetDynamic").validate({
                rules: {
                    primaryDnsDynamic:{
                        required: true,
                        // validateDNS : true,
                        validateIpAddress : true,
                        validateIsEmpty: true,
                        validateDNSEquality:{
                                primDns: "#primaryDnsDynamic",
                                secondDns: "#secondaryDnsDynamic"
                        }
                    },
                    secondaryDnsDynamic:{
                        validateIpAddress : true,
    //                  required: true,
    //                     validateDNS : true,
    //                  validateDNSEquality:{
    //                     primDns: "#primaryDns",
    //                     secondDns: "#secondaryDns"
    //                  }
                    },
                    //mac:{
                    //    validateMac : true
                    //},
                    mtu: {
                        required: true,
                        number: true,
                        digits: true,
                        max: 1540,
                        min: 1
                        //max: 1500,
                        // max: 1550,
                        // min: 1400
                    }
                },

                messages: {
                    primaryDnsDynamic: {
                        required: msgRequired,
                        validateIpAddress: msgIpDNS,
                        // validateDNS: msgDns,
                        validateIsEmpty: msgEmpty
                    },
                    secondaryDnsDynamic: {
//                  required: msgRequired,
//                         validateDNS: msgDns,
                        validateIpAddress : msgIpDNS,
    //                  validateDNSEquality: msgDNSEquality
                    },
                    //mac: {
                    //    validateMac: msgMac
                    //},
                    mtu: {
                        required: msgRequired,
                        number: msgNumber,
                        digits: msgOnlyNum,
                        //max: msgLe1500,
                        // max: msgLe1550,
                        // min: msgLe1400
                        max: msgLe1540,
                        min: msgGr1
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
            
            $('#primaryDnsDynamic').on('input',function(e){
                $("#secondaryDnsDynamic").valid();
            });

            $('#primaryDnsDynamic').on('change',function(e){
                $("#secondaryDnsDynamic").valid();
            });

            $('#secondaryDnsDynamic').on('input',function(e){
                $("#primaryDnsDynamic").valid();
            });

            $('#secondaryDnsDynamic').on('change',function(e){
                $("#primaryDnsDynamic").valid();
            });
            
            if(!($("#forResetDynamic").valid())) {
                th.removeAttr("disabled");
                th.css("opacity", "1");
                return false;
            }
                
//            var dns = th.parent().parent().find("input[name='dnsDynamic']");
//            var realDnsName = th.parent().parent().find("input[name='dnsName']").val();
//            var realDnsType = th.parent().parent().find("input[name='dnsType']").val();
//            paramNames.push(realDnsName);
//            paramValues.push(dns.val().trim());
//            paramTypes.push(realDnsType);
            var realDnsName = th.parent().parent().find("input[name='primaryDnsName']").val();
            var realDnsType = th.parent().parent().find("input[name='primaryDnsType']").val();
            var dns = th.parent().parent().find("input[name='primaryDnsDynamic']").val().trim();
            var secondaryDns = th.parent().parent().find("input[name='secondaryDnsDynamic']").val().trim();

            if(secondaryDns != ''){
                paramNames.push(realDnsName);
                paramValues.push(dns + ',' + secondaryDns);
                paramTypes.push(realDnsType);
            }else{
                paramNames.push(realDnsName);
                paramValues.push(dns);
                paramTypes.push(realDnsType);
            }
        }
            
        var realEnableDnsName = th.parent().parent().find("input[name='enableDnsName']").val();
        var realEnableDnsType = th.parent().parent().find("input[name='enableDnsType']").val();
        paramNames.push(realEnableDnsName);
        paramValues.push(valenableDns);
        paramTypes.push(realEnableDnsType);

        var enable = th.parent().parent().find("input[name='enable']");
        var valEnable = '';
        if(enable.is(":checked")){
            valEnable = '1';
        } else {
            valEnable = '0';
        }
        
        var realEnableName = th.parent().parent().find("input[name='enableName']").val();
        var realEnableType = th.parent().parent().find("input[name='enableType']").val();
        
        if(toAdd == 'true' && valEnable == '1'){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        if(toAdd == 'false' && (valEnable == '1' || valEnable == '0')){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        if(paramNames.length != 0 && isValid && isChanged) {
            var exst = false;
            var indx = 0;
            if(wanConnects.length > 0){
                for(var ii = 0; ii < wanConnects.length; ii++){
                    if(wanConnects[ii]['conT'] == 'dynamic'){
                        exst = true;
                        indx = ii;
                    } else if(wanConnects[ii]['conT'] == 'static'){
                        wanConnects.splice(ii,1);
                    }
                }
            }
            
            if(!exst){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "D";
                wanConnectsOBJ['conT'] = "dynamic";
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wanConnects.push(wanConnectsOBJ);
                
                getWanConnectionTable(wanNameNew,"dynamic");

            } else {
                if($.inArray('def_connection', wanConnects[indx].names) > -1){
                    var index = wanConnects[indx].names.indexOf('def_connection');
                    var connectioVal = wanConnects[indx].values[index];
                    paramNames.push('def_connection');
                    paramValues.push(connectioVal);
                }
                
                getWanConnectionTable(wanNameNew,"dynamic");

                wanConnects[indx]['names'] = paramNames;
                wanConnects[indx]['values'] = paramValues;
                wanConnects[indx]['types'] = paramTypes;
            }
            
            $("#divForWAN").empty();
            $("#shoeConnections").show();
            $(".general-settings").hide();
            $(".addDynamicIp").hide();
            $("#errTarif").empty();
            $("#addNewWan").show();
            $('#forResetDynamic').trigger('reset');
            checkDefaultConnection();
            return false;
            
        } else {
            var msg = getMssg["sale_required_fields"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    });
    
    $(document).on("click","#cancelDynamicWan",function(){
        if(wanConnects.length > 0){
            $("#shoeConnections").show();
        }
        $('#forResetDynamic #forDNSServers').show();
        $("#divForWAN").empty();
        $(".general-settings").hide();
        $(".addDynamicIp").hide();
        $("#errTarif").empty();
        $("#addNewWan").show();
        $('#forResetDynamic').validate().resetForm();
        checkDefaultConnection();
    });
    
    $(document).on("click","#addPPPWan",function(e){
        e.preventDefault();
        var th = $(this);
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();
        
        var msgRequired =  getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgMac = getMssg['error_message_mac'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber = getMssg['error_message_number'];
        var msgRepassword =  getMssg['error_message_repassword'];
        var msgEmpty = getMssg['error_message_empty'];
        // var msgGe0 = getMssg['error_message_ge_0'];
        var msgGr0 = getMssg['error_message_gr_0'];
        // var msgGe1 = getMssg['error_message_ge_1'];
        var msgLessThan = getMssg['error_message_le_255'];
        var msgReqField = getMssg['name_required_field'];
        var msgLe32 = getMssg['error_message_at_length_32'];
        var msgPass = getMssg['wifi-ascii'];
        var msgLe1550 = getMssg['error_message_le_1550'];
        var msgLe1400 = getMssg['error_message_le_1400'];


        $("#forResetPPPoE").validate({
            rules: {
                pppName: {
                    required: true,
                    validateIsEmpty: true,
                    validateConnectionNameLength: true
                },
                username: {
                    required: true,
                    noSpace: true,
                    validateASCII: true
                },
                mru: {
                    required: true,
                    number: true,
                    max: 1550,
                    min: 1400
                },
                pppEcho: {
                    required: true,
                    digits: true,
                    min: 1
                },
                pppEchoRetry: {
                    required: true,
                    digits: true,
                    min: 1,
                    max: 255
                },
                password: {
                    required: true,
                    validateIsEmpty: true,
                    validateASCII: true
                },
                rePassword: {
                    required: true,
                    equalTo: "#txtPassword",
                }
            },

            messages: {
                pppName: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateConnectionNameLength: msgLe32
                },
                username: {
                    required: msgRequired,
                    noSpace: msgReqField,
                    validateASCII: msgPass
                },
                mru: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgLe1400,
                    max: msgLe1550
                },
                pppEcho: {
                    required: msgRequired,
                    digits: msgNumber,
                    min: msgGr0
                },
                pppEchoRetry: {
                    required: msgRequired,
                    digits: msgNumber,
                    min: msgGr0,
                    max: msgLessThan
                },
                password: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateASCII: msgPass,
                },
                rePassword: {
                    required: msgRequired,
                    equalTo: msgRepassword
                }
            },
            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forResetPPPoE").valid())) {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            return false;
        }

        var pppName = th.parent().parent().find("input[name='pppName']");
        var nameVal = pppName.val();
        var realNameName = th.parent().parent().find("input[name='nameName']").val();
        var realNameType = th.parent().parent().find("input[name='nameType']").val();
        paramNames.push(realNameName);
        paramValues.push(nameVal);
        paramTypes.push(realNameType);

        var serviceName = th.parent().parent().find("input[name='serviceName']");
        if(serviceName.val().trim() != ''){
            isChanged = true;
            serviceName.removeClass("invalidVal");
            var realServiceName = th.parent().parent().find("input[name='serviceNameName']").val();
            var realNameType1 = th.parent().parent().find("input[name='serviceNameType']").val();
            paramNames.push(realServiceName);
            paramValues.push(serviceName.val().trim());
            paramTypes.push(realNameType1);
        }

        var username = th.parent().parent().find("input[name='username']");
        var realUsernameName = th.parent().parent().find("input[name='usernameName']").val();
        var realUsernameType = th.parent().parent().find("input[name='usernameType']").val();
        paramNames.push(realUsernameName);
        paramValues.push(username.val().trim());
        paramTypes.push(realUsernameType);

        if($('#autoGenPas').is(':checked')) {
            var password = 'autoGenerate';
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }else{
            var password = th.parent().parent().find("input[name='password']").val().trim();
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }

        var mru = th.parent().parent().find("input[name='mru']");
        var mruVal = mru.val().trim();
        isChanged = true;
        var realMruName = th.parent().parent().find("input[name='mruName']").val();
        var realMruType = th.parent().parent().find("input[name='mruType']").val();
        paramNames.push(realMruName);
        paramValues.push(mruVal);
        paramTypes.push(realMruType);

        var enableNat = th.parent().parent().find("input[name='enableNat']");
        var valenableNat='';
        if(enableNat.is(":checked")){
            valenableNat = '1';
        } else {
            valenableNat = '0';
        }
        
        var realEnableNatName = th.parent().parent().find("input[name='enableNatName']").val();
        var realEnableNatType = th.parent().parent().find("input[name='enableNatType']").val();
        
        if(toAdd == 'true' && valenableNat == '1'){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }
        
        var realEnableNatValue = th.parent().parent().find("input[name='enableNatValue']").val();
        if (toAdd == 'false' && realEnableNatValue != valenableNat) {
            isChanged = true;
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableNatName);
            paramValues.push(realEnableNatValue);
            paramTypes.push(realEnableNatType);
        }
        

        var standard = th.parent().parent().find(".authProtocolType option:selected").val();
        isChanged = true;
        var realStandardName = th.parent().parent().find("input[name='authProtocolTypeName']").val();
        var realStandardType = th.parent().parent().find("input[name='authProtocolTypeType']").val();
        paramNames.push(realStandardName);
        paramValues.push(standard);
        paramTypes.push(realStandardType);
        
        var keepAlive = th.parent().parent().find("input[name='enableKeepAlive']");
        var valKeepAlive = '';
        if (keepAlive.is(":checked")) {
            valKeepAlive = '1';
        } else {
            valKeepAlive = '0';
        }
        
        if(valKeepAlive == '1'){
            var pppecho = th.parent().parent().find("input[name='pppEcho']");
            if(pppecho.hasClass("required") && pppecho.val() == ''){
                pppecho.addClass("invalidVal");
                isValid = false;
            } else if(pppecho.val().trim() != ''){
                var pppechoVal = pppecho.val().trim();
                if(isNumber(pppechoVal)){
                    isChanged = true;
                    pppecho.removeClass("invalidVal");
                    var realPppechoName = th.parent().parent().find("input[name='pppEchoName']").val();
                    var realPppechoType = th.parent().parent().find("input[name='pppEchoType']").val();
                    paramNames.push(realPppechoName);
                    paramValues.push(pppechoVal);
                    paramTypes.push(realPppechoType);
                } else {
                    pppecho.addClass("invalidVal");
                    isValid=false;
                }
            }

            var pppechoRetry = th.parent().parent().find("input[name='pppEchoRetry']");
            if(pppechoRetry.hasClass("required") && pppechoRetry.val()==''){
                pppechoRetry.addClass("invalidVal");
                isValid = false;
            } else if(pppechoRetry.val().trim()!=''){
                var pppechoRetryVal = pppechoRetry.val().trim();
                if(isNumber(pppechoRetryVal)){
                    isChanged = true;
                    pppechoRetry.removeClass("invalidVal");
                    var realPppechoRetryName = th.parent().parent().find("input[name='pppEchoRetryName']").val();
                    var realPppechoRetryType = th.parent().parent().find("input[name='pppEchoRetryType']").val();
                    paramNames.push(realPppechoRetryName);
                    paramValues.push(pppechoRetryVal);
                    paramTypes.push(realPppechoRetryType);
                } else {
                    pppechoRetry.addClass("invalidVal");
                    isValid=false;
                }
            }
        }else{
            isChanged = true;
            var realPppechoName = $("input[name='pppEchoName']").val();
            var realPppechoType = $("input[name='pppEchoType']").val();
            paramNames.push(realPppechoName);
            paramValues.push('0');
            paramTypes.push(realPppechoType);

            var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
            var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
            paramNames.push(realPppechoRetryName);
            paramValues.push('0');
            paramTypes.push(realPppechoRetryType);
        }
        
        var enable = th.parent().parent().find("input[name='enable']");
        var valEnable = '';
        if(enable.is(":checked")){
            valEnable = '1';
        } else {
            valEnable = '0';
        }
        
        var realEnableName=th.parent().parent().find("input[name='enableName']").val();
        var realEnableType=th.parent().parent().find("input[name='enableType']").val();
        
        if(toAdd == 'true' && valEnable == '1'){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        var realEnableValue = th.parent().parent().find("input[name='enableValue']").val();
        if (toAdd == 'false' && realEnableValue != valEnable) {
            isChanged = true;
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableName);
            paramValues.push(realEnableValue);
            paramTypes.push(realEnableType);
        }

        if(paramNames.length!=0 && isValid && isChanged) {
            var wanId = $(this).parent().find("input[name='wanID']");
            var exst = false;
            var ppCount = 1;
            var indx = -1;
            if(wanConnects.length > 0){
                for(var ii = 0; ii < wanConnects.length; ii++){
                    if(wanConnects[ii]['conT'] == 'ppp'){
                        exst = true;
                        ppCount++;
                        if(wanId.length > 0){
                            if(wanId.val().trim() == wanConnects[ii]['id']){
                                indx = ii;
                            }
                        }
                    }
                }
            }
            if(indx == -1){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "P"+ppCount;
                wanConnectsOBJ['conT'] = "ppp";
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wanConnects.push(wanConnectsOBJ);

                getWanConnectionTable('','ppp');

            } else {
                if($.inArray('def_connection', wanConnects[indx].names) > -1){
                    var index = wanConnects[indx].names.indexOf('def_connection');
                    var connectioVal = wanConnects[indx].values[index];
                    paramNames.push('def_connection');
                    paramValues.push(connectioVal);
                }
                
                wanConnects[indx]['names'] = paramNames;
                wanConnects[indx]['values'] = paramValues;
                wanConnects[indx]['types'] = paramTypes;
                
                getWanConnectionTable('','ppp');

            }
            $('#enterpasswordmsg').show();
            $("#divForWAN").empty();
            $("#shoeConnections").show();
            $(".general-settings").hide();
            $(".addPPPIp").hide();
            $("#errTarif").empty();
            $("#addNewWan").show();
            $('#forResetPPPoE').trigger('reset');
            resetAllShowPassCheckboxes();
            checkDefaultConnection();
            return false;

        } else {
            var msg = getMssg["sale_required_fields"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    });
    
    $(document).on("click", "#cancelPPPWan", function () {
        if(wanConnects.length > 0){
            $("#shoeConnections").show();
        }
        $('#enterpasswordmsg').show();
        $("#divForWAN").empty();
        $(".general-settings").hide();
        $(".addPPPIp").hide();
        $("#errTarif").empty();
        $("#addNewWan").show();
        $('#forResetPPPoE').validate().resetForm();
        resetAllShowPassCheckboxes();
        checkDefaultConnection();
    });
    
    $(document).on("click", "#keepAliveOnoffswitch", function () {
        if ($(this).is(":checked")) {
            $(this).parents('div:eq(4)').find(".keep-aliveDevice").show();
        } else {
            $(this).parents('div:eq(4)').find(".keep-aliveDevice").hide();
        }
    });
    
    $(document).on("click", "#keepAliveOnoffswitchL2TP", function () {
        if ($(this).is(":checked")) {
            $(this).parents('div:eq(4)').find(".keep-aliveDeviceL2TP").show();
        } else {
            $(this).parents('div:eq(4)').find(".keep-aliveDeviceL2TP").hide();
        }
    });
    
    $(document).on("click", "#keepAliveOnoffswitchPPTP", function () {
        if ($(this).is(":checked")) {
            $(this).parents('div:eq(4)').find(".keep-aliveDeviceL2TP").show();
        } else {
            $(this).parents('div:eq(4)').find(".keep-aliveDeviceL2TP").hide();
        }
    });
    
    $(document).on("click","#addL2TPWan",function(e){
        e.preventDefault();
        var th = $(this);
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();
        var pppName = th.parent().parent().find("input[name='pppName']");
        var nameVal = pppName.val();
        if(pppName.hasClass("required") && pppName.val() == ''){
            pppName.addClass("invalidVal");
            isValid = false;
        } else {
            var pppVal = pppName.val().trim();
            if(pppVal != ''){
                isChanged = true;
                pppName.removeClass("invalidVal");
                var realNameName = th.parent().parent().find("input[name='nameName']").val();
                var realNameType = th.parent().parent().find("input[name='nameType']").val();
                paramNames.push(realNameName);
                paramValues.push(pppVal);
                paramTypes.push(realNameType);
            }
        }

        var msgRequired = getMssg['error_message_required'];
        var msgDns = getMssg['error_message_dns'];
        var msgMac =  getMssg['error_message_mac'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber = getMssg['error_message_number'];
        var msgRepassword =  getMssg['error_message_repassword'];
        var msgEmpty = getMssg['error_message_empty'];
        var msgGe0 = getMssg['error_message_ge_0'];
        var msgGr0 = getMssg['error_message_gr_0'];
        var msgGe1 = getMssg['error_message_ge_1'];
        var msgLessThan = getMssg['error_message_le_255'];
        var msgReqField = getMssg['name_required_field'];
        var msgLe32 = getMssg['error_message_at_length_32'];
        var msgPass = getMssg['wifi-ascii'];
        var msgLe1280 = getMssg['error_message_le_1280'];
        var msgLe1460 = getMssg['error_message_le_1460'];

        $("#forResetL2TP").validate({
            rules: {
                serviceNameL2TP:{
                    required: true,
                    validateDNS : true,
                    validateIsEmpty: true
                },
                pppName: {
                    required: true,
                    validateIsEmpty: true,
                    validateConnectionNameLength: true
                },
                username: {
                    required: true,
                    noSpace: true,
                    validateASCII: true
                },
                mru: {
                    required: true,
                    number: true,
                    min: 1280,
                    max: 1460
                },
                pppEcho: {
                    required: true,
                    number: true,
                    min: 1
                },
                pppEchoRetry: {
                    required: true,
                    number: true,
                    min: 1,
                    max:255
                },
                password: {
                    required: true,
                    validateIsEmpty: true,
                    validateASCII: true
                },
                rePassword: {
                    required: true,
                    equalTo: "#txtPasswordL2tp",
                }
            },

            messages: {
                serviceNameL2TP: {
                    required: msgRequired,
                    validateDNS: msgDns,
                    validateIsEmpty: msgEmpty
                },
                pppName: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateConnectionNameLength: msgLe32
                },
                username: {
                    required: msgRequired,
                    noSpace: msgReqField,
                    validateASCII: msgPass
                },
                mru: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgLe1280,
                    max: msgLe1460
                },
                pppEcho: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgGr0
                },
                pppEchoRetry: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgGr0,
                    max: msgLessThan
                },
                password: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateASCII: msgPass
                },
                rePassword: {
                    required: msgRequired,
                    equalTo: msgRepassword
                }
            },
            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forResetL2TP").valid())) {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            return false;
        }
        
        var serviceName = th.parent().parent().find("input[name='serviceNameL2TP']");
        if(serviceName.val().trim() != ''){
            isChanged = true;
            serviceName.removeClass("invalidVal");
            var realServiceName = th.parent().parent().find("input[name='serviceNameName']").val();
            var realNameType1 = th.parent().parent().find("input[name='serviceNameType']").val();
            paramNames.push(realServiceName);
            paramValues.push(serviceName.val().trim());
            paramTypes.push(realNameType1);
        }

        var username = th.parent().parent().find("input[name='username']");
        if(username.hasClass("required") && username.val()==''){
            username.addClass("invalidVal");
            isValid = false;
        } else if(username.val().trim() != ''){
            isChanged = true;
            username.removeClass("invalidVal");
            var realUsernameName=th.parent().parent().find("input[name='usernameName']").val();
            var realUsernameType=th.parent().parent().find("input[name='usernameType']").val();
            paramNames.push(realUsernameName);
            paramValues.push(username.val().trim());
            paramTypes.push(realUsernameType);
        }

        if($('#autoGenPasL2tp').is(':checked')) {
            var password = 'autoGenerate';
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }else{
            var password = th.parent().parent().find("input[name='password']").val().trim();
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }

        var mru = th.parent().parent().find("input[name='mru']");
        if(mru.hasClass("required") && mru.val() == ''){
            mru.addClass("invalidVal");
            isValid = false;
        } else {
            var mruVal = mru.val().trim();
            if(isNumber(mruVal)){
                isChanged = true;
                mru.removeClass("invalidVal");
                var realMruName=th.parent().parent().find("input[name='mruName']").val();
                var realMruType=th.parent().parent().find("input[name='mruType']").val();
                paramNames.push(realMruName);
                paramValues.push(mruVal);
                paramTypes.push(realMruType);
            } else {
                mru.addClass("invalidVal");
                isValid = false;
            }
        }

        var enableNat = th.parent().parent().find("input[name='enableNat']");
        var valenableNat='';
        if(enableNat.is(":checked")){
            valenableNat = '1';
        } else {
            valenableNat = '0';
        }
//        isChanged = true;
        
        var realEnableNatName = th.parent().parent().find("input[name='enableNatName']").val();
        var realEnableNatType = th.parent().parent().find("input[name='enableNatType']").val();
        
        if(toAdd == 'true' && valenableNat == '1'){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }
        
        var realEnableNatValue = th.parent().parent().find("input[name='enableNatValue']").val();
        if (toAdd == 'false' && realEnableNatValue != valenableNat) {
            isChanged = true;
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableNatName);
            paramValues.push(realEnableNatValue);
            paramTypes.push(realEnableNatType);
        }

        var standard = th.parent().parent().find(".authProtocolType option:selected").val();
        isChanged = true;
        var realStandardName = th.parent().parent().find("input[name='authProtocolTypeName']").val();
        var realStandardType = th.parent().parent().find("input[name='authProtocolTypeType']").val();
        paramNames.push(realStandardName);
        paramValues.push(standard);
        paramTypes.push(realStandardType);
        
        var keepAlive = th.parent().parent().find("input[name='enableKeepAlive']");
        var valKeepAlive = '';
        if (keepAlive.is(":checked")) {
            valKeepAlive = '1';
        } else {
            valKeepAlive = '0';
        }
        
        if(valKeepAlive == '1'){
            var pppecho = th.parent().parent().find("input[name='pppEcho']");
            if(pppecho.hasClass("required") && pppecho.val() == ''){
                pppecho.addClass("invalidVal");
                isValid = false;
            } else if(pppecho.val().trim() != ''){
                var pppechoVal = pppecho.val().trim();
                if(isNumber(pppechoVal)){
                    isChanged = true;
                    pppecho.removeClass("invalidVal");
                    var realPppechoName = th.parent().parent().find("input[name='pppEchoName']").val();
                    var realPppechoType = th.parent().parent().find("input[name='pppEchoType']").val();
                    paramNames.push(realPppechoName);
                    paramValues.push(pppechoVal);
                    paramTypes.push(realPppechoType);
                } else {
                    pppecho.addClass("invalidVal");
                    isValid=false;
                }
            }

            var pppechoRetry = th.parent().parent().find("input[name='pppEchoRetry']");
            if(pppechoRetry.hasClass("required") && pppechoRetry.val()==''){
                pppechoRetry.addClass("invalidVal");
                isValid=false;
            } else if(pppechoRetry.val().trim()!=''){
                var pppechoRetryVal = pppechoRetry.val().trim();
                if(isNumber(pppechoRetryVal)){
                    isChanged = true;
                    pppechoRetry.removeClass("invalidVal");
                    var realPppechoRetryName = th.parent().parent().find("input[name='pppEchoRetryName']").val();
                    var realPppechoRetryType = th.parent().parent().find("input[name='pppEchoRetryType']").val();
                    paramNames.push(realPppechoRetryName);
                    paramValues.push(pppechoRetryVal);
                    paramTypes.push(realPppechoRetryType);
                } else {
                    pppechoRetry.addClass("invalidVal");
                    isValid=false;
                }
            }
        }else{
            isChanged = true;
            var realPppechoName = $("input[name='pppEchoName']").val();
            var realPppechoType = $("input[name='pppEchoType']").val();
            paramNames.push(realPppechoName);
            paramValues.push('0');
            paramTypes.push(realPppechoType);

            var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
            var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
            paramNames.push(realPppechoRetryName);
            paramValues.push('0');
            paramTypes.push(realPppechoRetryType);
        }
        

        var enable = th.parent().parent().find("input[name='enable']");
        var valEnable = '';
        if(enable.is(":checked")){
            valEnable = '1';
        } else {
            valEnable = '0';
        }
//        isChanged = true;

        var realEnableName=th.parent().parent().find("input[name='enableName']").val();
        var realEnableType=th.parent().parent().find("input[name='enableType']").val();
        
        if(toAdd == 'true' && valEnable == '1'){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        var realEnableValue = th.parent().parent().find("input[name='enableValue']").val();
        if (toAdd == 'false' && realEnableValue != valEnable) {
            isChanged = true;
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableName);
            paramValues.push(realEnableValue);
            paramTypes.push(realEnableType);
        }
        
//        if(toAdd == 'true'){
            paramNames.push("conn_type");
            paramValues.push("L2TP_Relay");
            paramTypes.push("string");
//        }
        

        if(paramNames.length != 0 && isValid && isChanged) {
            var wanId = $(this).parent().find("input[name='wanID']");
            var exst = false;
            var ppCount = 1;
            var indx = -1;
            if(wanConnects.length > 0){
                for(var ii = 0; ii < wanConnects.length; ii++){
//                    if(wanConnects[ii]['conT'] == 'l2tp'){
                    if(wanConnects[ii]['conT'] == 'ppp'){
                        exst = true;
                        ppCount++;
                        if(wanId.length > 0){
                            if(wanId.val().trim() == wanConnects[ii]['id']){
                                indx = ii;
                            }
                        }
                    }
                }
            }
            if(indx == -1){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "L2"+ppCount;
                wanConnectsOBJ['conT'] = "ppp";
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wanConnects.push(wanConnectsOBJ);

                getWanConnectionTable('','ppp');

            } else {
                if($.inArray('def_connection', wanConnects[indx].names) > -1){
                    var index = wanConnects[indx].names.indexOf('def_connection');
                    var connectioVal = wanConnects[indx].values[index];
                    paramNames.push('def_connection');
                    paramValues.push(connectioVal);
                }
                
                wanConnects[indx]['names'] = paramNames;
                wanConnects[indx]['values'] = paramValues;
                wanConnects[indx]['types'] = paramTypes;
                
                getWanConnectionTable('','ppp');

            }
//            console.log(wanConnects);
            $('#enterpasswordmsgL2tp').show();
            $("#divForWAN").empty();
            $("#shoeConnections").show();
            $(".general-settings").hide();
            $(".addL2TPIp").hide();
            $("#errTarif").empty();
            $("#addNewWan").show();
            $('#forResetL2TP').trigger('reset');
            resetAllShowPassCheckboxes();
            checkDefaultConnection();
            return false;

        } else {
            var msg = getMssg["sale_required_fields"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    });
    
    $(document).on("click", "#cancelL2TPWan", function () {
        if(wanConnects.length > 0){
            $("#shoeConnections").show();
        }
        $('#enterpasswordmsgL2tp').show();
        $("#divForWAN").empty();
        $(".general-settings").hide();
        $(".addL2TPIp").hide();
        $("#errTarif").empty();
        $("#addNewWan").show();
        $('#forResetL2TP').validate().resetForm();
        resetAllShowPassCheckboxes();
        checkDefaultConnection();
    });

    $(document).on("click","#addPPTPWan",function(e){
        e.preventDefault();
        var th = $(this);
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();

        var msgRequired = getMssg['error_message_required'];
        var msgDns = getMssg['error_message_dns'];
        var msgMac =  getMssg['error_message_mac'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber = getMssg['error_message_number'];
        var msgRepassword =  getMssg['error_message_repassword'];
        var msgEmpty = getMssg['error_message_empty'];
        var msgGe0 = getMssg['error_message_ge_0'];
        var msgGe1 = getMssg['error_message_ge_1'];
        var msgLessThan = getMssg['error_message_le_255'];
        var msgGr0 = getMssg['error_message_gr_0'];
        var msgReqField = getMssg['name_required_field'];
        var msgLe32 = getMssg['error_message_at_length_32'];
        var msgPass = getMssg['wifi-ascii'];
        var msgLe1280 = getMssg['error_message_le_1280'];
        var msgLe1460 = getMssg['error_message_le_1460'];

        $("#forResetPPTP").validate({
            rules: {
                serviceNamePPTP:{
                    required: true,
                    validateDNS : true,
                    validateIsEmpty: true
                },
                pppName: {
                    required: true,
                    validateIsEmpty: true,
                    validateConnectionNameLength: true
                },
                username: {
                    required: true,
                    noSpace: true,
                    validateASCII: true
                },
                mru: {
                    required: true,
                    number: true,
                    min: 1280,
                    max: 1460
                },
                pppEcho: {
                    required: true,
                    number: true,
                    min: 1
                },
                pppEchoRetry: {
                    required: true,
                    number: true,
                    min: 1,
                    max: 255
                },
                password: {
                    required: true,
                    validateIsEmpty: true,
                    validateASCII: true
                },
                rePassword: {
                    required: true,
                    equalTo: "#txtPasswordPPTP",
                }
            },

            messages: {
                serviceNamePPTP: {
                    required: msgRequired,
                    validateDNS: msgDns,
                    validateIsEmpty: msgEmpty
                },
                pppName: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateConnectionNameLength: msgLe32
                },
                username: {
                    required: msgRequired,
                    noSpace: msgReqField,
                    validateASCII: msgPass
                },
                mru: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgLe1280,
                    max: msgLe1460
                },
                pppEcho: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgGr0
                },
                pppEchoRetry: {
                    required: msgRequired,
                    number: msgNumber,
                    min: msgGr0,
                    max: msgLessThan
                },
                password: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty,
                    validateASCII: msgPass
                },
                rePassword: {
                    required: msgRequired,
                    equalTo: msgRepassword
                }
            },
            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forResetPPTP").valid())) {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            return false;
        }
        
        var pppName = th.parent().parent().find("input[name='pppName']");
        var nameVal = pppName.val();
        
        if(pppName.hasClass("required") && pppName.val() == ''){
            pppName.addClass("invalidVal");
            isValid = false;
        } else {
            var pppVal = pppName.val().trim();
            if(pppVal != ''){
                isChanged = true;
                pppName.removeClass("invalidVal");
                var realNameName = th.parent().parent().find("input[name='nameName']").val();
                var realNameType = th.parent().parent().find("input[name='nameType']").val();
                paramNames.push(realNameName);
                paramValues.push(pppVal);
                paramTypes.push(realNameType);
            }
        }
        
        var serviceName = th.parent().parent().find("input[name='serviceNamePPTP']");
        if(serviceName.val().trim() != ''){
            isChanged = true;
            serviceName.removeClass("invalidVal");
            var realServiceName = th.parent().parent().find("input[name='serviceNameName']").val();
            var realNameType1 = th.parent().parent().find("input[name='serviceNameType']").val();
            paramNames.push(realServiceName);
            paramValues.push(serviceName.val().trim());
            paramTypes.push(realNameType1);
        }

        var username = th.parent().parent().find("input[name='username']");
        if(username.hasClass("required") && username.val()==''){
            username.addClass("invalidVal");
            isValid = false;
        } else if(username.val().trim() != ''){
            isChanged = true;
            username.removeClass("invalidVal");
            var realUsernameName=th.parent().parent().find("input[name='usernameName']").val();
            var realUsernameType=th.parent().parent().find("input[name='usernameType']").val();
            paramNames.push(realUsernameName);
            paramValues.push(username.val().trim());
            paramTypes.push(realUsernameType);
        }

        if($('#autoGenPasPPTP').is(':checked')) {
            var password = 'autoGenerate';
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }else{
            var password = th.parent().parent().find("input[name='password']").val().trim();
            var passwordType = th.parent().parent().find("input[name='passwordType']").val();
            var passwordName = th.parent().parent().find("input[name='passwordName']").val();
            isChanged = true;
            paramNames.push(passwordName);
            paramValues.push(password);
            paramTypes.push(passwordType);
        }

        var mru = th.parent().parent().find("input[name='mru']");
        if(mru.hasClass("required") && mru.val() == ''){
            mru.addClass("invalidVal");
            isValid = false;
        } else {
            var mruVal = mru.val().trim();
            if(isNumber(mruVal)){
                isChanged = true;
                mru.removeClass("invalidVal");
                var realMruName=th.parent().parent().find("input[name='mruName']").val();
                var realMruType=th.parent().parent().find("input[name='mruType']").val();
                paramNames.push(realMruName);
                paramValues.push(mruVal);
                paramTypes.push(realMruType);
            } else {
                mru.addClass("invalidVal");
                isValid = false;
            }
        }

        var enableNat = th.parent().parent().find("input[name='enableNat']");
        var valenableNat='';
        if(enableNat.is(":checked")){
            valenableNat = '1';
        } else {
            valenableNat = '0';
        }
//        isChanged = true;
        
        var realEnableNatName = th.parent().parent().find("input[name='enableNatName']").val();
        var realEnableNatType = th.parent().parent().find("input[name='enableNatType']").val();
        
        if(toAdd == 'true' && valenableNat == '1'){
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }
        
        var realEnableNatValue = th.parent().parent().find("input[name='enableNatValue']").val();
        if (toAdd == 'false' && realEnableNatValue != valenableNat) {
            isChanged = true;
            paramNames.push(realEnableNatName);
            paramValues.push(valenableNat);
            paramTypes.push(realEnableNatType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableNatName);
            paramValues.push(realEnableNatValue);
            paramTypes.push(realEnableNatType);
        }

        var standard = th.parent().parent().find(".authProtocolType option:selected").val();
        isChanged = true;
        var realStandardName = th.parent().parent().find("input[name='authProtocolTypeName']").val();
        var realStandardType = th.parent().parent().find("input[name='authProtocolTypeType']").val();
        paramNames.push(realStandardName);
        paramValues.push(standard);
        paramTypes.push(realStandardType);
        
        var keepAlive = th.parent().parent().find("input[name='enableKeepAlive']");
        var valKeepAlive = '';
        if (keepAlive.is(":checked")) {
            valKeepAlive = '1';
        } else {
            valKeepAlive = '0';
        }
        
        if(valKeepAlive == '1'){
            var pppecho = th.parent().parent().find("input[name='pppEcho']");
            if(pppecho.hasClass("required") && pppecho.val() == ''){
                pppecho.addClass("invalidVal");
                isValid = false;
            } else if(pppecho.val().trim() != ''){
                var pppechoVal = pppecho.val().trim();
                if(isNumber(pppechoVal)){
                    isChanged = true;
                    pppecho.removeClass("invalidVal");
                    var realPppechoName = th.parent().parent().find("input[name='pppEchoName']").val();
                    var realPppechoType = th.parent().parent().find("input[name='pppEchoType']").val();
                    paramNames.push(realPppechoName);
                    paramValues.push(pppechoVal);
                    paramTypes.push(realPppechoType);
                } else {
                    pppecho.addClass("invalidVal");
                    isValid=false;
                }
            }

            var pppechoRetry = th.parent().parent().find("input[name='pppEchoRetry']");
            if(pppechoRetry.hasClass("required") && pppechoRetry.val()==''){
                pppechoRetry.addClass("invalidVal");
                isValid=false;
            } else if(pppechoRetry.val().trim()!=''){
                var pppechoRetryVal = pppechoRetry.val().trim();
                if(isNumber(pppechoRetryVal)){
                    isChanged = true;
                    pppechoRetry.removeClass("invalidVal");
                    var realPppechoRetryName = th.parent().parent().find("input[name='pppEchoRetryName']").val();
                    var realPppechoRetryType = th.parent().parent().find("input[name='pppEchoRetryType']").val();
                    paramNames.push(realPppechoRetryName);
                    paramValues.push(pppechoRetryVal);
                    paramTypes.push(realPppechoRetryType);
                } else {
                    pppechoRetry.addClass("invalidVal");
                    isValid=false;
                }
            }
        }else{
            isChanged = true;
            var realPppechoName = $("input[name='pppEchoName']").val();
            var realPppechoType = $("input[name='pppEchoType']").val();
            paramNames.push(realPppechoName);
            paramValues.push('0');
            paramTypes.push(realPppechoType);

            var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
            var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
            paramNames.push(realPppechoRetryName);
            paramValues.push('0');
            paramTypes.push(realPppechoRetryType);
        }
        

        var enable = th.parent().parent().find("input[name='enable']");
        var valEnable = '';
        if(enable.is(":checked")){
            valEnable = '1';
        } else {
            valEnable = '0';
        }
//        isChanged = true;

        var realEnableName=th.parent().parent().find("input[name='enableName']").val();
        var realEnableType=th.parent().parent().find("input[name='enableType']").val();
        
        if(toAdd == 'true' && valEnable == '1'){
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }
        
        var realEnableValue = th.parent().parent().find("input[name='enableValue']").val();
        if (toAdd == 'false' && realEnableValue != valEnable) {
            isChanged = true;
            paramNames.push(realEnableName);
            paramValues.push(valEnable);
            paramTypes.push(realEnableType);
        }else if(toAdd == 'false'){
            paramNames.push(realEnableName);
            paramValues.push(realEnableValue);
            paramTypes.push(realEnableType);
        }
        
//        if(toAdd == 'true'){
            paramNames.push("conn_type");
            paramValues.push("PPTP_Relay");
            paramTypes.push("string");
//        }
        
        if(paramNames.length != 0 && isValid && isChanged) {
            var wanId = $(this).parent().find("input[name='wanID']");
            var exst = false;
            var ppCount = 1;
            var indx = -1;
            if(wanConnects.length > 0){
                for(var ii = 0; ii < wanConnects.length; ii++){
//                    if(wanConnects[ii]['conT'] == 'l2tp'){
                    if(wanConnects[ii]['conT'] == 'ppp'){
                        exst = true;
                        ppCount++;
                        if(wanId.length > 0){
                            if(wanId.val().trim() == wanConnects[ii]['id']){
                                indx = ii;
                            }
                        }
                    }
                }
            }
            if(indx == -1){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "PT"+ppCount;
                wanConnectsOBJ['conT'] = "ppp";
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wanConnects.push(wanConnectsOBJ);

                getWanConnectionTable('','ppp');

            } else {
                if($.inArray('def_connection', wanConnects[indx].names) > -1){
                    var index = wanConnects[indx].names.indexOf('def_connection');
                    var connectioVal = wanConnects[indx].values[index];
                    paramNames.push('def_connection');
                    paramValues.push(connectioVal);
                }
                
                wanConnects[indx]['names'] = paramNames;
                wanConnects[indx]['values'] = paramValues;
                wanConnects[indx]['types'] = paramTypes;
                
                getWanConnectionTable('','ppp');

            }
            $('#enterpasswordmsgPPTP').show();
            $("#divForWAN").empty();
            $("#shoeConnections").show();
            $(".general-settings").hide();
            $(".addPPTPIp").hide();
            $("#errTarif").empty();
            $("#addNewWan").show();
            $('#forResetPPTP').trigger('reset');
            resetAllShowPassCheckboxes();
            checkDefaultConnection();
            return false;

        } else {
            var msg = getMssg["sale_required_fields"];
            $("#errTarif").html(msg);
            $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    });
    
    $(document).on("click", "#cancelPPTPWan", function () {
        if(wanConnects.length > 0){
            $("#shoeConnections").show();
        }
        $('#enterpasswordmsgPPTP').show();
        $("#divForWAN").empty();
        $(".general-settings").hide();
        $(".addPPTPIp").hide();
        $("#errTarif").empty();
        $("#addNewWan").show();
        $('#forResetPPTP').validate().resetForm();
        resetAllShowPassCheckboxes();
        checkDefaultConnection();
    });

    function validateTarifWiFi(th) {
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgMac = getMssg['error_message_mac'];
        var msgNetmask = getMssg['error_message_netmask'];
        var msgNumber =getMssg['error_message_number'];
        var pskMessage = $("input[name='pskMessage']").val();
        var msgGe0 = getMssg['error_message_ge_0'];
        var pskMessageASCII = $("input[name='pskMessageASCII']").val();
        var msgEmpty = getMssg['error_message_empty'];
        var lessThan = getMssg['error_message_less_than'];
        var authVal = th.parent().parent().find(".netAuthType option:selected").val();
        if(authVal == "OPEN"){
            $("#forResetWIFI").validate({
                // ignore: 'hidden',
                rules: {
                    maxAssociatedClients: {
                        required: true,
                        number: true,
                        min: 0,
                        max: 20
                    },
                    ssid: {
                        required: true,
                        validateIsEmpty: true
                    }
                },

                messages: {
                    maxAssociatedClients: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0,
                        max: lessThan
                    },
                    ssid: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function (error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
        } else {
            $("#forResetWIFI").validate({
                // ignore: 'hidden',
                rules: {
                    maxAssociatedClients: {
                        required: true,
                        number: true,
                        min: 0,
                        max: 20
                    },
                    presharedKey: {
                        required: true,
                        validateLength: true,
                        validateASCII: true
                    },
                    ssid: {
                        required: true,
                        validateIsEmpty: true
                    },
                    wpaReneval: {
                        required: true,
                        number: true,
                        min: 0
                    },
                },

                messages: {
                    maxAssociatedClients: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0,
                        max: lessThan
                    },
                    presharedKey: {
                        validateLength: pskMessage,
                        validateASCII: pskMessageASCII
                    },
                    ssid: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty
                    },
                    wpaReneval: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0
                    },
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function (error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });
        }
        if(!($("#forResetWIFI").valid())) {
            //th.removeAttr("disabled");
            //th.css("opacity", "1");
            return false;
        } else {
            return true;
        }
    }

    $(document).on("change", ".frequencyBand", function () {
        var frequencyBand = $(".frequencyBand option:selected").val();
        if (frequencyBand == "2.4GHz") {
            $(".standardType option[value='a']").remove();
            $(".standardType option[value='ac']").remove();
            $(".standardType option[value='ac,n']").remove();
            $(".standardType option[value='ac,a,n']").remove();
            $(".standardType option[value='a,n']").remove();
            $(".standardType").append('<option value=b,g,n>802.11 B/G/N mixed</option>');
            $(".standardType").append('<option value=b>802.11 B</option>');
            $(".standardType").append('<option value=g-only>802.11 G</option>');
            var i;
            for(i = 1; i <= 13; i=i+1) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 36; i <= 64; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 136; i <= 144; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 149; i <= 165; i=i+4) {
                $(".channelType option[value="+i+"]").remove();
            }
        } else if(frequencyBand == "5GHz") {
            $(".standardType option[value='b,g,n']").remove();
            $(".standardType option[value='b']").remove();
            $(".standardType option[value='g-only']").remove();
            $(".standardType").append('<option value=a>802.11 A</option>');
            $(".standardType").append('<option value=ac>802.11 AC</option>');
            $(".standardType").append('<option value=ac,n>802.11 AC/N mixed</option>');
            $(".standardType").append('<option value=ac,a,n>802.11 AC/A/N mixed</option>');
            $(".standardType").append('<option value="a,n">802.11 A/N mixed</option>');
            var i;
            for(i = 1; i <= 13; i=i+1) {
                $(".channelType option[value="+i+"]").remove();
            }
            for(i = 36; i <= 64; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 136; i <= 144; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
            for(i = 149; i <= 165; i=i+4) {
                $(".channelType").append('<option value='+ i+'>'+i+'</option>');
            }
        }
    });

    $(document).on("click", "#addWifi", function () {
        var th = $(this);
        addTarifInWifi(th);

        return false;
    });

        function addTarifInWifi(th) {
        //var th = $(this);
        var tarifId = th.parent().find("input[name='templateId']").val();
        var tarifChangeName = 'null';
        var tarifChangeDesc = 'null';
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isValid = true;
        var isChanged = false;
        var toAdd = $("input[name='toAdd']").val();
        //var tarifName = $(".nameDescTarif").find("input[name='tarifName']");
        //
        //if(tarifName.hasClass("required") && tarifName.val().trim() == ''){
        //    tarifName.addClass("invalidVal");
        //    isValid = false;
        //} else {
        //    tarifName.removeClass("invalidVal");
        //    var oldTarifName = $(".nameDescTarif").find("input[name='oldTarifName']").val();
        //
        //    if(tarifName.val() != oldTarifName){
        //        tarifChangeName = tarifName.val();
        //    }
        //
        //    var desc = $(".nameDescTarif").find("textarea[name='tarifDesc']").val();
        //    var oldTarifDesc = $(".nameDescTarif").find("input[name='oldTarifDesc']").val();
        //
        //    if($.trim(desc) != $.trim(oldTarifDesc)){
        //        tarifChangeDesc = desc;
        //    }
        //}

        var enableWireless = th.parent().parent().find("input[name='enableWireless']");
        var valEnableWireless = '';
        if(enableWireless.is(":checked")){
            valEnableWireless = '1';
        } else {
            valEnableWireless = '0';
        }
//        isChanged = true;
        var realEnableWirelessName = th.parent().parent().find("input[name='enableWirelessName']").val();
        var realEnableWirelessType = th.parent().parent().find("input[name='enableWirelessType']").val();

        // if(toAdd == 'true' && valEnableWireless == '1'){
            paramNames.push(realEnableWirelessName);
            paramValues.push(valEnableWireless);
            paramTypes.push(realEnableWirelessType);
        // }

//        var realEnableWireless = $("input[name='enableWirelessValue']").val();
//         if(toAdd == 'false'){
//             paramNames.push(realEnableWirelessName);
//             paramValues.push(valEnableWireless);
//             paramTypes.push(realEnableWirelessType);
        // }

        var pskMessage = $("input[name='pskMessage']").val();
        var pskMessageASCII = $("input[name='pskMessageASCII']").val();

        if(toAdd == 'true'){
            var ifValid = validateTarifWiFi(th);

        }else if(toAdd == 'false'){
            var ifValid = validateTarifWiFi(th);

        }

            var frequencyBand = th.parent().parent().find(".frequencyBand option:selected").val();
            isChanged = true;
            var realfrequencyBandName = th.parent().parent().find("input[name='frequencyBandName']").val();
            var realfrequencyBandType = th.parent().parent().find("input[name='frequencyBandType']").val();
            paramNames.push(realfrequencyBandName);
            paramValues.push(frequencyBand);
            paramTypes.push(realfrequencyBandType);

        var ssid = th.parent().parent().find("input[name='ssid']");
        isChanged = true;
        var realSsidName = th.parent().parent().find("input[name='ssidName']").val();
        var realSsidType = th.parent().parent().find("input[name='ssidType']").val();
        paramNames.push(realSsidName);
        paramValues.push(ssid.val());
        paramTypes.push(realSsidType);

        var channel = th.parent().parent().find(".channelType option:selected").val();
        var realChannelName = '';
        var realChannelType = '';
        if(channel == 0){
            realChannelName = 'auto_enable';
            realChannelType = 'boolean';
            paramValues.push(1);
        } else {
            realChannelName = th.parent().parent().find("input[name='channelName']").val();
            realChannelType = th.parent().parent().find("input[name='channelType']").val();
            paramValues.push(channel);
        }
        isChanged = true;
        paramNames.push(realChannelName);
        paramTypes.push(realChannelType);

        var standard = th.parent().parent().find(".standardType option:selected").val();
        isChanged = true;
        var realStandardName = th.parent().parent().find("input[name='standardName']").val();
        var realStandardType = th.parent().parent().find("input[name='standardType']").val();
        paramNames.push(realStandardName);
        paramValues.push(standard);
        paramTypes.push(realStandardType);

        var transmitPower = th.parent().parent().find(".transmitPower option:selected").val();
        isChanged = true;
        var realTransmitPowerName = th.parent().parent().find("input[name='transmitPowerName']").val();
        var realTransmitPowerType = th.parent().parent().find("input[name='transmitPowerType']").val();
        paramNames.push(realTransmitPowerName);
        paramValues.push(transmitPower);
        paramTypes.push(realTransmitPowerType);

        var maxAssociatedClients = th.parent().parent().find("input[name='maxAssociatedClients']");
        isChanged = true;
        var realMaxAssociatedClientsName = th.parent().parent().find("input[name='maxAssociatedClientsName']").val();
        var realMaxAssociatedClientsType = th.parent().parent().find("input[name='maxAssociatedClientsType']").val();
        paramNames.push(realMaxAssociatedClientsName);
        paramValues.push(maxAssociatedClients.val());
        paramTypes.push(realMaxAssociatedClientsType);

        var authVal = th.parent().parent().find(".netAuthType option:selected").val();
        var authName = '';
        var authValForName = '';
        isChanged = true;
        var realAuthNameVal = '';
        var authValBeaconKey = 'beacon_type';
        var authValBeacon = '';
        var realAuthType = th.parent().parent().find("input[name='netAuthType']").val();
        // if(authVal != 'OPEN' && authVal != "WPA" && authVal != "WPA2" && authVal != "WPA/WPA2 mixed"){
            if(authVal == 'WPA-PSK'){
                authName = 'wpa_psk';
                realAuthNameVal = 'PSKAuthentication';
                authValBeacon = 'WPA';

                paramNames.push(authValBeaconKey);
                paramValues.push(authValBeacon);
                paramTypes.push(realAuthType);
                paramNames.push(authName);
                paramValues.push(realAuthNameVal);
                paramTypes.push(realAuthType);
            } else if (authVal == 'WPA2-PSK') {
                authName = 'wpa_psk2';
                realAuthNameVal = 'PSKAuthentication';
                authValBeacon = '11i';

                paramNames.push(authValBeaconKey);
                paramValues.push(authValBeacon);
                paramTypes.push(realAuthType);
                paramNames.push(authName);
                paramValues.push(realAuthNameVal);
                paramTypes.push(realAuthType);
            }else if (authVal == 'WPA-PSK/WPA2-PSK mixed') {
                authName = 'wpa_psk';
                var authName2 = 'wpa_psk2';
                realAuthNameVal = 'PSKAuthentication';
                authValBeacon = 'WPAand11i';

                paramNames.push(authValBeaconKey);
                paramValues.push(authValBeacon);
                paramTypes.push(realAuthType);
                paramNames.push(authName);
                paramValues.push(realAuthNameVal);
                paramTypes.push(realAuthType);
                paramNames.push(authName2);
                paramValues.push(realAuthNameVal);
                paramTypes.push(realAuthType);
            // }
        } else  if (authVal == "WPA") {
            authName = 'wpa';
            realAuthNameVal = 'WPAAuthenticationMode';
            authValBeacon = 'Basic';

            paramNames.push(authValBeaconKey);
            paramValues.push(authValBeacon);
            paramTypes.push(realAuthType);
            paramNames.push(authName);
            paramValues.push(realAuthNameVal);
            paramTypes.push(realAuthType);
        } else if (authVal == "WPA2") {
            authName = 'wpa2';
            realAuthNameVal = 'IEEE11iAuthenticationMode';
            authValBeacon = 'Basic';

            paramNames.push(authValBeaconKey);
            paramValues.push(authValBeacon);
            paramTypes.push(realAuthType);
            paramNames.push(authName);
            paramValues.push(realAuthNameVal);
            paramTypes.push(realAuthType);
        } else if (authVal == 'WPA/WPA2 mixed') {
            authName = 'wpa';
            var authName2 = 'wpa2';
            realAuthNameVal = 'WPAAuthenticationMode';
            var realAuthName1 = 'IEEE11iAuthenticationMode';
            authValBeacon = 'Basic';

            paramNames.push(authValBeaconKey);
            paramValues.push(authValBeacon);
            paramTypes.push(realAuthType);
            paramNames.push(authName);
            paramValues.push(realAuthNameVal);
            paramTypes.push(realAuthType);
            paramNames.push(authName2);
            paramValues.push(realAuthName1);
            paramTypes.push(realAuthType);
        } else {
            authVal = 'none';
            authName = 'basic_mode';
            realAuthNameVal = 'None';
            authValBeacon = 'Basic';

            paramNames.push(authValBeaconKey);
            paramValues.push(authValBeacon);
            paramTypes.push(realAuthType);
            paramNames.push(authName);
            paramValues.push(realAuthNameVal);
            paramTypes.push(realAuthType);
        }

        if(authVal != 'none' && toAdd == 'false'){
            var presharedKey = th.parent().parent().find("input[name='presharedKey']");
            validateTarifWiFi(th);
            var pskMessage = $("input[name='pskMessage']").val();
            var pskMessageASCII = $("input[name='pskMessageASCII']").val();

            isChanged = true;
            if(presharedKey.val() != ''){
                var realPresharedKeyName = th.parent().parent().find("input[name='presharedKeyName']").val();
                var realPresharedKeyType = th.parent().parent().find("input[name='presharedKeyType']").val();
                paramNames.push(realPresharedKeyName);
                // paramValues.push('"' + presharedKey.val().replace(/ /g, "&#32;") + '"');
                paramValues.push(presharedKey.val().replace(/ /g, "&#32;"));
                paramTypes.push(realPresharedKeyType);
            }
        }else if (authVal != 'none' && toAdd == 'true'){

            var presharedKey = th.parent().parent().find("input[name='presharedKey']");
            validateTarifWiFi(th);

            var pskMessage = $("input[name='pskMessage']").val();
            var pskMessageASCII = $("input[name='pskMessageASCII']").val();
            isChanged = true;
            if(presharedKey.val() != ''){
                var realPresharedKeyName = th.parent().parent().find("input[name='presharedKeyName']").val();
                var realPresharedKeyType = th.parent().parent().find("input[name='presharedKeyType']").val();
                paramNames.push(realPresharedKeyName);
                // paramValues.push('"' + presharedKey.val().replace(/ /g, "&#32;") + '"');
                paramValues.push(presharedKey.val().replace(/ /g, "&#32;"));
                paramTypes.push(realPresharedKeyType);
            }
        }

        var encryption = th.parent().parent().find(".encryptionType option:selected").val();
        if(authVal != 'none'){
            var realEncryptionType = th.parent().parent().find("input[name='encryptionType']").val();
            if(authVal == 'WPA-PSK') {
                isChanged = true;
                // var realEncryptionName = th.parent().parent().find("input[name='encryptionValue']").val();
                var realEncryptionName = "wpa_encrypt";
                paramNames.push(realEncryptionName);
                paramValues.push(encryption);
                paramTypes.push(realEncryptionType);
            } else if (authVal == 'WPA2-PSK') {
                isChanged = true;
                var realEncryptionName = "wpa_encrypt2";
                paramNames.push(realEncryptionName);
                paramValues.push(encryption);
                paramTypes.push(realEncryptionType);
            } else if (authVal == 'WPA-PSK/WPA2-PSK mixed'){
                isChanged = true;
                var realEncryptionName = "wpa_encrypt";
                var realEncryptionName2 = "wpa_encrypt2";
                paramNames.push(realEncryptionName);
                paramValues.push(encryption);
                paramTypes.push(realEncryptionType);
                paramNames.push(realEncryptionName2);
                paramValues.push(encryption);
                paramTypes.push(realEncryptionType);
            }
        }

        var wpaReneval = th.parent().parent().find("input[name='wpaReneval']");
        var wpaRenevalVal = wpaReneval.val().trim();
        if(authVal != 'none'){
            isChanged = true;
            var realWpaRenevalName = th.parent().parent().find("input[name='wpaRenevalName']").val();
            var realWpaRenevalType = th.parent().parent().find("input[name='wpaRenevalType']").val();
            paramNames.push(realWpaRenevalName);
            paramValues.push(wpaRenevalVal);
            paramTypes.push(realWpaRenevalType);
        }

        if (paramNames.length != 0 && isValid && isChanged &&  ifValid) {
            //var msg = getMssg["msg_ok"];
            ////var titleMsg = $('#msgTitle').val();
            //var changMsg =  getMssg['change_msg'];
            //var cancelMsg = getMssg['noChange'];
            //swal({
            //    title: " ",
            //    text: msg,
            //    showCancelButton: true,
            //    closeOnConfirm: true,
            //    confirmButtonText: changMsg,
            //    cancelButtonText: cancelMsg,
            //    confirmButtonColor: "#008DA9"
            //}, function() {


            var wanId = th.parent().find("input[name='wifiID']");
            var exst = false;
            var ppCount = 1;
            var indx = -1;
            if(wifiConnects.length > 0){
                for(var ii = 0; ii < wifiConnects.length; ii++){
                    exst = true;
                    ppCount++;
                    if(wanId.length > 0){
                        if(wanId.val().trim() == wifiConnects[ii]['id']){
                            indx = ii;
                        }
                    }
                }
            }
            if(indx == -1){
                var wanConnectsOBJ = {};
                wanConnectsOBJ['id'] = "W"+ppCount;
                wanConnectsOBJ['names'] = paramNames;
                wanConnectsOBJ['values'] = paramValues;
                wanConnectsOBJ['types'] = paramTypes;
                wifiConnects.push(wanConnectsOBJ);
                getWifiTable();
                // return false;
            } else {
                wifiConnects[indx]['names'] = paramNames;
                wifiConnects[indx]['values'] = paramValues;
                wifiConnects[indx]['types'] = paramTypes;

                getWifiTable();
                // return false;
            }
            $('#wifiPage').show();
            $('#addNewWifi').show();
            $('.addNewWifiDiv').show();
            $('#divForAddWifi').hide();
            $('#divForAddWifi1').hide();
            $('#wifiPage1').hide();
            $('#wifiPage11').hide();
            $("#showWiFI").show();
            $('#forResetWIFI').trigger('reset');

            if(wifiConnects.length > 0){
                var exist = false;
                var indexx = 0;
                if(allConnects.length > 0){
                    for(var ii = 0; ii < allConnects.length; ii++){
                        if(allConnects[ii]['conType'] == 'wifi'){
                            exist = true;
                            indexx = ii;
                        }
                    }
                }
                if(!exist){
                    var connectObj = {};
                    connectObj['conType'] = "wifi";
                    connectObj['conObj'] = wifiConnects;
                    allConnects.push(connectObj);
                } else {
                    allConnects[indexx]['conObj'] = wifiConnects;
                }
            } else {
                var msg = getMssg["no_connection"];
                $("#errTarif").html(msg);
                $("#errTarif").addClass("errorMessage");
            }

            if(wifiConnects.length >= 2) {
                $("#addNewWifi").prop( "disabled", true );
            }
                //wifiConnects
                /*var exst = false;
                var indx = 0;
                if (allConnects.length > 0) {
                    for (var ii = 0; ii < allConnects.length; ii++) {
                        if (allConnects[ii]['conType'] == 'wifi') {
                            exst = true;
                            indx = ii;
                        }
                    }
                }
                if (!exst) {
                    var wifiConnects = {};
                    wifiConnects['names'] = paramNames;
                    wifiConnects['values'] = paramValues;
                    wifiConnects['types'] = paramTypes;
                    var connectObj = {};
                    connectObj['conType'] = "wifi";
                    connectObj['conObj'] = wifiConnects;
                    allConnects.push(connectObj);
                } else {
                    allConnects[indx]['conObj']['names'] = paramNames;
                    allConnects[indx]['conObj']['values'] = paramValues;
                    allConnects[indx]['conObj']['types'] = paramTypes;
                }*/

            return false;

                // $("#errTarif").empty();
                //if (th.hasClass('addTemplatePage')) {
                //    saveTarifInFile(allConnects, tarifName.val(), desc);
                //} else {
                //    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                //}
            //});

        } else {
            // var msg = getMssg["sale_required_fields"];
            // $("#errTarif").html(msg);
            // $("#errTarif").addClass("errorMessage");
            return false;
        }
        return false;
    }

    $(document).on("click",".delWifiParam",function(){
        var wifiId = $(this).parent().find("input[name='wifiID']").val();
        for(var iii = 0; iii < wifiConnects.length; iii++){
            if(wifiConnects[iii]['id'] == wifiId.trim()){
                wifiConnects.splice(iii,1);
                if(wifiConnects.length == 0){
                    $(".WifiTable tr").not(':first').remove();
                    $("#showWiFI").hide();
                    $('.frequencyBand option').attr('disabled', false);
                } else {
                    $(".WifiTable tr").not(':first').remove();
                    for(var ii = 0; ii<wifiConnects.length; ii++){
                        var ssid_index = wifiConnects[ii].names.indexOf('ssid');
                        var ssid = wifiConnects[ii].values[ssid_index];
                        var wpa_psk_index = wifiConnects[ii].names.indexOf('wpa_psk');
                        var wpa_psk2_index = wifiConnects[ii].names.indexOf('wpa_psk2');
                        var wpa_psk = wifiConnects[ii].values[wpa_psk_index];
                        var wpa_psk2 = wifiConnects[ii].values[wpa_psk2_index];
                        var netAuth = '';

                        var frequency_band_index = wifiConnects[ii].names.indexOf('frequency_band');
                        var frequency_band = wifiConnects[ii].values[frequency_band_index];
                        $('.frequencyBand option').attr('disabled', false);

                        if(wpa_psk != undefined && wpa_psk2 != undefined) {
                            netAuth = 'WPA-PSK/WPA2-PSK mixed';
                        } else if(wpa_psk != undefined && wpa_psk2 == undefined) {
                            netAuth = 'WPA-PSK';
                        } else if(wpa_psk2 != undefined && wpa_psk == undefined) {
                            netAuth = 'WPA2-PSK';
                        } else if(wpa_psk2 == undefined && wpa_psk == undefined) {
                            netAuth = 'OPEN';
                        }

                        buildTableRowsForWifi((ii+1),ssid,netAuth,wifiConnects[ii]['id']);
                    }
                }
                if(wifiConnects.length >= 2) {
                    $("#addNewWifi").prop( "disabled", true );
                } else {
                    $("#addNewWifi").prop( "disabled", false );
                }
                return false;
            }
        }
    });

    $(document).on("click","#addTarifInWiFi",function () {
        var th = $(this);
        var status = addTarifInWifi(th);
        var tarifId = th.parent().find("input[name='templateId']").val();
        var tarifChangeName = 'null';
        var tarifChangeDesc = 'null';
        var isValid = true;
        var tarifName = $(".nameDescTarif").find("input[name='tarifName']");
        var errMsg = getMssg["templName_empty"];

        if(tarifName.hasClass("required") && tarifName.val().trim() == ''){
            tarifName.addClass("invalidVal");
            $("#errTarif").addClass("errorMessage");
            $("#errTarif").html(errMsg);
            isValid = false;
        } else if(tarifName.hasClass("invalidVal") && tarifName.val().trim() != '') {
            isValid = false;
        }else{
            tarifName.removeClass("invalidVal");
            var oldTarifName = $(".nameDescTarif").find("input[name='oldTarifName']").val();

            if(tarifName.val() != oldTarifName){
                tarifChangeName = tarifName.val();
            }

            var desc = $(".nameDescTarif").find("textarea[name='tarifDesc']").val();
            var oldTarifDesc = $(".nameDescTarif").find("input[name='oldTarifDesc']").val();

            if($.trim(desc) != $.trim(oldTarifDesc)){
                tarifChangeDesc = desc;
            }
        }
        if(status && isValid){
            var msg = getMssg["msg_ok"];
            //var titleMsg = $('#msgTitle').val();
            var changMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['noChange'];
            swal({
                title: " ",
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                if (th.hasClass('addTemplatePage')) {
                    saveTarifInFile(allConnects, tarifName.val(), desc);
                } else {
                    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                }
            });
        }
    });
    
    $(document).on("keyup","input[name='tarifName']",function(e){
        var th = $(this);
        var newTarifName = th.val();
        var oldTarifNamee = $(this).parent().find("input[name='oldTarifName']").val();

        if(newTarifName != oldTarifNamee){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkTarifNameExist.php",
                data: {
                    'templateName': newTarifName,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = 'login';
                    } else {
                        if(result!=''){
                            $("#errTarif").empty();
                            $("#errTarif").html(result);
                            $("#errTarif").addClass("errorMessage");
                            th.addClass("invalidVal");
                        } else {
                            th.removeClass("invalidVal");
                            $("#errTarif").empty();
                        }
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });
    

//---------- unused functions that may be used after testing -------------------

    $(".content").on("click","#skiptemplWifi",function(){

        var exst=false;
        var indx=0;
        if(allConnects.length>0){
            for(var ii=0;ii<allConnects.length;ii++){
                if(allConnects[ii]['conType']=='wan'){
                    exst=true;
                    indx=ii;
                }
            }
        }
        if(exst) {
            allConnects.splice(ii,1);
        }

        $("#errTarif").empty();
        //show next tab
        showNextTab("templWifi");

    });

    $(".content").on("click","#skiptemplVLAN",function (){
        var exst=false;
        var indx=0;
        if(allConnects.length>0){
            for(var ii=0;ii<allConnects.length;ii++){
                if(allConnects[ii]['conType']=='lan'){
                    exst=true;
                    indx=ii;
                }
            }
        }
        if(exst){
            allConnects.splice(ii,1);
        }

        $("#errTarif").empty();

        //show next tab
        showNextTab("templVLAN");
    });

    $(".content").on("click","#skiptoSave",function (){

        var tName=$("#errTarif").parent().find("input[name='tarifName']");
        if(tName.hasClass("required") && tName.val()==''){
            tName.addClass("invalidVal");
        } else {
            if(allConnects.length>0){
                tName.removeClass("invalidVal");
                var desc=$("#errTarif").parent().find("textarea[name='tarifDesc']").val();
                var msg=getMssg["msg_ok"];
                //var titleMsg = $('#msgTitle').val();
                var changMsg =  getMssg['change_msg'];
                var cancelMsg = getMssg['noChange'];
                swal({
                    title: " ",
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: changMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function() {
                    var exst = false;
                    var indx = 0;

                    for (var ii = 0; ii < allConnects.length; ii++) {
                        if (allConnects[ii]['conType'] == 'wifi') {
                            exst = true;
                            indx = ii;
                        }
                    }

                    if (exst) {
                        allConnects.splice(ii, 1);
                    }

                    $("#errTarif").empty();
                    //show next tab
                    var tarifName = tName.val();
                    saveTarifInFile(allConnects, tarifName, desc);

                });
        } else {
                var msg=getMssg["skip_all"];
                $("#errTarif").html(msg);
                $("#errTarif").addClass("errorMessage");
            }
        }
    });

    $(".content").on("click","#skiptoEdit",function (){

        var tarifChangeName='null';
        var tarifChangeDesc='null';
        var tarifId=$("#errTarif").parent().find("input[name='templateId']").val();

        var tName=$("#errTarif").parent().find("input[name='tarifName']");
        if(tName.hasClass("required") && tName.val()==''){
            tName.addClass("invalidVal");
        } else {
            if(allConnects.length>0){
                tName.removeClass("invalidVal");

                var oldTarifNamee=$("#errTarif").parent().find("input[name='oldTarifName']").val();
                if(tName.val()!=oldTarifNamee){
                    tarifChangeName=tName.val();
                }

                var desc=$("#errTarif").parent().find("textarea[name='tarifDesc']").val();
                var oldTarifDesc=$("#errTarif").parent().find("input[name='oldTarifDesc']").val();
                if($.trim(desc)!= $.trim(oldTarifDesc)){
                    tarifChangeDesc=desc;
                }

                var msg=getMssg["msg_ok"];
                //var titleMsg = $('#msgTitle').val();
                var changMsg =  getMssg['change_msg'];
                var cancelMsg = getMssg['noChange'];
                swal({
                    title: " ",
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: changMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function() {
                    var exst = false;
                    var indx = 0;

                    for (var ii = 0; ii < allConnects.length; ii++) {
                        if (allConnects[ii]['conType'] == 'wifi') {
                            exst = true;
                            indx = ii;
                        }
                    }

                    if (exst) {
                        allConnects.splice(ii, 1);
                    }

                    $("#errTarif").empty();
                    //show next tab
                    var tarifName = tName.val();

                    editTarif(tarifId, allConnects, tarifChangeName, tarifChangeDesc);
                });
            } else {
                var msg=getMssg["skip_all"];
                $("#errTarif").html(msg);
                $("#errTarif").addClass("errorMessage");
            }
        }
    });

// -----------------------------------------------------------------------------

//----------------------For Enable Generate Password (edit)---------------------

function enableGeneratePassword(password,genpassword,hideshowpass, passwordmsg){
    if ($(password).length > 0 && $(password).val() != '') {
        $(genpassword).prop('checked', false);
        $(hideshowpass).show();
        $(passwordmsg).hide();
    }
}
    enableGeneratePassword('#txtPassword','#autoGenPas','#hideShowPasswordPart', '#enterpasswordmsg');
    enableGeneratePassword('#txtPasswordPPTP','#autoGenPasPPTP','#hideShowPasswordPartPPTP', '#enterpasswordmsgPPTP');
    enableGeneratePassword('#txtPasswordL2tp','#autoGenPasL2tp','#hideShowPasswordPartL2tp', '#enterpasswordmsgL2tp');

});
