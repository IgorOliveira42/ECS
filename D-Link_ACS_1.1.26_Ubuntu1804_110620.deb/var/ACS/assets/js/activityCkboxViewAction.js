
$(document).ready(function () {

    $basepath = $('#basepath').data('bpath');
//
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
// ----------- Checkbox iCheck plugin-----------

    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;

    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional 
    });

    $('#all_fields').on('ifChecked ifUnchecked', function(event){

        if (event.type == 'ifChecked') {
                
            $('.fieids').iCheck('check');
            $('#forActivities .trash-select').css('display', 'block');
        } else {

            $('.fieids').iCheck('uncheck');
            $('#forActivities .trash-select').css('display', 'none');
        }
    });
    
    $('.fieids').on('ifChecked ifUnchecked', function(event){
        $activityID = $(this).closest('tr').find("input[name='activityID']").val();
        if (event.type == 'ifChecked') {
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');
            
            if(!$(this).hasClass('allFields')){
                $checked_array.push($activityID);
            }
            
            if($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds){
               $('#all_fields').prop('checked',true).iCheck('update');
            }
//            console.log($checked_array);
        } else {
        
            if($('#all_fields').is(':checked')){
                $('#all_fields').prop('checked',false).iCheck('update');
            }
            
            if(!$('.forFieldsCheck').find('.fieids').is(':checked')){
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($activityID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
        }
    });

    Array.prototype.removeByVal = function(val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".deleteAll", function (){
        var msg = getMssg['delete_all_activity'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        // var mac = $(".macType option:selected").val();
        var model = $(".modelTypeActivity option:selected").val();
        var task = $(".taskType option:selected").val();
        var status = $(".statusType option:selected").val();
        var mac = 0;
        var selectTime = $(".selectTime option:selected").val();
        var createTime = $("#datetimepicker_mask").val();
        if(mac == '0' && model == '0' && task == '0' && status == '-1' && createTime == '' && selectTime == '0'){
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                removeFilteredActivities(mac,model,task,status,createTime,selectTime);
            });
        }else {
            msg = getMssg['delete_filtered_activity'];
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(isConfirm){
                    removeFilteredActivities(mac,model,task,status,createTime,selectTime);
                }
            });
        }
    });
    
    $(document).on("click", ".deleteSelected", function (){
        var msg = getMssg['delete_selected_activity'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function() {
            removeActivities($checked_array);
        });
    });
    
    function removeActivities(e){
    
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'activityID': e,
                'actionName': "deleteTask",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    // var success = getMssg['action_succeed'];
                    // $("#resActivity").empty();
                    // $("#resActivity").removeClass("errorMessage");
                    // $("#resActivity").addClass("infoMessage");
                    // $("#resActivity").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000);
                } else if (result == 'false') {
                    var failed = getMssg['connect_failed'];
                    $("#resActivity").empty();
                    $("#resActivity").removeClass("infoMessage");
                    $("#resActivity").addClass("errorMessage");
                    $("#resActivity").html(failed);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        location.reload(true);
                    },10000);
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    function removeFilteredActivities(deviceId,modelId,operationTypeId,operationStatus,createTime,selectTime){
    
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'actionName': "deleteFilteredActivities",
                'deviceId': deviceId,
                'modelId': modelId,
                'operationTypeId': operationTypeId,
                'operationStatus': operationStatus,
                'createTime' : createTime,
                'selectTime' : selectTime,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    // var success = getMssg['action_succeed'];
                    // $("#resActivity").empty();
                    // $("#resActivity").removeClass("errorMessage");
                    // $("#resActivity").addClass("infoMessage");
                    // $("#resActivity").html(success);
                    setTimeout(function () {
                        location.reload(true);
                    }, 10000);
                } else if (result == 'false') {
                    var failed = getMssg['connect_failed'];
                    $("#resActivity").empty();
                    $("#resActivity").removeClass("infoMessage");
                    $("#resActivity").addClass("errorMessage");
                    $("#resActivity").html(failed);
                    $("body").css("cursor", "default");
                    setTimeout(function () {
                        location.reload(true);
                    },10000)
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
     
});

