// START OF FORM VALIDATION

    $.validator.addMethod("validateIpAddress", function(value, element) {
        if (value != '') {
            return value.trim().match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/);
        } else {
            return true;
        }
    });

    $.validator.addMethod("validateIpAddressInMask", function(value, element) {
        if (value != '') {
            var ip = value.split('/')[0];
            return ip.trim().match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/);
        } else {
            return true;
        }
    });

$.validator.addMethod("validateIpMask", function(value, element) {
    var ip = value.split('/')[0];
    var mask = value.split('/')[1];
    if (ip != '' && mask != undefined) {
        return mask.trim().match(/^([1-9]|[1-2][0-9]|3[0-1])$/);
    } else if (ip != '' && mask == undefined) {
        return false;
    }else {
        return true;
    }
});

    $.validator.addMethod("validateDomain", function(value, element) {
        if (value != '') {
            return value.trim().match(/^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,6})$/);
        } else {
            return true;
        }
    });


    function convertIpToNumber(ip) {
        var d = ip.split('.');
        if (d.length != 4) {
            return -1;
        }
        var d0 = parseInt(d[0]);
        var d1 = parseInt(d[1]);
        var d2 = parseInt(d[2]);
        var d3 = parseInt(d[3]);
        var n = d0 * Math.pow(256, 3);
        n += d1 * Math.pow(256, 2);
        n += d2 * 256;
        n += d3;
        return n;
    }

    function isNetMask(netmask) {
        if (netmask != 0 && ((netmask & 0x1) == 0)) {
            while ((netmask & 0x80000000) != 0) {
                netmask <<= 0x1
            }
            return (netmask == 0x0) ? true : false;
        }
            return false;
    }

    $.validator.addMethod("validateNetworkAddress", function(value, element, options) {
        var ip = $(options.ip).val().trim();
        var maskAddr = $(options.netmask).val().trim();

        var d = ip.split('.');
        if (d.length != 4) {
            return -1;
        }
        var q1 = parseInt(d[0]);
        var q2 = parseInt(d[1]);
        var q3 = parseInt(d[2]);
        var q4 = parseInt(d[3]);
        var ipBin={};
        ipBin[1]=String("00000000"+parseInt(q1,10).toString(2)).slice(-8);
        ipBin[2]=String("00000000"+parseInt(q2,10).toString(2)).slice(-8);
        ipBin[3]=String("00000000"+parseInt(q3,10).toString(2)).slice(-8);
        ipBin[4]=String("00000000"+parseInt(q4,10).toString(2)).slice(-8);

        var r = maskAddr.split('.');
        if (r.length != 4) {
            return -1;
        }
        var n1 = parseInt(r[0]);
        var n2 = parseInt(r[1]);
        var n3 = parseInt(r[2]);
        var n4 = parseInt(r[3]);
        var netBin={};
        netBin[1]=String("00000000"+parseInt(n1,10).toString(2)).slice(-8);
        netBin[2]=String("00000000"+parseInt(n2,10).toString(2)).slice(-8);
        netBin[3]=String("00000000"+parseInt(n3,10).toString(2)).slice(-8);
        netBin[4]=String("00000000"+parseInt(n4,10).toString(2)).slice(-8);
        var cidr=0;
        for (var j = 1; j <=4 ; j++) {
            for (var i = 0; i < 32; i++) {
                if (netBin[j][i] == 1) {
                    cidr = cidr + 1;
                }
            }
        }

        var mask=cidr;
        var importantBlock=Math.ceil(mask/8);
        var importantBlockBinary=ipBin[importantBlock];
        var maskBinaryBlockCount=mask%8;
        if(maskBinaryBlockCount==0)importantBlock++;
        var maskBinaryBlock="";
        var maskBlock="";
        for(var i=1;i<=8;i++){
            if(maskBinaryBlockCount>=i){
                maskBinaryBlock+="1";
            }else{
                maskBinaryBlock+="0";
            }
        }

        maskBlock=parseInt(maskBinaryBlock,2);

        //net & broadcast addr
        var netBlockBinary="";
        var bcBlockBinary="";
        for(var i=1;i<=8;i++){
            if(maskBinaryBlock.substr(i-1,1)=="1"){
                netBlockBinary+=importantBlockBinary.substr(i-1,1);
                bcBlockBinary+=importantBlockBinary.substr(i-1,1);
            }else{
                netBlockBinary+="0";
                bcBlockBinary+="1";
            }
        }

        var mask="";
        var maskBinary="";
        var net="";
        var bc="";
        var netBinary="";
        var bcBinary="";
        var rangeA="";
        var rangeB="";
        //loop to put whole strings block together
        for(var i=1;i<=4;i++){
            if(importantBlock>i) {
                //blocks before the important block.
                mask+="255";
                maskBinary+="11111111";
                netBinary+=ipBin[i];
                bcBinary+=ipBin[i];
                net+=parseInt(ipBin[i],2);
                bc+=parseInt(ipBin[i],2);
                rangeA+=parseInt(ipBin[i],2);
                rangeB+=parseInt(ipBin[i],2);
            }else if (importantBlock==i) {
                //the important block.
                mask+=maskBlock;
                maskBinary+=maskBinaryBlock;
                netBinary+=netBlockBinary;
                bcBinary+=bcBlockBinary;
                net+=parseInt(netBlockBinary,2);
                bc+=parseInt(bcBlockBinary,2);
                rangeA+=(parseInt(netBlockBinary,2));
                rangeB+=(parseInt(bcBlockBinary,2));
            }else {
                //block after the important block.
                mask+=0;
                maskBinary+="00000000";
                netBinary+="00000000";
                bcBinary+="11111111";
                net+="0";
                bc+="255";
                rangeA+=0;
                rangeB+=255;
            }
            //add . separator except the last block
            if(i<4){
                mask+=".";
                maskBinary+=".";
                netBinary+=".";
                bcBinary+=".";
                net+=".";
                bc+=".";
                rangeA+=".";
                rangeB+=".";
            }
        }
    if (ip==net || ip==bc) {
        return false;
    }
        return true;
    });

    $.validator.addMethod("validateNetMask", function(value, element) {
        var nmask = convertIpToNumber(value);
        return isNetMask(nmask);
    });
        
    $.validator.addMethod("validateStartEndIP", function(value, element, options) {
        var from = $(options.from).val().trim();
        var to = $(options.to).val().trim();
        if (from == "" || to == "") {
            return false;
        }
        var start = convertIpToNumber(from);
        var end = convertIpToNumber(to);
        if (start >= end) {
            return false;
        }
        return true;
    });

    $.validator.addMethod("validateStartEndIpBasedOnNetMask", function(value, element, options) {
        var from = $(options.from).val().trim();
        var to = $(options.to).val().trim();
        var mask = $(options.netmask).val().trim();
        if (from == "" || to == "" ||  mask == "") {
            return true;
        }
        var start = convertIpToNumber(from);
        var end = convertIpToNumber(to);
        var mask = convertIpToNumber(mask);
        if ((start & mask) != (end & mask)) {
            return false;
        }
        return true;
    });

    $.validator.addMethod("validateNetAddress", function(value, element, options) {
        var ip = $(options.ip).val().trim();
        var from = $(options.from).val().trim();
        var to = $(options.to).val().trim();

        var ip = convertIpToNumber(ip);
        var start = convertIpToNumber(from);
        var end = convertIpToNumber(to);

        if(ip>=start && ip<=end) {
            return false;
        }
        return true;
    });

    $.validator.addMethod("validateLeaseTime", function(value, element) {
        var val = parseFloat(value);
        return (val >= 120 /*&& val <= ((Math.pow(2, 32) - 2) * 60)*/);
    });
    
    $.validator.addMethod("leaseTimeIsDivided60", function(value, element) {
        var val = parseFloat(value);
//        return ((val % 60) == 0 ? true : false);
        if(val % 60 != 0){
            return true;
        }
        return true;
    });

    $.validator.addMethod("validateDNS", function(value, element) {
        var dns = value.trim();
        if (dns == '' || dns == 'localhost') {
            return true;
        } 
//	if (! dns.match(/^([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+[a-zA-Z]{2,6}$/)) {
//            var arr = dns.split(',');
//            for (ind = 0; ind < arr.length; ind++) {
//                if ( ! (arr[ind].trim()).match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/)) {
//                    return false;
//                }   
//            }
//	}
	if (! dns.match(/^([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+[a-zA-Z]{2,6}$/)) {
            if ( ! (dns.trim()).match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/)) {
                return false;
            }
	}
        return true;
    });
    
    $.validator.addMethod("validateDNSEquality", function(value, element, options) {
        var dns = value.trim();
        if (dns == '' || dns == 'localhost') {
            return true;
        } 
        var primeDns =  $(options.primDns).val().trim();
        var secondDns =  $(options.secondDns).val().trim();
       
        if(primeDns == secondDns){
            return false;
        }

        return true;
    });
    
    $.validator.addMethod("validateSingalDNS", function(value, element) {
        var dns = value.trim();
        if (dns == '') {
            return false;
        } 
	if (! dns.match(/^([a-zA-Z0-9]+(-[a-zA-Z0-9]+)*\.)+[a-zA-Z]{2,6}$/)) {
            if ( ! dns.match(/^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/)) {
                return false;
            }   
	}
        return true;
    });
    
    $.validator.addMethod("validateMac", function(value, element, options) {
        var val = value.trim();
        if (val == '') {
            return true;
        } 
        
        var siteType =  $(options.siteType).val().trim();
        if(siteType == 'armentel'){
            return true;
        }else if(siteType == 'main'){
            return (val.match("^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$"));
        }
    });

    $.validator.addMethod("validateAddressmac", function(value) {
        var val = value.trim();
        if(!val.match("^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$")) {
            return false;
        }
            return true;
    });
    
    $.validator.addMethod("validateLength", function(value, element) {
        if(value.length == 0){
            return true;
        }
        
        if(value.length < 8 || value.length > 63){
            return false;
        }
        
        return true;
    });
    
    $.validator.addMethod("validateASCII", function(value, element) {
        var val = value.trim();
        if (val == '') {
            return true;
        }
        for(var i=0; i<value.length; i++){
            if(value.charCodeAt(i)>127){
                return false;
            }
        }
        return true;
    });
    
    $.validator.addMethod("validateVersionLength", function(value, element) {
        var val = value.trim();
         if (val == '') {
            return true;
        }
        
        if(value.length > 40){
            return false;
        }
        
        return true;
    });

$.validator.addMethod("validateConnectionNameLength", function(value, element) {
    var val = value.trim();
    if (val == '') {
        return true;
    }

    if(value.length > 32){
        return false;
    }

    return true;
});
    
    $.validator.addMethod("validateNotZero", function(value, element) {
        var val = value.trim();
         if (val == 0) {
            return false;
        }
        return true;
    });
    
    $.validator.addMethod("validateIsEmpty", function(value, element) {
        var val = value.trim();
         if (val == '') {
            return false;
        }
        return true;
    });


    $.validator.addMethod("digitsForTime", function(value, element) {
        var val = value.trim();
        var reg = /^[0-9]*$/;
        if(reg.test(val) || val <= 0) {
            return true;
        }
            return false;

    });

    $.validator.addMethod("digitsForTimeMin", function(value, element) {
        var val = value.trim();
        if (val > 0) {
            return true;
        } else if (val == '') {
            return true;
        } else {
            return false;
        }
    });

    $.validator.addMethod("noSpace", function(value, element) {
        var val = value.indexOf(" ") ;
        if (val >= 0) {
            return false;
        }
        return true;
    });
    
    $.validator.addMethod("validateFirmwareFileType", function(value, element, options) {
        var uploadType = $(options.uploadType).val();
	if (uploadType == "uploadFW") {
	    var uploadRealFile = $(options.uploadRealFile);
	    //var fileType = uploadRealFile.prop('files')[0].type;
	    //if (fileType != "application/octet-stream") {
        //return false;
	    //}
        var extension = uploadRealFile.prop('files')[0].name.replace(/^.*\./, '');
        if (extension != "bin") {
            return false;
        }
	}
	// else if (uploadType == "uploadConfig") {
	//     var uploadRealFile = $(options.uploadRealFile);
	//     var fileType = uploadRealFile.prop('files')[0].type;
	//     if (fileType != "application/gzip" && fileType != "application/x-gzip" && fileType != "binary/octet-stream") {
	// 	return false;
	//     }
	// }
	else if (uploadType == "uploadTarif" || uploadType == "uploadDescription") {
	    var uploadRealFile = $(options.uploadRealFile);
	    var extension = uploadRealFile.prop('files')[0].name.replace(/^.*\./, '');
	    if (extension != 'ini') {
		return false;
	    }
	}
        return true;
    });
    
    $.validator.addMethod("validateURL", function(value, element) {
        return value.trim().match(/^((http|https):\/\/)*(([a-zA-Z0-9$\-_.+!*'(),;:&=]|%[0-9a-fA-F]{2}f)+@)?(((25[0-5]|2[0-4][0-9]|[0-1][0-9][0-9]|[1-9][0-9]|[0-9])(\.(25[0-5]|2[0-4][0-9]|[0-1][0-9][0-9]|[1-9][0-9]|[0-9])){3})|localhost|([a-zA-Z0-9\-\u00C0-\u017F]+\.)+([a-zA-Z]{2,}))(:[0-9]+)?(\/(([a-zA-Z0-9$\-_.+!*'(),;:@&=]|%[0-9a-fA-F]{2})*(\/([a-zA-Z0-9$\-_.+!*'(),;:@&=]|%[0-9a-fA-F]{2})*)*)?(\?([a-zA-Z0-9$\-_.+!*'(),;:@&=\/?]|%[0-9a-fA-F]{2})*)?(\#([a-zA-Z0-9$\-_.+!*'(),;:@&=\/?]|%[0-9a-fA-F]{2})*)?)?$/);
    });

    $.validator.addMethod("validateReservedIp", function(value, element) {
        var val = value.trim();
        if (val == "0.0.0.0" || val == "255.255.255.255") {
            return false;
        }
        return true;
    });

    $.validator.addMethod("email", function(value, element) {
        var val = value.trim();
        if (val == "") {
            return true;
        } else if (val.length >  100) {
            return false;
        } else {
            return val.trim().match(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,63}))$/);
        }
    });

    $.validator.addMethod("ipAddressIsEqual", function(value, element, options) {
        var ip = $(options.ip).val().trim();
        var gateway = $(options.gateway).val().trim();
        var ipAddr = convertIpToNumber(ip);
        var gatewayAddr = convertIpToNumber(gateway);
        if ( ipAddr == gatewayAddr ) {
            return false;
        }
        return true;
    });

    $.validator.addMethod("minlengthMac", function(value, element, options) {
        var length = value.trim();
        if(length.length < 10) {
            return false;
        } else {
            return true;
        }
    });

    $.validator.addMethod("validateDevInfoUploadFileType", function(value, element, options) {
        $("#msgUploadFile").empty();
        var uploadRealFile = $(options.uploadRealFile);
        var extension = uploadRealFile.prop('files')[0].name.replace(/^.*\./, '');
        if (extension != "xlsx" && extension != "csv") {
            return false;
        } else {
            return true;
        }
        return true;
    });


    $.validator.addMethod("validateDateTime", function(value, element, options) {
        var pattern = new RegExp("^\\d\\d\\d\\d-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]) (0[0-9]|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])$");
        if (value.search(pattern)===0) {
            return true;
        } else {
            return false;
        }
    });

    $.validator.addMethod("dateTimeLength", function(value, element, options) {
        var date = new Date(value);
        var realDate = new Date();
        var subDate = realDate - date;

        if(subDate > 0) {
            return false;
        } else {
            return true;
        }
    });

    $.validator.addMethod("invalidDate", function(value, element, options) {
        var date = value.split(' ')
        var split = date[0].split('-');
        var year = split[0];
        var month = split[1];
        var day = split[2];
        if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
            return false;
        } else if(month == 2 && year%4 == 0 && day > 29) {
            return false;
        } else if(month == 2 && year%4 != 0 && day > 28) {
            return false;
        } else {
            return true;
        }
    });

    //----------------------------validation IPv6-------------------------//

$.validator.addMethod("invalidIPv6", function(value, element, options) {
    var re = new RegExp(/^\s*((([0-9A-Fa-f]{1,4}:){7}([0-9A-Fa-f]{1,4}|:))|(([0-9A-Fa-f]{1,4}:){6}(:[0-9A-Fa-f]{1,4}|((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){5}(((:[0-9A-Fa-f]{1,4}){1,2})|:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3})|:))|(([0-9A-Fa-f]{1,4}:){4}(((:[0-9A-Fa-f]{1,4}){1,3})|((:[0-9A-Fa-f]{1,4})?:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){3}(((:[0-9A-Fa-f]{1,4}){1,4})|((:[0-9A-Fa-f]{1,4}){0,2}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){2}(((:[0-9A-Fa-f]{1,4}){1,5})|((:[0-9A-Fa-f]{1,4}){0,3}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(([0-9A-Fa-f]{1,4}:){1}(((:[0-9A-Fa-f]{1,4}){1,6})|((:[0-9A-Fa-f]{1,4}){0,4}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:))|(:(((:[0-9A-Fa-f]{1,4}){1,7})|((:[0-9A-Fa-f]{1,4}){0,5}:((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}))|:)))(%.+)?\s*$/);
    if (value.search(re)===0 || value == '') {
        return true;
    } else {
        return false;
    }
});

$.validator.addMethod("invalidPrefix", function(value, element, options) {
    var re = /^(0|[1-9]|[1-9][0-9]|1[0-2][0-8])$/;
    if (value.search(re)===0) {
        return true;
    } else {
        return false;
    }
});

$.validator.addMethod("validateStartEndIPv6", function(value, element, options) {
    var from = $(options.from).val().trim();
    var to = $(options.to).val().trim();
    var arrAddr1 = full(from).split(":");
    var arrAddr2 = full(to).split(":");

    for (var i = 0; i < arrAddr1.length; i++) {

        var partAddr1 = arrAddr1[i];
        var partAddr2 = arrAddr2[i];

        if (parseInt(partAddr1, 16) < parseInt(partAddr2, 16)) return true
        else if (parseInt(partAddr1, 16) > parseInt(partAddr2, 16)) return false;

    };

    return false;
});

$.validator.addMethod("validateEqualIPv6", function(value, element, options) {
    var ip = $(options.ip).val().trim();
    var gateway = $(options.gateway).val().trim();
    var arrAddr1 = full(gateway).split(":");
    var arrAddr2 = full(ip).split(":");

    for (var i = 0; i < arrAddr1.length; i++) {

        var partAddr1 = arrAddr1[i];
        var partAddr2 = arrAddr2[i];

        if (parseInt(partAddr1, 16) < parseInt(partAddr2, 16)) return true
        else if (parseInt(partAddr1, 16) > parseInt(partAddr2, 16)) return true;

    };

    return false;
});

$.validator.addMethod("validateDHCPIPv6", function(value, element, options) {
    var from = $(options.from).val().trim();
    var to = $(options.to).val().trim();
    var real = $(options.real).val().trim();
    var arrAddr1 = full(from).split(":");
    var arrAddr2 = full(to).split(":");
    var arrAddrReal = full(real).split(":");

    for (var i = 0; i < arrAddr1.length; i++) {

        var partAddr1 = arrAddr1[i];
        var partAddr2 = arrAddr2[i];
        var partAddrReal = arrAddrReal[i];

        if (parseInt(partAddrReal, 16) < parseInt(partAddr1, 16) || parseInt(partAddrReal, 16) > parseInt(partAddr2, 16)) return true

    };

    return false;
});

$.validator.addMethod("reservedIPv6", function(value, element, options) {
    var addr = $(options.ip).val().trim();
    var prefix = $(options.netmask).val().trim();
    var network = getNetworkAddress(addr, prefix);
    if (network == addr) return false;
        var shortNetwork = short(network);
        switch (shortNetwork) {
            case '::': return false;
            case '::1': return false;
            case '2001:db8::': return false;
            case 'fc00::': return false;
            case 'ff00::': return false;
        };

        return true;
});

$.validator.addMethod("validateRangeIPv6", function(value, element, options) {
    var addr = $(options.ip).val().trim();
    var prefix = $(options.prexif).val().trim();
    var net = $(options.net).val().trim();
    var netAddr = getNetworkAddress(net, prefix);

    var addrNet = getNetwork(addr, prefix, false);

    if (addrNet.net != netAddr) return false;
    else return true;
});

$.validator.addMethod("validatePort", function(value) {
  var val = value[0];
  if (val == '0'){
      return false;
  } else {
      return true;
  }
});

function getNetwork(addr, prefix) {
    var subnet = prefixMask(addr, prefix, false);

    return {
        net: subnet,
        prefix: prefix
    }
}

function getNetworkAddress(addr, prefix) {
    return prefixMask(addr, prefix, false);
};

function prefixMask(addr, prefix, invert) {

    var isAddrShort = isShort(addr);
    if (isAddrShort) addr = full(addr);

    var bits = toBits(addr);
    var prefix = parseInt(prefix);

    var result = "";

    var len = 0;
    for (var index = 0; index < bits.length; index++) {

        var bit = bits[index];

        if (bit == ":") {
            result += ":";
            continue;
        };

        if (len >= prefix) result += (invert) ? "1" : "0";
        else result += bit;

        len = len + 1;

    };

    var result = fromBits(result);

    return (isAddrShort) ? short(result) : result;;
};

function full(addr) {
    var arrAddr = addr.split(":");
    var arrResult = [];

    var shortLen = 8 - _.compact(arrAddr).length;

    _.each(arrAddr, function(elem, index) {

        if (elem == "") {
            while (shortLen) {
                arrResult.push("0000");
                --shortLen;
            };
            return;
        };

        while (elem.length < 4) {
            elem = "0" + elem;
        };

        arrResult.push(elem);

    });

    return arrResult.join(":");
};

function isShort(addr) {
    return (addr.length != 39)
};

function toBits(addr) {
    var arrAddr = full(addr).split(":");

    return _.map(arrAddr, function(partAddr) {
        var bits = parseInt(partAddr, 16).toString(2);

        while (bits.length < 16) bits = "0" + bits;

        return bits;
    }).join(":");
};

function fromBits(bits) {
    var arrBits = bits.split(":");

    var result = _.map(arrBits, function(partBits) {
        var partAddr = parseInt(partBits, 2).toString(16);

        while (partAddr.length < 4) partAddr = "0" + partAddr;

        return partAddr;
    }).join(":")

    return short(result);
};

function short(addr) {

    var workAddr = _.clone(addr);

    // удаляем ведущии нули.
    workAddr = workAddr.replace(/([0-9a-f]+)(?=(:|$))/ig, function(octet) {
        octet = octet.replace(/^0{1,3}/, "");
        return octet;
    });

    // сокращаем самую длинную нулевую последовательность групп
    var zeroSequence = findLongestZeroSeq(workAddr);

    if (_.isNull(zeroSequence)) return workAddr;

    workAddr = workAddr.replace(zeroSequence, "::");

    return workAddr.replace(/\:{2,}/, "::");

    function findLongestZeroSeq(addr) {
        var sequences = addr.match(/((^|:)0)+/g);

        if (!sequences) return null;

        return _.max(sequences, function(seq) {
            return seq.length;
        });
    };
};

// END OF FORM VALIDATION
