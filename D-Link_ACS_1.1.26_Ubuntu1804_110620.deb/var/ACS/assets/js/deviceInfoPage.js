
var devStatuss = '';
var interval = '';
var intervalAutoRefresh = '';
var intervalSetTypeLan = '';
var intervalSetTypeWan = '';
var intervalSetTypeWifi = '';
var intervalSetTypeVlan = '';
var intervalSetTypeStatistics = ''
var intervalSetTypeStatisticClients = '';
var intervalSetTypeStatisticInterfaces = '';
var intervalSetTypeStatisticRouting = '';
var intervalSetTypeVoip = '';
var intervalSetTypeInfo = '';
var intervalRefresh = '';
var intervalTaskRefresh = '';
var intervalLan = '';
var intervalWan = '';
var intervalWifi = '';
var intervalVlan = '';
var intervalVoip = '';
var intervalInfo = '';
var intervalLte = '';
var intervalWireless = [];


//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg=result;
//            }
//        }
//    });
//    return retMsg;
//}

$(document).ready(function () {
    if ($.cookie().conectionName){
        var idCheckbox = $.cookie().conectionName;
        setTimeout(function () {
            $("#" + idCheckbox).click();
        },10);
        $.removeCookie('conectionName');
    }
    console.log('deviceInfo');
    $basepath = $('#basepath').data('bpath');
    var devId = $("input[name='devID']").val();
    var serialN = $("input[name='serialN']").val();
    var macAddress = $("input[name='macAddress']").val();
    var actTab = $("input[name='actionName']").val();
    var havePerm = $('.devices_bl').find("input[name='havePermission']").val();
    var token_cookie = $("input[name='token_cookie']").val();
    var btnShow=globalVar.getCookie(globalVar.TASKS.REFRESH+devId);
    console.log(globalVar.TASKS.REFRESH+"=" + btnShow);

    if(btnShow==='true'){
        $("#refreshButton").show();
    }else{
        $("#refreshButton").hide();
    }
    $("#refreshButton").on("click" , function (e) {
        e.stopPropagation();
        var th=$(this);
        var refBtn=$('#refresh_page');
        var getAllBtn=$('#getAllParams');
        ajaxRequest.send({
            type:globalVar.HTTP.POST,
            name:globalVar.TASKS.REFRESH,
            check:globalVar.TASKS.REFRESH,
            data: {
                'deviceID': devId,
                'fromApp':true
            },
            response:function(respons) {
                th.prop("disabled", true);
                updateActivities(devId);
                $("#refreshMsg").empty();
                $('#refreshMsg').show();
                $("#refreshMsg").html(getMssg['action_succeed']);
                $("#refreshMsg").addClass("infoMessage");
                $("body").css("cursor", "default");
                $(":button").prop("disabled", true);
                location.reload(true);

            },
            getStatus:function(status){
                //task was done
                refBtn.prop("disabled",false);
                $("#refreshMsg").empty();
                $('#refreshMsg').hide();
                refBtn.hide();
                getAllBtn.prop("disabled",false);
                getAllBtn.show();
                var serialN = $("input[name='serialN']").val();
                location.reload(true);
                //removeCache();
                //getTree("../tmp/"+serialN+"_name.xml");
            }
        });
        return false;
    });
//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    function updateActivities(deviceID){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/eachDevActivity.php",
            data: {
                'deviceID': deviceID,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forDActiv").empty();
                    $("#forDActiv").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }    
   
    function updateAfterTheAction() {
//        var countForm = $("#infoId").length;
//        if (countForm > 0) {
//            $("#infoId").submit();
//        } else {
//            var devidd = devId;
//            var newForm = '<form action="'+ $basepath +'devInfo/" id="infoId"  method="post" ><input type="hidden" name="devId" value="' + devidd + '" /></form>';
//            $(".devices_bl").append(newForm);
//            $("#infoId").submit();
//        }
        location.reload(true);
    }

    $('body').oLoader();
    devStatuss = 'true';
    $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getTabPageForDevice.php",
                data: {
                    'deviceID': devId,
                    'serialNumber':serialN,
                    'actionName': actTab,
                    'devStatus': devStatuss,
                    'havePermissions':havePerm,
                    'macAddress':macAddress,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result =='logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $('body').oLoader('hide');
                        $("#fragment-"+actTab).empty();
                        $("#fragment-"+actTab).html(result);
                        $("#fragment-"+actTab).show();
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
                updateActivities(devId);
    //         }
    //     },
    //     error: function(xhr, status, error) {
    //         document.location.href = $basepath + '500';
    //     }
    // });

    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/eachDevActivity.php",
        data: {
            'deviceID': devId,
            'fromApp':true
        },
        async: false,
        success: function (result) {
            if (result =='logged_out') {
                document.location.href = $basepath + 'login';
            } else {
                $("#forDActiv").empty();
                $("#forDActiv").html(result);
            }
        },
        error: function(xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });

    function getTaskStatus(devId,tab){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName':"'set'",
                'deviceID': devId,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                var changed = true;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
//                }else if(result == 0 || result == 1 || result == -1){
//                    changed = false;
//                }else { 
//                    changed = true;
//                }
                }else if(result == 2){
                    changed = true;
                }else if(result == 1 || result == 0 || result == -1) { 
                    changed = false;
                }else {
                    changed = false;
                    switch (tab) {
                        case 'info':
                            clearInterval(intervalSetTypeInfo);
                            break;
                        case 'lan':
                            clearInterval(intervalSetTypeLan);
                            break;
                        case 'wan':
                            clearInterval(intervalSetTypeWan);
                            break;
                        case 'vlan':
                            clearInterval(intervalSetTypeVlan);
                            break;
                        case 'statistics':
                            clearInterval(intervalSetTypeStatistics);
                            break;
                        case 'voip':
                            clearInterval(intervalSetTypeVoip);
                            break;
                        case 'wireless':
                            clearInterval(intervalSetTypeWifi);
                            break;
                        case 'lte':
                            clearInterval(intervalSetTypeWifi);
                            break;
                    }
                }
                var msg = getMssg['config_change'];
                if(changed){
                    $('.nav-tabs').find(".fragment").each(function() {
                        if($(this).attr('id') == tab){
                            $(this).addClass('hasChanged');
                            $(this).attr('title', msg);
                        }
                    });
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    function getCorrentTaskIdByTab(devId,tab){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName': "tabs",
                'deviceID': devId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result != -1){
                    switch (tab) {
                        case 'info':
                            intervalInfo = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'lan':
                            intervalLan = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'wan':
                            intervalWan = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'vlan':
                            intervalVlan = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'statistics':
                            intervalVlan = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'voip':
                            intervalVoip = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'wireless':
                            intervalWifi = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                        case 'lte':
                            intervalLte = setInterval(function(){
                                getActivitiStatusByIdFromTab(result,tab);
                            }, 1000);
                            break;
                    }
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    function getActivitiStatusByIdFromTab(activityId,tab){
        // var errorAjax = true;
        var i=0;
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getLastStatusOfTheActivity.php",
            data: {
                'activityID': activityId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                var completed = true;
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'completed') {
                    completed = true;
                } else if (result == 'waiting' || result == 'processing') {
                    completed = false;
                    } else {
                    completed = true;

                    }

                    if (completed) {
                        switch (tab) {
                            case 'info':
                                clearInterval(intervalInfo);
                                $('#igmpApply').removeAttr("disabled");
                                $('#remoteAccessApply').removeAttr("disabled");
                                $('#stunApply').removeAttr("disabled");
                                $('#stunOnoffswitch').removeAttr("disabled");
                                break;
                                case 'lan':
                                    clearInterval(intervalLan);
                                    $('#addLan').removeAttr("disabled");
                                    $('#addLanV6').removeAttr("disabled");
                                    break;
                                case 'wan':
                                    clearInterval(intervalWan);
                                    $('#addStaticWan').removeAttr("disabled");
                                    $('#addDynamicWan').removeAttr("disabled");
                                    $('#addPPPWan').removeAttr("disabled");
                                    break;
                                case 'vlan':
                                    clearInterval(intervalVlan);
                                    $('#addBridge').removeAttr("disabled");
                                    $('#editBridge').removeAttr("disabled");
                                    break;
                                case 'voip':
                                    clearInterval(intervalVoip);
                                    $('#editVoip').removeAttr("disabled");
                                    break;
                                case 'wireless':
                                    clearInterval(intervalWifi);
                                    $('#addWLAN').removeAttr("disabled");
                                    break;
                                case 'lte':
                                    clearInterval(intervalLte);
                                    $('#lteApply').removeAttr("disabled");
                                    break;
                            }
                        } else {
                            switch (tab) {
                                case 'info':
//                            clearInterval(intervalInfo);
                                    $('#stunApply').attr('disabled', 'disabled');
                                    $('#igmpApply').attr('disabled', 'disabled');
                                    $('#remoteAccessApply').attr('disabled', 'disabled');
                                    break;
                                case 'lan':
//                            clearInterval(intervalLan);
                                    $('#addLan').attr('disabled', 'disabled');
                                    $('#addLanV6').attr('disabled', 'disabled');
                                    break;
                                case 'wan':
//                            clearInterval(intervalWan);
                                    $('#addStaticWan').attr('disabled', 'disabled');
                                    $('#addDynamicWan').attr('disabled', 'disabled');
                                    $('#addPPPWan').attr('disabled', 'disabled');
                                    break;
                                case 'vlan':
//                            clearInterval(intervalVlan);
                                    $('#addBridge').attr('disabled', 'disabled');
                                    $('#editBridge').attr('disabled', 'disabled');
                                    break;
                                case 'voip':
//                            clearInterval(intervalVoip);
                                    $('#editVoip').attr('disabled', 'disabled');
                                    break;
                                case 'wireless':
//                            clearInterval(intervalWifi);
                                    $('#lteApply').attr('disabled', 'disabled');
                                    break;
                                case 'lte':
                                    $('#lteApply').attr('disabled', 'disabled');
                                    break;
                            }
                        }
                    },
                    error: function (xhr, status, error) {
                        if (i==3) {
                            $(this).attr("disabled", "disabled");
                            $(this).css("opacity", "0.5");
                            $(this).css("cursor", "default");
                            var msg = getMssg['update_page'];
                            swal({
                                title: '',
                                text: msg,
                                showCancelButton: false,
                                closeOnConfirm: true,
                                confirmButtonText: '',
                                confirmButtonColor: "#008DA9"
                            }, function(isConfirm) {
                                if(isConfirm){

                                }else{
                                    $(this).removeAttr("disabled");
                                    $(this).css("opacity","1");
                                    $(this).css("cursor","pointer");
                                }
                            });

                            // document.location.href = $basepath + '500';
                            // location.reload(true);
                        } else {
                            i++;
                            getActivitiStatusByIdFromTab(activityId,tab);
                        }
                    }
                });
    }
    
    $(document).on("click", "#refresh", function () {

        $('#refresh').attr('disabled', true);
        $("#refresh").addClass("refreshButtonClick");

        var th=$(this);
        if(th.attr("disabled")!="disabled"){
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'actionName': "auto_refresh",
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        var success = getMssg['action_succeed'];
                        $("#resDev").empty();
                        $("#resDev").html(success);
                        setTimeout(function () {
                            updateActivities(devId);
                            th.attr("disabled","disabled");
//                            th.css("opacity","0.5");
//                            th.css("cursor","default");
                        }, 2000);
                    } else if (result == 'false'){
                        $("body").css("cursor", "default");
                        var failed = getMssg['connect_failed'];
                        $("#resDev").empty();
                        $("#resDev").html(failed);
                    } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click",".fragment",function(){
        var th = $(this);
        
        $("body").css("cursor", "wait");

        var id = $(this).attr('id');
        var actionName = '';
        var isRunningRefresh = 'false';
        if(intervalTaskRefresh > 0){
            isRunningRefresh = 'true';
        }
        
        switch (id) {
            case 'info':
                actionName = 'info';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeInfo);
                }
                break;
            case 'lan':
                actionName = 'lan'; 
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeLan);
                }
                break;
            case 'wan':
                actionName = 'wan';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeWan);
                }
                break;
            case 'vlan':
                actionName = 'vlan';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeVlan);
                }
                break;
            // case 'statistics':
            //     actionName = 'statistics';
            //     if(th.hasClass('hasChanged')){
            //         th.removeClass('hasChanged');
            //         th.attr('title', '');
            //        // clearInterval(intervalSetTypeStatistics);
            //     }
            //     break;
            case 'voip':
                actionName = 'voip';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeVoip);
                }
                break;
            case 'wireless':
                actionName = 'wireless';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeWifi);
                }
                break;
            case 'monitoring':
                actionName = 'monitoring';
                break;
            case 'update':
                actionName = 'update';
                break;
            case 'diagnostic':
                actionName = 'diagnostic';
                break;
            case 'voip':
                actionName = 'voip';
                break;
            case 'activities':
                actionName = 'activities';
                break;
            case 'tree':
                actionName = 'tree';
                break;
            case 'lte':
                actionName = 'lte';
                break;
        }
        
        if(actionName != '' && actionName!='statistics'){
            // $('body').oLoader('show');

            // $.ajax({
                // type: "POST",
                // url: $basepath + "secureFiles/actions/ajaxActions/checkDevStatus.php",
                // data: {
                //     'deviceID': devId,
                //     'fromApp':true
                // },
                // async: true,
                // success: function (result) {
                //
                //     if (result =='logged_out') {
                //         document.location.href = $basepath + 'login';
                //     } else {
                //         result = result.trim();
                //         devStatuss = result;
                //
                    devStatuss = 'true';

                getSettiongsByTab(th,actionName,devStatuss,isRunningRefresh);
            
                    // }
                // },
                // error: function(xhr, status, error) {
                //     document.location.href = $basepath + '500';
                // }
            // });
        } else {
            $("body").css("cursor", "default");
        }
    });

    $(document).on("click",".statistic_sub",function(){
        var th = $(this);
        $("body").css("cursor", "wait");
        var id = $(this).attr('id');
        var actionName = '';
        var isRunningRefresh = 'false';
        if(intervalTaskRefresh > 0){
            isRunningRefresh = 'true';
        }
        switch (id) {
            case 'statisticRouting':
                actionName = 'statisticRouting';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeStatisticRouting);
                }
                break;
            case 'statisticInterfaces':
                actionName = 'statisticInterfaces';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeStatisticInterfaces);
                }
                break;
            case 'statisticClients':
                actionName = 'statisticClients';
                if(th.hasClass('hasChanged')){
                    th.removeClass('hasChanged');
                    th.attr('title', '');
                    clearInterval(intervalSetTypeStatisticClients);
                }
                break;
        }
        if(actionName != ''){
            devStatuss = 'true';
            getSettiongsByTab(th,actionName,devStatuss,isRunningRefresh);
        } else {
            $("body").css("cursor", "default");
        }
    });


    function getSettiongsByTab(th,actionName,devStatuss,isRunningRefresh,page){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTabPageForDevice.php",
            data: {
                'deviceID': devId,
                'serialNumber':serialN,
                'actionName': actionName,
                'devStatus':devStatuss,
                'isRunningRefresh':isRunningRefresh,
                'havePermissions':havePerm,
                'macAddress':macAddress,
                'page':page,
                'fromApp':true
            },
            async: false,
            success: function (result) {

                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#graybox").hide();
                    $('body').oLoader('hide');

                    $(".tabLi").removeClass("activeTabLi");

                    var statPart=actionName.indexOf('statistic');
                    if(statPart==0){
                        $("#statistics").parent().addClass("activeTabLi");
                    }else{

                        th.parent().addClass("activeTabLi");
                    }

                    //$("#fragment-"+actionName).empty();
                    $(".eachFragment").empty();
                    $("#fragment-"+actionName).show();
                    $("#fragment-"+actionName).html(result);
                    $(".eachFragment").hide();
                    $("#fragment-"+actionName).show();
                    $("body").css("cursor", "default");
                    if (navigator.userAgent.indexOf("Firefox") < 60) {
                        $(".legendTracertDiagnostic").css("paddingTop", "20px");
                        $(".legendUploadDownloadDiagnostic").css("paddingTop", "20px");

                    }
                    $(".popover").each(function () {
                        var popover = $(this);
                        var ctrl = $(popover.context);
                        ctrl.popover('hide');
                    });
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }


    $(document).on("click",".eachStatisticPage", function (){
        var page = $(this).find("input[name ='page']").val();
        var actionName = 'statisticInterfaces';
        var isRunningRefresh = 'false';
        if(intervalTaskRefresh > 0){
            isRunningRefresh = 'true';
        }
        devStatuss = 'true';
        var devId = $("input[name='devID']").val();
        getSettiongsByTab($(".statistic_sub"),actionName,devStatuss,isRunningRefresh,page);
    });
    $(document).on("click",".eachStatisticClientsPage", function (){
        var page = $(this).find("input[name ='page']").val();
        var actionName = 'statisticClients';
        var isRunningRefresh = 'false';
        if(intervalTaskRefresh > 0){
            isRunningRefresh = 'true';
        }
        devStatuss = 'true';
        var devId = $("input[name='devID']").val();
        getSettiongsByTab($(".statistic_sub"),actionName,devStatuss,isRunningRefresh,page);
    });
    
// --------------------- infPageForDevice.php ---------------------------

    $(document).on("click", "#igmpApply", function (){

        var igmpValue = $("input[name='igmpValue']").val();
        var version = $(".selectIGMP option:selected").val();
        var th = $(this);
        if(igmpValue != version){
            if (th.attr("disabled") != "disabled") {
                th.attr("disabled", "disabled");
//                th.css("opacity", "0.5");
                $("body").css("cursor", "wait");

                if(version == 2 || version == 3){
                    if($('#refreshButton').css('display') == 'none') {
                        setIGMP(version, devId);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                setIGMP(version, devId);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }

                } else if(version == 0){
                    if($('#refreshButton').css('display') == 'none') {
                        setIGMPoff(version, devId);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                setIGMPoff(version, devId);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }
                }
            }
            $("#actionRes").addClass("infoMessage");
            $("#actionRes").removeClass("errorMessage");
        }else{
            var failed = getMssg["nothing_changed"];
            $("#actionRes").removeClass("infoMessage");
            $("#actionRes").addClass("errorMessage");
            $("#actionRes").empty();
            $("#actionRes").html(failed);
            th.removeAttr("disabled");
//            th.css("opacity", "1"); 
        }
    });

    function setIGMP(version, devId) {
	ajaxRequest.send({
            type:globalVar.HTTP.POST,
            name:globalVar.TASKS.SET_IGMP,
            chack:globalVar.TASKS.SET,
            data: {
                'version': version,
                'deviceID': devId,
                'fromApp':true,
            },
            response:function(respons) {
                var success = getMssg['action_succeed'];
                $("#actionRes").empty();
                $("#actionRes").html(success);
                setTimeout(function () {
                    getCorrentTaskIdByTab(devId,'info');
                    $("body").css("cursor", "default");
                }, 2000);
            },
            getStatus:function(status){
                $("#actionRes").empty();
                //task was done
            }
        });
        /*$.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'version': version,
                'deviceID': devId,
                'actionName': 'setIGMP',
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(success);

                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'info');
                        $("body").css("cursor", "default");
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionRes").empty();
                    }, 10000);

                } else if (result == 'false') {

                    $("body").css("cursor", "default");
                    var failed = getMssg['connect_failed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(failed);
                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);

                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });*/
    }

    function setIGMPoff(version, devId) {
        ajaxRequest.send({
            type:globalVar.HTTP.POST,
            name:globalVar.TASKS.IGMP_OFF,
            chack:globalVar.TASKS.SET,
            data: {
                'version': version,
                'deviceID': devId,
                'fromApp':true,
            },
            response:function(respons) {
                var success = getMssg['action_succeed'];
                $("#actionRes").empty();
                $("#actionRes").html(success);
                setTimeout(function () {
                    getCorrentTaskIdByTab(devId,'info');
                    $("body").css("cursor", "default");
                }, 2000);
            },
            getStatus:function(status){
                $("#actionRes").empty();
                //task was done
            }
        });
        /*$.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'version': version,
                'deviceID': devId,
                'actionName': 'setIGMPoff',
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    $("body").css("cursor", "default");
                    var success = getMssg['action_succeed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(success);

                    setTimeout(function () {
                        updateActivities(devId);
                        $("body").css("cursor", "default");
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionRes").empty();
                    }, 10000);

                } else if (result == 'false') {
                    $("body").css("cursor", "default");
                    var failed = getMssg['connect_failed'];
                    $("#actionRes").empty();
                    $("#actionRes").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);

                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });*/
    }

    $(document).on("change", "#igmpSelect", function (){
        $("#actionRes").empty();
    });

    $(document).on("click", "#myonoffswitch", function (){

        var dumpVal;
        if( $(this).is(":checked")){
            dumpVal = 1;
        } else {
            dumpVal = 0;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeDumpVal.php",
            data: {
                'devId':devId,
                'dumpVal': dumpVal,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else  if (result == true){

                    $("#dumpRes").empty();
                    if(dumpVal == 0){
                        var res = getMssg['turn_off'];
                        $("#dumpRes").html(res);
                    } else {
                        var res = getMssg['turn_on'];
                        $("#dumpRes").html(res);
                    }

                    setTimeout(function () {
                        $("#dumpRes").empty();
                        if(dumpVal == 0){
                            $(this).removeAttr("checked");
                        } else {
                            $(this).attr("checked","checked");
                        }
    //                      $("input[name='dumpRealVal']").val(dumpVal);
                    }, 2000);

                } else  if (result == false){
                    var res = getMssg['connect_failed'];
                    $("#dumpRes").empty();
                    $("#dumpRes").html(res);
                    setTimeout(function () {
                        $("#dumpRes").empty();
                    }, 2000);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#showLogFiles", function (){

        var mac = $(this).parent().find("input[name='serial']").val();

        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
            data: {
                'functionName': 'showLogFiles',
                'dirName': 'logUpload',
                'macAddress': mac,
                'devId' : devId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                $('.devices_bl').find("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#showCustomLogFiles", function (){

        var mac = $(this).parent().find("input[name='serial']").val();

        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
            data: {
                'functionName': 'showCustomLogFiles',
                'dirName': 'logUpload',
                'macAddress': mac,
                'devId' : devId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                $('.devices_bl').find("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#showDumpFiles", function (){
        var mac = $(this).parent().find("input[name='serial']").val();

        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
            data: {
                'functionName': 'showDumpFiles',
                'dirName': 'dump',
                'macAddress': mac,
                'devId' : devId,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                $('.devices_bl').find("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#showDownloadedConfigs", function (){
        var mac = $(this).parent().find("input[name='serial']").val();

        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/getDownloadedConfigsOfTheDevice.php',
            data: {
                'macAddress': mac,
                'showConfig': true,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                $("#fileList").empty();
                $("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
    $(document).on("click", ".removeConfig", function (){
        var coinfigId = $(this).closest('tr').next('tr').find("input[name='confId']").val();
        var coinfigName = $(this).closest('tr').next('tr').find("input[name='name']").val();
        
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_remove_config'];
        
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                $.ajax({
                    type: "POST",
                    url: $basepath + 'secureFiles/actions/ajaxActions/getDownloadedConfigsOfTheDevice.php',
                    data: {
                        'configId': coinfigId,
                        'coinfigName': coinfigName,
                        'showConfig': false,
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        setTimeout(function () {
                            updateAfterTheAction();
                        }, 1000);
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
       });
    });

    $(document).on("click", ".rmConfigfile", function () {
        var th = $(this);
        var configSelectBox = $(".filesName");
        var configId = $(".filesName option:selected").val();

        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_fw'];
//        var deviceID = th.parent().parent().find("input[name='devID']").val();
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                $.ajax({
                    type: "POST",
                    url:  $basepath + "secureFiles/actions/ajaxActions/getConfigs.php",
                    data: {
                        'deviceID': devId,
                        'actionName': "removeConfig",
                        'configId': configId,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            $(".filesName option:selected").remove();
                            $(".rmConfigfile").css("visibility", "hidden");
                            var msg = getMssg['no_fw'];
                            if (configSelectBox.find("option").length <= 1) {
                                $("#contentUpdate").empty();
                                $("#contentUpdate").html('<span style ="margin-left: 20px;">'+ msg +'</span>');
                            }

                        } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }else{
                th.removeAttr("disabled");
//                th.css("opacity","1");
//                th.css("cursor","pointer");
            }
        });
    });
  

//----------- clear results of showLogFiles and showDumpFiles buttons-----------

    $(document).click(function(){
        if(!$('#showConfigTb').hasClass('showConfig-table')){
            // $("#fileList").empty();
        }
    });

//-------------------------end--------------------------------------------------

    $(document).on("click", ".showFileCont", function (){ 
        var str = $(this).text();

        if($('#logfile').hasClass('logFiles')){
            showFilesContent('logUpload',str);
        } else if ($('#customLogfile').hasClass('customLogFiles')){
            showFilesContent('logUpload',str);
        } else if($('#dumpfile').hasClass('dumpFiles')){
            showFilesContent('dump',str);
        }
    });

    function showFilesContent(folder,str){
        $.ajax({
            type: "POST",
            url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
            data: {
                'functionName':'GetFileContent',
                'dirName': folder,
                'fileName': str,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                var w = window.open();
                var html = $(result).html();
                $(w.document.body).html(html);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        }); 	
    }
    
//----------------- pagination of the showConfig file list--------------------

    $(document).on("click", ".eachConfig", function (){
        var page = $(this).find("input[name ='page']").val();
        var mac =  $("input[name='deviceMac']").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDownloadedConfigsOfTheDevice.php",
            data:{
                "page":page,
                'showConfig': true,
                "macAddress":mac,
                "fromApp":true
            },
            async: false,
            success:function(result){
                $("#fileList").empty();
                $("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

//------------------------end pagination----------------------------------------

    $(document).on("click", "#updateConfig", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            var devID = $('.devices_bl').find("input[name='devID']").val();
            var name = th.parent().find("input[name='name']").val();
            var size = th.parent().find("input[name='size']").val();
            var fileId = th.parent().find("input[name='confId']").val();
            $("#showConfigTb").css("cursor", "wait");
            $("body").css("cursor","wait");

            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
            th.parent().find("#addInDb").attr("disabled", "disabled");
//            th.parent().find("#addInDb").attr("opacity", "0.5");
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devID,
                    'fileName':name,
                    'fileSize':size,
                    'fileID': fileId,
                    // 'actionName': 'configBackup',
                    'actionName': 'config',
                    'token': token_cookie,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'true') {
                        var success =  getMssg['action_succeed'];
                        th.parent().find("#resDev").css("color", "#14a0bc");
                        th.parent().find("#resDev").empty();
                        th.parent().find("#resDev").html(success);
                        updateActivities(devId);
                        setTimeout(function () {
//                            location.reload(true);
                            th.closest('tr').removeClass("in");
                        }, 10000);
                        setTimeout(function () {
                            intervalRefresh = setInterval(function(){
                                getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                            }, 2000);
                        }, 3000); 
                    } else if (result == 'false') {
                        $(".addedTR").css("cursor", "default");
                        var failed = getMssg['action_failed'];
                        th.parent().find("#resDev").empty();
                        th.parent().find("#resDev").html(failed);
                        th.parent().find("#resDev").css("color", "red");
                        $("body").css("cursor","default");

                        setTimeout(function () {
                            $("#showConfigTb").css("cursor", "default");;
                            th.parent().find("#resDev").empty();
                        }, 10000);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", "#addInDb", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {

            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
            th.parent().find("#updateConfig").attr("disabled", "disabled");
//            th.parent().find("#updateConfig").attr("opacity", "0.5");
            var devID = $('.devices_bl').find("input[name='devID']").val();
            var name = th.parent().find("input[name='name']").val();
            var size = th.parent().find("input[name='size']").val();
            $("#showConfigTb").css("cursor", "wait");
            $("body").css("cursor","wait");
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/addBackupInDb.php",
                data: {
                    'deviceID': devID,
                    'fileName':name,
                    'fileSize':size,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'true') {
                        var success =  getMssg['action_succeed'];
                        th.parent().find("#resDev").css("color", "#14a0bc");
                        th.parent().find("#resDev").empty();
                        //th.parent().find("#resDev").html(success);
                        setTimeout(function () {
                            location.reload(true);
                        }, 10000);
                    } else if (result == 'false') {
                        $(".addedTR").css("cursor", "default");
                        var failed = getMssg['action_failed'];
                        th.parent().find("#resDev").empty();
                        th.parent().find("#resDev").html(failed);
                        th.parent().find("#resDev").css("color", "red");

                        $("body").css("cursor","default");

                        setTimeout(function () {
                            $("#showConfigTb").css("cursor", "default");;
                            th.parent().find("#resDev").empty();
                        }, 10000);
                    } else if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    
//------------change color of the active fa-sun-o in results of the showConfigs table-------------------
    
    $(document).on("click", ".sun1", function () {
        $(this).toggleClass( "blueSun");
    });
    
//----------------------------------------------------------------------------------
//    
//----------------------------end infPageForDevice.php ------------------------------------------------------    
    

//------------------------------ devActivity.php------------------------------------

    $(document).on("click", ".setTasks", function () {
        var trid = $(this).closest('tr').next('tr').attr('id');
        if($('#'+trid).is(':visible')){
            $('#'+trid).hide();
        } else {
            $("body").css("cursor", "wait");
            var actType = $(this).parent().find("input[name='activityTypeName']").val();
//            if (actType.trim().indexOf("set") == 0 && actType.trim().length == 3){
            if (actType.trim() == "set" || actType.trim() == "addConnection" || actType.trim() == "addVlanPort" || isCreateVlan(actType) || isDeleteVlanOrPort(actType)){
                $('#'+trid).css('display','table-row');
                var activityID = $(this).parent().find("input[name='activityID']").val();
                
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/getAllParamsValuesByActivityID.php",
                    data: {
                        'activityID': activityID,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if(result=='logged_out'){
                            document.location.href = $basepath + 'login';
                        } else {$("body").css("cursor", "default");
                            $('#'+trid).find(".activeValue").html(result);
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            } else {
                $("body").css("cursor", "default");
            }
        }
    });
    
    setInterval(function(){
        $(".devActTr").each(function(){
            var activId=$(this).find("input[name='activityID']").val();

            var th=$(this);
            var i=0;

            getStatusOfTheActivity(i, activId, th);
                    // $.ajax({
                    //     type: "POST",
                    //     url: $basepath + "secureFiles/actions/ajaxActions/getLastStatusOfTheActivity.php",
                    //     data: {
                    //         'activityID': activId,
                    //         'fromApp': true
                    //     },
                    //     async: true,
                    //     success: function (result) {
                    //         if (result == 'logged_out') {
                    //             document.location.href = $basepath + 'login';
                    //         } else {
                    //             $("body").css("cursor", "default");
                    //             th.find(".devActTd").empty();
                    //             th.find(".devActTd").html(result);
                    //         }
                    //         errorAjax = false;
                    //     },
                    //     error: function (xhr, status, error) {
                    //         if (i==3) {
                    //             errorAjax = true;
                    //             document.location.href = $basepath + '500';
                    //             // location.reload(true);
                    //         }
                    //     }
                    // });


        });
    },2000);
    
 function getStatusOfTheActivity(i, activId, th) {
     $.ajax({
         type: "POST",
         url: $basepath + "secureFiles/actions/ajaxActions/getLastStatusOfTheActivity.php",
         data: {
             'activityID': activId,
             'fromApp': true
         },
         async: true,
         success: function (result) {
             if (result == 'logged_out') {
                 document.location.href = $basepath + 'login';
             } else {
                 $("body").css("cursor", "default");
                 th.find(".devActTd").empty();
                 th.find(".devActTd").html(result);
             }
             // errorAjax = false;
         },
         error: function (xhr, status, error) {
             if (i==3) {
                 $(this).attr("disabled", "disabled");
                 $(this).css("opacity", "0.5");
                 $(this).css("cursor", "default");
                 var msg = getMssg['update_page'];
                 swal({
                     title: '',
                     text: msg,
                     showCancelButton: false,
                     closeOnConfirm: true,
                     confirmButtonText: '',
                     confirmButtonColor: "#008DA9"
                 }, function(isConfirm) {
                     if(isConfirm){

                     }else{
                         $(this).removeAttr("disabled");
                         $(this).css("opacity","1");
                         $(this).css("cursor","pointer");
                     }
                 });

                 // document.location.href = $basepath + '500';
             } else {
                 i++;
                 getStatusOfTheActivity(i, activId, th);
             }
         }
     });

 }
//-------------- pagination of the Activity ------------------------------------
    
    $(document).on("click",".eachDevActivityPage",function(){
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllDevActivitiesByPage.php",
            data: {
                'deviceID':devId,
                'page': page,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#forDActiv").empty();
                    $("#forDActiv").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
// -----------------------end pagination----------------------------------------
  
//------------------- end devActivity.php --------------------------------------

//------------------- lanPageForDevice.php -------------------------------------

    $(document).on("change",".modeType",function() {
        var modeType = $(".modeType option:selected").val();
        if (modeType == '1') {
            $("#forEnableMode").show();
            $("#forExternalDHCP").hide();
            $(".lanpage1").show();
            $("#actionResult").empty();
            $('.lanform').find("input[name='startIP']").val($("#startIP").attr('value'));
            $('.lanform').find("input[name='endIP']").val($("#endIP").attr('value'));
            $('.lanform').find("input[name='leaseTime']").val($("#leaseTime").attr('value'));
        } else if (modeType == '0') {
            $("#forEnableMode").hide();
            $("#forExternalDHCP").hide();
            $(".lanpage1").hide();
            $("#actionResult").empty();
            $("div.error_messageLan").remove();
            $(".error_messageLan").removeClass("error");
            $('.lanform').find("input[name='startIP']").val('');
            $('.lanform').find("input[name='endIP']").val('');
            $('.lanform').find("input[name='leaseTime']").val('');
        } else if (modeType == '2') {
            $("#forEnableMode").hide();
            $(".lanpage1").hide();
            $("#forExternalDHCP").show();
            $("#actionResult").empty();
        }
    });
    
    $(document).on("click", "#cancelLan", function(event){
        //    before reset

        event.preventDefault();
        // stops the form from resetting after this function

        $("div.error_messageLan").remove();
        $(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();
        // resets the form before continuing the function
        
        //        after reset

        var modVal = $(".modeType option:selected").val();
        if(modVal == 1){
            $("#forEnableMode").show();
            $(".lanpage1").show();
        }else{
            $("#forEnableMode").hide();
            $(".lanpage1").hide();
        }
    });

    $(document).on("click", "#cancelLanV6", function(event){
        event.preventDefault();
        $("div.error_messageLan").remove();
        $(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();
        var modeStatic = $(".staticModeType option:selected").val();
        var modeDynamic = $(".dynamicModeType option:selected").val();

        if(modeStatic == 1) {
            $("input[name ='ipv6Address']").attr("disabled", "disabled");
            $("input[name ='ipv6Address']").css("opacity", "0.5");
            $("input[name ='prefixIPv6']").attr("disabled", "disabled");
            $("input[name ='prefixIPv6']").css("opacity", "0.5");
            $("input[name ='leasTimeIPv6']").attr("disabled", "disabled");
            $("input[name ='leasTimeIPv6']").css("opacity", "0.5");
        } else if(modeStatic == 0) {
            $("input[name ='ipv6Address']").removeAttr("disabled");
            $("input[name ='ipv6Address']").css("opacity", "1");
            $("input[name ='prefixIPv6']").removeAttr("disabled");
            $("input[name ='prefixIPv6']").css("opacity", "1");
            $("input[name ='leasTimeIPv6']").removeAttr("disabled");
            $("input[name ='leasTimeIPv6']").css("opacity", "1");
        }

        if(modeDynamic == 'Disabled') {
            $(".startEndIPv6").hide();
            $(".leasTime").hide();
        } else if(modeDynamic == 'Stateful') {
            $(".startEndIPv6").show();
            $(".leasTime").show();
        } else if(modeDynamic == 'Stateless') {
            $(".startEndIPv6").hide();
            $(".leasTime").show();
        }
    });
    
    function toggleNotification(obj,numIn,connType) {
        
        $('body').css("cursor", "wait");
        
        var notification;
        if (obj.is(":checked")) {
            notification = 'on';
        } else {
            notification = 'off';
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': "notification",
                'notificationType': notification,
                'numIn': numIn,
                'conType': connType,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#actionRes").empty();
                    $("#actionResNot").html(success);

                    setTimeout(function () {
                        updateActivities(devId);
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                        $("#actionResNot").empty();
                    }, 3000);

//                    setTimeout(function () {
//                        updateAfterTheAction();
//                    }, 10000);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    $(document).on("click", "#myonoffswitchLan", function () {
        var th = $(this);
        toggleNotification(th,"","LAN");
    });

    $(document).on("click", "#myonoffswitchWan", function () {
        var th = $(this);
        var numIn = $("input[name='numindex']").val();
        toggleNotification(th,numIn,"IPoE");
    });

    $(document).on("click", "#myonoffswitchWanDyn", function () {
        var th = $(this);
        var numIn = $("input[name='numindex']").val();
        toggleNotification(th,numIn,"IPoE");
    });

    $(document).on("click", "#myonoffswitchPPP", function () {
        var th = $(this);
        var numIn = $("input[name='numindex']").val();
        toggleNotification(th,numIn,"PPPoE");
    });

    $(document).on("click", "#myonoffswitchWireless", function () {
        var th = $(this);
        var numIn = $("input[name='numIndex']").val();
        toggleNotification(th,numIn,"WLAN");
    });

    function isNumber(n) {
        return !isNaN(parseFloat(n)) && isFinite(n);
    }
    
    $(document).on("keyup", "#leaseTime", function (e) {
        var value = $( this ).val().trim();
        var msgleaseTimeIsDivided60 = getMssg['recommend_message_lease_time_divided_60'];
        if(isNumber(value) && value % 60 == 0 && value > 59){
            $('#recomm-message-lease-time').empty();
        }else if (isNumber(value) && value % 60 != 0 && value > 59){
             $('#recomm-message-lease-time').html(msgleaseTimeIsDivided60);
        }else{
            $('#recomm-message-lease-time').empty();
        }
    }).keyup();

    $(document).on("click", ".eachLogFile", function (){
        var page = $(this).find("input[name ='page']").val();
        var mac = $("input[name='serial']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/functions.php",
            data:{
                "page":page,
                'functionName': 'showLogFiles',
                'dirName': 'logUpload',
                'macAddress': mac,
                'fromApp': true
            },
            async: false,
            success:function(result){
            $("#fileList").empty();
            $("#fileList").html(result);
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        });

    $(document).on("click", ".eachCustomLogFile", function (){
        var page = $(this).find("input[name ='page']").val();
        var mac = $("input[name='serial']").val();
        $.ajax({
            type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/functions.php",
                data:{
                    "page":page,
                    'functionName': 'showCustomLogFiles',
                    'dirName': 'logUpload',
                    'macAddress': mac,
                    'fromApp': true
                },
                async: false,
                success:function(result){
                $("#fileList").empty();
                $("#fileList").html(result);
                },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
                }
            });
        });

    $(document).on("click", ".eachDumpFile", function (){
        var page = $(this).find("input[name ='page']").val();
        var mac = $("input[name='serial']").val();
        $.ajax({
            type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/functions.php",
                data:{
                    "page":page,
                    'functionName': 'showDumpFiles',
                    'dirName': 'dump',
                    'macAddress': mac,
                    'fromApp': true
                },
                async: false,
                success:function(result){
                    $("#fileList").empty();
                    $("#fileList").html(result);
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        });


    $(document).on("click", ".lanParam", function (){
        var lanIpType = $(this).find(".lanIpType").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getLanTabPageForDevice.php",
            data: {
                'serialNumber':serialN,
                'deviceID':devId,
                'lanIpType': lanIpType,
                'devStatus':devStatuss,
                'havPermissions':havePerm,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#lanList").empty();
                    $("#lanList").html(result);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    $(document).on("click", "#addLanV6", function (){
        var th = $(this);
        th.attr("disabled", "disabled");
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgStartIp = getMssg['error_message_startip'];
        var msgStartSubnetIps = getMssg['error_message_start_ip_based_on_netmask'];
        var msgEndSubnetIps = getMssg['error_message_end_ip_based_on_netmask'];
        var msgEndIp = getMssg['error_message_endip'];
        var msgLeaseTime = getMssg['error_message_lease_time'];
        var msgNumber = getMssg['error_message_number'];
        var msgNetAddr = getMssg["error_message_ip_reange"];
        var prefixOutOfReang = getMssg["prefix_msg"];
        var msgReservedIPv6 = getMssg["error_message_net_address"];

        $(".lanformIPv6").validate({
            rules: {
                ipv6Address: {
                    required: true,
                    invalidIPv6: true,
                    validateDHCPIPv6: {
                        from : "#startIPv6",
                        to : "#endIPv6",
                        real : "#ipv6Address"
                    },
                    reservedIPv6: {
                        ip : "#ipv6Address",
                        netmask: "#prefixIPv6"
                    }
                },
                prefixIPv6: {
                    required: true,
                    number: true,
                    invalidPrefix: true,
                    min: 64
                },
                startIPv6: {
                    required: true,
                    invalidIPv6: true,
                    validateRangeIPv6: {
                        net : "#ipv6Address",
                        prexif: "#prefixIPv6",
                        ip: "#startIPv6"
                    },
                    validateStartEndIPv6: {
                        from : "#startIPv6",
                        to : "#endIPv6"
                    }
                },
                endIPv6: {
                    required: true,
                    invalidIPv6: true,
                    validateRangeIPv6: {
                        net : "#ipv6Address",
                        prexif: "#prefixIPv6",
                        ip: "#endIPv6"
                    },
                    validateStartEndIPv6: {
                        from : "#startIPv6",
                        to : "#endIPv6"
                    }
                },
                leasTimeIPv6: {
                    required: true,
                    number: true,
                    validateLeaseTime : true,
                    digits: true
                }
            },

            messages: {
                ipv6Address: {
                    required: msgRequired,
                    invalidIPv6: msgIp,
                    validateDHCPIPv6: msgNetAddr,
                    reservedIPv6: msgReservedIPv6
                },
                prefixIPv6: {
                    required: msgRequired,
                    invalidPrefix: prefixOutOfReang,
                    number: msgNumber,
                    min: prefixOutOfReang
                },
                startIPv6: {
                    required: msgRequired,
                    invalidIPv6: msgIp,
                    validateRangeIPv6: msgStartSubnetIps,
                    validateStartEndIPv6: msgStartIp
                },
                endIPv6: {
                    required: msgRequired,
                    invalidIPv6: msgIp,
                    validateRangeIPv6: msgEndSubnetIps,
                    validateStartEndIPv6: msgEndIp
                },
                leasTimeIPv6: {
                    required: msgRequired,
                    number: msgNumber,
                    validateLeaseTime : msgLeaseTime,
                    digits: msgNumber
                }
            },

            errorElement: "div",
            errorClass: 'error_messageLan',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error);
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($(".lanformIPv6").valid())) {
            th.removeAttr("disabled");
            return false;
        }

        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var isChanged = false;
        var changeStatelessMode = false;
        var changeStatefulMode = false;
        var modeStatic = $(".staticModeType option:selected").val();
        var modeDynamic = $(".dynamicModeType option:selected").val();
        var ipv6 = $("input[name ='ipv6Address']").val();
        var prefix = $("input[name ='prefixIPv6']").val();
        var endIPv6 = $("input[name ='endIPv6']").val();
        var startIPv6 = $("input[name ='startIPv6']").val();
        var leaseTime = $("input[name ='leasTimeIPv6']").val();
        var ipv6Real = $("input[nprefixame = 'ipv6AddressValue']").val();
        var prefixReal = $("input[name = 'prefixIPv6Value']").val();
        var endIPv6Real = $("input[name = 'endIPv6Value']").val();
        var startIPv6Real = $("input[name = 'startIPv6Value']").val();
        var leaseTimeReal = $("input[name = 'leasTimeIPv6Value']").val();
        var modeStaticReal = $("input[name = 'ipv6StaticModeValue']").val();
        var modeDynamicReal = $("input[name = 'ipv6DynamicModeValue']").val();

        if (modeStatic == 0 || modeStatic == 1){
            if(ipv6.trim() != ipv6Real || prefix.trim() != prefixReal){
                var ipv6Value = ipv6+ "/" + prefix;
                var realIpv6Name = $("input[name = 'ipv6AddressName']").val();
                var realIpv6Type = $("input[name = 'ipv6AddressType']").val();
                paramNames.push(realIpv6Name);
                paramValues.push(ipv6Value);
                paramTypes.push(realIpv6Type);
                isChanged = true;
            }
        }

        if (modeStatic != modeStaticReal){
            var realIpv6StaticModeName = $("input[name = 'ipv6StaticModeName']").val();
            var realIpv6StaticModeType = $("input[name = 'ipv6StaticModeType']").val();
            paramNames.push(realIpv6StaticModeName);
            paramValues.push(modeStatic);
            paramTypes.push(realIpv6StaticModeType);
            isChanged = true;
        }

        if(modeStatic==1) {
            if (modeDynamic != modeDynamicReal) {
                var realIpv6DynamicName = $("input[name = 'ipv6DynamicModeName']").val();
                var realIpv6DynamicType = $("input[name = 'ipv6DynamicModeType']").val();
                paramNames.push(realIpv6DynamicName);
                paramValues.push(modeDynamic);
                paramTypes.push(realIpv6DynamicType);

                var realIpv6DHCPName = $("input[name = 'ipv6DHCPName']").val();
                var realIpv6DHCPType = $("input[name = 'ipv6DHCPType']").val();
                var realIpv6DHCPValue = $("input[name = 'ipv6DHCPValue']").val();
                paramNames.push(realIpv6DHCPName);
                paramValues.push(realIpv6DHCPValue);
                paramTypes.push(realIpv6DHCPType);
                isChanged = true;

                if (modeDynamic == "Stateless") {
                    var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                    var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                    paramNames.push(realLeasTimeIPv6Name);
                    paramValues.push(leaseTime/60);
                    paramTypes.push(realLeasTimeIPv6Type);
                    changeStatelessMode = true;
                    isChanged = true;
                }
                if (modeDynamic == "Stateful") {
                    if (modeDynamicReal != "Stateless") {
                        var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                        var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                        paramNames.push(realLeasTimeIPv6Name);
                        paramValues.push(leaseTime/60);
                        paramTypes.push(realLeasTimeIPv6Type);
                    }
                    var realStartIPv6Name = $("input[name = 'startIPv6Name']").val();
                    var realStartIPv6Type = $("input[name = 'startIPv6Type']").val();
                    paramNames.push(realStartIPv6Name);
                    paramValues.push(startIPv6);
                    paramTypes.push(realStartIPv6Type);
                    var realEndIPv6Name = $("input[name = 'endIPv6Name']").val();
                    var realEndIPv6Type = $("input[name = 'endIPv6Type']").val();
                    paramNames.push(realEndIPv6Name);
                    paramValues.push(endIPv6);
                    paramTypes.push(realEndIPv6Type);
                    changeStatefulMode = true;
                    isChanged = true;
                }
            }
        }

        if (modeDynamic == "Stateless" && modeStatic == 1 && changeStatelessMode==false){
            if(leaseTime != leaseTimeReal){
                var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                paramNames.push(realLeasTimeIPv6Name);
                paramValues.push(leaseTime/60);
                paramTypes.push(realLeasTimeIPv6Type);
                isChanged = true;
            }
        }

        if (modeDynamic == "Stateful" && modeStatic == 1 && changeStatefulMode==false){
            if(leaseTime != leaseTimeReal){
                var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                paramNames.push(realLeasTimeIPv6Name);
                paramValues.push(leaseTime/60);
                paramTypes.push(realLeasTimeIPv6Type);
                isChanged = true;
            }
            if (startIPv6 != startIPv6Real){
                var realStartIPv6Name = $("input[name = 'startIPv6Name']").val();
                var realStartIPv6Type = $("input[name = 'startIPv6Type']").val();
                paramNames.push(realStartIPv6Name);
                paramValues.push(startIPv6);
                paramTypes.push(realStartIPv6Type);
                isChanged = true;
            }
            if (endIPv6 != endIPv6Real){
                var realEndIPv6Name = $("input[name = 'endIPv6Name']").val();
                var realEndIPv6Type = $("input[name = 'endIPv6Type']").val();
                paramNames.push(realEndIPv6Name);
                paramValues.push(endIPv6);
                paramTypes.push(realEndIPv6Type);
                isChanged = true;
            }

        }

        if (modeDynamic != modeDynamicReal && modeStatic==0){
            var realIpv6DynamicName = $("input[name = 'ipv6DynamicModeName']").val();
            var realIpv6DynamicType = $("input[name = 'ipv6DynamicModeType']").val();
            paramNames.push(realIpv6DynamicName);
            paramValues.push(modeDynamic);
            paramTypes.push(realIpv6DynamicType);

            var realIpv6DHCPName = $("input[name = 'ipv6DHCPName']").val();
            var realIpv6DHCPType = $("input[name = 'ipv6DHCPType']").val();
            var realIpv6DHCPValue = $("input[name = 'ipv6DHCPValue']").val();
            paramNames.push(realIpv6DHCPName);
            paramValues.push(realIpv6DHCPValue);
            paramTypes.push(realIpv6DHCPType);
            if (modeDynamic == "Stateless" && modeStatic == 0){
                var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                paramNames.push(realLeasTimeIPv6Name);
                paramValues.push(leaseTime/60);
                paramTypes.push(realLeasTimeIPv6Type);
                changeStatelessMode = true;
            }
            if (modeDynamic == "Stateful" && modeStatic == 0){
                if(modeDynamicReal != "Stateless" || leaseTime != leaseTimeReal){
                    var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                    var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                    paramNames.push(realLeasTimeIPv6Name);
                    paramValues.push(leaseTime/60);
                    paramTypes.push(realLeasTimeIPv6Type);
                }

                var realStartIPv6Name = $("input[name = 'startIPv6Name']").val();
                var realStartIPv6Type = $("input[name = 'startIPv6Type']").val();
                paramNames.push(realStartIPv6Name);
                paramValues.push(startIPv6);
                paramTypes.push(realStartIPv6Type);
                var realEndIPv6Name = $("input[name = 'endIPv6Name']").val();
                var realEndIPv6Type = $("input[name = 'endIPv6Type']").val();
                paramNames.push(realEndIPv6Name);
                paramValues.push(endIPv6);
                paramTypes.push(realEndIPv6Type);
                changeStatefulMode = true;
            }
            isChanged = true;
        }

        if (modeDynamic == "Stateless" && modeStatic == 0 && changeStatelessMode==false){
            if(leaseTime != leaseTimeReal){
                var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                paramNames.push(realLeasTimeIPv6Name);
                paramValues.push(leaseTime/60);
                paramTypes.push(realLeasTimeIPv6Type);
                isChanged = true;
            }
        }

        if (modeDynamic == "Stateful" && modeStatic == 0 && changeStatefulMode==false){
            if(leaseTime != leaseTimeReal){
                var realLeasTimeIPv6Name = $("input[name = 'leasTimeIPv6Name']").val();
                var realLeasTimeIPv6Type = $("input[name = 'leasTimeIPv6Type']").val();
                paramNames.push(realLeasTimeIPv6Name);
                paramValues.push(leaseTime/60);
                paramTypes.push(realLeasTimeIPv6Type);
                isChanged = true;
            }
            if (startIPv6 != startIPv6Real){
                var realStartIPv6Name = $("input[name = 'startIPv6Name']").val();
                var realStartIPv6Type = $("input[name = 'startIPv6Type']").val();
                paramNames.push(realStartIPv6Name);
                paramValues.push(startIPv6);
                paramTypes.push(realStartIPv6Type);
                isChanged = true;
            }
            if (endIPv6 != endIPv6Real){
                var realEndIPv6Name = $("input[name = 'endIPv6Name']").val();
                var realEndIPv6Type = $("input[name = 'endIPv6Type']").val();
                paramNames.push(realEndIPv6Name);
                paramValues.push(endIPv6);
                paramTypes.push(realEndIPv6Type);
                isChanged = true;
            }
        }

        var actionName = "setLanIPv6";

        if (paramNames.length != 0 && isChanged) {
            if($('#refreshButton').css('display') == 'none') {
                lanApply(devId, serialN, paramNames, paramValues, paramTypes, actionName);
            } else {
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function (isConfirm) {
                    if (isConfirm) {
                        lanApply(devId, serialN, paramNames, paramValues, paramTypes, actionName);
                    } else {
                        th.removeAttr("disabled");
                    }
                });
            }
        } else if (!isChanged) {
            $('body').css("cursor", "default");
            var failed = th.parent().find("input[name='nothingChange']").val();
            $("#actionResult").removeClass("infoMessage");
            $("#actionResult").addClass("errorMessage");
            $("#actionResult").empty();
            $("#actionResult").html(failed);
            th.removeAttr("disabled");
        }else {
            $('body').css("cursor", "default");
            th.removeAttr("disabled");
        }
        return false;
    });



    $(document).on("click", "#addLan", function (e) {
        e.preventDefault();
        var msg = getMssg['start_ip_outside'];
        var th = $(this);
        
        th.attr("disabled", "disabled");
//        th.css("opacity", "0.5");
        
        // $.ajax({
        //     type: "POST",
        //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        //     data: {
        //         'deviceID': devId,
        //         'actionName': "connection",
        //         'fromApp': true
        //     },
        //     async: true,
        //     success: function (result) {
        //         if (result == 'true') {
                    var msgRequired = getMssg['error_message_required'];
                    var msgIp = getMssg['error_message_ip'];
                    var msgNetmask = getMssg['error_message_netmask'];
                    var msgStartIp = getMssg['error_message_startip'];
                    var msgStartSubnetIps = getMssg['error_message_start_ip_based_on_netmask'];
                    var msgEndSubnetIps = getMssg['error_message_end_ip_based_on_netmask'];
                    var msgEndIp = getMssg['error_message_endip'];
                    var msgLeaseTime = getMssg['error_message_lease_time'];
                    var msgleaseTimeIsDivided60 = getMssg['recommend_message_lease_time_divided_60'];
                    var msgNumber = getMssg['error_message_number'];
                    var msgNetAddress =getMssg['error_message_net_address'];
                    var msgNetAddr = getMssg["error_message_ip_reange"];

                    $(".lanform").validate({
                        rules: {
                            ipAddress: {
                                required: true,
                                validateIpAddress : true,
                                validateNetworkAddress: {
                                    ip : "#ipAddress",
                                    netmask: "#netmask"
                                },
                                validateNetAddress: {
                                    ip: "#ipAddress",
                                    from : "#startIP",
                                    to : "#endIP"
                                }
                            },
                            netmask: {
                                required: true,
                                validateIpAddress : true,
                                validateNetMask : true
                            },
                            startIP: {
                                required: true,
                                validateIpAddress : true,
                                validateNetworkAddress: {
                                    ip : "#startIP",
                                    netmask: "#netmask"
                                },
                                    validateStartEndIP: {
                                        from : "#startIP",
                                        to : "#endIP"
                                    },
                                    validateStartEndIpBasedOnNetMask: {
                                        from : "#startIP",
                                        to : "#ipAddress",
                                        netmask: "#netmask"
                                    }
                            },
                            endIP: {
                                required: true,
                                validateIpAddress : true,
                                validateNetworkAddress: {
                                    ip : "#endIP",
                                    netmask: "#netmask"
                                },
                                    validateStartEndIP: {
                                        from : "#startIP",
                                        to : "#endIP"
                                    },
                                    validateStartEndIpBasedOnNetMask: {
                                        from : "#endIP",
                                        to : "#ipAddress",
                                        netmask: "#netmask"
                                    }
                            },
                            leaseTime: {
                                required: true,
                                number: true,
                                validateLeaseTime : true,
                                digits: true,
//				leaseTimeIsDivided60: false
                            },
                            
                            externalDHCP: {
                                required: true,
                                validateIpAddress: true,
                            }
                        },
                        
                        messages: {
                            ipAddress: {
                                required: msgRequired,
                                validateIpAddress: msgIp,
                                validateNetworkAddress: msgNetAddress,
                                validateNetAddress: msgNetAddr
                            },
                            netmask: {
                                required: msgRequired,
                                validateIpAddress: msgIp,
                                validateNetMask: msgNetmask
                            },
                            startIP: {
                                required: msgRequired,
                                validateIpAddress: msgIp,
                                validateNetworkAddress: msgNetAddress,
                                validateStartEndIP: msgStartIp,
                                validateStartEndIpBasedOnNetMask: msgStartSubnetIps
                            },
                            endIP: {
                                required: msgRequired,
                                validateIpAddress: msgIp,
                                validateNetworkAddress: msgNetAddress,
                                validateStartEndIP: msgEndIp,
                                validateStartEndIpBasedOnNetMask: msgEndSubnetIps
                            },
                            leaseTime: {
                                required: msgRequired,
                                number: msgNumber,
                                validateLeaseTime : msgLeaseTime,
                                digits: msgNumber,
//				leaseTimeIsDivided60: ''
                            },
                            externalDHCP: {
                                required: msgRequired,
                                validateIpAddress: msgIp
                            }
                        },
                        
//                        debug:true,
                        errorElement: "div",
                        errorClass: 'error_messageLan',
                        errorPlacement: function(error, element) {
                            var placement = $(element).data('error');
                            if (placement) {
                                $(placement).append(error);
                            } else {
                                error.insertAfter(element);
                            }
                        },
//                        success: function(div) {
//                            var parentId = $(div).parent().attr("id");
//                            if(parentId == "error-message-lease-time"){
//                                $(div).html(msgleaseTimeIsDivided60);
//                            }
//                        },
                        });

                        $('#startIP').on('input',function(e){
                            $("#endIP").valid();
                            $("#netmask").valid();
                            $("#ipAddress").valid();
                        });
                        $('#startIP').on('change',function(e){
                            $("#endIP").valid();
                            $("#netmask").valid();
                            $("#ipAddress").valid();
                        });

                        $('#endIP').on('input',function(e){
                            $("#startIP").valid();
                            $("#netmask").valid();
                            $("#ipAddress").valid();
                        });
                        $('#endIP').on('change',function(e){
                            $("#startIP").valid();
                            $("#netmask").valid();
                            $("#ipAddress").valid();
                        });

                        $('#netmask').on('input',function(e){
                            $("#startIP").valid();
                            $("#endIP").valid();
                            $("#ipAddress").valid();
                        });
                        $('#netmask').on('change',function(e){
                            $("#startIP").valid();
                            $("#endIP").valid();
                            $("#ipAddress").valid();
                        });

                        if(!($(".lanform").valid())) {
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            return false;
                        }
                        
                        var paramNames = [];
                        var paramValues = [];
                        var paramTypes = [];
                        var isValid = true;
                        var isChanged = false;
                        var needCheckStartIp = false;
                        var needCheckEndIp = false;
                        var ipAddr = $("input[name='ipAddress']");
                        var mode = $(".modeType option:selected").val();

                        var realIpAddressVal = $("input[name='ipAddressValue']").val();
                        if (ipAddr.val().trim() != realIpAddressVal.trim()) {
                            isChanged = true;
                            var realIpAddressName = $("input[name='ipAddressName']").val();
                            var realIpAddressType = $("input[name='ipAddressType']").val();
                            paramNames.push(realIpAddressName);
                            paramValues.push(ipAddr.val());
                            paramTypes.push(realIpAddressType);
                            if (mode == '1') {
                                needCheckStartIp = true;
                                needCheckEndIp = true;
                            }
                        }

                        var netmask = $("input[name='netmask']");
                        var realNetmaskVal = $("input[name='netmaskValue']").val();
                        if (netmask.val().trim() != realNetmaskVal.trim()) {
                            isChanged = true;
                            var realNetmaskName = $("input[name='netmaskName']").val();
                            var realNetmaskType = $("input[name='netmaskType']").val();
                            paramNames.push(realNetmaskName);
                            paramValues.push(netmask.val());
                            paramTypes.push(realNetmaskType);
                        }

                        var realDhcpEnableVal = $("input[name='dhcpServerEnableValue']").val();
                        if (mode != -1) {
                            if (mode != realDhcpEnableVal && (mode == '0' || mode == '1')) {
                                isChanged = true;
                                var realDhcpEnableName = $("input[name='dhcpServerEnableName']").val();
                                var realDhcpServerEnableType = $("input[name='dhcpServerEnableType']").val();
                                paramNames.push(realDhcpEnableName);
                                paramValues.push(mode);
                                paramTypes.push(realDhcpServerEnableType);
                            }
                        } else {
                            $(".modeType").addClass("invalidVal");
                            isValid = false;
                        }

                        if (mode == '1') {
                            var startIP = $("input[name='startIP']").val().trim();
                            var realStartIPVal = $("input[name='startIPValue']").val().trim();
                            if (startIP != realStartIPVal) {
                                isChanged = true;
                                var realStartIPName = $("input[name='startIPName']").val();
                                var realStartIPType = $("input[name='startIPType']").val();
                                paramNames.push(realStartIPName);
                                paramValues.push(startIP);
                                paramTypes.push(realStartIPType);
                            }
//                                if (needCheckStartIp) {
//                                    $.ajax({
//                                        type: "POST",
//                                        url: $basepath + "secureFiles/actions/ajaxActions/checkStartEndIp.php",
//                                        data: {
//                                            'checkedIp': startIP.val(),
//                                            'ipAddress': ipAddr.val(),
//                                            'netMask': netmask.val(),
//                                            'fromApp': true
//                                        },
//                                        async: false,
//                                        success: function (res) {
//                                            if (res == 'true') {
//                                                isChanged = true;
//                                                startIP.removeClass("invalidVal");
//                                                var realStartIPName = $("input[name='startIPName']").val();
//                                                var realStartIPType = $("input[name='startIPType']").val();
//                                                paramNames.push(realStartIPName);
//                                                paramValues.push(startIP.val().trim());
//                                                paramTypes.push(realStartIPType);
////                                                    needCheckEndIp = true;
//                                            } else if (res == 'false') {
//                                                    var msg = $('#msgForLan').val();
//                                                    $("#actionResult").removeClass("infoMessage");
//                                                    $("#actionResult").addClass("errorMessage");
//                                                    $("#actionResult").html(msg);
//                                                    $('body').css("cursor", "default");
//                                                    startIP.addClass("invalidVal");
//                                                    isValid = false;
//                                            } else if (res = 'logged_out') {
//                                                     document.location.href = $basepath + 'login';
//                                            }
//                                        }
//                                    });
//                                }

                            var endIP = $("input[name='endIP']").val().trim();
                            var realEndIPVal = $("input[name='endIPValue']").val().trim();
                            if (endIP != realEndIPVal) {
                                isChanged = true;
                                var realEndIPName = $("input[name='endIPName']").val();
                                var realEndIPType = $("input[name='endIPType']").val();
                                paramNames.push(realEndIPName);
                                paramValues.push(endIP);
                                paramTypes.push(realEndIPType);
                            }
//                        if (needCheckEndIp) {
//                            $.ajax({
//                                type: "POST",
//                                url: $basepath + "secureFiles/actions/ajaxActions/checkStartEndIp.php",
//                                data: {
//                                    'checkedIp': endIP.val(),
//                                    'ipAddress': ipAddr.val(),
//                                    'netMask': netmask.val(),
//                                    'fromApp': true
//                                },
//                                async: false,
//                                success: function (res) {
//                                    if (res == 'true') {
//                                        isChanged = true;
//                                        endIP.removeClass("invalidVal");
//                                        var realEndIPName = $("input[name='endIPName']").val();
//                                        var realEndIPType = $("input[name='endIPType']").val();
//                                        paramNames.push(realEndIPName);
//                                        paramValues.push(endIP.val().trim());
//                                        paramTypes.push(realEndIPType);
//                                    } else if (res == 'false') {
//    //                                                                    var msg = '<?php echo $ini_array['end_ip_outside']?>';
//                                            $("#actionResult").removeClass("infoMessage");
//                                            $("#actionResult").addClass("errorMessage");
//                                            $("#actionResult").html(msg);
//                                            $('body').css("cursor", "default");
//                                            endIP.addClass("invalidVal");
//                                            isValid = false;
//                                    } else if (res = 'logged_out') {
//                                            document.location.href = $basepath + 'login';
//                                    }
//                                }
//                            });
//                        }

                            var leaseTime = $("input[name='leaseTime']");
                            var realLeaseTimeVal = $("input[name='dhcpLeaseTimeValue']").val().trim();
                            if (leaseTime.val().trim() != realLeaseTimeVal) {
                                var leaseTimeVal = leaseTime.val().trim();
                                isChanged = true;
                                var realLeaseTimeName = $("input[name='dhcpLeaseTimeName']").val();
                                var realDhcpLeaseTimeType = $("input[name='dhcpLeaseTimeType']").val();
                                paramNames.push(realLeaseTimeName);
                                var leaseTimeValInt = parseInt(leaseTime.val().trim());
                                paramValues.push(leaseTimeValInt);
                                paramTypes.push(realDhcpLeaseTimeType);
                            }
                        }else if(mode == '2'){
                            var externalDHCP = $("input[name='externalDHCP']").val().trim();
                            var realexternalDHCP = $("input[name='externalDHCPValue']").val().trim();
                            if (externalDHCP != realexternalDHCP) {
                                isChanged = true;
                                var externalDHCPName = $("input[name='externalDHCPName']").val();
                                var externalDHCPType = $("input[name='externalDHCPType']").val();
                                paramNames.push(externalDHCPName);
                                paramValues.push(externalDHCP);
                                paramTypes.push(externalDHCPType);
                            }
                        }
                var actionName = "setLan";
                if (paramNames.length != 0 && isValid && isChanged) {
                    if($('#refreshButton').css('display') == 'none') {
                        lanApply(devId, serialN, paramNames, paramValues, paramTypes, actionName);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                lanApply(devId, serialN, paramNames, paramValues, paramTypes, actionName);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }

//                    $.ajax({
//                        type: "POST",
//                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
//                        data: {
//                            'deviceID': devId,
//                            'serialN': serialN,
//                            'changedParamNames': paramNames,
//                            'changedParamValues': paramValues,
//                            'changedParamTypes': paramTypes,
//                            'actionName': "setLan",
//                            'fromApp': true
//                        },
//                        async: false,
//                        success: function (result) {
//                            if (result == 'true') {
//                                var success = getMssg['action_succeed'];
//                                $("#actionResult").empty();
//                                $("#actionResult").html(success);
//                                $("#actionResult").removeClass("errorMessage");
//                                $("#actionResult").addClass("infoMessage");
//                                setTimeout(function () {
//                                    updateActivities(devId);
//                                    getCorrentTaskIdByTab(devId,'lan');
//                                    $('body').css("cursor", "default");
//                                }, 2000);
//
////                                setTimeout(function () {
////                                    intervalSetTypeLan = setInterval(function(){
////                                        getTaskStatus(devId,'lan');
////                                    }, 2000);
////                                }, 3000);
//                                setTimeout(function () {
//                                    intervalRefresh = setInterval(function(){
//                                        getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
//                                    }, 2000);
//                                }, 3000);
//
//                                setTimeout(function () {
////                                    updateAfterTheAction();
//                                    $("#actionResult").empty();
//                                    //th.removeAttr("disabled");
//                                    //th.css("opacity", "1");
//                                }, 10000);
//
//                            } else if (result == 'false') {
//                                    $('body').css("cursor", "default");
//                                    var failed = getMssg['action_failed'];
//                                    $("#actionResult").empty();
//                                    $("#actionResult").html(failed);
//                                    $("#actionResult").removeClass("infoMessage");
//                                    $("#actionResult").addClass("errorMessage");
//
//                                    setTimeout(function () {
//                                        updateAfterTheAction();
//                                    }, 10000);
//                            } else if (result == 'logged_out') {
//                                    document.location.href = $basepath + 'login';
//                                }
//                            },
//                            error: function(xhr, status, error) {
//                                document.location.href = $basepath + '500';
//                            }
//                        });

                    } else if (isValid && !isChanged) {
                        $('body').css("cursor", "default");
                        var failed = th.parent().find("input[name='nothingChange']").val();
                        $("#actionResult").removeClass("infoMessage");
                        $("#actionResult").addClass("errorMessage");
                        $("#actionResult").empty();
                        $("#actionResult").html(failed);
                        th.removeAttr("disabled");
//                        th.css("opacity", "1");
                    }else {
                        $('body').css("cursor", "default");
                        th.removeAttr("disabled");
//                        th.css("opacity", "1");
//                        $("#actionResult").empty();
                    }

        //         } else if (result == 'false') {
        //             $("input").attr("disabled", "disabled");
        //             $("select").attr("disabled", "disabled");
        //             $("#divForAdd").hide();
        //             var msg = getMssg['dev_unavailable'];
        //             $("#actionResult").removeClass("infoMessage");
        //             $("#actionResult").addClass("errorMessage");
        //             $("#actionResult").html(msg);
        //             $('body').css("cursor", "default");
        //
        //             setTimeout(function () {
        //                 updateAfterTheAction();
        //             }, 10000);
        //         } else if (result = 'logged_out') {
        //                 document.location.href = $basepath + 'login';
        //         }
        //     },
        //     error: function(xhr, status, error) {
        //         document.location.href = $basepath + '500';
        //     }
        // });
            return false;
    });

    $(document).on("change",".staticModeType",function() {
        var modeStatic = $(".staticModeType option:selected").val();
        var modeDynamic = $(".dynamicModeType option:selected").val();

        if(modeStatic == 1) {
            $("input[name ='ipv6Address']").attr('readonly', true);
            $("input[name ='ipv6Address']").css("opacity", "0.5");
            $("input[name ='prefixIPv6']").attr('readonly', true);
            $("input[name ='prefixIPv6']").css("opacity", "0.5");
            $("input[name ='leasTimeIPv6']").attr('readonly', true);
            $("input[name ='leasTimeIPv6']").css("opacity", "0.5");
        } else if(modeStatic == 0) {
            $("input[name ='ipv6Address']").removeAttr("readonly");
            $("input[name ='ipv6Address']").css("opacity", "1");
            $("input[name ='prefixIPv6']").removeAttr("readonly");
            $("input[name ='prefixIPv6']").css("opacity", "1");
            $("input[name ='leasTimeIPv6']").removeAttr("readonly");
            $("input[name ='leasTimeIPv6']").css("opacity", "1");
        }
    });

    $(document).on("change",".dynamicModeType",function() {
        var modeStatic = $(".staticModeType option:selected").val();
        var modeDynamic = $(".dynamicModeType option:selected").val();
        if(modeDynamic == 'Disabled') {
            $(".startEndIPv6").hide();
            $(".leasTime").hide();
        } else if(modeDynamic == 'Stateful') {
            $(".startEndIPv6").show();
            $(".leasTime").show();
        } else if(modeDynamic == 'Stateless') {
            $(".startEndIPv6").hide();
            $(".leasTime").show();
        }
    });

    function lanApply(devId, serialN, paramNames, paramValues, paramTypes, actionName) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'serialN': serialN,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'actionName': actionName,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#actionResult").empty();
                    $("#actionResult").html(success);
                    $("#actionResult").removeClass("errorMessage");
                    $("#actionResult").addClass("infoMessage");
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'lan');
                        $('body').css("cursor", "default");
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResult").empty();
                    }, 10000);

                } else if (result == 'false') {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResult").empty();
                    $("#actionResult").html(failed);
                    $("#actionResult").removeClass("infoMessage");
                    $("#actionResult").addClass("errorMessage");

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    }

    //$(document).on("click", "#cancelLan", function () {
    //    $(".lanform").validate().resetForm();
    //});
    
//------------------- end lanPageForDevice.php -------------------------------------

    
//-------------------------- wanPageForDevice1.php------------------------------  
 

    $(document).on("change", "input[name='defaultGat']", function () {

        var msg = getMssg['def_gateway'];
        var th = $(this);
        var clicked_id = th.attr('id');
        var titleMsg = getMssg['title_msg'];
        var changMsg =  getMssg['change_msg'];
        var cancelMsg = getMssg['cancel'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: changMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                if (th.attr("disabled") != "disabled") {
//                    th.css("opacity", "0.5");
                    $('body').css("cursor", "wait");
                    // $.ajax({
                    //     type: "POST",
                    //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    //     data: {
                    //         'deviceID': devId,
                    //         'actionName': "connection",
                    //         'fromApp': true
                    //     },
                    //     async: true,
                    //     success: function (result) {
                    //         if (result == 'true') {
                                var index = parent.document.getElementById("index_" + clicked_id).value;
                                var connect_index = parent.document.getElementById("c_" + clicked_id).value;
                                var conn_type = parent.document.getElementById(clicked_id + "_select_conn_type").value;
                                var wan_id = parent.document.getElementById(clicked_id + "_wanID").value;
                               
                                $.ajax({
                                    type: "POST",
                                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                    data: {
                                        'token': token_cookie,
                                        'deviceID': devId,
                                        // 'wanID': wan_id,
                                        // 'serialN': serialN,
                                        'index': index,
                                        'connectIndex': connect_index,
                                        'connectType': conn_type,
                                        'actionName': 'setDefaultGateway',
                                        'fromApp': true
                                    },
                                    async: false,
                                    success: function (result) {
                                        var result = JSON.parse(result);
                                        if(result.result != 'false') {
                                            var success = getMssg['action_succeed'];
                                            $("#actionRes").removeClass("errorMessage");
                                            $("#actionRes").addClass("infoMessage");
                                            $("#actionRes").empty();
                                            $("#actionRes").html(success);
                                            setTimeout(function () {
                                                updateActivities(devId);
                                            }, 2000);
                                            
                                            setTimeout(function () {
                                                intervalRefresh = setInterval(function(){
                                                    getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                                                }, 2000);
                                            }, 3000);
                                            
//                                            setTimeout(function () {
//                                                intervalSetTypeWan = setInterval(function(){
//                                                    getTaskStatus(devId,'wan');
//                                                }, 2000);
//                                            }, 3000);
                                            
                                            setTimeout(function () {
//                                                updateAfterTheAction();
                                                $("#actionRes").empty();
                                            }, 10000);
                                        } else if (result.result == 'false') {
                                            var failed = getMssg['action_failed'];
                                            $("#actionRes").addClass("errorMessage");
                                            $("#actionRes").removeClass("infoMessage");
                                            $("#actionRes").empty();
                                            $("#actionRes").html(failed);

                                            setTimeout(function () {
                                                updateAfterTheAction();
                                            }, 10000);
                                        } else if (result.result == 'logged_out') {
                                            document.location.href = $basepath + 'login';
                                        }
                                    },
                                    error: function(xhr, status, error) {
                                        // alert(error);
                                        document.location.href = $basepath + '500';
                                    }
                                });
                    //         } else if (result == 'false') {
                    //             $("input").attr("disabled", "disabled");
                    //             $("select").attr("disabled", "disabled");
                    //             $("#divForAdd").hide();
                    //             var msg = getMssg['dev_unavailable'];
                    //             $("#actionRes").addClass("errorMessage");
                    //             $("#actionRes").removeClass("infoMessage");
                    //             $("#actionRes").empty();
                    //             $("#actionRes").html(msg);
                    //
                    //             setTimeout(function () {
                    //                 updateAfterTheAction();
                    //             }, 10000);
                    //         } else if (result = 'logged_out') {
                    //             document.location.href = $basepath + 'login';
                    //         }
                    //     },
                    //     error: function(xhr, status, error) {
                    //         document.location.href = $basepath + '500';
                    //     }
                    // });
                }
                }else{
                    $('input[type=radio]').prop('checked', function () {
                        return this.getAttribute('checked') == 'checked';
                    });
                }
            });
    });

    $(document).on("change", "input[name='defaultGatIPv6']", function () {

        var msg = getMssg['def_gateway'];
        var th = $(this);
        var clicked_id = th.attr('id');
        var titleMsg = getMssg['title_msg'];
        var changMsg =  getMssg['change_msg'];
        var cancelMsg = getMssg['cancel'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: changMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                if (th.attr("disabled") != "disabled") {
                    $('body').css("cursor", "wait");
                    var index = parent.document.getElementById("index_" + clicked_id).value;
                    var connect_index = parent.document.getElementById("c_" + clicked_id).value;
                    var conn_type = parent.document.getElementById(clicked_id + "_select_conn_type").value;
                    var wan_id = parent.document.getElementById(clicked_id + "_wanID").value;

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/api/acs_api.php",
                        data: {
                            'token': token_cookie,
                            'deviceID': devId,
                            'wanID': wan_id,
                            'connectType': conn_type,
                            'method': 'setDefaultGateway',
                        },
                        async: false,
                        success: function (result) {
                            var result = JSON.parse(result);
                            if(result.result != 'false') {
                                var success = getMssg['action_succeed'];
                                $("#actionRes").removeClass("errorMessage");
                                $("#actionRes").addClass("infoMessage");
                                $("#actionRes").empty();
                                $("#actionRes").html(success);
                                setTimeout(function () {
                                    updateActivities(devId);
                                }, 2000);

                                setTimeout(function () {
                                    intervalRefresh = setInterval(function(){
                                        getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                                    }, 2000);
                                }, 3000);

                                setTimeout(function () {
                                    $("#actionRes").empty();
                                }, 10000);
                            } else if (result.result == 'false') {
                                var failed = getMssg['action_failed'];
                                $("#actionRes").addClass("errorMessage");
                                $("#actionRes").removeClass("infoMessage");
                                $("#actionRes").empty();
                                $("#actionRes").html(failed);

                                setTimeout(function () {
                                    updateAfterTheAction();
                                }, 10000);
                            } else if (result.result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }
            }else{
                $('input[type=radio]').prop('checked', function () {
                    return this.getAttribute('checked') == 'checked';
                });
            }
        });
    });



    $(document).on("click", ".wanParam", function (){
        var actionName = $(this).parent().find("input[name='conType']").val();
        var wanID = $(this).parent().find("input[name='wanID']").val();

        $('body').oLoader('show');
        //
        // $.ajax({
        //     type: "POST",
        //     url: $basepath + "secureFiles/actions/ajaxActions/checkDevStatus.php",
        //     data: {
        //         'deviceID': devId,
        //         'fromApp':true
        //     },
        //     async: false,
        //     success: function (result) {
        //
        //         if (result =='logged_out') {
        //             document.location.href = $basepath + 'login';
        //         } else {
        //             result = result.trim();
        //             devStatuss = result;
                    devStatuss = 'true';
                    $('body').oLoader('hide');

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDevice.php",
                        data: {
                            'serialNumber':serialN,
                            'deviceID':devId,
                            'actionName': actionName,
                            'devStatus':devStatuss,
                            'wanParamID':wanID,
                            'havPermissions':havePerm,
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if (result =='logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                $(".wanpage1").empty();
                                $(".wanpage1").html(result);
                                $("body").css("cursor", "default");
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
        //         }
        //     },
        //     error: function(xhr, status, error) {
        //         document.location.href = $basepath + '500';
        //     }
        // });
    });

    $(document).on("click", "#addNewWan", function () {

        if($(this).attr("disabled")!="disabled"){

            $("body").css("cursor", "wait");
            var actionName = 'Static';
            $('body').oLoader('show');

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/checkDevStatus.php",
            //     data: {
            //         'deviceID': devId,
            //         'fromApp':true
            //     },
            //     async: false,
            //     success: function (result) {
            //         if (result =='logged_out') {
            //             document.location.href = $basepath + 'login';
            //         } else { result=result.trim();
            //             devStatuss = result;
                        devStatuss = 'true';

                        $('body').oLoader('hide');

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDeviceToAdd.php",
                            data: {
                                'serialNumber':serialN,
                                'actionName': actionName,
                                'devStatus':devStatuss,
                                'havPermissions':'true',
                                'fromApp':true
                            },
                            async: false,
                            success: function (result) {
                                if (result =='logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    $('.general-settings').show();
                                    $(".wanpage1").empty();
                                    $(".wanpage1").html(result);
                                    $("#delStatWan").hide();
                                    $("body").css("cursor", "default");
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });

    $(document).on("change keyup",".gsConnType",function(){
        var selectedConType = $(".gsConnType option:selected").val();
        var devStatuss = $("input[name='deviceStatus']").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDeviceToAdd.php",
            data: {
                'serialNumber':serialN,
                'actionName': selectedConType,
                'devStatus':devStatuss,
                'havPermissions':'true',
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $(".wanpage1").empty();
                    $(".wanpage1").html(result);
                    $("#delDynWan").hide();
                    $("#delStatWan").hide();
                    $("#delPPPWan").hide();
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

//-------------------------- end wanPageForDevice1.php-------------------------- 

//-------------------------- wanDynamic.php-------------------------------------

    $(document).on("click", "#getDnsonoffswitch", function () {
        if ($(this).is(":checked")) {
            $("#forDNSServers").hide();
        } else {
            $("#forDNSServers").show();
        }
    });

    $(document).on("click", "#getSlaaconoffswitch", function () {
        if ($(this).is(":checked")) {
            $("#forSLAACServers").hide();
        } else {
            $("#forSLAACServers").show();
        }
    });
    
    $(document).on("click", "#cancelDynamicWan", function (e) {
        e.preventDefault();
//        $("#forReset").validate().resetForm();
        $("div.error_messageLan").remove(); 
	$(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();
        
        //        after reset
        var dnsCheckbox = $("input[name='enableDns']");
        if(dnsCheckbox.is(":checked")){
            $("#forDNSServers").hide();
        }else{
            $("#forDNSServers").show();
        }
    });

    $(document).on("click", "#cancelDynamicWanIPv6", function (e) {
        e.preventDefault();
//        $("#forReset").validate().resetForm();
        $("div.error_messageLan").remove();
        $(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();

        //        after reset
        var dnsCheckbox = $("input[name='enableDns']");
        if(dnsCheckbox.is(":checked")){
            $("#forDNSServers").hide();
        }else{
            $("#forDNSServers").show();
        }
        var slaacCheckbox = $("input[name='enableSlaac']");
        if(slaacCheckbox.is(":checked")){
            $("#forSLAACServers").hide();
        }else{
            $("#forSLAACServers").show();
        }
    });

    
    $(document).on("click", "#keepAliveOnoffswitch", function () {
        if ($(this).is(":checked")) {
            $(".keep-aliveDevice").show();
        } else {
            $(".keep-aliveDevice").hide();
        }
    });
    
    $(document).on("click", "#cancelPPPWan", function(event){
    //    before reset

        event.preventDefault();
        // stops the form from resetting after this function
        $("div.error_messageLan").remove(); 
	$(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();
        // resets the form before continuing the function
        
        //        after reset
        var keepCheckbox = $("input[name='enableKeepAlive']");
        if(keepCheckbox.is(":checked")){
            $(".keep-aliveDevice").show();
        }else{
            $(".keep-aliveDevice").hide();
        }

        // after cancel generate password
        if (this.checked) {
            $('#txtPassword').prop('type', 'text');
        } else {
            $('#txtPassword').prop('type', 'password');
        }

    });
    

    function deleteConnection(th,actionName){
        var isDefConnection = $("input[name='isDefConn']").val();
        var hasPPPConnections = $("input[name='hasPPPConnections']").val();
        
        if(actionName == 'delDynWan' || actionName == 'delStatWan'){
            
            if(isDefConnection == 0 && hasPPPConnections == 0){
                delConnections(th,actionName);
                
            }else if(isDefConnection == 0 && hasPPPConnections > 0){
                var titleMsg = getMssg['title_msg'];
                var msgChange =  getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msg = getMssg['msg_del_IPOE_conn'];

                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: msgChange,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){
                        delConnections(th,actionName)
                    }
                });
            }else{
                var failed = getMssg["error_message_defconn"];
                swal({
                    title: '',
                    text:failed
                });
            }
        }else if(actionName == 'delPPPWan'){
            if(isDefConnection == 0){
                delConnections(th,actionName);
            }else{
                var failed = getMssg["error_message_defconn"];
                swal({
                    title: '',
                    text:failed
                });
            }
        }else {
            delConnections(th,actionName);
        }
    }

    function delConnections(th,actionName){
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
            $("body").css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {
                        var index = $("input[name='index']").val();
                        var connect_index = $("input[name='connect_index']").val();

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                            data: {
                                'deviceID': devId,
                                'serialN': serialN,
                                'index': index,
                                'connectIindex': connect_index,
                                'actionName': actionName,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'true') {
                                    var success = getMssg['action_succeed'];
                                    $("#actionResWan").removeClass("errorMessage");
                                    $("#actionResWan").addClass("infoMessage");
                                    $("#actionResWan").empty();
                                    $("#actionResWan").html(success);
                                    setTimeout(function () {
                                        updateActivities(devId);
                                        $("body").css("cursor", "default");
                                    }, 2000);
                                    setTimeout(function () {
                                        intervalRefresh = setInterval(function(){
                                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                                        }, 2000);
                                    }, 3000);
                                    setTimeout(function () {
//                                        updateAfterTheAction();
                                        $("#actionResWan").empty();
                                    }, 5000);
                                } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['action_failed'];
                                        $("#actionResWan").addClass("errorMessage");
                                        $("#actionResWan").removeClass("infoMessage");
                                        $("#actionResWan").empty();
                                        $("#actionResWan").html(failed);
                                        setTimeout(function () {
                                            updateAfterTheAction();
                                        }, 10000);
                                } else if (result == 'logged_out') {
                                           document.location.href = $basepath + 'login';
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").empty();
            //                 $("#actionResWan").html(msg);
            //                 $("body").css("cursor", "default");
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    }

    $(document).on("click", "#delDynWan", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delDynWan');
    });

    $(document).on("click", "#delStatWan", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delStatWan');
    });

    $(document).on("click", "#delStatWanIpv6", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delStatWanIpv6');
    });

    $(document).on("click", "#delDynWanIPv6", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delDynWanIPv6');
    });

    $(document).on("click", "#delPPPWan", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delPPPWan');
    });

    $(document).on("click", "#delPPPIPv6Wan", function (e) {
        e.preventDefault();
        var th = $(this);
        deleteConnection(th,'delPPPIPv6Wan');
    });


    $(document).on("change", "#enableonoffswitch", function () {
        var isDefConnection = $("input[name='isDefConn']").val();
        if(isDefConnection == 1){
            if(!$(this).is(':checked')){
                var titleMsg = getMssg['title_msg_disable_connection'];
                var msgChange =  getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msg = getMssg['error_message_defconn_disable'];

                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: msgChange,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(!isConfirm){
                        $('input[name=enable]').prop('checked', function () {
                            return this.getAttribute('checked') == 'checked';
                        });
                    }
                });
            }
        }
    });

    $(document).on("click", "#addDynamicWan", function (e) {
        e.preventDefault();
        var th = $(this);
        var haveConnection = false;
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
            //$("body").css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {

                        var paramNames = [];
                        var paramValues = [];
                        var paramTypes = [];
                        var isValid = true;
                        var isChanged = false;
                        var toAdd = $("input[name='toAdd']").val();
                        var mtu = $("input[name='mtu']");
                        var mtuVal = mtu.val().trim();
                        var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
                        var wanNameType = document.getElementsByName("dWNameType")[0].value;
                        var wanNameNew = "";

                        var realStartIPVal = $("input[name='mtuValue']").val().trim();
                        if (toAdd == 'false' && mtuVal != realStartIPVal) {
                            isChanged = true;
                            var realStartIPName = $("input[name='mtuName']").val();
                            var realStartIPType = $("input[name='mtuType']").val();
                            paramNames.push(realStartIPName);
                            paramValues.push(mtuVal);
                            paramTypes.push(realStartIPType);
                        }
                            
                        if(toAdd == 'true'){
                            isChanged = true;
                            var realStartIPName = $("input[name='mtuName']").val();
                            var realStartIPType = $("input[name='mtuType']").val();
                            paramNames.push(realStartIPName);
                            paramValues.push(mtuVal);
                            paramTypes.push(realStartIPType);
                        }

                        wanNameNew = document.getElementsByName("dWName")[0].value;
                        if (wanNameOld !== wanNameNew) {
                            paramNames.push("Name");
                            paramValues.push(wanNameNew);
                            paramTypes.push(wanNameType);
                            isChanged = true;
                        }

                        var enablePING = $("input[name='enablePing']");
                        var valenablePING = '';
                        if (enablePING.is(":checked")) {
                            valenablePING = '1';
                        } else {
                            valenablePING = '0';
                        }

                        var realEnablePINGName = $("input[name='enablePingName']").val();
                        var realEnablePINGType = $("input[name='enablePingType']").val();

                        if(toAdd == 'true' && valenablePING == '1'){
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }

                        var realEnablePING = $("input[name='enablePingValue']").val();
                        if (toAdd == 'false' && valenablePING != realEnablePING) {
                            isChanged = true;
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }
                        
                        var enableNat = $("input[name='enableNat']");
                        var valenableNat = '';
                        if (enableNat.is(":checked")) {
                            valenableNat = '1';
                        } else {
                            valenableNat = '0';
                        }

                        var realEnableNatName = $("input[name='enableNatName']").val();
                        var realEnableNatType = $("input[name='enableNatType']").val();

                        if(toAdd == 'true' && valenableNat == '1'){
                            paramNames.push(realEnableNatName);
                            paramValues.push(valenableNat);
                            paramTypes.push(realEnableNatType);
                        }

                        var realEnableNat = $("input[name='enableNatValue']").val();
                        if (toAdd == 'false' && valenableNat != realEnableNat) {
                            isChanged = true;
                            paramNames.push(realEnableNatName);
                            paramValues.push(valenableNat);
                            paramTypes.push(realEnableNatType);
                        }

                        //-------------------IGMP-------------------------------
                        var enableIGMP = $("input[name='enableIGMP']");
                        var valenableIGMP = '';
                        if (enableIGMP.is(":checked")) {
                            valenableIGMP = '1';
                        } else {
                            valenableIGMP = '0';
                        }

                        var realEnableIGMPName = $("input[name='enableIGMPName']").val();
                        var realEnableIGMPType = $("input[name='enableIGMPType']").val();

                        if(toAdd == 'true' && valenableIGMP == '1'){
                            paramNames.push(realEnableIGMPName);
                            paramValues.push(valenableIGMP);
                            paramTypes.push(realEnableIGMPType);
                        }

                        var realEnableIGMP = $("input[name='enableIGMPValue']").val();
                        if (toAdd == 'false' && valenableIGMP != realEnableIGMP) {
                            isChanged = true;
                            paramNames.push(realEnableIGMPName);
                            paramValues.push(valenableIGMP);
                            paramTypes.push(realEnableIGMPType);
                        }
                        //-----------------end IGMP---------------------------------

                        //----------------EnableDns --------------------------------

                        var enableDns = $("input[name='enableDns']");
                        var realDnsName = $("input[name='primaryDnsName']").val();
                        var realDnsType = $("input[name='primaryDnsType']").val();
                        var realEnableDnsName = $("input[name='enableDnsName']").val();
                        var realEnableDnsType = $("input[name='enableDnsType']").val();
                        var valenableDns = '';

                        if (enableDns.is(":checked")) {
//                            valenableDns = '1';
                            valenableDns = '0';
                            isChanged = true;
                            paramNames.push(realEnableDnsName);
                            paramValues.push(valenableDns);
                            paramTypes.push(realEnableDnsType);
                        } else {
//                            valenableDns = '0';
                            valenableDns = '1';
                            
                            var msgRequired = getMssg['error_message_required'];
                            var msgIp = getMssg['error_message_ip'];
                            var msgMac = getMssg['error_message_mac'];
                            var msgNetmask = getMssg['error_message_netmask'];
                            var msgNumber = getMssg['error_message_number'];
                            var msgDns = getMssg['error_message_dns'];
                            var msgLe1400 = getMssg['error_message_le_1400'];
                            var msgIpDNS = getMssg['error_message_ip_dns'];
			    var msgGe1 = getMssg['error_message_ge_1'];
			    var msgLe1540 = getMssg['error_message_le_1540'];
                //var msgLe1500 = getMssg['error_message_le_1500'];
                            var msgLe1550 = getMssg['error_message_le_1550'];
			    var msgDNSEquality = getMssg['error_message_dns_equality'];
                            var msgOnlyNum = getMssg['error_message_digit_number'];
                            var msgLe32 = getMssg['error_message_at_length_32'];

                            $("#forReset").validate({
                                rules: {
                                    dWName: {
                                        required: true,
                                        validateConnectionNameLength: true
                                    },
                                    primaryDns:{
                                        required: true,
                                        // validateDNS : true,
                                        validateIpAddress : true,
                                        validateDNSEquality:{
                                            primDns: "#primaryDns",
                                            secondDns: "#secondaryDns"
                                        }
                                    },
                                    secondaryDns:{
//                                        required: true,
//                                         validateDNS : true,
                                        validateIpAddress : true,
//                                        validateDNSEquality:{
//                                            primDns: "#primaryDns",
//                                            secondDns: "#secondaryDns"
//                                        }
                                    },
                                    mac:{
                                        required: true,
                                        validateMac : {
                                            siteType: '#siteType'
                                        }
                                    },
				    mtu: {
					required: true,
					number: true,
                        digits: true,
                        // min: 1400,
                        // max: 1550
					min: 1,
                    // max: 1500,
					max: 1540
				    }
                                },

                                messages: {
                                    dWName: {
                                        required: msgRequired,
                                        validateConnectionNameLength: msgLe32
                                    },
                                    primaryDns: {
                                        required: msgRequired,
                                        // validateDNS: msgDns,
                                        validateIpAddress: msgIpDNS,
                                        validateDNSEquality: msgDNSEquality
                                    },
                                    secondaryDns: {
//                                        required: msgRequired,
                                        validateIpAddress: msgIpDNS,
//                                         validateDNS: msgDns,
//                                        validateDNSEquality: msgDNSEquality
                                    },
                                    mac: {
                                        required: msgRequired,
                                        validateMac: msgMac
                                    },
				    mtu: {
					    required: msgRequired,
					    number: msgNumber,
                        digits: msgOnlyNum,
					    min : msgGe1,
                        // min: msgLe1400,
                        // max: msgLe1550
					max: msgLe1540
				    }
                                },
                                errorElement: "div",
                                errorClass: 'error_messageLan',
                                errorPlacement: function(error, element) {
                                    var placement = $(element).data('error');
                                    if (placement) {
                                        $(placement).append(error)
                                    } else {
                                        error.insertAfter(element);
                                    }
                                }
                            });
                            
                            $('#primaryDns').on('input',function(e){
                                $("#secondaryDns").valid();
                            });
                            
                            $('#primaryDns').on('change',function(e){
                                $("#secondaryDns").valid();
                            });
                            
                            $('#secondaryDns').on('input',function(e){
                                $("#primaryDns").valid();
                            });
                            
                            $('#secondaryDns').on('change',function(e){
                                $("#primaryDns").valid();
                            });
                            
                            if(!($("#forReset").valid())) {
                                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                                return false;
                            }
                           
                            var dns = $("input[name='primaryDns']").val().trim();
                            var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                            var secondaryDns = $("input[name='secondaryDns']").val().trim();
                            var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                            if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                                isChanged = true;
                                if(secondaryDns != realSecondaryDns && secondaryDns != ''){
                                    paramNames.push(realDnsName);
                                    paramValues.push(dns + ',' + secondaryDns);
                                    paramTypes.push(realDnsType);
                                }else if(secondaryDns != ''){
                                    paramNames.push(realDnsName);
                                    paramValues.push(dns + ',' + secondaryDns);
                                    paramTypes.push(realDnsType);
                                }else{
                                    paramNames.push(realDnsName);
                                    paramValues.push(dns);
                                    paramTypes.push(realDnsType);
                                }
                            }
                            isChanged = true;
                            paramNames.push(realEnableDnsName);
                            paramValues.push(valenableDns);
                            paramTypes.push(realEnableDnsType);
                        }

                        // var realEnableDns = $("input[name='enableDnsValue']").val();
                        // if (valenableDns != realEnableDns) {
                        //     isChanged = true;
                        //     paramNames.push(realEnableDnsName);
                        //     paramValues.push(valenableDns);
                        //     paramTypes.push(realEnableDnsType);
                        // }
                        //
                        //-----------EnableDns end ---------------------------------

                        var msgRequired = getMssg['error_message_required'];
                        var msgIp = getMssg['error_message_ip'];
                        var msgMac = getMssg['error_message_mac'];
                        var msgNetmask = getMssg['error_message_netmask'];
                        var msgNumber = getMssg['error_message_number'];
			            var msgGe1 = getMssg['error_message_ge_1'];
			            // var msgLe1540 = getMssg['error_message_le_1540'];
                        var msgLe1500 = getMssg['error_message_le_1500'];
                        var msgLe1550 = getMssg['error_message_le_1550'];

                        $("#forReset").validate({
                            rules: {
                                mac:{
                                    required: true,
                                    validateMac : {
                                        siteType: '#siteType'
                                    }
                                },
				mtu: {
				    required: true,
				    number: true,
                    digits: true,
				    min: 1,
                    // min: 1400,
                    // max: 1550
                    //max: 1500
				    max: 1540
				}
                            },

                            messages: {
                                mac: {
                                    required: msgRequired,
                                    validateMac: msgMac
                                },
				mtu: {
				    required: msgRequired,
				    number: msgNumber,
                    digits: msgOnlyNum,
				    min : msgGe1,
                    // min: msgLe1400,
				    max: msgLe1540
                    // max: msgLe1550
				}
                            },
                            errorElement: "div",
                            errorClass: 'error_messageLan',
                            errorPlacement: function(error, element) {
                                var placement = $(element).data('error');
                                if (placement) {
                                    $(placement).append(error)
                                } else {
                                    error.insertAfter(element);
                                }
                            }
                        });

                        if(!($("#forReset").valid())) {
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            return false;
                        }

                        var mac = $("input[name='mac']");
                        var realEndIPVal = $("input[name='macValue']").val().trim();
                        if (mac.val().trim() != realEndIPVal) {
                            isChanged = true;
                            var realEndIPName = $("input[name='macName']").val();
                            var realEndIPType = $("input[name='macType']").val();
                            paramNames.push(realEndIPName);
                            paramValues.push(mac.val().trim());
                            paramTypes.push(realEndIPType);
                        }

                        var enable = $("input[name='enable']");
                        var valEnable = '';
                        if (enable.is(":checked")) {
                            valEnable = '1';
                        } else {
                            valEnable = '0';
                        }

                        var realEnableName = $("input[name='enableName']").val();
                        var realEnableType = $("input[name='enableType']").val();

                        if(toAdd == 'true'){
                            paramNames.push(realEnableName);
                            paramValues.push(valEnable);
                            paramTypes.push(realEnableType);
                        }

                        var realEnable = $("input[name='enableValue']").val();
                        if (toAdd == 'false' && valEnable != realEnable) {
                            isChanged = true;
                            paramNames.push(realEnableName);
                            paramValues.push(valEnable);
                            paramTypes.push(realEnableType);
                        }

    //                            default conn//
//                        var defconn = $("input[name='defconn']");
//                        var valdefcon = '';
//                        if (defconn.is(":checked")) {
//                            valdefcon = '1';
//                        } else {
//                            valdefcon = '0';
//                        }
//
//                        var realdefconName = $("input[name='defconName']").val();
//                        var realdefconType = $("input[name='defconType']").val();
//                        var realdefcon = $("input[name='defconValue']").val();
                        var isChecket = false;
                       
//                        if(toAdd == 'true' && valdefcon == '1'){
////                            paramNames.push(realdefconName);
////                            paramValues.push(realdefcon);
////                            paramTypes.push(realdefconType);
//                            isChecket = true;
//                        }

    //                    if (valdefcon != realdefcon && valdefcon == '1') {
    //                        isChanged = true;
    //                       
    //                    }else if (valdefcon != realdefcon && valdefcon == '0') {
    //                            isChanged = true;
    //                            paramNames.push(realdefconName);
    //                            paramValues.push(valdefcon);
    //                            paramTypes.push(realdefconType);
    //                        }
                        //}

                        var interfaceType = $("#interfaceType option:selected").val();
//                        var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                        var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                        if (interfaceType != realinterfaceType) {
//                            isChanged = true;
//                            var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                            paramNames.push(realInterfaceTypeName);
//                            paramValues.push(interfaceType);
//                            paramTypes.push(realInterfaceTypeType);
//                        }
                        
                        var having = $("input[name='having']").val();
                        if (paramNames.length != 0 && isValid && isChanged) {
                            var index = $("input[name='index']").val();
                            var connect_index = $("input[name='connect_index']").val();
                            var id_conn = $("input[name='id_conn']").val();
                            var flagl = $("input[name='flagl']").val();
                            var actionName;
                            if(interfaceType == '-1'){
                                actionName = flagl == "addDynamicWan" ? "addDynamicWan" : "setDynamicWan";
                            }else{
                                actionName = "addDynamicWan";
                                index = '%d';
                            }

                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDevice.php",
                                data: {
                                    'deviceID': devId,
                                    'serialNumber': serialN,
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if(result==1) {
                                        haveConnection = true;
                                    } else {
                                        haveConnection = false;
                                    }
                                },
                                error: function(xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });

                            if(haveConnection==true && actionName == "addDynamicWan") {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOff = getMssg['removeConnection'];

                                // swal({
                                //     title: titleMsg,
                                //     text: msgOff,
                                //     showCancelButton: true,
                                //     closeOnConfirm: true,
                                //     confirmButtonText: rmMsg,
                                //     cancelButtonText: cancelMsg,
                                //     confirmButtonColor: "#008DA9"
                                // }, function (isConfirm) {
                                //     if (isConfirm) {
                                        if($('#refreshButton').css('display') == 'none') {
                                            addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamic');
                                        } else {
                                            var titleMsg = getMssg['title_msg'];
                                            var rmMsg = getMssg['change_msg'];
                                            var cancelMsg = getMssg['cancel'];
                                            var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                            swal({
                                                title: titleMsg,
                                                text: msgOffOn,
                                                showCancelButton: true,
                                                closeOnConfirm: true,
                                                confirmButtonText: rmMsg,
                                                cancelButtonText: cancelMsg,
                                                confirmButtonColor: "#008DA9"
                                            }, function (isConfirm) {
                                                if (isConfirm) {
                                                    addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having);
                                                } else {
                                                    th.removeAttr("disabled");
                                                }
                                            });
                                        }
                                //     } else {
                                //         th.removeAttr("disabled");
                                //     }
                                // });
                            } else {
                                if($('#refreshButton').css('display') == 'none') {
                                    if(actionName == "addDynamicWan") {
                                        addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamic');
                                    } else if(actionName == "setDynamicWan") {
                                        editDynamicWan(devId,id_conn, index, connect_index, paramNames, paramValues,paramTypes, actionName, having, 'dynamic')
                                    }
                                } else {
                                    var titleMsg = getMssg['title_msg'];
                                    var rmMsg = getMssg['change_msg'];
                                    var cancelMsg = getMssg['cancel'];
                                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                    swal({
                                        title: titleMsg,
                                        text: msgOffOn,
                                        showCancelButton: true,
                                        closeOnConfirm: true,
                                        confirmButtonText: rmMsg,
                                        cancelButtonText: cancelMsg,
                                        confirmButtonColor: "#008DA9"
                                    }, function (isConfirm) {
                                        if (isConfirm) {
                                            if(actionName == "addDynamicWan") {
                                                addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamic');
                                            } else if(actionName == "setDynamicWan") {
                                                editDynamicWan(devId, id_conn, index, connect_index, paramNames, paramValues,paramTypes, actionName, having, 'dynamic')
                                            }
                                        } else {
                                            th.removeAttr("disabled");
                                        }
                                    });
                                }

                            }
                        } else if (isValid && !isChanged) {
                                    $('body').css("cursor", "default");
                                    var failed = getMssg["nothing_changed"];
                                    $("#actionResWan").removeClass("infoMessage");
                                    $("#actionResWan").addClass("errorMessage");
                                    $("#actionResWan").empty();
                                    $("#actionResWan").html(failed);
                                    th.removeAttr("disabled");
//                                    th.css("opacity", "1");
                                } else {
                                    $('body').css("cursor", "default");
                                    th.removeAttr("disabled");
//                                    th.css("opacity", "1");
                                    $("#actionRes").empty();
                                }
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").html(msg);
            //                 $('body').css("cursor", "default");
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 5000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });

    function addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, type) {
        $.ajax({
            type: "POST",
            url: $basepath +"secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionName,
                'deviceID': devId,
                'forWeb': "",
                // 'defConnection': isChecket,
                // 'index': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'interface_type': interfaceType,
                'type': type,
                'having': having,
                'token': token_cookie
                // 'fromApp': true
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);

                } else if (result.result=="false" || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result.result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }

            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
                // document.location.href = $basepath + '500';
            }
        });
    }

    function editDynamicWan(devId, id_conn, index, connect_index, paramNames, paramValues,paramTypes, actionName, having) {
        if(id_conn == '') {
            id_conn = devId;
        }
        $.ajax({
            type: "POST",
            url: $basepath +"secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionName,
                'deviceID': devId,
                'forWeb': "",
                // 'id': id_conn,
                // 'defConnection': isChecket,
                'numIndex': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                // 'interface_type': interfaceType,
                // 'type': 'dynamic',
                'having': having,
                'token': token_cookie
                // 'fromApp': true
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);

                } else if (result.result == 'false' || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result.result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }

            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

    $(document).on("click", "#addDynamicWanIPv6", function (e) {
        e.preventDefault();
        var th = $(this);
        var haveConnection = false;
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
            //$("body").css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {

            var paramNames = [];
            var paramValues = [];
            var paramTypes = [];
            var isValid = true;
            var isChanged = false;
            var toAdd = $("input[name='toAdd']").val();
            var mtu = $("input[name='mtu']");
            var mtuVal = mtu.val().trim();
            var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
            var wanNameType = document.getElementsByName("dWNameType")[0].value;
            var wanNameNew = "";

            var realStartIPVal = $("input[name='mtuValue']").val().trim();
            if (toAdd == 'false' && mtuVal != realStartIPVal) {
                isChanged = true;
                var realStartIPName = $("input[name='mtuName']").val();
                var realStartIPType = $("input[name='mtuType']").val();
                paramNames.push(realStartIPName);
                paramValues.push(mtuVal);
                paramTypes.push(realStartIPType);
            }

            if(toAdd == 'true'){
                isChanged = true;
                var realStartIPName = $("input[name='mtuName']").val();
                var realStartIPType = $("input[name='mtuType']").val();
                paramNames.push(realStartIPName);
                paramValues.push(mtuVal);
                paramTypes.push(realStartIPType);
            }

            wanNameNew = document.getElementsByName("dWName")[0].value;
            if (wanNameOld !== wanNameNew) {
                paramNames.push("Name");
                paramValues.push(wanNameNew);
                paramTypes.push(wanNameType);
                isChanged = true;
            }

            //-------------------IGMP-------------------------------
            var enableIGMP = $("input[name='enableIGMP']");
            var valenableIGMP = '';
            if (enableIGMP.is(":checked")) {
                valenableIGMP = '1';
            } else {
                valenableIGMP = '0';
            }

            var realEnableIGMPName = $("input[name='enableIGMPName']").val();
            var realEnableIGMPType = $("input[name='enableIGMPType']").val();

            if(toAdd == 'true' && valenableIGMP == '1'){
                paramNames.push(realEnableIGMPName);
                paramValues.push(valenableIGMP);
                paramTypes.push(realEnableIGMPType);
            }

            var realEnableIGMP = $("input[name='enableIGMPValue']").val();
            if (toAdd == 'false' && valenableIGMP != realEnableIGMP) {
                isChanged = true;
                paramNames.push(realEnableIGMPName);
                paramValues.push(valenableIGMP);
                paramTypes.push(realEnableIGMPType);
            }
            //-----------------end IGMP---------------------------------

            //-------------------PING-------------------------------
            // var enablePING = $("input[name='enablePing']");
            // var valenablePING = '';
            // if (enablePING.is(":checked")) {
            //     valenablePING = '1';
            // } else {
            //     valenablePING = '0';
            // }
            //
            // var realEnablePINGName = $("input[name='enablePingName']").val();
            // var realEnablePINGType = $("input[name='enablePingType']").val();
            //
            // if(toAdd == 'true' && valenablePING == '1'){
            //     paramNames.push(realEnablePINGName);
            //     paramValues.push(valenablePING);
            //     paramTypes.push(realEnablePINGType);
            // }
            //
            // var realEnablePING = $("input[name='enablePingValue']").val();
            // if (toAdd == 'false' && valenablePING != realEnablePING) {
            //     isChanged = true;
            //     paramNames.push(realEnablePINGName);
            //     paramValues.push(valenablePING);
            //     paramTypes.push(realEnablePINGType);
            // }
            //-----------------end PING---------------------------------


            //----------------EnableDns --------------------------------

            var enableDns = $("input[name='enableDns']");
            var realDnsName = $("input[name='primaryDnsName']").val();
            var realDnsType = $("input[name='primaryDnsType']").val();
            var realEnableDnsName = $("input[name='enableDnsName']").val();
            var realEnableDnsType = $("input[name='enableDnsType']").val();
            var valenableDns = '';

            if (enableDns.is(":checked")) {
//                            valenableDns = '1';
                valenableDns = '0';
                isChanged = true;
                paramNames.push(realEnableDnsName);
                paramValues.push(valenableDns);
                paramTypes.push(realEnableDnsType);
            } else {
//                            valenableDns = '0';
                valenableDns = '1';

                var msgRequired = getMssg['error_message_required'];
                var msgIp = getMssg['error_message_ip'];
                var msgMac = getMssg['error_message_mac'];
                var msgNetmask = getMssg['error_message_netmask'];
                var msgNumber = getMssg['error_message_number'];
                var msgDns = getMssg['error_message_dns'];
                var msgLe1400 = getMssg['error_message_le_1400'];
                var msgIpDNS = getMssg['error_message_ip_dns'];
                var msgGe1 = getMssg['error_message_ge_1'];
                var msgLe1540 = getMssg['error_message_le_1540'];
                //var msgLe1500 = getMssg['error_message_le_1500'];
                var msgLe1550 = getMssg['error_message_le_1550'];
                var msgDNSEquality = getMssg['error_message_dns_equality'];
                var msgOnlyNum = getMssg['error_message_digit_number'];
                var msgLe32 = getMssg['error_message_at_length_32'];
                var msgIp = getMssg['error_message_ip'];
                $("#forResetIPv6").validate({
                    rules: {
                        dWName: {
                            required: true,
                            validateConnectionNameLength: true
                        },
                        primaryDns:{
                            required: true,
                            // validateDNS : true,
                            invalidIPv6: true,
                            validateDNSEquality:{
                                primDns: "#primaryDns",
                                secondDns: "#secondaryDns"
                            }
                        },
                        secondaryDns:{
//                                        required: true,
//                                         validateDNS : true,
                            invalidIPv6: true,
//                                        validateDNSEquality:{
//                                            primDns: "#primaryDns",
//                                            secondDns: "#secondaryDns"
//                                        }
                        },
                        mac:{
                            required: true,
                            validateMac : {
                                siteType: '#siteType'
                            }
                        },
                        mtu: {
                            required: true,
                            number: true,
                            digits: true,
                            // min: 1400,
                            // max: 1550
                            min: 1,
                            //max: 1500,
                            max: 1540
                        },
                        Slaac: {
                            invalidIPv6: true,
                            required: true
                        }
                    },

                    messages: {
                        dWName: {
                            required: msgRequired,
                            validateConnectionNameLength: msgLe32
                        },
                        primaryDns: {
                            required: msgRequired,
                            // validateDNS: msgDns,
                            invalidIPv6: msgIp,
                            validateDNSEquality: msgDNSEquality
                        },
                        secondaryDns: {
//                                        required: msgRequired,
                            invalidIPv6: msgIp,
//                                         validateDNS: msgDns,
//                                        validateDNSEquality: msgDNSEquality
                        },
                        mac: {
                            required: msgRequired,
                            validateMac: msgMac
                        },
                        mtu: {
                            required: msgRequired,
                            number: msgNumber,
                            digits: msgOnlyNum,
                            min : msgGe1,
                            // min: msgLe1400,
                            // max: msgLe1550
                            max: msgLe1540
                        },
                        Slaac: {
                            invalidIPv6: msgIp,
                            required: msgRequired
                        }
                    },
                    errorElement: "div",
                    errorClass: 'error_messageLan',
                    errorPlacement: function(error, element) {
                        var placement = $(element).data('error');
                        if (placement) {
                            $(placement).append(error)
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });

                $('#primaryDns').on('input',function(e){
                    $("#secondaryDns").valid();
                });

                $('#primaryDns').on('change',function(e){
                    $("#secondaryDns").valid();
                });

                $('#secondaryDns').on('input',function(e){
                    $("#primaryDns").valid();
                });

                $('#secondaryDns').on('change',function(e){
                    $("#primaryDns").valid();
                });

                if(!($("#forResetIPv6").valid())) {
                    th.removeAttr("disabled");
//                                th.css("opacity", "1");
                    return false;
                }

                var realPrimDnsName = $("input[name='primaryDnsName']").val();
                var reaSecDnsName = $("input[name='secondaryDnsName']").val();
                var realDnsType = $("input[name='primaryDnsType']").val();
                var dns = $("input[name='primaryDns']").val().trim();
                var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                var secondaryDns = $("input[name='secondaryDns']").val().trim();
                var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                    isChanged = true;
                    if(secondaryDns != realSecondaryDns && secondaryDns != ''){
                        paramNames.push(realPrimDnsName);
                        paramNames.push(reaSecDnsName);
                        paramValues.push(dns);
                        paramValues.push(secondaryDns);
                        paramTypes.push(realDnsType);
                        paramTypes.push(realDnsType);
                    }else if(secondaryDns != ''){
                        paramNames.push(realPrimDnsName);
                        paramNames.push(reaSecDnsName);
                        paramValues.push(dns);
                        paramValues.push(secondaryDns);
                        paramTypes.push(realDnsType);
                        paramTypes.push(realDnsType);
                    }
                    isChanged = true;
                    paramNames.push(realEnableDnsName);
                    paramValues.push(valenableDns);
                    paramTypes.push(realEnableDnsType);
                }
            }

            // var realEnableDns = $("input[name='enableDnsValue']").val();
            // if (valenableDns != realEnableDns) {
            //     isChanged = true;
            //     paramNames.push(realEnableDnsName);
            //     paramValues.push(valenableDns);
            //     paramTypes.push(realEnableDnsType);
            // }
            //
            //-----------EnableDns end ---------------------------------


            var msgRequired = getMssg['error_message_required'];
            var msgIp = getMssg['error_message_ip'];
            var msgMac = getMssg['error_message_mac'];
            var msgNetmask = getMssg['error_message_netmask'];
            var msgNumber = getMssg['error_message_number'];
            var msgGe1 = getMssg['error_message_ge_1'];
            // var msgLe1540 = getMssg['error_message_le_1540'];
            var msgLe1500 = getMssg['error_message_le_1500'];
            var msgLe1550 = getMssg['error_message_le_1550'];
            var msgIp = getMssg['error_message_ip'];

            $("#forResetIPv6").validate({
                rules: {
                    mac:{
                        required: true,
                        validateMac : {
                            siteType: '#siteType'
                        }
                    },
                    mtu: {
                        required: true,
                        number: true,
                        digits: true,
                        min: 1,
                        // min: 1400,
                        // max: 1550
                        //max: 1500
                        max: 1540
                    },
                    Slaac: {
                        invalidIPv6: true,
                        required: true
                    }
                },

                messages: {
                    mac: {
                        required: msgRequired,
                        validateMac: msgMac
                    },
                    mtu: {
                        required: msgRequired,
                        number: msgNumber,
                        digits: msgOnlyNum,
                        min : msgGe1,
                        // min: msgLe1400,
                        max: msgLe1540
                        // max: msgLe1550
                    },
                    Slaac: {
                        invalidIPv6: msgIp,
                        required: msgRequired
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });

            if(!($("#forResetIPv6").valid())) {
                th.removeAttr("disabled");
//                            th.css("opacity", "1");
                return false;
            }


            var mac = $("input[name='mac']");
            var realEndIPVal = $("input[name='macValue']").val().trim();
            if (mac.val().trim() != realEndIPVal) {
                isChanged = true;
                var realEndIPName = $("input[name='macName']").val();
                var realEndIPType = $("input[name='macType']").val();
                paramNames.push(realEndIPName);
                paramValues.push(mac.val().trim());
                paramTypes.push(realEndIPType);
            }

            //-------------------SLAAC-------------------------------
            var enableSLAAC = $("input[name='enableSlaac']");
            var valenableSLAAC = '';
            if (enableSLAAC.is(":checked")) {
                valenableSLAAC = '1';
            } else {
                valenableSLAAC = '0';
            }

            var realEnableSLAACName = $("input[name='enableSlaacName']").val();
            var realEnableSLAACType = $("input[name='enableSlaacType']").val();

            if(toAdd == 'true'){
                paramNames.push(realEnableSLAACName);
                paramValues.push(valenableSLAAC);
                paramTypes.push(realEnableSLAACType);
            }

            var realEnableSLAAC = $("input[name='enableSlaacValue']").val();
            if (toAdd == 'false' && valenableSLAAC != realEnableSLAAC) {
                isChanged = true;
                paramNames.push(realEnableSLAACName);
                paramValues.push(valenableSLAAC);
                paramTypes.push(realEnableSLAACType);
            }

            var slaac = $("input[name='Slaac']").val().trim();
            var realslaacVal = $("input[name='SlaacValue']").val().trim();
            var realslaacName = $("input[name='SlaacName']").val();
            var realslaacType = $("input[name='SlaacType']").val();
            if (slaac != realslaacVal) {
                isChanged = true;
                paramNames.push(realslaacName);
                paramValues.push(slaac);
                paramTypes.push(realslaacType);
            }
            //-----------SLAAC end ---------------------------------


            var enable = $("input[name='enable']");
            var valEnable = '';
            if (enable.is(":checked")) {
                valEnable = '1';
            } else {
                valEnable = '0';
            }

            var realEnableName = $("input[name='enableName']").val();
            var realEnableType = $("input[name='enableType']").val();

            if(toAdd == 'true'){
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);
            }

            var realEnable = $("input[name='enableValue']").val();
            if (toAdd == 'false' && valEnable != realEnable) {
                isChanged = true;
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);
            }

            //                            default conn//
//                        var defconn = $("input[name='defconn']");
//                        var valdefcon = '';
//                        if (defconn.is(":checked")) {
//                            valdefcon = '1';
//                        } else {
//                            valdefcon = '0';
//                        }
//
//                        var realdefconName = $("input[name='defconName']").val();
//                        var realdefconType = $("input[name='defconType']").val();
//                        var realdefcon = $("input[name='defconValue']").val();
            var isChecket = false;

//                        if(toAdd == 'true' && valdefcon == '1'){
////                            paramNames.push(realdefconName);
////                            paramValues.push(realdefcon);
////                            paramTypes.push(realdefconType);
//                            isChecket = true;
//                        }

            //                    if (valdefcon != realdefcon && valdefcon == '1') {
            //                        isChanged = true;
            //
            //                    }else if (valdefcon != realdefcon && valdefcon == '0') {
            //                            isChanged = true;
            //                            paramNames.push(realdefconName);
            //                            paramValues.push(valdefcon);
            //                            paramTypes.push(realdefconType);
            //                        }
            //}

            var interfaceType = $("#interfaceType option:selected").val();
//                        var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                        var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                        if (interfaceType != realinterfaceType) {
//                            isChanged = true;
//                            var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                            paramNames.push(realInterfaceTypeName);
//                            paramValues.push(interfaceType);
//                            paramTypes.push(realInterfaceTypeType);
//                        }

            var having = $("input[name='having']").val();
            if (paramNames.length != 0 && isValid && isChanged) {
                var index = $("input[name='index']").val();
                var connect_index = $("input[name='connect_index']").val();
                var id_conn = $("input[name='id_conn']").val();
                var flagl = $("input[name='flagl']").val();
                var actionName;
                if(interfaceType == '-1'){
                    actionName = flagl == "addDynamicIPv6Wan" ? "addDynamicWan" : "setDynamicWanIPv6";
                }else{
                    actionName = "addDynamicWan";
                    index = '%d';
                }

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDevice.php",
                    data: {
                        'deviceID': devId,
                        'serialNumber': serialN,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if(result==1) {
                            haveConnection = true;
                        } else {
                            haveConnection = false;
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });

                if(haveConnection==true && actionName == "addDynamicWan") {
                    var titleMsg = getMssg['title_msg'];
                    var rmMsg = getMssg['change_msg'];
                    var cancelMsg = getMssg['cancel'];
                    var msgOff = getMssg['removeConnection'];

                    // swal({
                    //     title: titleMsg,
                    //     text: msgOff,
                    //     showCancelButton: true,
                    //     closeOnConfirm: true,
                    //     confirmButtonText: rmMsg,
                    //     cancelButtonText: cancelMsg,
                    //     confirmButtonColor: "#008DA9"
                    // }, function (isConfirm) {
                    //     if (isConfirm) {
                            if($('#refreshButton').css('display') == 'none') {
                                addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamicIPv6');
                            } else {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                swal({
                                    title: titleMsg,
                                    text: msgOffOn,
                                    showCancelButton: true,
                                    closeOnConfirm: true,
                                    confirmButtonText: rmMsg,
                                    cancelButtonText: cancelMsg,
                                    confirmButtonColor: "#008DA9"
                                }, function (isConfirm) {
                                    if (isConfirm) {
                                        addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamicIPv6');
                                    } else {
                                        th.removeAttr("disabled");
                                    }
                                });
                            }
                        // } else {
                        //     th.removeAttr("disabled");
                        // }
                    // });
                } else {
                    if($('#refreshButton').css('display') == 'none') {
                        if(actionName == "addDynamicWan") {
                            addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having, 'dynamicIPv6');
                        } else if(actionName == "setDynamicWanIPv6") {
                            editDynamicWan(devId,id_conn, index, connect_index, paramNames, paramValues,paramTypes, actionName, having, 'dynamicIPv6')
                        }
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                if(actionName == "addDynamicWan") {
                                    addDynamicWan(devId, isChecket, index, connect_index, paramNames, paramValues,paramTypes, interfaceType, actionName, having);
                                } else if(actionName == "setDynamicWanIPv6") {
                                    editDynamicWan(devId, id_conn, index, connect_index, paramNames, paramValues,paramTypes, actionName, having)
                                }
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }

                }
            } else if (isValid && !isChanged) {
                $('body').css("cursor", "default");
                var failed = getMssg["nothing_changed"];
                $("#actionResWan").removeClass("infoMessage");
                $("#actionResWan").addClass("errorMessage");
                $("#actionResWan").empty();
                $("#actionResWan").html(failed);
                th.removeAttr("disabled");
//                                    th.css("opacity", "1");
            } else {
                $('body').css("cursor", "default");
                th.removeAttr("disabled");
//                                    th.css("opacity", "1");
                $("#actionRes").empty();
            }
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").html(msg);
            //                 $('body').css("cursor", "default");
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 5000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });




//    $(document).on("click","#cancelDynamicWan",function(e){
//        $("#forReset").validate().resetForm();
//    });
//--------------------------end wanDynamic.php----------------------------------

//-------------------------- wanStatic.php -------------------------------------

    $(document).on("click", "#addStaticWan", function (e) {
        e.preventDefault();
        var th = $(this);
        var haveConnection = false;
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
//            $('body').css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {
                        var msgRequired = getMssg['error_message_required'];
                        var msgIp = getMssg['error_message_ip'];
                        var msgDns = getMssg['error_message_dns'];
                        var msgMac = getMssg['error_message_mac'];
                        var msgNetmask = getMssg['error_message_netmask'];
                        var msgNumber = getMssg['error_message_number'];
                        var msgIpGatewayIps = getMssg['error_message_ip_gateway_based_on_netmask'];
                        var msgGe1 = getMssg['error_message_ge_1'];
                        var msgLe1540 = getMssg['error_message_le_1540'];
                        var msgLe1500 = getMssg['error_message_le_1500'];
                        var msgLe1550 = getMssg['error_message_le_1550'];
                        var msgDNSEquality = getMssg['error_message_dns_equality'];
                        var msgLe1400 = getMssg['error_message_le_1400'];
                        var msgOnlyNum = getMssg['error_message_digit_number'];
                        var msgNetAddress =getMssg['error_message_net_address'];
                        var msgIpGateway = getMssg['error_message_ip_gateway'];
                        var msgLe32 = getMssg['error_message_at_length_32'];
                        var msgIpDNS = getMssg['error_message_ip_dns'];

                        $("#forReset").validate({
                            rules: {

                                dWName: {
                                    required: true,
                                    validateConnectionNameLength: true
                                },

                                ip: {
                                    required: true,
                                    validateIpAddress : true,
                                        validateStartEndIpBasedOnNetMask: {
                                            from : "#ip",
                                            to : "#gateway",
                                            netmask: "#netmask_wan"
                                        },
                                    validateNetworkAddress: {
                                        ip : "#ip",
                                        netmask: "#netmask_wan"
                                    }
                                },
                                netmask_wan: {
                                    required: true,
                                    validateIpAddress : true,
                                    validateNetMask : true
                                },
                                gateway:{
                                    required: true,
                                    validateIpAddress : true,
                                        validateStartEndIpBasedOnNetMask: {
                                            from : "#ip",
                                            to : "#gateway",
                                            netmask: "#netmask_wan"
                                        },
                                    validateNetworkAddress: {
                                        ip : "#gateway",
                                        netmask: "#netmask_wan"
                                    },
                                    ipAddressIsEqual: {
                                        ip : "#ip",
                                        gateway : "#gateway"
                                    }
                                },
                                primaryDns:{
                                    required: true,
                                    validateIpAddress : true,
                                    // validateDNS : true,
                                    validateDNSEquality:{
                                            primDns: "#primaryDns",
                                            secondDns: "#secondaryDns"
                                    }
                                },
                                secondaryDns:{
                                    validateIpAddress : true,
//                                        required: true,
//                                         validateDNS : true,
//                                        validateDNSEquality:{
//                                            primDns: "#primaryDns",
//                                            secondDns: "#secondaryDns"
//                                        }
                                    },
                                mac:{
                                    required: true,
                                    validateMac : {
                                        siteType: '#siteType'
                                    }
                                },
				mtu: {
				    required: true,
				    number: true,
                    digits: true,
				    min: 1,
                    // min: 1400,
                    // max: 1550
				    max: 1540
                    //max: 1500
				}
                            },

                            messages: {
                                dWName: {
                                    required: msgRequired,
                                    validateConnectionNameLength: msgLe32
                                },
                                ip: {
                                    required: msgRequired,
                                    validateIpAddress: msgIp,
                                    validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                                    validateNetworkAddress: msgNetAddress
                                },
                                netmask_wan: {
                                    required: msgRequired,
                                    validateIpAddress: msgIp,
                                    validateNetMask: msgNetmask
                                },
                                gateway: {
                                    required: msgRequired,
                                    validateIpAddress: msgIp,
                                    validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                                    validateNetworkAddress: msgNetAddress,
                                    ipAddressIsEqual: msgIpGateway
                                },
                                primaryDns: {
                                    required: msgRequired,
                                    validateIpAddress : msgIpDNS,
                                    // validateDNS: msgDns,
                                    validateDNSEquality: msgDNSEquality
                                },
                                secondaryDns: {
                                    validateIpAddress : msgIpDNS,
//                                        required: msgRequired,
//                                         validateDNS: msgDns,
//                                        validateDNSEquality: msgDNSEquality
                                },
                                mac: {
                                    required: msgRequired,
                                    validateMac: msgMac
                                },
				mtu: {
				    required: msgRequired,
				    number: msgNumber,
                    digits: msgOnlyNum,
				    min : msgGe1,
                    // min: msgLe1400,
                    max: msgLe1540
				    // max: msgLe1550
				}
                            },
                            errorElement: "div",
                            errorClass: 'error_messageLan',
                            errorPlacement: function(error, element) {
                                var placement = $(element).data('error');
                                if (placement) {
                                    $(placement).append(error)
                                } else {
                                    error.insertAfter(element);
                                }
                            }
                        });

                        $('#ip').on('input',function(e){
                            $("#gateway").valid();
                            $("#netmask_wan").valid();
                        });
                        $('#ip').on('change',function(e){
                            $("#gateway").valid();
                            $("#netmask_wan").valid();
                        });

                        $('#gateway').on('input',function(e){
                            $("#ip").valid();
                            $("#netmask_wan").valid();
                        });
                        $('#gateway').on('change',function(e){
                            $("#ip").valid();
                            $("#netmask_wan").valid();
                        });

                        $('#netmask_wan').on('input',function(e){
                            $("#ip").valid();
                            $("#gateway").valid();
                        });
                        
                        $('#netmask_wan').on('change',function(e){
                            $("#ip").valid();
                            $("#gateway").valid();
                        });
                        
                        $('#primaryDns').on('input',function(e){
                            $("#secondaryDns").valid();
                        });

                        $('#primaryDns').on('change',function(e){
                            $("#secondaryDns").valid();
                        });

                        $('#secondaryDns').on('input',function(e){
                            $("#primaryDns").valid();
                        });

                        $('#secondaryDns').on('change',function(e){
                            $("#primaryDns").valid();
                        });
                        
                        if(!($("#forReset").valid())) {
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            return false;
                        }
                    
                        var paramNames = [];
                        var paramValues = [];
                        var paramTypes = [];
                        var isValid = true;
                        var isChanged = false;
                        var toAdd = $("input[name='toAdd']").val();
                        var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
                        var wanNameType = document.getElementsByName("dWNameType")[0].value;
                        var wanNameNew = "";
                        var ipAddr = $("input[name='ip']");

                        wanNameNew = document.getElementsByName("dWName")[0].value;
                        if (wanNameOld !== wanNameNew) {
                            paramNames.push("Name");
                            paramValues.push(wanNameNew);
                            paramTypes.push(wanNameType);
                            isChanged = true;
                        }
                        var realIpAddressVal = $("input[name='ipValue']").val();
                        if (ipAddr.val().trim() != realIpAddressVal.trim()) {
                            ipAddr.removeClass("invalidVal");
                            isChanged = true;
                            var realIpAddressName = $("input[name='ipName']").val();
                            var realIpAddressType = $("input[name='ipType']").val();
                            paramNames.push(realIpAddressName);
                            paramValues.push(ipAddr.val());
                            paramTypes.push(realIpAddressType);
                        }
                        
                        var netmask = $("input[name='netmask_wan']");
                        var realNetmaskVal = $("input[name='netmaskValue']").val();
                        if (netmask.val().trim() != realNetmaskVal.trim()) {
                            netmask.removeClass("invalidVal");
                            isChanged = true;
                            var realNetmaskName = $("input[name='netmaskName']").val();
                            var realNetmaskType = $("input[name='netmaskType']").val();
                            paramNames.push(realNetmaskName);
                            paramValues.push(netmask.val());
                            paramTypes.push(realNetmaskType);
                        }

                        var mtu = $("input[name='mtu']");
                        var mtuVal = mtu.val().trim();
                        var realStartIPVal = $("input[name='mtuValue']").val().trim();
                            if (toAdd == 'false' && mtuVal != realStartIPVal) {
                                if (isNumber(mtuVal)) {
                                    isChanged = true;
                                    mtu.removeClass("invalidVal");
                                    var realStartIPName = $("input[name='mtuName']").val();
                                    var realStartIPType = $("input[name='mtuType']").val();
                                    paramNames.push(realStartIPName);
                                    paramValues.push(mtuVal);
                                    paramTypes.push(realStartIPType);
                                } else {
                                    mtu.addClass("invalidVal");
                                    isValid = false;
                                }
                            }
                                
                        if(toAdd == 'true'){
                            if (isNumber(mtuVal)) {
                                isChanged = true;
                                mtu.removeClass("invalidVal");
                                var realStartIPName = $("input[name='mtuName']").val();
                                var realStartIPType = $("input[name='mtuType']").val();
                                paramNames.push(realStartIPName);
                                paramValues.push(mtuVal);
                                paramTypes.push(realStartIPType);
                            } else {
                                mtu.addClass("invalidVal");
                                isValid = false;
                            }
                        }

                        var mac = $("input[name='mac']");
                        var realEndIPVal = $("input[name='macValue']").val().trim();
                        if (mac.val().trim() != realEndIPVal.trim()) {
                            isChanged = true;
                            mac.removeClass("invalidVal");
                            var realEndIPName = $("input[name='macName']").val();
                            var realEndIPType = $("input[name='macType']").val();
                            paramNames.push(realEndIPName);
                            paramValues.push(mac.val().trim());
                            paramTypes.push(realEndIPType);
                        }

                        var gateway = $("input[name='gateway']");
                        var realLeaseTimeVal = $("input[name='gatewayValue']").val().trim();
                        if (gateway.val().trim() != realLeaseTimeVal) {
                            gateway.removeClass("invalidVal");
                            isChanged = true;
                            gateway.removeClass("invalidVal");
                            var realLeaseTimeName = $("input[name='gatewayName']").val();
                            var realDhcpLeaseTimeType = $("input[name='gatewayType']").val();
                            paramNames.push(realLeaseTimeName);
                            paramValues.push(gateway.val().trim());
                            paramTypes.push(realDhcpLeaseTimeType);
                        }
                        
                        var realDnsName = $("input[name='primaryDnsName']").val();
                        var realDnsType = $("input[name='primaryDnsType']").val();
                        var dns = $("input[name='primaryDns']").val().trim();
                        var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                        var secondaryDns = $("input[name='secondaryDns']").val().trim();
                        var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                        if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                            isChanged = true;
                            if(secondaryDns != realSecondaryDns && secondaryDns != ''){
                                paramNames.push(realDnsName);
                                paramValues.push(dns + ',' + secondaryDns);
                                paramTypes.push(realDnsType);
                            }else if(secondaryDns != ''){
                                paramNames.push(realDnsName);
                                paramValues.push(dns + ',' + secondaryDns);
                                paramTypes.push(realDnsType);
                            }else{
                                paramNames.push(realDnsName);
                                paramValues.push(dns);
                                paramTypes.push(realDnsType);
                            }
                        }

                        var enablePING = $("input[name='enablePing']");
                        var valenablePING = '';
                        if (enablePING.is(":checked")) {
                            valenablePING = '1';
                        } else {
                            valenablePING = '0';
                        }

                        var realEnablePINGName = $("input[name='enablePingName']").val();
                        var realEnablePINGType = $("input[name='enablePingType']").val();

                        if(toAdd == 'true' && valenablePING == '1'){
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }

                        var realEnablePING = $("input[name='enablePingValue']").val();
                        if (toAdd == 'false' && valenablePING != realEnablePING) {
                            isChanged = true;
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }

                            var enableNat = $("input[name='enableNat']");
                            var valenableNat = '';
                            if (enableNat.is(":checked")) {
                                valenableNat = '1';
                            } else {
                                valenableNat = '0';
                            }
                            var realEnableNatName = $("input[name='enableNatName']").val();
                            var realEnableNatType = $("input[name='enableNatType']").val();

                            if(toAdd == 'true' && valenableNat == '1'){
                                paramNames.push(realEnableNatName);
                                paramValues.push(valenableNat);
                                paramTypes.push(realEnableNatType);
                            }

                            var realEnableNat = $("input[name='enableNatValue']").val();
                            if (toAdd == 'false' && valenableNat != realEnableNat) {
                                isChanged = true;
                                paramNames.push(realEnableNatName);
                                paramValues.push(valenableNat);
                                paramTypes.push(realEnableNatType);
                            }

                            var enable = $("input[name='enable']");
                            var valEnable = '';
                            if (enable.is(":checked")) {
                                valEnable = '1';
                            } else {
                                valEnable = '0';
                            }
                            var realEnableName = $("input[name='enableName']").val();
                            var realEnableType = $("input[name='enableType']").val();

                            if(toAdd == 'true'){
                                paramNames.push(realEnableName);
                                paramValues.push(valEnable);
                                paramTypes.push(realEnableType);
                            }

                            var realEnable = $("input[name='enableValue']").val();
                            if (toAdd == 'false' && valEnable != realEnable) {
                                isChanged = true;
                                paramNames.push(realEnableName);
                                paramValues.push(valEnable);
                                paramTypes.push(realEnableType);
                            }

                            //----------------- IGMP -------------------------------
                            var enableIGMP = $("input[name='enableIGMP']");
                            var valenableIGMP = '';
                            if (enableIGMP.is(":checked")) {
                                valenableIGMP = '1';
                            } else {
                                valenableIGMP = '0';
                            }
                            var realEnableIGMPName = $("input[name='enableIGMPName']").val();
                            var realEnableIGMPType = $("input[name='enableIGMPType']").val();

                            if(toAdd == 'true' && valenableIGMP == '1'){
                                paramNames.push(realEnableIGMPName);
                                paramValues.push(valenableIGMP);
                                paramTypes.push(realEnableIGMPType);
                            }

                            var realEnableIGMP = $("input[name='enableIGMPValue']").val();
                            if (toAdd == 'false' && valenableIGMP != realEnableIGMP) {
                                isChanged = true;
                                paramNames.push(realEnableIGMPName);
                                paramValues.push(valenableIGMP);
                                paramTypes.push(realEnableIGMPType);
                            }

                        //----------------- default connection------------------
//                            var defconn = $("input[name='defconn']");
//                            var valdefcon = '';
//                            if (defconn.is(":checked")) {
//                                valdefcon = '1';
//                            } else {
//                                valdefcon = '0';
//                            }
//
//                            var realdefconName = $("input[name='defconName']").val();
//                            var realdefconType = $("input[name='defconType']").val();
//                            var realdefconVal = $("input[name='defconValue']").val();
                            var isChecket = false;
//                            
//                            if(toAdd == 'true' && valdefcon == '1'){
////                                paramNames.push(realdefconName);
////                                paramValues.push(realdefconVal);
////                                paramTypes.push(realdefconType);
//                                isChecket = true;                            
//                            }

    //                        var realdefcon = $("input[name='defconValue']").val();
    //                        if (valdefcon != realdefcon) {
    //                            isChanged = true;
    //                            paramNames.push(realdefconName);
    //                            paramValues.push(realdefcon);
    //                            paramTypes.push(realdefconType);
    //                        }
                            //------------------------------------------------------  

                            var interfaceType = $("#interfaceType option:selected").val();
//                            var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                            if (interfaceType != realinterfaceType) {
//                                isChanged = true;
//                                var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                                var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                                paramNames.push(realInterfaceTypeName);
//                                paramValues.push(interfaceType);
//                                paramTypes.push(realInterfaceTypeType);
//                            }

//                            }
//                        }

                        var having = $("input[name='having']").val();
                        if (paramNames.length != 0 && isValid && isChanged) {
                            var index = $("input[name='index']").val();
                            var connect_index = $("input[name='connect_index']").val();
                            var id_conn = $("input[name='id_conn']").val();
                            var flagl = $("input[name='flagl']").val();
                            var actionName;
                            if(interfaceType == '-1'){
                                actionName = flagl == "addStaticWan" ? "addStaticWan" : "setStaticWan";
                            }else{
                                actionName = "addStaticWan";
                                index = '%d';
                            }

                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDevice.php",
                                data: {
                                    'deviceID': devId,
                                    'serialNumber': serialN,
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if(result==1) {
                                        haveConnection = true;
                                    } else {
                                        haveConnection = false;
                                    }
                                },
                                error: function(xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });

                            if(haveConnection==true && actionName == "addStaticWan") {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOff = getMssg['removeConnection'];

                                // swal({
                                //     title: titleMsg,
                                //     text: msgOff,
                                //     showCancelButton: true,
                                //     closeOnConfirm: true,
                                //     confirmButtonText: rmMsg,
                                //     cancelButtonText: cancelMsg,
                                //     confirmButtonColor: "#008DA9"
                                // }, function (isConfirm) {
                                //     if (isConfirm) {
                                        if($('#refreshButton').css('display') == 'none') {
                                            addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'static');
                                        } else {
                                            var titleMsg = getMssg['title_msg'];
                                            var rmMsg = getMssg['change_msg'];
                                            var cancelMsg = getMssg['cancel'];
                                            var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                            swal({
                                                title: titleMsg,
                                                text: msgOffOn,
                                                showCancelButton: true,
                                                closeOnConfirm: true,
                                                confirmButtonText: rmMsg,
                                                cancelButtonText: cancelMsg,
                                                confirmButtonColor: "#008DA9"
                                            }, function (isConfirm) {
                                                if (isConfirm) {
                                                    addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'static');
                                                } else {
                                                    th.removeAttr("disabled");
                                                }
                                            });
                                        }
                                //     } else {
                                //         th.removeAttr("disabled");
                                //     }
                                // });
                            } else {
                                if ($('#refreshButton').css('display') == 'none') {
                                    if(actionName == "addStaticWan") {
                                        addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'static');
                                    } else if(actionName == "setStaticWan") {
                                        editStaticWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionName, having);
                                    }
                                } else {
                                    var titleMsg = getMssg['title_msg'];
                                    var rmMsg = getMssg['change_msg'];
                                    var cancelMsg = getMssg['cancel'];
                                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                    swal({
                                        title: titleMsg,
                                        text: msgOffOn,
                                        showCancelButton: true,
                                        closeOnConfirm: true,
                                        confirmButtonText: rmMsg,
                                        cancelButtonText: cancelMsg,
                                        confirmButtonColor: "#008DA9"
                                    }, function (isConfirm) {
                                        if (isConfirm) {
                                            if(actionName == "addStaticWan") {
                                                addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'static');
                                            } else if(actionName == "setStaticWan") {
                                                editStaticWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionName, having);
                                            }
                                        } else {
                                            th.removeAttr("disabled");
                                        }
                                    });
                                }
                            }

                        } else if (isValid && !isChanged) {
                                $('body').css("cursor", "default");
                                var failed = getMssg["nothing_changed"];
                                $("#actionResWan").removeClass("infoMessage");
                                $("#actionResWan").addClass("errorMessage");
                                $("#actionResWan").empty();
                                $("#actionResWan").html(failed);
                                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                        } else {
                            $('body').css("cursor", "default");
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            $("#actionRes").empty();
                        }
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").empty();
            //                 $("#actionResWan").html(msg);
            //                 $('body').css("cursor", "default");
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });


    $(document).on("click", "#addStaticWanIpv6", function (e) {
        e.preventDefault();
        var th = $(this);
        var haveConnection = false;
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");

            var msgRequired = getMssg['error_message_required'];
            var msgIp = getMssg['error_message_ip'];
            var msgDns = getMssg['error_message_dns'];
            var msgMac = getMssg['error_message_mac'];
            var msgNumber = getMssg['error_message_number'];
            // var msgIpGatewayIps = getMssg['error_message_ip_gateway_based_on_netmask'];
            var msgGe1 = getMssg['error_message_ge_1'];
            var msgLe1540 = getMssg['error_message_le_1540'];
            var msgLe1550 = getMssg['error_message_le_1550'];
            var msgDNSEquality = getMssg['error_message_dns_equality'];
            var msgLe1400 = getMssg['error_message_le_1400'];
            var msgOnlyNum = getMssg['error_message_digit_number'];
            // var msgNetAddress =getMssg['error_message_net_address'];
            var msgIpGateway = getMssg['error_message_ip_gateway'];
            var msgLe32 = getMssg['error_message_at_length_32'];
            var msgIpDNS = getMssg['error_message_ipv6_dns'];
            var prefixOutOfReang = getMssg["prefix_msg"];


            $("#forResetIPv6").validate({
                rules: {

                    dWName: {
                        required: true,
                        validateConnectionNameLength: true
                    },

                    ipV6: {
                        required: true,
                        invalidIPv6: true,
                        // validateStartEndIpBasedOnNetMask: {
                        //     from : "#ip",
                        //     to : "#gateway",
                        //     netmask: "#netmask_wan"
                        // },
                        // validateNetworkAddress: {
                        //     ip : "#ip",
                        //     netmask: "#netmask_wan"
                        // }
                    },
                    prefix_wanIPv6: {
                        required: true,
                        number: true,
                        invalidPrefix: true,
                        min: 64
                    },
                    gatewayIPv6:{
                        required: true,
                        invalidIPv6 : true,
                        validateEqualIPv6: {
                            ip : "#ipV6",
                            gateway : "#gatewayIPv6"
                        }
                    },
                    primaryDnsIPv6:{
                        required: true,
                        invalidIPv6 : true,
                        // validateDNS : true,
                        validateDNSEquality:{
                            primDns: "#primaryDnsIPv6",
                            secondDns: "#secondaryDnsIPv6"
                        }
                    },
                    secondaryDnsIPv6:{
                        invalidIPv6 : true,
                    },
                    macIPv6:{
                        required: true,
                        validateMac : {
                            siteType: '#siteType'
                        }
                    },
                    mtuIPv6: {
                        required: true,
                        number: true,
                        digits: true,
                        min: 1,
                        // min: 1400,
                        // max: 1550
                        max: 1540
                        //max: 1500
                    }
                },

                messages: {
                    dWName: {
                        required: msgRequired,
                        validateConnectionNameLength: msgLe32
                    },
                    ipV6: {
                        required: msgRequired,
                        invalidIPv6: msgIp,
                        // validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                        // validateNetworkAddress: msgNetAddress
                    },
                    prefixIPv6: {
                        required: msgRequired,
                        invalidPrefix: prefixOutOfReang,
                        number: msgNumber,
                        min: prefixOutOfReang
                    },
                    gatewayIPv6: {
                        required: msgRequired,
                        invalidIPv6: msgIp,
                        // validateStartEndIpBasedOnNetMask: msgIpGatewayIps,
                        // validateNetworkAddress: msgNetAddress,
                        validateEqualIPv6: msgIpGateway
                    },
                    primaryDnsIPv6: {
                        required: msgRequired,
                        invalidIPv6 : msgIpDNS,
                        // validateDNS: msgDns,
                        validateDNSEquality: msgDNSEquality
                    },
                    secondaryDnsIPv6: {
                        invalidIPv6 : msgIpDNS,
//                                        required: msgRequired,
//                                         validateDNS: msgDns,
//                                        validateDNSEquality: msgDNSEquality
                    },
                    macIPv6: {
                        required: msgRequired,
                        validateMac: msgMac
                    },
                    mtuIPv6: {
                        required: msgRequired,
                        number: msgNumber,
                        digits: msgOnlyNum,
                        min : msgGe1,
                        // min: msgLe1400,
                        max: msgLe1540
                        // max: msgLe1550
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });

            $('#ipV6').on('input',function(e){
                $("#gatewayIPv6").valid();
            });
            $('#ipV6').on('change',function(e){
                $("#gatewayIPv6").valid();
            });

            $('#gatewayIPv6').on('input',function(e){
                $("#ipV6").valid();
            });
            $('#gatewayIPv6').on('change',function(e){
                $("#ipV6").valid();
            });

            $('#primaryDnsIPv6').on('input',function(e){
                $("#secondaryDnsIPv6").valid();
            });

            $('#primaryDnsIPv6').on('change',function(e){
                $("#secondaryDnsIPv6").valid();
            });

            $('#secondaryDnsIPv6').on('input',function(e){
                $("#primaryDnsIPv6").valid();
            });

            $('#secondaryDnsIPv6').on('change',function(e){
                $("#primaryDnsIPv6").valid();
            });

            if(!($("#forResetIPv6").valid())) {
                th.removeAttr("disabled");
//                            th.css("opacity", "1");
                return false;
            }

            var paramNames = [];
            var paramValues = [];
            var paramTypes = [];
            var isValid = true;
            var isChanged = false;
            var toAdd = $("input[name='toAdd']").val();
            var wanNameOld = document.getElementsByName("dWNameCurr")[0].value;
            var wanNameType = document.getElementsByName("dWNameType")[0].value;
            var wanNameNew = "";
            var ipAddr = $("input[name='ipV6']");
            var prefix = $("input[name='prefix_wanIPv6']");

            wanNameNew = document.getElementsByName("dWName")[0].value;
            if (wanNameOld !== wanNameNew) {
                paramNames.push("Name");
                paramValues.push(wanNameNew);
                paramTypes.push(wanNameType);
                isChanged = true;
            }
            var realIpAddressVal = $("input[name='ipV6Value']").val();
            var realPrefixVal = $("input[name='prefixIPv6Value']").val();
            if (ipAddr.val() != realIpAddressVal || prefix.val() != realPrefixVal) {
                ipAddr.removeClass("invalidVal");
                isChanged = true;
                var realIpAddressName = $("input[name='ipV6Name']").val();
                var realIpAddressType = $("input[name='ipV6Type']").val();
                paramNames.push(realIpAddressName);
                paramValues.push(ipAddr.val() + "/" + prefix.val());
                paramTypes.push(realIpAddressType);

            }

            var mtu = $("input[name='mtuIPv6']");
            var mtuVal = mtu.val().trim();
            var realStartIPVal = $("input[name='mtuIPv6Value']").val().trim();
            if (toAdd == 'false' && mtuVal != realStartIPVal) {
                if (isNumber(mtuVal)) {
                    isChanged = true;
                    mtu.removeClass("invalidVal");
                    var realStartIPName = $("input[name='mtuIPv6Name']").val();
                    var realStartIPType = $("input[name='mtuIPv6Type']").val();
                    paramNames.push(realStartIPName);
                    paramValues.push(mtuVal);
                    paramTypes.push(realStartIPType);
                } else {
                    mtu.addClass("invalidVal");
                    isValid = false;
                }
            }

            if(toAdd == 'true'){
                if (isNumber(mtuVal)) {
                    isChanged = true;
                    mtu.removeClass("invalidVal");
                    var realStartIPName = $("input[name='mtuIPv6Name']").val();
                    var realStartIPType = $("input[name='mtuIPv6Type']").val();
                    paramNames.push(realStartIPName);
                    paramValues.push(mtuVal);
                    paramTypes.push(realStartIPType);
                } else {
                    mtu.addClass("invalidVal");
                    isValid = false;
                }
            }

            var mac = $("input[name='macIPv6']");
            var realEndIPVal = $("input[name='macIPv6Value']").val().trim();
            if (mac.val().trim() != realEndIPVal.trim()) {
                isChanged = true;
                mac.removeClass("invalidVal");
                var realEndIPName = $("input[name='macIPv6Name']").val();
                var realEndIPType = $("input[name='macIPv6Type']").val();
                paramNames.push(realEndIPName);
                paramValues.push(mac.val().trim());
                paramTypes.push(realEndIPType);
            }

            var gateway = $("input[name='gatewayIPv6']");
            var realLeaseTimeVal = $("input[name='gatewayIPv6Value']").val().trim();
            if (gateway.val().trim() != realLeaseTimeVal) {
                gateway.removeClass("invalidVal");
                isChanged = true;
                gateway.removeClass("invalidVal");
                var realLeaseTimeName = $("input[name='gatewayIPv6Name']").val();
                var realDhcpLeaseTimeType = $("input[name='gatewayIPv6Type']").val();
                paramNames.push(realLeaseTimeName);
                paramValues.push(gateway.val().trim());
                paramTypes.push(realDhcpLeaseTimeType);
            }

            var realPrimDnsName = $("input[name='primaryDnsIPv6Name']").val();
            var reaSecDnsName = $("input[name='secondaryDnsIPv6Name']").val();
            var realDnsType = $("input[name='primaryDnsIPv6Type']").val();
            var dns = $("input[name='primaryDnsIPv6']").val().trim();
            var realDnsVal = $("input[name='primaryDnsIPv6Value']").val().trim();
            var secondaryDns = $("input[name='secondaryDnsIPv6']").val().trim();
            var realSecondaryDns = $("input[name='secondaryDnsIPv6Value']").val().trim();
            if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                isChanged = true;
                if(secondaryDns != realSecondaryDns && secondaryDns != ''){
                    paramNames.push(realPrimDnsName);
                    paramNames.push(reaSecDnsName);
                    paramValues.push(dns);
                    paramValues.push(secondaryDns);
                    paramTypes.push(realDnsType);
                    paramTypes.push(realDnsType);
                }else if(secondaryDns != ''){
                    paramNames.push(realPrimDnsName);
                    paramNames.push(reaSecDnsName);
                    paramValues.push(dns);
                    paramValues.push(secondaryDns);
                    paramTypes.push(realDnsType);
                    paramTypes.push(realDnsType);
                }else{
                    paramNames.push(realPrimDnsName);
                    paramValues.push(dns);
                    paramTypes.push(realDnsType);
                }
            }
            //----------------- Ping -------------------------------
            // var enablePing = $("input[name='enablePing']");
            // var valenablePing = '';
            // if (enablePing.is(":checked")) {
            //     valenablePing = '1';
            // } else {
            //     valenablePing = '0';
            // }
            // var realEnablePingName = $("input[name='enablePingName']").val();
            // var realEnablePingType = $("input[name='enablePingType']").val();
            //
            // if(toAdd == 'true' && valenablePing == '1'){
            //     paramNames.push(realEnablePingName);
            //     paramValues.push(valenablePing);
            //     paramTypes.push(realEnablePingType);
            // }
            //
            // var realEnablePing = $("input[name='enablePingValue']").val();
            // if (toAdd == 'false' && valenablePing != realEnablePing) {
            //     isChanged = true;
            //     paramNames.push(realEnablePingName);
            //     paramValues.push(valenablePing);
            //     paramTypes.push(realEnablePingType);
            // }

            var enable = $("input[name='enable']");
            var valEnable = '';
            if (enable.is(":checked")) {
                valEnable = '1';
            } else {
                valEnable = '0';
            }
            var realEnableName = $("input[name='enableName']").val();
            var realEnableType = $("input[name='enableType']").val();

            if(toAdd == 'true'){
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);

            }

            var realEnable = $("input[name='enableValue']").val();
            if (toAdd == 'false' && valEnable != realEnable) {
                isChanged = true;
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);
            }

            //----------------- IGMP -------------------------------
            var enableIGMP = $("input[name='enableIGMP']");
            var valenableIGMP = '';
            if (enableIGMP.is(":checked")) {
                valenableIGMP = '1';
            } else {
                valenableIGMP = '0';
            }
            var realEnableIGMPName = $("input[name='enableIGMPName']").val();
            var realEnableIGMPType = $("input[name='enableIGMPType']").val();

            if(toAdd == 'true' && valenableIGMP == '1'){
                paramNames.push(realEnableIGMPName);
                paramValues.push(valenableIGMP);
                paramTypes.push(realEnableIGMPType);
            }

            var realEnableIGMP = $("input[name='enableIGMPValue']").val();
            if (toAdd == 'false' && valenableIGMP != realEnableIGMP) {
                isChanged = true;
                paramNames.push(realEnableIGMPName);
                paramValues.push(valenableIGMP);
                paramTypes.push(realEnableIGMPType);
            }

            //----------------- default connection------------------
//                            var defconn = $("input[name='defconn']");
//                            var valdefcon = '';
//                            if (defconn.is(":checked")) {
//                                valdefcon = '1';
//                            } else {
//                                valdefcon = '0';
//                            }
//
//                            var realdefconName = $("input[name='defconName']").val();
//                            var realdefconType = $("input[name='defconType']").val();
//                            var realdefconVal = $("input[name='defconValue']").val();
            var isChecket = false;
//
//                            if(toAdd == 'true' && valdefcon == '1'){
////                                paramNames.push(realdefconName);
////                                paramValues.push(realdefconVal);
////                                paramTypes.push(realdefconType);
//                                isChecket = true;
//                            }

            //                        var realdefcon = $("input[name='defconValue']").val();
            //                        if (valdefcon != realdefcon) {
            //                            isChanged = true;
            //                            paramNames.push(realdefconName);
            //                            paramValues.push(realdefcon);
            //                            paramTypes.push(realdefconType);
            //                        }
            //------------------------------------------------------

            var interfaceType = $("#interfaceType option:selected").val();
//                            var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                            if (interfaceType != realinterfaceType) {
//                                isChanged = true;
//                                var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                                var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                                paramNames.push(realInterfaceTypeName);
//                                paramValues.push(interfaceType);
//                                paramTypes.push(realInterfaceTypeType);
//                            }

//                            }
//                        }

            var having = $("input[name='having']").val();
            if (paramNames.length != 0 && isValid && isChanged) {
                var index = $("input[name='index']").val();
                var connect_index = $("input[name='connect_index']").val();
                var id_conn = $("input[name='id_conn']").val();
                var flagl = $("input[name='flagl']").val();
                var actionName;
                if(interfaceType == '-1'){
                    actionName = flagl == "addStaticIPv6Wan" ? "addStaticWan" : "setStaticIPv6Wan";
                }else{
                    actionName = "addStaticWan";
                    index = '%d';
                }


                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/getWANTabPageForDevice.php",
                    data: {
                        'deviceID': devId,
                        'serialNumber': serialN,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if(result==1) {
                            haveConnection = true;
                        } else {
                            haveConnection = false;
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });

                if(haveConnection==true && actionName == "addStaticWan") {
                    var titleMsg = getMssg['title_msg'];
                    var rmMsg = getMssg['change_msg'];
                    var cancelMsg = getMssg['cancel'];
                    var msgOff = getMssg['removeConnection'];

                    // swal({
                    //     title: titleMsg,
                    //     text: msgOff,
                    //     showCancelButton: true,
                    //     closeOnConfirm: true,
                    //     confirmButtonText: rmMsg,
                    //     cancelButtonText: cancelMsg,
                    //     confirmButtonColor: "#008DA9"
                    // }, function (isConfirm) {
                    //     if (isConfirm) {
                            if($('#refreshButton').css('display') == 'none') {
                                addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'staticIPv6');
                            } else {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                swal({
                                    title: titleMsg,
                                    text: msgOffOn,
                                    showCancelButton: true,
                                    closeOnConfirm: true,
                                    confirmButtonText: rmMsg,
                                    cancelButtonText: cancelMsg,
                                    confirmButtonColor: "#008DA9"
                                }, function (isConfirm) {
                                    if (isConfirm) {
                                        addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'staticIPv6');
                                    } else {
                                        th.removeAttr("disabled");
                                    }
                                });
                            }
                        // } else {
                        //     th.removeAttr("disabled");
                        // }
                    // });
                } else {
                    if ($('#refreshButton').css('display') == 'none') {
                        if(actionName == "addStaticWan") {
                            addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'staticIPv6');
                        } else if(actionName == "setStaticIPv6Wan") {
                            editStaticWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionName, having);
                        }
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                if(actionName == "addStaticWan") {
                                    addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,'staticIPv6');
                                } else if(actionName == "setStaticWan") {
                                    editStaticWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionName, having);
                                }
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }
                }
            } else if (isValid && !isChanged) {
                $('body').css("cursor", "default");
                var failed = getMssg["nothing_changed"];
                $("#actionResWan").removeClass("infoMessage");
                $("#actionResWan").addClass("errorMessage");
                $("#actionResWan").empty();
                $("#actionResWan").html(failed);
                th.removeAttr("disabled");
//                                th.css("opacity", "1");
            } else {
                $('body').css("cursor", "default");
                th.removeAttr("disabled");
//                            th.css("opacity", "1");
                $("#actionRes").empty();
            }
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").empty();
            //                 $("#actionResWan").html(msg);
            //                 $('body').css("cursor", "default");
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });


    function addStaticWan(devId, serialN, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionName,type){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionName,
                'deviceID': devId,
                'forWeb' : "",
                // 'defConnection': isChecket,
                // 'index': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'interface_type': interfaceType,
                'type': type,
                'token': token_cookie
                // 'having': having
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);

                } else if (result.result == 'false' || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result.result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

    function editStaticWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionName, having){
        if(id_conn == '') {
            id_conn = devId;
        }
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionName,
                'deviceID': devId,
                "forWeb" : "",
                // 'id': id_conn,
                'numIndex': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'having': having,
                'token': token_cookie
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);

                } else if (result.result == 'false' || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result.result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

    $(document).on("click","#cancelStaticWan",function(e){
        $("div.error_messageLan").remove(); 
	    $(".error_messageLan").removeClass("error");
        $(this).closest('form').get(0).reset();
//        $("#forReset").validate().resetForm();
    });
    
    $(document).on("click","#diagnostic",function(e){
        e.preventDefault();
        var th = $(this);
        if(th.hasClass("ready")){
//            th.removeClass("ready");
            th.attr('disabled','disabled');
            
            var failed = getMssg['action_failed'];
            var index = $("input[name='index']").val();
            var connect_index = $("input[name='connect_index']").val();
            var host = $("input[name='host']");
            var hostVal = host.val();
            var typeConn = '';
            
            var msgRequired = getMssg['error_message_required'];
            var msgIp = getMssg['error_message_ip'];
            var msgDns = getMssg['error_message_dns'];
            var msgMac = getMssg['error_message_mac'];
            var msgNetmask = getMssg['error_message_netmask'];
            var msgNumber = getMssg['error_message_number'];

            $("#forHost").validate({
                rules: {
                    host:{
                        required: true,
                        validateDNS : true
                    },
                },

                messages: {
                    host: {
                        required: msgRequired,
                        validateDNS: msgDns
                    },
                },
                errorElement: "div",
                errorClass: 'error_message',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });

            if(!($("#forHost").valid())) {
                th.removeAttr("disabled");
//                th.css("opacity", "1");
                return false;
            }
            
            th.attr('disabled','disabled');
//            th.css("opacity", "0.5");
            
            var actionType = '';
            if(th.hasClass("forStatic")){
                actionType = "Static";
                typeConn = 3;
            }else if(th.hasClass("forDynamic")){
                actionType = "DHCP";
                typeConn = 3;
            }else if(th.hasClass("forPPPoE")){
                actionType = "PPPoE";
                typeConn = 1;
            }else if(th.hasClass("forLTE")){
                actionType = "LTE";
                typeConn = 2;
                index = $("input[name='cell_index']").val();
                connect_index = $("input[name='dev_index']").val();
            } else {
                actionType = "L2TP";
                typeConn = 1;
            }
            
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'host': hostVal,
                    'serialN': serialN,
                    'index': index,
                    'connectIndex': connect_index,
                    'actionName': "diagnostic",
                    'pingType': actionType,
                    'fromPage': 'wan',
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        var success = getMssg['action_succeed'];
                        $("#actionResWanHost").empty();
                        $("#actionResWanHost").html(success);
                        $("#actionResWanHost").addClass("infoMessage");
                        $("#actionResWanHost").removeClass("errorMessage");
                        setTimeout(function () {
                            updateActivities(devId);
                            $('body').css("cursor", "default");
                        }, 2000);

    //------------- get the last 2 diagnostic activity status ---------------------
    //------------- if they are completed show the ping result --------------------

                        var interv = setInterval(function(){

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getLastActivityStatus.php",
                            data: {
                                'deviceID': devId,
                                'pingName': 'diagnostic',
                                'fromApp': true
                            },
                            async: true,
                            success: function (result) {
                                if(result == 'logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else if(result == 2){
                                    clearInterval(interv);

                                    $.ajax({
                                        type: "POST",
                                        url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
                                        data: {
                                            'deviceID': devId,
                                            'host': hostVal,
                                            'pingName': 'diagnostic',
                                            'index': index,
                                            'connectionType': typeConn,
                                            'fromApp': true
                                        },
                                        async: true,
                                        success: function (result) {
                                            if(result == 'logged_out'){
                                                document.location.href = $basepath + 'login';
                                            } else {
                                                $("#pingResult").empty();
                                                $("#pingResult").html(result);
                                                $("#actionResWanHost").empty();
                                                th.removeAttr("disabled");
//                                                th.css("opacity", "1");
                                                th.addClass("active");
                                                th.addClass("ready");
                                            }
                                        }
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        },5000);
                    } else if (result == 'false'){
                            $('body').css("cursor", "default");
                            $("#actionResWanHost").empty();
                            $("#actionResWanHost").html(failed);
                            $("#actionResWanHost").removeClass("infoMessage");
                            $("#actionResWanHost").addClass("errorMessage");
                    } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", "#showDiagnostic",function() {
        var showDiagnostic = getMssg['show_diagnostic'];
        var hideDiagnostic = getMssg['hide_diagnostic'];
        if($('.showDiagnostic').is(":hidden")) {
            $("#showDiagnostic").html(hideDiagnostic);
            $('.showDiagnostic').show();
        } else {
            $("#showDiagnostic").html(showDiagnostic);
            $('.showDiagnostic').hide();
        }

    });

//-------------------------- end wanStatic.php ---------------------------------

//-------------------------- wanPPP.php ----------------------------------------

    $(document).on("change","#chkShow",function() {
        if (this.checked) {
            $('#txtPassword').prop('type', 'text');
        } else {
            $('#txtPassword').prop('type', 'password');
        }
    });

    $(document).on("click","#txtPassword",function() {
        if($('#showPasswordDiv').is(":hidden")){
            $("#showPasswordDiv").show();
        }
    });

    $(document).on('focus','#txtPassword', function(e){
        $(window).keyup(function (e) {
            var key = e.which;
            if (key  == 9) {
                if($('#showPasswordDiv').is(":hidden")){
                    $("#showPasswordDiv").show();
                }
            }
        });
        this.removeAttribute('readonly');
    });

    $(document).on("click","#autoGenPas",function() {
//        $('#chkShow').change(function() {
//            if (this.checked) {
//                $('#txtPassword').prop('type', 'text');
//            } else {
//                $('#txtPassword').prop('type', 'password');
//            }
//        });

        if($('#showPasswordDiv').is(":hidden")){
            $("#showPasswordDiv").show();
        }

        if(this.checked) {

            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                data: {
                    'mac':serialN,
                    'action': 'genPassword',
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if(result=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        document.getElementsByName('password')[0].value = result;
                                // request client info by device serial number etc. mac

                        $.ajax({
                            type: "POST",
                            url: $basepath + 'secureFiles/actions/ajaxActions/Passwords.php',
                            data: {
                                'mac': serialN,
                                'action': 'genPPPUserName',
                                'fromApp':true
                            },
                            async: true,
                            success: function (output) {
                                    // generate username
                                var mix = output.split(" ");
                                var userName = output.slice(12, 18);
                                document.getElementsByName('username')[0].value = userName;
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click","#addPPPWan",function(e) {
        e.preventDefault();
        var th = $(this);
        var type = th.parent().find("input[name='PPPType']").val();
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
//            $('body').css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {
                                                
                        var paramNames = [];
                        var paramValues = [];
                        var paramTypes = [];
                        var notifParamStatus = [];
                        var notifParamNum = [];
                        var notifType = [];
                        var isValid = true;
                        var isChanged = false;
                        var toAdd = $("input[name='toAdd']").val();
                        var pppName = $("input[name='pppName']");
                        var nameVal = pppName.val();

                        var realNameVal = $("input[name='nameValue']").val().trim();
                        if (nameVal.trim() != realNameVal) {
                            isChanged = true;
                            pppName.removeClass("invalidVal");
                            var realNameName = $("input[name='nameName']").val();
                            var realNameType = $("input[name='nameType']").val();
                            paramNames.push(realNameName);
                            paramValues.push(nameVal.trim());
                            paramTypes.push(realNameType);
                        }
                        
                        var serviceName = $("input[name='serviceName']");
                        var msgRequired = getMssg['error_message_required'];
                        var msgIp = getMssg['error_message_ip'];
                        var msgMac = getMssg['error_message_mac'];
                        var msgNetmask = getMssg['error_message_netmask'];
                        var msgNumber = getMssg['error_message_number'];
                        var msgGe0 = getMssg['error_message_ge_0'];
                        var msgLessThan = getMssg['error_message_le_255'];
                        var msgDns = getMssg['error_message_dns'];
                        // var msgLe1492 = getMssg['error_message_le_1492'];
                        // var msgGe1 = getMssg['error_message_ge_1'];
                        var msgLe1280 = getMssg['error_message_le_1280'];
                        var msgLe1460 = getMssg['error_message_le_1460'];
                        var msgLe1550 = getMssg['error_message_le_1550'];
                        var msgLe1400 = getMssg['error_message_le_1400'];
                        var msgEmpty = getMssg['error_message_empty'];
                        var msgLe32 = getMssg['error_message_at_length_32'];
                        var msgPass = getMssg['wifi-ascii'];


                        
                        if(type == 'pppoe'){

                            $("#forReset").validate({
                                rules: {
				    pppName: {
                                        required: true,
                                        validateConnectionNameLength: true
				    },
				    username: {
                                        required: true,
                        validateASCII: true
				    },
				    password: {
                        required: true,
                        validateIsEmpty: true,
                        validateASCII: true
				    },
				    mru: {
                        required: true,
                        number: true,
                        min: 1400,
                        max: 1550


				    },
				    pppEcho: {
                                        required: true,
					number: true,
                                        min: 0
				    },
				    pppEchoRetry: {
                                        required: true,
					number: true,
                                        min: 0,
                                        max: 255
				    },
                                    mac:{
                                        required: true,
                                        validateMac : {
                                            siteType: '#siteType'
                                        }
                                    },
                                    Slaac: {
                                        invalidIPv6: true,
                                        required: true
                                    }
                                },

                                messages: {
				    pppName: {
                                        required: msgRequired,
                                        validateConnectionNameLength: msgLe32
				    },
				    username: {
                                        required: msgRequired,
                        validateASCII: msgPass
				    },
				    password: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty,
                        validateASCII: msgPass
				    },
				    mru: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgLe1400,
                        max: msgLe1550
				    },
				    pppEcho: {
                                        required: msgRequired,
					number: msgNumber,
                                        min: msgGe0
				    },
				    pppEchoRetry: {
                                        required: msgRequired,
					number: msgNumber,
                                        min: msgGe0,
                                        max: msgLessThan
				    },
                                    mac: {
                                        required: msgRequired,
                                        validateMac: msgMac
                                    },
                                    Slaac: {
                                        invalidIPv6: msgIp,
                                        required: msgRequired
                                    }
                                },
                                errorElement: "div",
                                errorClass: 'error_messageLan',
                                errorPlacement: function(error, element) {
                                    var placement = $(element).data('error');
                                    if (placement) {
                                        $(placement).append(error)
                                    } else {
                                        error.insertAfter(element);
                                    }
                                }
                            });
                            
                            if(toAdd != 'true'){
                                $("#txtPassword").rules("remove");
                            }

                            if(!($("#forReset").valid())) {
                                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                                return false;
                            }
                            
//                            var serviceName = $("input[name='serviceName']");
                            var realNameVal1 = $("input[name='serviceNameValue']").val().trim();
                            if (serviceName.val().trim() != realNameVal1) {
                                isChanged = true;
                                serviceName.removeClass("invalidVal");
                                var realNameName1 = $("input[name='serviceNameName']").val();
                                var realNameType1 = $("input[name='serviceNameType']").val();
                                paramNames.push(realNameName1);
                                paramValues.push(serviceName.val().trim());
                                paramTypes.push(realNameType1);
                            }
                        }
                        
                        if(type == 'l2tp' || type == 'pptp'){

                            $("#forReset").validate({
                                rules: {
				    pppName: {
                                        required: true,
                                        validateConnectionNameLength: true
				    },
				    username: {
                                        required: true,
                        validateASCII: true,
				    },
				    password: {
                        required: true,
                        validateIsEmpty: true,
                        validateASCII: true,
				    },
				    mru: {
                        required: true,
                        number: true,
                        min: 1280,
                        max: 1460
				    },
				    pppEcho: {
                                        required: true,
					number: true,
                                        min: 0
				    },
				    pppEchoRetry: {
                                        required: true,
					number: true,
                                        min: 0,
                                        max: 255
				    },
                                    serviceName:{
                                        required: true,
                                        validateDNS : true
                                    },
                                    mac:{
                                        required: true,
                                        validateMac : {
                                            siteType: '#siteType'
                                        }
                                    }
                                },

                                messages: {
				    pppName: {
                                        required: msgRequired,
                                        validateConnectionNameLength: msgLe32
				    },
				    username: {
                                        required: msgRequired,
                        validateASCII: msgPass
				    },
				    password: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty,
                        validateASCII: msgPass
				    },
				    mru: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgLe1280,
                        max: msgLe1460
				    },
				    pppEcho: {
                                        required: msgRequired,
					number: msgNumber,
                                        min: msgGe0
				    },
				    pppEchoRetry: {
                                        required: msgRequired,
					number: msgNumber,
                                        min: msgGe0,
                                        max: msgLessThan
				    },
                                    serviceName: {
                                        required: msgRequired,
                                        validateDNS: msgDns
                                    },
                                    mac: {
                                        required: msgRequired,
                                        validateMac: msgMac
                                    },
                                },
                                errorElement: "div",
                                errorClass: 'error_messageLan',
                                errorPlacement: function(error, element) {
                                    var placement = $(element).data('error');
                                    if (placement) {
                                        $(placement).append(error)
                                    } else {
                                        error.insertAfter(element);
                                    }
                                }
                            });
                            
                            if(toAdd != 'true'){
                                $("#txtPassword").rules("remove");
                            }
                            
                            if(!($("#forReset").valid())) {
                                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                                return false;
                            }
                            
//                            var serviceName = $("input[name='serviceName']");
                            var realNameVal1 = $("input[name='serviceNameValue']").val().trim();
                            if (serviceName.val().trim() != realNameVal1) {
                                isChanged = true;
                                serviceName.removeClass("invalidVal");
                                var realNameName1 = $("input[name='serviceNameName']").val();
                                var realNameType1 = $("input[name='serviceNameType']").val();
                                paramNames.push(realNameName1);
                                paramValues.push(serviceName.val().trim());
                                paramTypes.push(realNameType1);
                            }
                        }
                        
                        var mac = $("input[name='mac']");
                        var macVal = mac.val().trim();
                        var realEndIPVal = $("input[name='macValue']").val().trim();
                        if (macVal != realEndIPVal) {
                            isChanged = true;
                            var realEndIPName = $("input[name='macName']").val();
                            var realEndIPType = $("input[name='macType']").val();
                            paramNames.push(realEndIPName);
                            paramValues.push(macVal);
                            paramTypes.push(realEndIPType);
                        }
                        
                        var username = $("input[name='username']");
                        if (username.hasClass("required") && username.val() == '') {
                            username.addClass("invalidVal");
                            isValid = false;
                        } else {
                            var realUsernameVal = $("input[name='usernameValue']").val().trim();
                            if (username.val().trim() != realUsernameVal) {
                                isChanged = true;
                                username.removeClass("invalidVal");
                                var realUsernameName = $("input[name='usernameName']").val();
                                var realUsernameType = $("input[name='usernameType']").val();
                                paramNames.push(realUsernameName);
                                paramValues.push(username.val().trim());
                                paramTypes.push(realUsernameType);
                            }
                        }

                        var password = $("input[name='password']");
                        var realPasswordVal = $("input[name='passwordValue']").val().trim();
                        if (password.val().trim() != realPasswordVal) {
                            var realPasswordName = $("input[name='passwordName']").val();
                            var realPasswordType = $("input[name='passwordType']").val();
                            paramNames.push(realPasswordName);
                            paramValues.push(password.val().trim());
                            paramTypes.push(realPasswordType);
                            isChanged = true;
                        }

                        var mru = $("input[name='mru']");
                        var mruVal = mru.val().trim();
                        var realMruVal = $("input[name='mruValue']").val().trim();
                        if (mruVal != realMruVal) {
                            isChanged = true;
                            var realMruName = $("input[name='mruName']").val();
                            var realMruType = $("input[name='mruType']").val();
                            paramNames.push(realMruName);
                            paramValues.push(mruVal);
                            paramTypes.push(realMruType);
                        }

                        var enablePING = $("input[name='enablePing']");
                        var valenablePING = '';
                        if (enablePING.is(":checked")) {
                            valenablePING = '1';
                        } else {
                            valenablePING = '0';
                        }

                        var realEnablePINGName = $("input[name='enablePingName']").val();
                        var realEnablePINGType = $("input[name='enablePingType']").val();

                        if(toAdd == 'true' && valenablePING == '1'){
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }

                        var realEnablePING = $("input[name='enablePingValue']").val();
                        if (toAdd == 'false' && valenablePING != realEnablePING) {
                            isChanged = true;
                            paramNames.push(realEnablePINGName);
                            paramValues.push(valenablePING);
                            paramTypes.push(realEnablePINGType);
                        }

                        var enableNat = $("input[name='enableNat']");
                        var valenableNat = '';
                        if (enableNat.is(":checked")) {
                            valenableNat = '1';
                        } else {
                            valenableNat = '0';
                        }

                        var realEnableNatName = $("input[name='enableNatName']").val();
                        var realEnableNatType = $("input[name='enableNatType']").val();

                        if(toAdd == 'true' && valenableNat == '1'){
                            paramNames.push(realEnableNatName);
                            paramValues.push(valenableNat);
                            paramTypes.push(realEnableNatType);
                        }

                        var realEnableNat = $("input[name='enableNatValue']").val();
                        if (toAdd == 'false' && valenableNat != realEnableNat) {
                            isChanged = true;
                            paramNames.push(realEnableNatName);
                            paramValues.push(valenableNat);
                            paramTypes.push(realEnableNatType);
                        }

                        var standard = $(".authProtocolType option:selected").val();
                        var realStandardVal = $("input[name='authProtocolTypeValue']").val();
                        if (standard != realStandardVal) {
                            isChanged = true;
                            var realStandardName = $("input[name='authProtocolTypeName']").val();
                            var realStandardType = $("input[name='authProtocolTypeType']").val();
                            paramNames.push(realStandardName);
                            paramValues.push(standard);
                            paramTypes.push(realStandardType);
                        }

                        var keepAlive = $("input[name='enableKeepAlive']");
                        var valKeepAlive = '';
                        if (keepAlive.is(":checked")) {
                            valKeepAlive = '1';
                        } else {
                            valKeepAlive = '0';
                        }

                        var pppecho = $("input[name='pppEcho']");
                        var realPppechoVal = $("input[name='pppEchoValue']").val().trim();
                        var realPppechoName = $("input[name='pppEchoName']").val();
                        var realPppechoType = $("input[name='pppEchoType']").val();
                        
                        var pppechoRetry = $("input[name='pppEchoRetry']");
                        var realPppechoRetryVal = $("input[name='pppEchoRetryValue']").val().trim();
                        var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
                        var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
                        var pppechoVal = pppecho.val().trim();
                        
                        if(valKeepAlive == '1' && toAdd == 'true'){
                            if (pppechoVal != realPppechoVal) {
                                isChanged = true;
                                paramNames.push(realPppechoName);
                                paramValues.push(pppechoVal);
                                paramTypes.push(realPppechoType);
                            }

                            var pppechoRetryVal = pppechoRetry.val().trim();
                            if (pppechoRetryVal != realPppechoRetryVal) {
                                isChanged = true;
                                paramNames.push(realPppechoRetryName);
                                paramValues.push(pppechoRetryVal);
                                paramTypes.push(realPppechoRetryType);
                            }
                        }
                        
                        if(toAdd == 'false' && valKeepAlive == '1'){
                            if (pppechoVal != realPppechoVal) {
                                isChanged = true;
                                paramNames.push(realPppechoName);
                                paramValues.push(pppechoVal);
                                paramTypes.push(realPppechoType);
                            }
                            
                            var pppechoRetryVal = pppechoRetry.val().trim();
                            if (pppechoRetryVal != realPppechoRetryVal) {
                                isChanged = true;
                                paramNames.push(realPppechoRetryName);
                                paramValues.push(pppechoRetryVal);
                                paramTypes.push(realPppechoRetryType);
                            }
                        }
                        
                        if(toAdd == 'false' && valKeepAlive == '0'){
                            if(pppechoVal > 0){
                                isChanged = true;
                                paramNames.push(realPppechoName);
                                paramValues.push('0');
                                paramTypes.push(realPppechoType);
                                
                                paramNames.push(realPppechoRetryName);
                                paramValues.push('0');
                                paramTypes.push(realPppechoRetryType);
                            }
                        }
                        

                        var enable = $("input[name='enable']");
                        var valEnable = '';
                        if (enable.is(":checked")) {
                            valEnable = '1';
                        } else {
                            valEnable = '0';
                        }

                        var realEnableName = $("input[name='enableName']").val();
                        var realEnableType = $("input[name='enableType']").val();

                        if(toAdd == 'true'){
                            paramNames.push(realEnableName);
                            paramValues.push(valEnable);
                            paramTypes.push(realEnableType);
                        }

                        var realEnable = $("input[name='enableValue']").val();
                        if (toAdd == 'false' && valEnable != realEnable) {
                            isChanged = true;
                            paramNames.push(realEnableName);
                            paramValues.push(valEnable);
                            paramTypes.push(realEnableType);
                        }

            //----------------- default connection -----------------------------

                        var defconn = $("input[name='defconn']");
                        var valdefcon = '';
                        if (defconn.is(":checked")) {
                            valdefcon = '1';
                        } else {
                            valdefcon = '0';
                        }

                        var realdefconName = $("input[name='defconName']").val();
                        var realdefconType = $("input[name='defconType']").val();
                        var realdefcon = $("input[name='defconValue']").val();
                        var isChecket = false;
                        
                        if(toAdd == 'true' && valdefcon == '1'){
//                            paramNames.push(realdefconName);
//                            paramValues.push(realdefcon);
//                            paramTypes.push(realdefconType);
                            isChecket = true;
                        }

    //                    if (valdefcon != realdefcon ) {
    //                        isChanged = true;
    //                        
    //                        paramNames.push(realdefconName);
    //                        paramValues.push(valdefcon);
    //                        paramTypes.push(realdefconType);
    //                    } 

                        var interfaceType = $("#interfaceType option:selected").val();
//                        var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                        if (interfaceType != realinterfaceType) {
//                            isChanged = true;
//                            var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                            var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                            paramNames.push(realInterfaceTypeName);
//                            paramValues.push(interfaceType);
//                            paramTypes.push(realInterfaceTypeType);
//                        }

                        if (paramNames.length != 0 && isValid && isChanged) {
                            var index = $("input[name='index']").val();
                            var connect_index = $("input[name='connect_index']").val();
                            var id_conn = $("input[name='id_conn']").val();
                            var actionType = $("input[name='actionType']").val();
                            if(actionType == "addPPPWan") {
                                if ($('#refreshButton').css('display') == 'none') {
                                    addPPPoEWan(devId, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionType, type);
                                } else {
                                    var titleMsg = getMssg['title_msg'];
                                    var rmMsg = getMssg['change_msg'];
                                    var cancelMsg = getMssg['cancel'];
                                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                    swal({
                                        title: titleMsg,
                                        text: msgOffOn,
                                        showCancelButton: true,
                                        closeOnConfirm: true,
                                        confirmButtonText: rmMsg,
                                        cancelButtonText: cancelMsg,
                                        confirmButtonColor: "#008DA9"
                                    }, function (isConfirm) {
                                        if (isConfirm) {
                                            addPPPoEWan(devId, index, connect_index, paramNames, paramValues, paramTypes, actionType);
                                        } else {
                                            th.removeAttr("disabled");
                                        }
                                    });
                                }
                            } else if(actionType == "changePPPWan") {
                                if ($('#refreshButton').css('display') == 'none') {
                                    editPPPoEWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionType);
                                } else {
                                    var titleMsg = getMssg['title_msg'];
                                    var rmMsg = getMssg['change_msg'];
                                    var cancelMsg = getMssg['cancel'];
                                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                    swal({
                                        title: titleMsg,
                                        text: msgOffOn,
                                        showCancelButton: true,
                                        closeOnConfirm: true,
                                        confirmButtonText: rmMsg,
                                        cancelButtonText: cancelMsg,
                                        confirmButtonColor: "#008DA9"
                                    }, function (isConfirm) {
                                        if (isConfirm) {
                                            editPPPoEWan(devId,id_conn, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionType, type);
                                        } else {
                                            th.removeAttr("disabled");
                                        }
                                    });
                                }
                            }
                        } else if (isValid && !isChanged) {
                                $('body').css("cursor", "default");
                                var failed = getMssg["nothing_changed"];
                                $("#actionResWan").removeClass("infoMessage");
                                $("#actionResWan").addClass("errorMessage");
                                $("#actionResWan").empty();
                                $("#actionResWan").html(failed);
                                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                        } else {
                            $('body').css("cursor", "default");
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            $("#actionResWan").empty();
                        }
            //         } else if (result == 'false') {
            //             $("input").attr("disabled", "disabled");
            //             $("select").attr("disabled", "disabled");
            //             $("#divForAdd").hide();
            //             var msg = getMssg['dev_unavailable'];
            //             $("#actionResWan").removeClass("infoMessage");
            //             $("#actionResWan").addClass("errorMessage");
            //             $("#actionResWan").empty();
            //             $("#actionResWan").html(msg);
            //             $('body').css("cursor", "default");
            //             setTimeout(function () {
            //                 updateAfterTheAction();
            //             }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });

    $(document).on("click","#addPPPIPv6Wan",function(e) {
        e.preventDefault();
        var th = $(this);
        var type = th.parent().find("input[name='PPPType']").val();
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");
//            $('body').css("cursor", "wait");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {

            var paramNames = [];
            var paramValues = [];
            var paramTypes = [];
            var notifParamStatus = [];
            var notifParamNum = [];
            var notifType = [];
            var isValid = true;
            var isChanged = false;
            var toAdd = $("input[name='toAdd']").val();
            var pppName = $("input[name='pppName']");
            var nameVal = pppName.val();

            var realNameVal = $("input[name='nameValue']").val().trim();
            if (nameVal.trim() != realNameVal) {
                isChanged = true;
                pppName.removeClass("invalidVal");
                var realNameName = $("input[name='nameName']").val();
                var realNameType = $("input[name='nameType']").val();
                paramNames.push(realNameName);
                paramValues.push(nameVal.trim());
                paramTypes.push(realNameType);
            }

            var enableDns = $("input[name='enableDns']");
            var realDnsName = $("input[name='primaryDnsName']").val();
            var realDnsType = $("input[name='primaryDnsType']").val();
            var realEnableDnsName = $("input[name='enableDnsName']").val();
            var realEnableDnsType = $("input[name='enableDnsType']").val();
            var valenableDns = '';

            if (enableDns.is(":checked")) {
//                            valenableDns = '1';
                valenableDns = '0';
                isChanged = true;
                paramNames.push(realEnableDnsName);
                paramValues.push(valenableDns);
                paramTypes.push(realEnableDnsType);
            } else {
                valenableDns = '1';

                var serviceName = $("input[name='serviceName']");
                var msgRequired = getMssg['error_message_required'];
                var msgIp = getMssg['error_message_ip'];
                var msgMac = getMssg['error_message_mac'];
                var msgNetmask = getMssg['error_message_netmask'];
                var msgNumber = getMssg['error_message_number'];
                var msgGe0 = getMssg['error_message_ge_0'];
                var msgLessThan = getMssg['error_message_le_255'];
                var msgDns = getMssg['error_message_dns'];
                // var msgLe1492 = getMssg['error_message_le_1492'];
                // var msgGe1 = getMssg['error_message_ge_1'];
                var msgLe1280 = getMssg['error_message_le_1280'];
                var msgLe1460 = getMssg['error_message_le_1460'];
                var msgLe1550 = getMssg['error_message_le_1550'];
                var msgLe1400 = getMssg['error_message_le_1400'];
                var msgEmpty = getMssg['error_message_empty'];
                var msgLe32 = getMssg['error_message_at_length_32'];
                var msgPass = getMssg['wifi-ascii'];
                var msgIpDNS = getMssg['error_message_ipv6_dns'];
                var msgDNSEquality = getMssg['error_message_dns_equality'];

                $("#forReset").validate({
                    rules: {
                        pppName: {
                            required: true,
                            validateConnectionNameLength: true
                        },
                        username: {
                            required: true,
                            validateASCII: true
                        },
                        password: {
                            required: true,
                            validateIsEmpty: true,
                            validateASCII: true
                        },
                        mru: {
                            required: true,
                            number: true,
                            min: 1400,
                            max: 1550


                        },
                        pppEcho: {
                            required: true,
                            number: true,
                            min: 0
                        },
                        pppEchoRetry: {
                            required: true,
                            number: true,
                            min: 0,
                            max: 255
                        },
                        mac: {
                            required: true,
                            validateMac: {
                                siteType: '#siteType'
                            }
                        },
                        Slaac: {
                            invalidIPv6: true,
                            required: true
                        },
                        primaryDns: {
                            required: true,
                            invalidIPv6: true,
                            // validateDNS : true,
                            validateDNSEquality: {
                                primDns: "#primaryDns",
                                secondDns: "#secondaryDns"
                            }
                        },
                        secondaryDns: {
                            invalidIPv6: true,
                        },
                    },

                    messages: {
                        pppName: {
                            required: msgRequired,
                            validateConnectionNameLength: msgLe32
                        },
                        username: {
                            required: msgRequired,
                            validateASCII: msgPass
                        },
                        password: {
                            required: msgRequired,
                            validateIsEmpty: msgEmpty,
                            validateASCII: msgPass
                        },
                        mru: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgLe1400,
                            max: msgLe1550
                        },
                        pppEcho: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgGe0
                        },
                        pppEchoRetry: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgGe0,
                            max: msgLessThan
                        },
                        mac: {
                            required: msgRequired,
                            validateMac: msgMac
                        },
                        Slaac: {
                            invalidIPv6: msgIp,
                            required: msgRequired
                        },
                        primaryDns: {
                            required: msgRequired,
                            invalidIPv6: msgIpDNS,
                            // validateDNS: msgDns,
                            validateDNSEquality: msgDNSEquality
                        },
                        secondaryDns: {
                            invalidIPv6: msgIpDNS
                        }
                    },
                    errorElement: "div",
                    errorClass: 'error_messageLan',
                    errorPlacement: function (error, element) {
                        var placement = $(element).data('error');
                        if (placement) {
                            $(placement).append(error)
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });

                $('#primaryDnsIPv6').on('input', function (e) {
                    $("#secondaryDnsIPv6").valid();
                });

                $('#primaryDnsIPv6').on('change', function (e) {
                    $("#secondaryDnsIPv6").valid();
                });

                $('#secondaryDnsIPv6').on('input', function (e) {
                    $("#primaryDnsIPv6").valid();
                });

                $('#secondaryDnsIPv6').on('change', function (e) {
                    $("#primaryDnsIPv6").valid();
                });

                if (toAdd != 'true') {
                    $("#txtPassword").rules("remove");
                }

                if (!($("#forReset").valid())) {
                    th.removeAttr("disabled");
//                                th.css("opacity", "1");
                    return false;
                }

                var dns = $("input[name='primaryDns']").val().trim();
                var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                var secondaryDns = $("input[name='secondaryDns']").val().trim();
                var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                    isChanged = true;
                    if (secondaryDns != realSecondaryDns && secondaryDns != '') {
                        paramNames.push(realDnsName);
                        paramValues.push(dns + ',' + secondaryDns);
                        paramTypes.push(realDnsType);
                    } else if (secondaryDns != '') {
                        paramNames.push(realDnsName);
                        paramValues.push(dns + ',' + secondaryDns);
                        paramTypes.push(realDnsType);
                    } else {
                        paramNames.push(realDnsName);
                        paramValues.push(dns);
                        paramTypes.push(realDnsType);
                    }
                }
                isChanged = true;
                paramNames.push(realEnableDnsName);
                paramValues.push(valenableDns);
                paramTypes.push(realEnableDnsType);

            }

            var serviceName = $("input[name='serviceName']");
            var msgRequired = getMssg['error_message_required'];
            var msgIp = getMssg['error_message_ip'];
            var msgMac = getMssg['error_message_mac'];
            var msgNetmask = getMssg['error_message_netmask'];
            var msgNumber = getMssg['error_message_number'];
            var msgGe0 = getMssg['error_message_ge_0'];
            var msgLessThan = getMssg['error_message_le_255'];
            var msgDns = getMssg['error_message_dns'];
            // var msgLe1492 = getMssg['error_message_le_1492'];
            // var msgGe1 = getMssg['error_message_ge_1'];
            var msgLe1280 = getMssg['error_message_le_1280'];
            var msgLe1460 = getMssg['error_message_le_1460'];
            var msgLe1550 = getMssg['error_message_le_1550'];
            var msgLe1400 = getMssg['error_message_le_1400'];
            var msgEmpty = getMssg['error_message_empty'];
            var msgLe32 = getMssg['error_message_at_length_32'];
            var msgPass = getMssg['wifi-ascii'];
            var msgIpDNS = getMssg['error_message_ipv6_dns'];
            var msgDNSEquality = getMssg['error_message_dns_equality'];

            $("#forReset").validate({
                rules: {
                    pppName: {
                        required: true,
                        validateConnectionNameLength: true
                    },
                    username: {
                        required: true,
                        validateASCII: true
                    },
                    password: {
                        required: true,
                        validateIsEmpty: true,
                        validateASCII: true
                    },
                    mru: {
                        required: true,
                        number: true,
                        min: 1400,
                        max: 1550


                    },
                    pppEcho: {
                        required: true,
                        number: true,
                        min: 0
                    },
                    pppEchoRetry: {
                        required: true,
                        number: true,
                        min: 0,
                        max: 255
                    },
                    mac:{
                        required: true,
                        validateMac : {
                            siteType: '#siteType'
                        }
                    },
                    Slaac: {
                        invalidIPv6: true,
                        required: true
                    },
                },

                messages: {
                    pppName: {
                        required: msgRequired,
                        validateConnectionNameLength: msgLe32
                    },
                    username: {
                        required: msgRequired,
                        validateASCII: msgPass
                    },
                    password: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty,
                        validateASCII: msgPass
                    },
                    mru: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgLe1400,
                        max: msgLe1550
                    },
                    pppEcho: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0
                    },
                    pppEchoRetry: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0,
                        max: msgLessThan
                    },
                    mac: {
                        required: msgRequired,
                        validateMac: msgMac
                    },
                    Slaac: {
                        invalidIPv6: msgIp,
                        required: msgRequired
                    },
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });


            if (toAdd != 'true') {
                $("#txtPassword").rules("remove");
            }

            if (!($("#forReset").valid())) {
                th.removeAttr("disabled");
//                                th.css("opacity", "1");
                return false;
            }


//                            var serviceName = $("input[name='serviceName']");
                var realNameVal1 = $("input[name='serviceNameValue']").val().trim();
                if (serviceName.val().trim() != realNameVal1) {
                    isChanged = true;
                    serviceName.removeClass("invalidVal");
                    var realNameName1 = $("input[name='serviceNameName']").val();
                    var realNameType1 = $("input[name='serviceNameType']").val();
                    paramNames.push(realNameName1);
                    paramValues.push(serviceName.val().trim());
                    paramTypes.push(realNameType1);
                }

            var mac = $("input[name='mac']");
            var macVal = mac.val().trim();
            var realEndIPVal = $("input[name='macValue']").val().trim();
            if (macVal != realEndIPVal) {
                isChanged = true;
                var realEndIPName = $("input[name='macName']").val();
                var realEndIPType = $("input[name='macType']").val();
                paramNames.push(realEndIPName);
                paramValues.push(macVal);
                paramTypes.push(realEndIPType);
            }

            var username = $("input[name='username']");
            if (username.hasClass("required") && username.val() == '') {
                username.addClass("invalidVal");
                isValid = false;
            } else {
                var realUsernameVal = $("input[name='usernameValue']").val().trim();
                if (username.val().trim() != realUsernameVal) {
                    isChanged = true;
                    username.removeClass("invalidVal");
                    var realUsernameName = $("input[name='usernameName']").val();
                    var realUsernameType = $("input[name='usernameType']").val();
                    paramNames.push(realUsernameName);
                    paramValues.push(username.val().trim());
                    paramTypes.push(realUsernameType);
                }
            }

            var password = $("input[name='password']");
            var realPasswordVal = $("input[name='passwordValue']").val().trim();
            if (password.val().trim() != realPasswordVal) {
                var realPasswordName = $("input[name='passwordName']").val();
                var realPasswordType = $("input[name='passwordType']").val();
                paramNames.push(realPasswordName);
                paramValues.push(password.val().trim());
                paramTypes.push(realPasswordType);
                isChanged = true;
            }

            var mru = $("input[name='mru']");
            var mruVal = mru.val().trim();
            var realMruVal = $("input[name='mruValue']").val().trim();
            if (mruVal != realMruVal) {
                isChanged = true;
                var realMruName = $("input[name='mruName']").val();
                var realMruType = $("input[name='mruType']").val();
                paramNames.push(realMruName);
                paramValues.push(mruVal);
                paramTypes.push(realMruType);
            }

            var enablePING = $("input[name='enablePing']");
            var valenablePING = '';
            if (enablePING.is(":checked")) {
                valenablePING = '1';
            } else {
                valenablePING = '0';
            }

            var realEnablePINGName = $("input[name='enablePingName']").val();
            var realEnablePINGType = $("input[name='enablePingType']").val();

            if(toAdd == 'true' && valenablePING == '1'){
                paramNames.push(realEnablePINGName);
                paramValues.push(valenablePING);
                paramTypes.push(realEnablePINGType);
            }

            var realEnablePING = $("input[name='enablePingValue']").val();
            if (toAdd == 'false' && valenablePING != realEnablePING) {
                isChanged = true;
                paramNames.push(realEnablePINGName);
                paramValues.push(valenablePING);
                paramTypes.push(realEnablePINGType);
            }

            var enableSLAAC = $("input[name='enableSlaac']");
            var valenableSLAAC = '';
            if (enableSLAAC.is(":checked")) {
                valenableSLAAC = '1';
            } else {
                valenableSLAAC = '0';
            }

            var realEnableSLAACName = $("input[name='enableSlaacName']").val();
            var realEnableSLAACType = $("input[name='enableSlaacType']").val();

            if(toAdd == 'true'){
                paramNames.push(realEnableSLAACName);
                paramValues.push(valenableSLAAC);
                paramTypes.push(realEnableSLAACType);
            }

            var realEnableSLAAC = $("input[name='enableSlaacValue']").val();
            if (toAdd == 'false' && valenableSLAAC != realEnableSLAAC) {
                isChanged = true;
                paramNames.push(realEnableSLAACName);
                paramValues.push(valenableSLAAC);
                paramTypes.push(realEnableSLAACType);
            }

            var slaac = $("input[name='Slaac']").val().trim();
            var realslaacVal = $("input[name='SlaacValue']").val().trim();
            var realslaacName = $("input[name='SlaacName']").val();
            var realslaacType = $("input[name='SlaacType']").val();
            if (slaac != realslaacVal) {
                isChanged = true;
                paramNames.push(realslaacName);
                paramValues.push(slaac);
                paramTypes.push(realslaacType);
            }

            var enableNat = $("input[name='enableNat']");
            var valenableNat = '';
            if (enableNat.is(":checked")) {
                valenableNat = '1';
            } else {
                valenableNat = '0';
            }

            var realEnableNatName = $("input[name='enableNatName']").val();
            var realEnableNatType = $("input[name='enableNatType']").val();

            if(toAdd == 'true' && valenableNat == '1'){
                paramNames.push(realEnableNatName);
                paramValues.push(valenableNat);
                paramTypes.push(realEnableNatType);
            }

            var realEnableNat = $("input[name='enableNatValue']").val();
            if (toAdd == 'false' && valenableNat != realEnableNat) {
                isChanged = true;
                paramNames.push(realEnableNatName);
                paramValues.push(valenableNat);
                paramTypes.push(realEnableNatType);
            }

            var standard = $(".authProtocolType option:selected").val();
            var realStandardVal = $("input[name='authProtocolTypeValue']").val();
            if (standard != realStandardVal) {
                isChanged = true;
                var realStandardName = $("input[name='authProtocolTypeName']").val();
                var realStandardType = $("input[name='authProtocolTypeType']").val();
                paramNames.push(realStandardName);
                paramValues.push(standard);
                paramTypes.push(realStandardType);
            }

            var keepAlive = $("input[name='enableKeepAlive']");
            var valKeepAlive = '';
            if (keepAlive.is(":checked")) {
                valKeepAlive = '1';
            } else {
                valKeepAlive = '0';
            }

            var pppecho = $("input[name='pppEcho']");
            var realPppechoVal = $("input[name='pppEchoValue']").val().trim();
            var realPppechoName = $("input[name='pppEchoName']").val();
            var realPppechoType = $("input[name='pppEchoType']").val();

            var pppechoRetry = $("input[name='pppEchoRetry']");
            var realPppechoRetryVal = $("input[name='pppEchoRetryValue']").val().trim();
            var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
            var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
            var pppechoVal = pppecho.val().trim();

            if(valKeepAlive == '1' && toAdd == 'true'){
                if (pppechoVal != realPppechoVal) {
                    isChanged = true;
                    paramNames.push(realPppechoName);
                    paramValues.push(pppechoVal);
                    paramTypes.push(realPppechoType);
                }

                var pppechoRetryVal = pppechoRetry.val().trim();
                if (pppechoRetryVal != realPppechoRetryVal) {
                    isChanged = true;
                    paramNames.push(realPppechoRetryName);
                    paramValues.push(pppechoRetryVal);
                    paramTypes.push(realPppechoRetryType);
                }
            }

            if(toAdd == 'false' && valKeepAlive == '1'){
                if (pppechoVal != realPppechoVal) {
                    isChanged = true;
                    paramNames.push(realPppechoName);
                    paramValues.push(pppechoVal);
                    paramTypes.push(realPppechoType);
                }

                var pppechoRetryVal = pppechoRetry.val().trim();
                if (pppechoRetryVal != realPppechoRetryVal) {
                    isChanged = true;
                    paramNames.push(realPppechoRetryName);
                    paramValues.push(pppechoRetryVal);
                    paramTypes.push(realPppechoRetryType);
                }
            }

            if(toAdd == 'false' && valKeepAlive == '0'){
                if(pppechoVal > 0){
                    isChanged = true;
                    paramNames.push(realPppechoName);
                    paramValues.push('0');
                    paramTypes.push(realPppechoType);

                    paramNames.push(realPppechoRetryName);
                    paramValues.push('0');
                    paramTypes.push(realPppechoRetryType);
                }
            }


            var enable = $("input[name='enable']");
            var valEnable = '';
            if (enable.is(":checked")) {
                valEnable = '1';
            } else {
                valEnable = '0';
            }

            var realEnableName = $("input[name='enableName']").val();
            var realEnableType = $("input[name='enableType']").val();

            if(toAdd == 'true'){
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);
            }

            var realEnable = $("input[name='enableValue']").val();
            if (toAdd == 'false' && valEnable != realEnable) {
                isChanged = true;
                paramNames.push(realEnableName);
                paramValues.push(valEnable);
                paramTypes.push(realEnableType);
            }

            //----------------- default connection -----------------------------

            var defconn = $("input[name='defconn']");
            var valdefcon = '';
            if (defconn.is(":checked")) {
                valdefcon = '1';
            } else {
                valdefcon = '0';
            }

            var realdefconName = $("input[name='defconName']").val();
            var realdefconType = $("input[name='defconType']").val();
            var realdefcon = $("input[name='defconValue']").val();
            var isChecket = false;

            if(toAdd == 'true' && valdefcon == '1'){
//                            paramNames.push(realdefconName);
//                            paramValues.push(realdefcon);
//                            paramTypes.push(realdefconType);
                isChecket = true;
            }

            //                    if (valdefcon != realdefcon ) {
            //                        isChanged = true;
            //
            //                        paramNames.push(realdefconName);
            //                        paramValues.push(valdefcon);
            //                        paramTypes.push(realdefconType);
            //                    }

            var interfaceType = $("#interfaceType option:selected").val();
//                        var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                        if (interfaceType != realinterfaceType) {
//                            isChanged = true;
//                            var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
//                            var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
//                            paramNames.push(realInterfaceTypeName);
//                            paramValues.push(interfaceType);
//                            paramTypes.push(realInterfaceTypeType);
//                        }

            if (paramNames.length != 0 && isValid && isChanged) {
                var index = $("input[name='index']").val();
                var connect_index = $("input[name='connect_index']").val();
                var id_conn = $("input[name='id_conn']").val();
                var actionType = $("input[name='actionType']").val();
                if(actionType == "addPPPWan") {
                    if ($('#refreshButton').css('display') == 'none') {
                        addPPPoEWan(devId, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionType, 'pppoeIPv6');
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                addPPPoEWan(devId, index, connect_index, paramNames, paramValues, paramTypes, actionType);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }
                } else if(actionType == "changePPPIPv6Wan") {
                    if ($('#refreshButton').css('display') == 'none') {
                        editPPPoEWan(devId,id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionType);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                editPPPoEWan(devId,id_conn, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionType, 'pppoeIPv6');
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }
                }
            } else if (isValid && !isChanged) {
                $('body').css("cursor", "default");
                var failed = getMssg["nothing_changed"];
                $("#actionResWan").removeClass("infoMessage");
                $("#actionResWan").addClass("errorMessage");
                $("#actionResWan").empty();
                $("#actionResWan").html(failed);
                th.removeAttr("disabled");
//                                th.css("opacity", "1");
            } else {
                $('body').css("cursor", "default");
                th.removeAttr("disabled");
//                            th.css("opacity", "1");
                $("#actionResWan").empty();
            }
            //         } else if (result == 'false') {
            //             $("input").attr("disabled", "disabled");
            //             $("select").attr("disabled", "disabled");
            //             $("#divForAdd").hide();
            //             var msg = getMssg['dev_unavailable'];
            //             $("#actionResWan").removeClass("infoMessage");
            //             $("#actionResWan").addClass("errorMessage");
            //             $("#actionResWan").empty();
            //             $("#actionResWan").html(msg);
            //             $('body').css("cursor", "default");
            //             setTimeout(function () {
            //                 updateAfterTheAction();
            //             }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });

    $(document).on("click","#addPPPDualStackWan",function(e) {
        e.preventDefault();
        var th = $(this);
        var type = th.parent().find("input[name='PPPType']").val();
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            var paramNamesPPP = [];
            var paramValuesPPP = [];
            var paramTypesPPP = [];
            var paramNamesIPv6 = [];
            var paramValuesIPv6 = [];
            var paramTypesIPv6 = [];
            var notifParamStatus = [];
            var notifParamNum = [];
            var notifType = [];
            var isValid = true;
            var isChanged = false;
            var toAdd = $("input[name='toAdd']").val();
            var pppName = $("input[name='pppName']");
            var nameVal = pppName.val();

            var realNameVal = $("input[name='nameValue']").val().trim();

            if(toAdd) {
                paramNamesIPv6.push("DualInterface");
                paramValuesIPv6.push("%s");
                paramTypesIPv6.push("unsignedInt");
            }

            if (nameVal.trim() != realNameVal) {
                isChanged = true;
                pppName.removeClass("invalidVal");
                var realNameName = $("input[name='nameName']").val();
                var realNameType = $("input[name='nameType']").val();
                paramNamesPPP.push(realNameName);
                paramValuesPPP.push(nameVal.trim());
                paramTypesPPP.push(realNameType);
                paramNamesIPv6.push(realNameName);
                paramValuesIPv6.push(nameVal.trim());
                paramTypesIPv6.push(realNameType);
            }

            var enableDns = $("input[name='enableDns']");
            var realDnsName = $("input[name='primaryDnsName']").val();
            var realDnsType = $("input[name='primaryDnsType']").val();
            var realEnableDnsName = $("input[name='enableDnsName']").val();
            var realEnableDnsType = $("input[name='enableDnsType']").val();
            var valenableDns = '';
            var enableDnsIpv6 = '';

            if (enableDns.is(":checked")) {
                valenableDns = '0';
                enableDnsIpv6 = '1';
                isChanged = true;
                paramNamesPPP.push(realEnableDnsName);
                paramValuesPPP.push(valenableDns);
                paramTypesPPP.push(realEnableDnsType);
                paramNamesIPv6.push(realEnableDnsName);
                paramValuesIPv6.push(enableDnsIpv6);
                paramTypesIPv6.push(realEnableDnsType);
            } else {
                valenableDns = '0';
                enableDnsIpv6 = '0';
                isChanged = true;
                paramNamesPPP.push(realEnableDnsName);
                paramValuesPPP.push(valenableDns);
                paramTypesPPP.push(realEnableDnsType);
                paramNamesIPv6.push(realEnableDnsName);
                paramValuesIPv6.push(enableDnsIpv6);
                paramTypesIPv6.push(realEnableDnsType);

                var serviceName = $("input[name='serviceName']");
                var msgRequired = getMssg['error_message_required'];
                var msgIp = getMssg['error_message_ip'];
                var msgMac = getMssg['error_message_mac'];
                var msgNetmask = getMssg['error_message_netmask'];
                var msgNumber = getMssg['error_message_number'];
                var msgGe0 = getMssg['error_message_ge_0'];
                var msgLessThan = getMssg['error_message_le_255'];
                var msgDns = getMssg['error_message_dns'];
                // var msgLe1492 = getMssg['error_message_le_1492'];
                // var msgGe1 = getMssg['error_message_ge_1'];
                var msgLe1280 = getMssg['error_message_le_1280'];
                var msgLe1460 = getMssg['error_message_le_1460'];
                var msgLe1550 = getMssg['error_message_le_1550'];
                var msgLe1400 = getMssg['error_message_le_1400'];
                var msgEmpty = getMssg['error_message_empty'];
                var msgLe32 = getMssg['error_message_at_length_32'];
                var msgPass = getMssg['wifi-ascii'];
                var msgIpDNS = getMssg['error_message_ipv6_dns'];
                var msgDNSEquality = getMssg['error_message_dns_equality'];

                $("#forReset").validate({
                    rules: {
                        pppName: {
                            required: true,
                            validateConnectionNameLength: true
                        },
                        username: {
                            required: true,
                            validateASCII: true
                        },
                        password: {
                            required: true,
                            validateIsEmpty: true,
                            validateASCII: true
                        },
                        mru: {
                            required: true,
                            number: true,
                            min: 1400,
                            max: 1550


                        },
                        pppEcho: {
                            required: true,
                            number: true,
                            min: 0
                        },
                        pppEchoRetry: {
                            required: true,
                            number: true,
                            min: 0,
                            max: 255
                        },
                        mac: {
                            required: true,
                            validateMac: {
                                siteType: '#siteType'
                            }
                        },
                        Slaac: {
                            invalidIPv6: true,
                            required: true
                        },
                        primaryDns: {
                            required: true,
                            invalidIPv6: true,
                            // validateDNS : true,
                            validateDNSEquality: {
                                primDns: "#primaryDns",
                                secondDns: "#secondaryDns"
                            }
                        },
                        secondaryDns: {
                            invalidIPv6: true,
                        },
                    },

                    messages: {
                        pppName: {
                            required: msgRequired,
                            validateConnectionNameLength: msgLe32
                        },
                        username: {
                            required: msgRequired,
                            validateASCII: msgPass
                        },
                        password: {
                            required: msgRequired,
                            validateIsEmpty: msgEmpty,
                            validateASCII: msgPass
                        },
                        mru: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgLe1400,
                            max: msgLe1550
                        },
                        pppEcho: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgGe0
                        },
                        pppEchoRetry: {
                            required: msgRequired,
                            number: msgNumber,
                            min: msgGe0,
                            max: msgLessThan
                        },
                        mac: {
                            required: msgRequired,
                            validateMac: msgMac
                        },
                        Slaac: {
                            invalidIPv6: msgIp,
                            required: msgRequired
                        },
                        primaryDns: {
                            required: msgRequired,
                            invalidIPv6: msgIpDNS,
                            // validateDNS: msgDns,
                            validateDNSEquality: msgDNSEquality
                        },
                        secondaryDns: {
                            invalidIPv6: msgIpDNS
                        }
                    },
                    errorElement: "div",
                    errorClass: 'error_messageLan',
                    errorPlacement: function (error, element) {
                        var placement = $(element).data('error');
                        if (placement) {
                            $(placement).append(error)
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });

                $('#primaryDnsIPv6').on('input', function (e) {
                    $("#secondaryDnsIPv6").valid();
                });

                $('#primaryDnsIPv6').on('change', function (e) {
                    $("#secondaryDnsIPv6").valid();
                });

                $('#secondaryDnsIPv6').on('input', function (e) {
                    $("#primaryDnsIPv6").valid();
                });

                $('#secondaryDnsIPv6').on('change', function (e) {
                    $("#primaryDnsIPv6").valid();
                });

                if (toAdd != 'true') {
                    $("#txtPassword").rules("remove");
                }

                if (!($("#forReset").valid())) {
                    th.removeAttr("disabled");
                    return false;
                }

                // var dns = $("input[name='primaryDns']").val().trim();
                // var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                // var secondaryDns = $("input[name='secondaryDns']").val().trim();
                // var secondaryDnsType = $("input[name='secondaryDnsType']").val().trim();
                // var secondaryDnsName = $("input[name='secondaryDnsName']").val().trim();
                // var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                // if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                //     isChanged = true;
                //     if(dns != realDnsVal) {
                //         paramNamesIPv6.push(realDnsName);
                //         paramValuesIPv6.push(dns);
                //         paramTypesIPv6.push(realDnsType);
                //     } else if (secondaryDns != realSecondaryDns && secondaryDns != '') {
                //         isChanged = true;
                //         paramNamesIPv6.push(secondaryDnsName);
                //         paramValuesIPv6.push(secondaryDns);
                //         paramTypesIPv6.push(secondaryDnsType);
                //     }
                // }
                var realPrimDnsName = $("input[name='primaryDnsName']").val();
                var reaSecDnsName = $("input[name='secondaryDnsName']").val();
                var realDnsType = $("input[name='primaryDnsType']").val();
                var dns = $("input[name='primaryDns']").val().trim();
                var realDnsVal = $("input[name='primaryDnsValue']").val().trim();
                var secondaryDns = $("input[name='secondaryDns']").val().trim();
                var realSecondaryDns = $("input[name='secondaryDnsValue']").val().trim();
                if (dns != realDnsVal || secondaryDns != realSecondaryDns) {
                    isChanged = true;
                    if(secondaryDns != realSecondaryDns && secondaryDns != ''){
                        paramNamesIPv6.push(realPrimDnsName);
                        paramNamesIPv6.push(reaSecDnsName);
                        paramValuesIPv6.push(dns);
                        paramValuesIPv6.push(secondaryDns);
                        paramTypesIPv6.push(realDnsType);
                        paramTypesIPv6.push(realDnsType);
                    }else if(secondaryDns != ''){
                        paramNamesIPv6.push(realPrimDnsName);
                        paramNamesIPv6.push(reaSecDnsName);
                        paramValuesIPv6.push(dns);
                        paramValuesIPv6.push(secondaryDns);
                        paramTypesIPv6.push(realDnsType);
                        paramTypesIPv6.push(realDnsType);
                    }else{
                        paramNamesIPv6.push(realPrimDnsName);
                        paramValuesIPv6.push(dns);
                        paramTypesIPv6.push(realDnsType);
                    }
                }
            }



            var serviceName = $("input[name='serviceName']");
            var msgRequired = getMssg['error_message_required'];
            var msgIp = getMssg['error_message_ip'];
            var msgMac = getMssg['error_message_mac'];
            var msgNetmask = getMssg['error_message_netmask'];
            var msgNumber = getMssg['error_message_number'];
            var msgGe0 = getMssg['error_message_ge_0'];
            var msgLessThan = getMssg['error_message_le_255'];
            var msgDns = getMssg['error_message_dns'];
            // var msgLe1492 = getMssg['error_message_le_1492'];
            // var msgGe1 = getMssg['error_message_ge_1'];
            var msgLe1280 = getMssg['error_message_le_1280'];
            var msgLe1460 = getMssg['error_message_le_1460'];
            var msgLe1550 = getMssg['error_message_le_1550'];
            var msgLe1400 = getMssg['error_message_le_1400'];
            var msgEmpty = getMssg['error_message_empty'];
            var msgLe32 = getMssg['error_message_at_length_32'];
            var msgPass = getMssg['wifi-ascii'];
            var msgIpDNS = getMssg['error_message_ipv6_dns'];
            var msgDNSEquality = getMssg['error_message_dns_equality'];

            $("#forReset").validate({
                rules: {
                    pppName: {
                        required: true,
                        validateConnectionNameLength: true
                    },
                    username: {
                        required: true,
                        validateASCII: true
                    },
                    password: {
                        required: true,
                        validateIsEmpty: true,
                        validateASCII: true
                    },
                    mru: {
                        required: true,
                        number: true,
                        min: 1400,
                        max: 1550
                    },
                    pppEcho: {
                        required: true,
                        number: true,
                        min: 0
                    },
                    pppEchoRetry: {
                        required: true,
                        number: true,
                        min: 0,
                        max: 255
                    },
                    mac:{
                        required: true,
                        validateMac : {
                            siteType: '#siteType'
                        }
                    },
                    Slaac: {
                        invalidIPv6: true,
                        required: true
                    }
                },

                messages: {
                    pppName: {
                        required: msgRequired,
                        validateConnectionNameLength: msgLe32
                    },
                    username: {
                        required: msgRequired,
                        validateASCII: msgPass
                    },
                    password: {
                        required: msgRequired,
                        validateIsEmpty: msgEmpty,
                        validateASCII: msgPass
                    },
                    mru: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgLe1400,
                        max: msgLe1550
                    },
                    pppEcho: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0
                    },
                    pppEchoRetry: {
                        required: msgRequired,
                        number: msgNumber,
                        min: msgGe0,
                        max: msgLessThan
                    },
                    mac: {
                        required: msgRequired,
                        validateMac: msgMac
                    },
                    Slaac: {
                        invalidIPv6: msgIp,
                        required: msgRequired
                    }
                },
                errorElement: "div",
                errorClass: 'error_messageLan',
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                }
            });


            if (toAdd != 'true') {
                $("#txtPassword").rules("remove");
            }

            if (!($("#forReset").valid())) {
                th.removeAttr("disabled");
                return false;
            }

            var realNameVal1 = $("input[name='serviceNameValue']").val().trim();
            if (serviceName.val().trim() != realNameVal1) {
                isChanged = true;
                serviceName.removeClass("invalidVal");
                var realNameName1 = $("input[name='serviceNameName']").val();
                var realNameType1 = $("input[name='serviceNameType']").val();
                paramNamesPPP.push(realNameName1);
                paramValuesPPP.push(serviceName.val().trim());
                paramTypesPPP.push(realNameType1);
            }

            var mac = $("input[name='mac']");
            var macVal = mac.val().trim();
            var realEndIPVal = $("input[name='macValue']").val().trim();
            if (macVal != realEndIPVal) {
                isChanged = true;
                var realEndIPName = $("input[name='macName']").val();
                var realEndIPType = $("input[name='macType']").val();
                paramNamesPPP.push(realEndIPName);
                paramValuesPPP.push(macVal);
                paramTypesPPP.push(realEndIPType);
                paramNamesIPv6.push(realEndIPName);
                paramValuesIPv6.push(macVal);
                paramTypesIPv6.push(realEndIPType);
            }
            var username = $("input[name='username']");
            if (username.hasClass("required") && username.val() == '') {
                username.addClass("invalidVal");
                isValid = false;
            } else {
                var realUsernameVal = $("input[name='usernameValue']").val().trim();
                if (username.val().trim() != realUsernameVal) {
                    isChanged = true;
                    username.removeClass("invalidVal");
                    var realUsernameName = $("input[name='usernameName']").val();
                    var realUsernameType = $("input[name='usernameType']").val();
                    paramNamesPPP.push(realUsernameName);
                    paramValuesPPP.push(username.val().trim());
                    paramTypesPPP.push(realUsernameType);
                }
            }

            var password = $("input[name='password']");
            var realPasswordVal = $("input[name='passwordValue']").val().trim();
            if (password.val().trim() != realPasswordVal) {
                var realPasswordName = $("input[name='passwordName']").val();
                var realPasswordType = $("input[name='passwordType']").val();
                paramNamesPPP.push(realPasswordName);
                paramValuesPPP.push(password.val().trim());
                paramTypesPPP.push(realPasswordType);
                isChanged = true;
            }

            var mru = $("input[name='mru']");
            var mruVal = mru.val().trim();
            var realMruVal = $("input[name='mruValue']").val().trim();
            if (mruVal != realMruVal) {
                isChanged = true;
                var realMruName = $("input[name='mruName']").val();
                var realMruType = $("input[name='mruType']").val();
                paramNamesPPP.push(realMruName);
                paramValuesPPP.push(mruVal);
                paramTypesPPP.push(realMruType);
            }

            var mtu = $("input[name='mtu']");
            var mtuVal = mtu.val().trim();
            var realMtuVal = $("input[name='mtuValue']").val().trim();
            if (mtuVal != realMtuVal) {
                isChanged = true;
                var realMtuName = $("input[name='mtuName']").val();
                var realMtuType = $("input[name='mtuType']").val();
                paramNamesIPv6.push(realMtuName);
                paramValuesIPv6.push(mtuVal);
                paramTypesIPv6.push(realMtuType);
            }

            var enablePING = $("input[name='enablePing']");
            var valenablePING = '';
            if (enablePING.is(":checked")) {
                valenablePING = '1';
            } else {
                valenablePING = '0';
            }

            var realEnablePINGName = $("input[name='enablePingName']").val();
            var realEnablePINGType = $("input[name='enablePingType']").val();

            if(toAdd == 'true' && valenablePING == '1'){
                paramNamesPPP.push(realEnablePINGName);
                paramValuesPPP.push(valenablePING);
                paramTypesPPP.push(realEnablePINGType);
            }

            var realEnablePING = $("input[name='enablePingValue']").val();
            if (toAdd == 'false' && valenablePING != realEnablePING) {
                isChanged = true;
                paramNamesPPP.push(realEnablePINGName);
                paramValuesPPP.push(valenablePING);
                paramTypesPPP.push(realEnablePINGType);
            }

            var enableSLAAC = $("input[name='enableSlaac']");
            var valenableSLAAC = '';
            if (enableSLAAC.is(":checked")) {
                valenableSLAAC = '1';
            } else {
                valenableSLAAC = '0';
            }

            var realEnableSLAACName = $("input[name='enableSlaacName']").val();
            var realEnableSLAACType = $("input[name='enableSlaacType']").val();

            if(toAdd == 'true'){
                paramNamesIPv6.push(realEnableSLAACName);
                paramValuesIPv6.push(valenableSLAAC);
                paramTypesIPv6.push(realEnableSLAACType);
            }

            var realEnableSLAAC = $("input[name='enableSlaacValue']").val();
            if (toAdd == 'false' && valenableSLAAC != realEnableSLAAC) {
                isChanged = true;
                paramNamesIPv6.push(realEnableSLAACName);
                paramValuesIPv6.push(valenableSLAAC);
                paramValuesIPv6.push(realEnableSLAACType);
            }

            var slaac = $("input[name='Slaac']").val().trim();
            var realslaacVal = $("input[name='SlaacValue']").val().trim();
            var realslaacName = $("input[name='SlaacName']").val();
            var realslaacType = $("input[name='SlaacType']").val();
            if (slaac != realslaacVal) {
                isChanged = true;
                paramNamesIPv6.push(realslaacName);
                paramValuesIPv6.push(slaac);
                paramTypesIPv6.push(realslaacType);
            }

            var enableNat = $("input[name='enableNat']");
            var valenableNat = '';
            if (enableNat.is(":checked")) {
                valenableNat = '1';
            } else {
                valenableNat = '0';
            }

            var realEnableNatName = $("input[name='enableNatName']").val();
            var realEnableNatType = $("input[name='enableNatType']").val();

            if(toAdd == 'true' && valenableNat == '1'){
                paramNamesPPP.push(realEnableNatName);
                paramValuesPPP.push(valenableNat);
                paramTypesPPP.push(realEnableNatType);
                paramNamesIPv6.push(realEnableNatName);
                paramValuesIPv6.push(valenableNat);
                paramTypesIPv6.push(realEnableNatType);
            }

            var realEnableNat = $("input[name='enableNatValue']").val();
            if (toAdd == 'false' && valenableNat != realEnableNat) {
                isChanged = true;
                paramNamesPPP.push(realEnableNatName);
                paramValuesPPP.push(valenableNat);
                paramTypesPPP.push(realEnableNatType);
                paramNamesIPv6.push(realEnableNatName);
                paramValuesIPv6.push(valenableNat);
                paramTypesIPv6.push(realEnableNatType);
            }

            var standard = $(".authProtocolType option:selected").val();
            var realStandardVal = $("input[name='authProtocolTypeValue']").val();
            if (standard != realStandardVal) {
                isChanged = true;
                var realStandardName = $("input[name='authProtocolTypeName']").val();
                var realStandardType = $("input[name='authProtocolTypeType']").val();
                paramNamesPPP.push(realStandardName);
                paramValuesPPP.push(standard);
                paramTypesPPP.push(realStandardType);
            }

            var keepAlive = $("input[name='enableKeepAlive']");
            var valKeepAlive = '';
            if (keepAlive.is(":checked")) {
                valKeepAlive = '1';
            } else {
                valKeepAlive = '0';
            }

            var pppecho = $("input[name='pppEcho']");
            var realPppechoVal = $("input[name='pppEchoValue']").val().trim();
            var realPppechoName = $("input[name='pppEchoName']").val();
            var realPppechoType = $("input[name='pppEchoType']").val();

            var pppechoRetry = $("input[name='pppEchoRetry']");
            var realPppechoRetryVal = $("input[name='pppEchoRetryValue']").val().trim();
            var realPppechoRetryName = $("input[name='pppEchoRetryName']").val();
            var realPppechoRetryType = $("input[name='pppEchoRetryType']").val();
            var pppechoVal = pppecho.val().trim();

            if(valKeepAlive == '1' && toAdd == 'true'){
                if (pppechoVal != realPppechoVal) {
                    isChanged = true;
                    paramNamesPPP.push(realPppechoName);
                    paramValuesPPP.push(pppechoVal);
                    paramTypesPPP.push(realPppechoType);
                }

                var pppechoRetryVal = pppechoRetry.val().trim();
                if (pppechoRetryVal != realPppechoRetryVal) {
                    isChanged = true;
                    paramNamesPPP.push(realPppechoRetryName);
                    paramValuesPPP.push(pppechoRetryVal);
                    paramTypesPPP.push(realPppechoRetryType);
                }
            }

            if(toAdd == 'false' && valKeepAlive == '1'){
                if (pppechoVal != realPppechoVal) {
                    isChanged = true;
                    paramNamesPPP.push(realPppechoName);
                    paramValuesPPP.push(pppechoVal);
                    paramTypesPPP.push(realPppechoType);
                }

                var pppechoRetryVal = pppechoRetry.val().trim();
                if (pppechoRetryVal != realPppechoRetryVal) {
                    isChanged = true;
                    paramNamesPPP.push(realPppechoRetryName);
                    paramValuesPPP.push(pppechoRetryVal);
                    paramTypesPPP.push(realPppechoRetryType);
                }
            }

            if(toAdd == 'false' && valKeepAlive == '0'){
                if(pppechoVal > 0){
                    isChanged = true;
                    paramNamesPPP.push(realPppechoName);
                    paramValuesPPP.push('0');
                    paramTypesPPP.push(realPppechoType);

                    paramNamesPPP.push(realPppechoRetryName);
                    paramValuesPPP.push('0');
                    paramTypesPPP.push(realPppechoRetryType);
                }
            }


            var enable = $("input[name='enable']");
            var valEnable = '';
            if (enable.is(":checked")) {
                valEnable = '1';
            } else {
                valEnable = '0';
            }

            var realEnableName = $("input[name='enableName']").val();
            var realEnableType = $("input[name='enableType']").val();

            if(toAdd == 'true'){
                paramNamesPPP.push(realEnableName);
                paramValuesPPP.push(valEnable);
                paramTypesPPP.push(realEnableType);
                paramNamesIPv6.push(realEnableName);
                paramValuesIPv6.push(valEnable);
                paramTypesIPv6.push(realEnableType);
            }

            var realEnable = $("input[name='enableValue']").val();
            if (toAdd == 'false' && valEnable != realEnable) {
                isChanged = true;
                paramNamesPPP.push(realEnableName);
                paramValuesPPP.push(valEnable);
                paramTypesPPP.push(realEnableType);
                paramNamesIPv6.push(realEnableName);
                paramValuesIPv6.push(valEnable);
                paramTypesIPv6.push(realEnableType);
            }

            //----------------- default connection -----------------------------

            var defconn = $("input[name='defconn']");
            var valdefcon = '';
            if (defconn.is(":checked")) {
                valdefcon = '1';
            } else {
                valdefcon = '0';
            }

            var realdefconName = $("input[name='defconName']").val();
            var realdefconType = $("input[name='defconType']").val();
            var realdefcon = $("input[name='defconValue']").val();
            var isChecket = false;

            if(toAdd == 'true' && valdefcon == '1'){
                isChecket = true;
            }

            var interfaceType = $("#interfaceType option:selected").val();

            if ((paramNamesPPP.length != 0 || paramNamesIPv6.length != 0) && isValid && isChanged) {
                var index = $("input[name='index']").val();
                var connect_index = $("input[name='connect_index']").val();
                var id_conn = $("input[name='id_conn']").val();
                var actionType = $("input[name='actionType']").val();
                if(actionType == "addPPPDualStackWan") {
                    if ($('#refreshButton').css('display') == 'none') {
                        addPPPoEDualStackWan(devId, paramNamesPPP, paramValuesPPP, paramTypesPPP, paramNamesIPv6, paramValuesIPv6, paramTypesIPv6, interfaceType, actionType, type);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                addPPPoEDualStackWan(devId, paramNamesPPP, paramValuesPPP, paramTypesPPP, paramNamesIPv6, paramValuesIPv6, paramTypesIPv6, interfaceType, actionType, type);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }
                } else if(actionType == "changePPPDualStackWan") {

                }
            } else if (isValid && !isChanged) {
                $('body').css("cursor", "default");
                var failed = getMssg["nothing_changed"];
                $("#actionResWan").removeClass("infoMessage");
                $("#actionResWan").addClass("errorMessage");
                $("#actionResWan").empty();
                $("#actionResWan").html(failed);
                th.removeAttr("disabled");
//                                th.css("opacity", "1");
            } else {
                $('body').css("cursor", "default");
                th.removeAttr("disabled");
//                            th.css("opacity", "1");
                $("#actionResWan").empty();
            }
        }
    });

    function addPPPoEDualStackWan(devId, paramNamesPPP, paramValuesPPP, paramTypesPPP, paramNamesIPv6, paramValuesIPv6, paramTypesIPv6, interfaceType, actionType, type) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionType,
                'deviceID': devId,
                'changedParamNamesPPP': paramNamesPPP,
                'changedParamValuesPPP': paramValuesPPP,
                'changedParamTypesPPP': paramTypesPPP,
                'changedParamNamesIPv6': paramNamesIPv6,
                'changedParamValuesIPv6': paramValuesIPv6,
                'changedParamTypesIPv6': paramTypesIPv6,
                'interface_type': interfaceType,
                'type': type,
                'token': token_cookie
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);
                } else if(result.result == "false" || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if(result.result == "logged_out") {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

    function addPPPoEWan(devId, isChecket, index, connect_index, paramNames, paramValues, paramTypes, interfaceType, actionType, type) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionType,
                'deviceID': devId,
                "forWeb" : "",
                // 'defConnection': isChecket,
                // 'index': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'interface_type': interfaceType,
                'type': type,
                'token': token_cookie
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                        }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                            }, 2000);
                        }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                        }, 10000);
                    } else if(result.result == "false" || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                        }, 10000);
                    } else if(result.result == "logged_out") {
                    document.location.href = $basepath + 'login';
                    }
            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

    function editPPPoEWan(devId, id_conn, index, connect_index, paramNames, paramValues, paramTypes, actionType) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': actionType,
                'deviceID': devId,
                'forWeb' : "",
                // 'id': id_conn,
                'numIndex': index,
                // 'connectIndex': connect_index,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'token': token_cookie
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if(result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wan');
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);
                } else if(result.result == "false" || result.result == "Invalid token") {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if(result.result == "logged_out") {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                $(this).attr("disabled", "disabled");
                $(this).css("opacity", "0.5");
                $(this).css("cursor", "default");
                var msg = getMssg['update_page'];
                swal({
                    title: '',
                    text: msg,
                    showCancelButton: false,
                    closeOnConfirm: true,
                    confirmButtonText: '',
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){

                    }else{
                        $(this).removeAttr("disabled");
                        $(this).css("opacity","1");
                        $(this).css("cursor","pointer");
                    }
                });
            }
        });
    }

//    $(document).on("click","#cancelPPPWan",function(e){
//        $("#forReset").validate().resetForm();
//    });
//-------------------------------- end wanPPP.php ------------------------------

//-------------------------- wirelessPageForDevice.php -------------------------

    $(document).on("click","#wlanonoffswitch",function() {
        if ($(this).is(":checked")) {
            $(".BSSIDType").removeAttr("disabled");
//            $("#forBssid").css("opacity", "1");

        } else {
            $(".BSSIDType").attr("disabled", "disabled");
//            $("#forBssid").css("opacity", "0.6");
        }
    });

    $(document).on("change",".netAuthType",function() {
        var authTypeVal = $(".netAuthType option:selected").val();

        if (authTypeVal != "OPEN" && authTypeVal != "WPA" && authTypeVal != "WPA2" && authTypeVal != "WPA/WPA2 mixed" ) {
            $("#forPSk").css("visibility","visible");
        } else {
            $("#forPSk").css('visibility','hidden');
        }
        
        if (authTypeVal == "OPEN") {
            $("#forReneval").css("visibility","hidden");
        } else {
            $("#forReneval").css('visibility','visible');
        }
    });

    $(document).on("click","#cancelWLAN",function() {
        var enableWireless = $("input[name='enableWirelessValue']").val();
        if (enableWireless == 1) {
            $(".BSSIDType").removeAttr("disabled");
//            $("#forBssid").css("opacity", "1");
        } else {
            $(".BSSIDType").attr("disabled", "disabled");
//            $("#forBssid").css("opacity", "0.6");
        }

        var authValue = $("input[name='netAuthValue']").val();
        if (authValue != "OPEN" && authValue != "WPA" && authValue != "WPA2" && authValue != "WPA/WPA2 mixed") {
            $("#forPSk").css("visibility","visible");
        } else {
            $("#forPSk").css('visibility','hidden');
        }

        if (authValue == "OPEN") {
            $("#forReneval").css("visibility","hidden");
        } else {
            $("#forReneval").css('visibility','visible');
        }
    });
    
    $(document).on("click",".wlanParam",function() {
        var wlanId = $(this).parent().find("input[name='wlanID']").val();
        var mbSsid = $(this).closest('tr').find("input[name='enableMbssid']");
        var state = document.getElementById("mbssidonoffswitch"+wlanId);
        
        if(state.defaultChecked){
            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/checkDevStatus.php",
            //     data: {
            //         'deviceID': devId,
            //         'fromApp':true
            //     },
            //     async: true,
            //     success: function (result) {
            //
            //         if (result =='logged_out') {
            //             document.location.href = $basepath + 'login';
            //         } else {
            //             result = result.trim();
            //             devStatuss = result;
                        devStatuss = 'true';
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getTabPageForDevice.php",
                            data: {
                                'deviceID': devId,
                                'devStatus': devStatuss,
                                'havePermissions': havePerm,
                                'actionName': 'wireless',
                                'serialNumber':serialN,
                                'macAddress':macAddress,
                                'wlanId': wlanId,
                                'fromInnerPage' : true,
                                'fromApp': true
                            },
                            async: true,
                            success: function (result) {
                                if(result == 'logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else {
                                    $("#fragment-"+'wireless').empty();
                                    $("#fragment-"+'wireless').html(result);
                                    $(".eachFragment").hide();
                                    $("#fragment-"+'wireless').show();
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }else{
            var info = getMssg["wifi_mbssid_msg"];
            swal({
                title: '',
                text:info 
            });
        }
    });
    
//    $(document).on("click","input[name='enableMbssid']",function() {
//        var th = $(this);
//        th.attr('disabled','disabled');
//        var wlanId = th.closest('tr').find("input[name='wlanID']").val();
//        var state = document.getElementById("mbssidonoffswitch"+wlanId);
//        th.closest('tr').find(".wlanParam").addClass('templateInGroup');
//        var isAccessPoint = th.closest('tr').find("input[name='accessPoint']").val();
//        
//        if($(this).is(':checked')){
//            toggleWireless(th,true);
//            
//        }else{
//            if(isAccessPoint == 'false'){
//                toggleWireless(th,false);
//            }else{
//                var info = getMssg["wifi_mbssid_disable_msg"];
//                swal({
//                    title: '',
//                    text:info 
//                });
//                th.removeAttr("disabled");
//                th.prop('checked',state.defaultChecked);
//                th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
//            }
//        }
//    });
    
    jQuery.extend({
        compare: function (arrayA, arrayB) {
            if (arrayA.length != arrayB.length) { return false; }
            // sort modifies original array
            // (which are passed by reference to our method!)
            // so clone the arrays before sorting
            var a = jQuery.extend(true, [], arrayA);
            var b = jQuery.extend(true, [], arrayB);
            //sorting functionality is disabled for this case
            //a.sort(); 
            //b.sort();
            for (var i = 0, l = a.length; i < l; i++) {
                if (a[i] !== b[i]) { 
                    return false;
                }
            }
            return true;
        }
    });



    $(document).on("click","input[name='enableMbssid']",function() {
        // var defaultCheckeds = new Array();
        // var changedCheckeds = new Array();
        var finalChanges = new Array();
        var th = $(this);
        // defaultCheckeds.length = 0;
        // changedCheckeds.length = 0;
        finalChanges = [];

        var wlanId = th.closest('tr').find("input[name='wlanID']").val();
        var state = document.getElementById("mbssidonoffswitch"+wlanId);
        var isAccessPoint = th.closest('tr').find("input[name='accessPoint']").val();
        var isAccessPoint1 = th.closest('tr').find("input[name='accessPoint1']").val();

        // if(isAccessPoint == 'false' && isAccessPoint1 == 'false' ){
            // $("input[name='enableMbssid']").each(function () {
                var wlanId = $(this).closest('tr').find("input[name='wlanID']").val();
                var state = document.getElementById("mbssidonoffswitch"+wlanId);
                var index = $(this).closest('tr').find("input[name='numIndex']").val();

                // defaultCheckeds.push(state.defaultChecked);
                // changedCheckeds.push(this.checked);
                if(state.defaultChecked != this.checked){
                    finalChanges['index'+index] = this.checked;
                }
            // });
            
            // if(jQuery.compare(defaultCheckeds, changedCheckeds)){
            //     $('.apply_wireless_status').hide();
            // }else{
            //     $('.apply_wireless_status').show();
            // }
            // var th = $(this);
            th.attr('disabled','disabled');
            // $('#forReset').find(".wlanParam").addClass('templateInGroup');
            // $('#forReset').find("input[name='enableMbssid']").attr('disabled','disabled');

            if($('#refreshButton').css('display') == 'none'){
                var titleMsg = getMssg['title_msg'];
                var rmMsg =  getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOn = getMssg['msg_mbssid_turnOn'];
                var msgOff = getMssg['msg_mbssid_turnOff'];
                var msgOffOn = getMssg['msg_mbssid_changed'];

                swal({
                    title: titleMsg,
                    text: msgOffOn ,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){
                        toggleWireless(th,finalChanges);
                    }else{
                        //                th.prop('checked',state.defaultChecked);
                        //                th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
                        th.removeAttr("disabled");
                        $('#forReset').find(".wlanParam").removeClass("templateInGroup");
                        $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
                        $('.apply_wireless_status').hide();
                        if(th.is(':checked')) {
                            th.prop('checked',false).iCheck('update');
                        } else {
                            th.prop('checked', true).iCheck('update');
                        }
                        // for (var i in finalChanges) {
                        //     var numIndex = $("input[name='numIndex']").filter(function() { return this.value == i.substr(5); });
                        //     numIndex.closest('tr').find("input[name='enableMbssid']").attr('checked',!finalChanges[i]);
                        // }
                    }
                });

            }else{
                var titleMsg = getMssg['title_msg'];
                var rmMsg =  getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn ,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function(isConfirm) {
                    if(isConfirm){
                        toggleWireless(th,finalChanges);
                    }else{
                        th.removeAttr("disabled");
                        $('#forReset').find(".wlanParam").removeClass("templateInGroup");
                        $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
                    }
                });
            }


        /*}else{
            var info = getMssg["wifi_mbssid_disable_msg"];
            swal({
                title: '',
                text:info 
            });
            th.removeAttr("disabled");
            th.prop('checked',state.defaultChecked);
            th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
        }*/
        // if(isAccessPoint1 == 'false' && isAccessPoint == 'false'){
        //     $("input[name='enableMbssid']").each(function () {
        //         var wlanId = $(this).closest('tr').find("input[name='wlanID']").val();
        //         var state = document.getElementById("mbssidonoffswitch"+wlanId);
        //         var index = $(this).closest('tr').find("input[name='numIndex']").val();
        //         defaultCheckeds.push(state.defaultChecked);
        //         changedCheckeds.push(this.checked);
        //         if(state.defaultChecked != this.checked){
        //             finalChanges['index'+index] = this.checked;
        //         }
        //     });
        //
        //     if(jQuery.compare(defaultCheckeds, changedCheckeds)){
        //         $('.apply_wireless_status').hide();
        //     }else{
        //         $('.apply_wireless_status').show();
        //     }
        //
        // }else{
        //     var info = getMssg["wifi_mbssid_disable_msg"];
        //     swal({
        //         title: '',
        //         text:info
        //     });
        //     th.removeAttr("disabled");
        //     th.prop('checked',state.defaultChecked);
        //     th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
        // }
    });
    
    // $(document).on("click","#changeWifiStatuses",function(e) {
    //     e.preventDefault();
    //     var th = $(this);
    //     th.attr('disabled','disabled');
    //     $('#forReset').find(".wlanParam").addClass('templateInGroup');
    //     $('#forReset').find("input[name='enableMbssid']").attr('disabled','disabled');
    //
    //     if($('#refreshButton').css('display') == 'none'){
    //         var titleMsg = getMssg['title_msg'];
    //         var rmMsg =  getMssg['change_msg'];
    //         var cancelMsg = getMssg['cancel'];
    //         var msgOn = getMssg['msg_mbssid_turnOn'];
    //         var msgOff = getMssg['msg_mbssid_turnOff'];
    //         var msgOffOn = getMssg['msg_mbssid_changed'];
    //
    //         swal({
    //             title: titleMsg,
    //             text: msgOffOn ,
    //             showCancelButton: true,
    //             closeOnConfirm: true,
    //             confirmButtonText: rmMsg,
    //             cancelButtonText: cancelMsg,
    //             confirmButtonColor: "#008DA9"
    //         }, function(isConfirm) {
    //             if(isConfirm){
    //                 toggleWireless(th,finalChanges);
    //             }else{
    // //                th.prop('checked',state.defaultChecked);
    // //                th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
    //                 th.removeAttr("disabled");
    //                 $('#forReset').find(".wlanParam").removeClass("templateInGroup");
    //                 $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
    //                 $('.apply_wireless_status').hide();
    //
    //                 for (var i in finalChanges) {
    //                     var numIndex = $("input[name='numIndex']").filter(function() { return this.value == i.substr(5); });
    //                     numIndex.closest('tr').find("input[name='enableMbssid']").attr('checked',!finalChanges[i]);
    //                 }
    //             }
    //         });
    //
    //     }else{
    //         var titleMsg = getMssg['title_msg'];
    //         var rmMsg =  getMssg['change_msg'];
    //         var cancelMsg = getMssg['cancel'];
    //         var msgOffOn = getMssg['msg_mbssid_whatever_change'];
    //
    //         swal({
    //             title: titleMsg,
    //             text: msgOffOn ,
    //             showCancelButton: true,
    //             closeOnConfirm: true,
    //             confirmButtonText: rmMsg,
    //             cancelButtonText: cancelMsg,
    //             confirmButtonColor: "#008DA9"
    //         }, function(isConfirm) {
    //             if(isConfirm){
    //                 toggleWireless(th,finalChanges);
    //             }else{
    //                 th.removeAttr("disabled");
    //                 $('#forReset').find(".wlanParam").removeClass("templateInGroup");
    //                 $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
    //             }
    //         });
    //     }
    // });


    $(document).on("change","#onoffswitchWireless2_4ghz",function(e) {
        e.preventDefault();
        var th = $(this);
        var checkedVal = '';
        if(th.is(":checked")) {
            checkedVal = 1;
        } else {
            checkedVal = 0;
        }
        th.attr('disabled','disabled');
        var inputs = $(".wireless_2_4_gh table tbody tr td").find("input[name='numIndex']");
        var checkedInputs =  [];

        for(var i = 0; i < inputs.length; i++){
            checkedInputs.push($(inputs[i]).val());
        }
        if($('#refreshButton').css('display') == 'none'){
            var titleMsg = getMssg['title_msg'];
            var rmMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['cancel'];
            var msgOn = getMssg['msg_mbssid_turnOn'];
            var msgOff = getMssg['msg_mbssid_turnOff'];
            var msgOffOn = getMssg['msg_mbssid_changed'];

            swal({
                title: titleMsg,
                text: msgOffOn ,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(isConfirm){
                    enableWireless(checkedInputs, checkedVal);
                    th.prop('checked', false);
                }else{
                    th.prop('checked', false);
                    th.removeAttr("disabled");
                }
            });

        }else{
            var titleMsg = getMssg['title_msg'];
            var rmMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['cancel'];
            var msgOffOn = getMssg['msg_mbssid_whatever_change'];

            swal({
                title: titleMsg,
                text: msgOffOn ,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(isConfirm){
                    enableWireless(checkedInputs, checkedVal);
                    th.prop('checked', false);
                }else{
                    th.removeAttr("disabled");
                    th.prop('checked', false);
                }
            });
        }
    });

    $(document).on("change","#onoffswitchWireless5ghz",function(e) {
        e.preventDefault();
        var th = $(this);
        var checkedVal = '';
        if(th.is(":checked")) {
            checkedVal = 1;
        } else {
            checkedVal = 0;
        }
        th.attr('disabled','disabled');
        var inputs = $(".wireless_5_gh table tbody tr td").find("input[name='numIndex']");
        var checkedInputs =  [];

        for(var i = 0; i < inputs.length; i++){
            checkedInputs.push($(inputs[i]).val());
        }
        if($('#refreshButton').css('display') == 'none'){
            var titleMsg = getMssg['title_msg'];
            var rmMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['cancel'];
            var msgOn = getMssg['msg_mbssid_turnOn'];
            var msgOff = getMssg['msg_mbssid_turnOff'];
            var msgOffOn = getMssg['msg_mbssid_changed'];

            swal({
                title: titleMsg,
                text: msgOffOn ,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(isConfirm){
                    enableWireless(checkedInputs, checkedVal);
                    th.prop('checked', false);
                }else{
                    th.removeAttr("disabled");
                    th.prop('checked', false);
                }
            });

        }else{
            var titleMsg = getMssg['title_msg'];
            var rmMsg =  getMssg['change_msg'];
            var cancelMsg = getMssg['cancel'];
            var msgOffOn = getMssg['msg_mbssid_whatever_change'];

            swal({
                title: titleMsg,
                text: msgOffOn ,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function(isConfirm) {
                if(isConfirm){
                    enableWireless(checkedInputs, checkedVal);
                    th.prop('checked', false);
                }else{
                    th.removeAttr("disabled");
                    th.prop('checked', false);
                }
            });
        }
    });


    function enableWireless(checkedInputs, checkedVal) {
        var paramNames = [];
        var paramValues = [];
        var paramTypes = [];
        var paramIndex = [];

        for (var i in checkedInputs) {
            paramNames.push('RadioEnabled');
            paramValues.push(checkedVal);
            paramTypes.push('boolean');
            paramIndex.push(checkedInputs[i]);
        }
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'serialN': serialN,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
                'index': paramIndex,
                'actionName': "setWLan",
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                    }, 2000);
                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId,'wifi');
                        }, 2000);
                        intervalWireless.push(intervalRefresh);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);
                } else if (result == 'false') {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function toggleWireless(th,checked){
        
//        var titleMsg = getMssg['title_msg'];
//        var rmMsg =  getMssg['change_msg'];
//        var cancelMsg = getMssg['cancel'];
//        var msgOn = getMssg['msg_mbssid_turnOn'];
//        var msgOff = getMssg['msg_mbssid_turnOff'];
//        var msgOffOn = getMssg['msg_mbssid_changed'];
//        
//        swal({
//            title: titleMsg,
//            text: msgOffOn ,
//            showCancelButton: true,
//            closeOnConfirm: true,
//            confirmButtonText: rmMsg,
//            cancelButtonText: cancelMsg,
//            confirmButtonColor: "#008DA9"
//        }, function(isConfirm) {
//            if(isConfirm){
                var paramNames = [];
                var paramValues = [];
                var paramTypes = [];
                var paramIndex = [];
                
                for (var i in checked) {
                    paramNames.push('Enable');
                    paramValues.push(checked[i] ? '1' : '0');
                    paramTypes.push('boolean');
                    paramIndex.push(i.substr(5));
                }

//                var valEnableWireless = '';
//                if (checked) {
//                    valEnableWireless = '1';
//                } else {
//                    valEnableWireless = '0';
//                }
//                
//                if (checked != state.defaultChecked) {
////                    var realEnableWirelessName = $("input[name='enableWirelessName']").val();
////                    var realEnableWirelessType = $("input[name='enableWirelessType']").val();
//                    paramNames.push('Enable');
//                    paramValues.push(valEnableWireless);
//                    paramTypes.push('boolean');
//                }
              
//                var index = th.closest('tr').find("input[name='numIndex']").val();

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'serialN': serialN,
                        'changedParamNames': paramNames,
                        'changedParamValues': paramValues,
                        'changedParamTypes': paramTypes,
//                        'interface_type': interfaceType,
                        'index': paramIndex,
                        'actionName': "setWLan",
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#actionResWan").removeClass("errorMessage");
                            $("#actionResWan").addClass("infoMessage");
                            $("#actionResWan").empty();
                            $("#actionResWan").html(success);
                            setTimeout(function () {
                                updateActivities(devId);
                            }, 2000);
//                                        setTimeout(function () {
//                                            intervalSetTypeWifi = setInterval(function(){
//                                                getTaskStatus(devId,'wireless');
//                                            }, 2000);
//                                        }, 3000);

                            setTimeout(function () {
                                intervalRefresh = setInterval(function(){
                                    getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId,'wifi');
                                }, 2000);
                                intervalWireless.push(intervalRefresh);
                            }, 3000);

                            setTimeout(function () {
//                                            updateAfterTheAction();
                                $("#actionResWan").empty();
                            }, 10000);
                        } else if (result == 'false') {
                                $('body').css("cursor", "default");
                                var failed = getMssg['action_failed'];
                                $("#actionResWan").removeClass("infoMessage");
                                $("#actionResWan").addClass("errorMessage");
                                $("#actionResWan").empty();
                                $("#actionResWan").html(failed);

                                setTimeout(function () {
                                    updateAfterTheAction();
                                }, 10000);
                        } else if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
                
//            }else{
////                th.prop('checked',state.defaultChecked);
////                th.closest('tr').find(".wlanParam").removeClass("templateInGroup");
//                th.removeAttr("disabled");
//                $('#forReset').find(".wlanParam").removeClass("templateInGroup");
//                $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
//                $('.apply_wireless_status').hide();
//                
//                for (var i in finalChanges) {
//                    var numIndex = $("input[name='numIndex']").filter(function() { return this.value == i.substr(5); });
//                    numIndex.closest('tr').find("input[name='enableMbssid']").attr('checked',!finalChanges[i]);
//                }
//            }
//        });
    }

    
    $(document).on("click","#addWLAN",function(e) {
        e.preventDefault();
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
//            th.css("opacity", "0.5");

            // $.ajax({
            //     type: "POST",
            //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            //     data: {
            //         'deviceID': devId,
            //         'actionName': "connection",
            //         'fromApp': true
            //     },
            //     async: true,
            //     success: function (result) {
            //         if (result == 'true') {
                        var paramNames = [];
                        var paramValues = [];
                        var paramTypes = [];
                        var isValid = true;
                        var isChanged = false;
                        var pskMessage='';
                        var maxAssocClient = $("input[name='maxAssocClient']").val().trim();

                        var hideSSID = $("input[name='hidessidOnoffswitch']");
                        var valEnableHideSSID = '';
                        if (hideSSID.is(":checked")) {
                            valEnableHideSSID = '0';
                        } else {
                            valEnableHideSSID = '1';
                        }
                        var realEnableHideSSID = $("input[name='hideSSIdValue']").val();
                        if (valEnableHideSSID != realEnableHideSSID) {
                            isChanged = true;
                            var realEnableHideSSIDName = $("input[name='hideSSIdName']").val();
                            var realEnableHideSSIDType = $("input[name='hideSSIdType']").val();
                            paramNames.push(realEnableHideSSIDName);
                            paramValues.push(valEnableHideSSID);
                            paramTypes.push(realEnableHideSSIDType);
                        }
                        var enableWireless = $("input[name='enableWireless']");
                        var valEnableWireless = '';
                        if (enableWireless.is(":checked")) {
                            valEnableWireless = '1';
                        } else {
                            valEnableWireless = '0';
                        }
                        var realEnableWireless = $("input[name='enableWirelessValue']").val();
                        if (valEnableWireless != realEnableWireless) {
                            isChanged = true;
                            var realEnableWifiBeaconName = $("input[name='enableWirelessBeaconAdvertisementName']").val();
                            var realEnableWirelessType = $("input[name='enableWirelessType']").val();
                            paramNames.push(realEnableWifiBeaconName);
                            paramValues.push(valEnableWireless);
                            paramTypes.push(realEnableWirelessType);
                        }

                        var channel = $(".channelType option:selected").val();
                        var realChannelVal = $("input[name='channelValue']").val();
                        var AutoChannelEnable = $("input[name='AutoChannelEnable']").val();
                        if(AutoChannelEnable == 1 && channel != '-1'){
                            var realChannelName = '';
                            var realChannelType = '';
                            if (channel == 0) {
                                realChannelName = 'AutoChannelEnable';
                                realChannelType = 'boolean';
                                paramValues.push(1);
                            } else {
                                realChannelName = $("input[name='channelName']").val();
                                realChannelType = $("input[name='channelType']").val();
                                paramValues.push(channel);
                            }
                            isChanged = true;
                            paramNames.push(realChannelName);
                            paramTypes.push(realChannelType);
                            
                        }else if (channel != realChannelVal && channel != '-1') {
                            var realChannelName = '';
                            var realChannelType = '';
                            if (channel == 0) {
                                realChannelName = 'AutoChannelEnable';
                                realChannelType = 'boolean';
                                paramValues.push(1);
                            } else {
                                realChannelName = $("input[name='channelName']").val();
                                realChannelType = $("input[name='channelType']").val();
                                paramValues.push(channel);
                            }
                            isChanged = true;
                            paramNames.push(realChannelName);
                            paramTypes.push(realChannelType);
                        }

                        var standard = $(".standardType option:selected").val();
                        var realStandardVal = $("input[name='standardValue']").val();
                        if (standard != realStandardVal) {
                            isChanged = true;
                            var realStandardName = $("input[name='standardName']").val();
                            var realStandardType = $("input[name='standardType']").val();
                            paramNames.push(realStandardName);
                            paramValues.push(standard);
                            paramTypes.push(realStandardType);
                        }

                        var authVal = "";
                        var authValBeacon="";
                        var authVal1 = $(".netAuthType option:selected").val();
                        var realAuthVal = $("input[name='netAuthValue']").val();
                        if (authVal1 != realAuthVal) {
                            isChanged = true;
                            var realAuthName = '';
                            var realAuthType = $("input[name='netAuthType']").val();
                            if (authVal1 != 'OPEN' && authVal1 != "WPA" && authVal1 != "WPA2" && authVal1 != "WPA/WPA2 mixed" ) {
                                if (authVal1 == 'WPA-PSK') {
                                    realAuthName = 'WPAAuthenticationMode';
                                    authVal = 'PSKAuthentication';
                                    var realAuthName1 = 'BeaconType';
                                    authValBeacon = 'WPA';

                                    paramNames.push(realAuthName);
                                    paramValues.push(authVal);
                                    paramTypes.push(realAuthType);
                                    paramNames.push(realAuthName1);
                                    paramValues.push(authValBeacon);
                                    paramTypes.push(realAuthType);
                                } else if (authVal1 == 'WPA2-PSK') {
                                        realAuthName = 'IEEE11iAuthenticationMode';
                                        var realAuthName1 = 'BeaconType';
                                        authVal = 'PSKAuthentication';
                                        authValBeacon = '11i';

                                        paramNames.push(realAuthName);
                                        paramValues.push(authVal);
                                        paramTypes.push(realAuthType);
                                        paramNames.push(realAuthName1);
                                        paramValues.push(authValBeacon);
                                        paramTypes.push(realAuthType);
                                } else if (authVal1 == 'WPA-PSK/WPA2-PSK mixed') {
                                        var realAuthName1 = 'IEEE11iAuthenticationMode';
                                        var realAuthName2 = 'WPAAuthenticationMode';
                                        var realAuthName3 = 'BeaconType';
                                        authVal = 'PSKAuthentication';
                                        authValBeacon = 'WPAand11i';

                                        paramNames.push(realAuthName1);
                                        paramValues.push(authVal);
                                        paramTypes.push(realAuthType);
                                        paramNames.push(realAuthName2);
                                        paramValues.push(authVal);
                                        paramTypes.push(realAuthType);
                                        paramNames.push(realAuthName3);
                                        paramValues.push(authValBeacon);
                                        paramTypes.push(realAuthType);
                                //} else if (authVal1 == 'WPA/WPA2 mixed') {
                                //        var realAuthName1 = 'IEEE11iAuthenticationMode';
                                //        var realAuthName2 = 'WPAAuthenticationMode';
                                //        var realAuthName3 = 'BeaconType';
                                //        authVal = 'EAPAuthentication';
                                //        authValBeacon = 'WPAand11i';
                                //
                                //        paramNames.push(realAuthName1);
                                //        paramValues.push(authVal);
                                //        paramTypes.push(realAuthType);
                                //        paramNames.push(realAuthName2);
                                //        paramValues.push(authVal);
                                //        paramTypes.push(realAuthType);
                                //        paramNames.push(realAuthName3);
                                //        paramValues.push(authValBeacon);
                                //        paramTypes.push(realAuthType);
                                }
                            } else {
                                authVal = 'None';
                                realAuthName = 'BasicAuthenticationMode';
                                var realAuthName1 = 'BeaconType';
                                authValBeacon = 'Basic';

                                paramNames.push(realAuthName);
                                paramValues.push(authVal);
                                paramTypes.push(realAuthType);
                                paramNames.push(realAuthName1);
                                paramValues.push(authValBeacon);
                                paramTypes.push(realAuthType);
                            }
                        }

                        if(authVal != ''){
                            if (authVal != 'None') {
                                var presharedKey = $("input[name='presharedKey']");
                                var realPresharedKeyVal = $("input[name='presharedKeyValue']").val();
                                
                                if (presharedKey.val() != realPresharedKeyVal) {
                                    var msgRequired = getMssg['error_message_required'];
                                    var msgIp = getMssg['error_message_ip'];
                                    var msgMac = getMssg['error_message_mac'];
                                    var msgNetmask = getMssg['error_message_netmask'];
                                    var msgNumber = getMssg['error_message_number'];
                                    pskMessage = $("input[name='pskMessage']").val();
				    var msgGe0 = getMssg['error_message_ge_0'];
				    var lessThan = getMssg['error_message_less_than'];
                                    var pskMessageASCII = $("input[name='pskMessageASCII']").val();
                                    
                                    $("#forReset").validate({
                                        rules: {
                                            presharedKey: {
                                                validateLength: true,
                                                validateASCII: true
                                            },
                                            ssid: {
                                                required: true,
                                            },
                                            wpaReneval: {
                                                required: true,
                                                number: true,
						min: 0
                                            },
                                            maxAssociatedClients: {
                                                required: true,
                                                number: true,
						min: 0
                                            },
                                        },

                                        messages: {
                                            presharedKey: {
                                                validateLength: pskMessage,
                                                validateASCII: pskMessageASCII
                                            },
                                            ssid: {
                                                required: msgRequired,
                                            },
                                            wpaReneval: {
                                                required: msgRequired,
                                                number: msgNumber,
						min : msgGe0
                                            },
                                            maxAssociatedClients: {
                                                required: msgRequired,
                                                number: msgNumber,
						min : msgGe0
                                            },
                                        },
                                        errorElement: "div",
                                        errorClass: 'error_messageLan',
                                        errorPlacement: function(error, element) {
                                            var placement = $(element).data('error');
                                            if (placement) {
                                                $(placement).append(error)
                                            } else {
                                                error.insertAfter(element);
                                            }
                                        }
                                    });

                                    if(!($("#forReset").valid())) {
                                        th.removeAttr("disabled");
//                                        th.css("opacity", "1");
                                        return false;
                                    }
                                        
                                        pskMessage = "";
                                        isChanged = true;
                                        presharedKey.removeClass("invalidVal");
                                        var realPresharedKeyName = $("input[name='presharedKeyName']").val();
                                        var realPresharedKeyType = $("input[name='presharedKeyType']").val();
                                        paramNames.push(realPresharedKeyName);
                                        paramValues.push(presharedKey.val().replace(/ /g, '&#32;'));
                                        paramTypes.push(realPresharedKeyType);
                                    }
                            }
                            
                        } else if (authVal1 != 'OPEN' && authVal1 != "WPA" && authVal1 != "WPA2" && authVal1 != "WPA/WPA2 mixed") {
                                var presharedKey = $("input[name='presharedKey']");
                                var realPresharedKeyVal = $("input[name='presharedKeyValue']").val();
                                if (presharedKey.val() != realPresharedKeyVal) {
                                    
                                    var msgRequired = getMssg['error_message_required'];
                                    var msgIp = getMssg['error_message_ip'];
                                    var msgMac = getMssg['error_message_mac'];
                                    var msgNetmask = getMssg['error_message_netmask'];
                                    var msgNumber = getMssg['error_message_number'];
                                    pskMessage = $("input[name='pskMessage']").val();
				    var msgGe0 = getMssg['error_message_ge_0'];
                                    var lessThan = getMssg['error_message_less_than'];
                                    var pskMessageASCII = $("input[name='pskMessageASCII']").val();

                                    $("#forReset").validate({
                                        rules: {
                                            ssid: {
                                                required: true,
                                            },
                                            wpaReneval: {
                                                required: true,
                                                number: true,
						min: 0
                                            },
                                            maxAssociatedClients: {
                                                required: true,
                                                number: true,
						min: 0
                                            },
                                            presharedKey: {
                                                validateLength: true,
                                                validateASCII: true
                                            },
                                       
                                        },

                                        messages: {
                                            presharedKey: {
                                                validateLength: pskMessage,
                                                validateASCII: pskMessageASCII
                                            },
                                            ssid: {
                                                required: msgRequired,
                                            },
                                            wpaReneval: {
                                                required: msgRequired,
                                                number: msgNumber,
						min : msgGe0
                                            },
                                            maxAssociatedClients: {
                                                required: msgRequired,
                                                number: msgNumber,
						min : msgGe0
                                            },
                                        },
                                        errorElement: "div",
                                        errorClass: 'error_messageLan',
                                        errorPlacement: function(error, element) {
                                            var placement = $(element).data('error');
                                            if (placement) {
                                                $(placement).append(error)
                                            } else {
                                                error.insertAfter(element);
                                            }
                                        }
                                    });

                                    if(!($("#forReset").valid())) {
                                        th.removeAttr("disabled");
//                                        th.css("opacity", "1");
                                        return false;
                                    }

                                    pskMessage = "";
                                    isChanged = true;
                                    presharedKey.removeClass("invalidVal");
                                    var realPresharedKeyName = $("input[name='presharedKeyName']").val();
                                    var realPresharedKeyType = $("input[name='presharedKeyType']").val();
                                    paramNames.push(realPresharedKeyName);
                                    paramValues.push(presharedKey.val().replace(/ /g, '&#32;'));
                                    paramTypes.push(realPresharedKeyType);
                                }
                        }

                        var msgRequired = getMssg['error_message_required'];
                        var msgIp = getMssg['error_message_ip'];
                        var msgMac = getMssg['error_message_mac'];
                        var msgNetmask = getMssg['error_message_netmask'];
                        var msgNumber = getMssg['error_message_number'];
                        pskMessage = $("input[name='pskMessage']").val();
			var msgGe0 = getMssg['error_message_ge_0'];
                        var lessThan = getMssg['error_message_less_than'];
                        var pskMessageASCII = $("input[name='pskMessageASCII']").val();

                        $("#forReset").validate({
                            rules: {
                                ssid: {
                                    required: true,
                                },
                                wpaReneval: {
                                    required: true,
                                    number: true,
				    min: 0
                                },
                                maxAssociatedClients: {
                                    required: true,
                                    number: true,
				    min: 0
                                },
                                presharedKey: {
                                    validateLength: true,
                                    validateASCII: true
                                },
                            },

                            messages: {
                                ssid: {
                                    required: msgRequired,
                                },
                                wpaReneval: {
                                    required: msgRequired,
                                    number: msgNumber,
				    min : msgGe0
                                },
                                maxAssociatedClients: {
                                    required: msgRequired,
                                    number: msgNumber,
				    min : msgGe0
                                },
                                presharedKey: {
                                    validateLength: pskMessage,
                                    validateASCII: pskMessageASCII
                                },
                            },
                            errorElement: "div",
                            errorClass: 'error_messageLan',
                            errorPlacement: function(error, element) {
                                var placement = $(element).data('error');
                                if (placement) {
                                    $(placement).append(error)
                                } else {
                                    error.insertAfter(element);
                                }
                            }
                        });

                        if(!($("#forReset").valid())) {
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                            return false;
                        }

                        var ssid = $("input[name='ssid']");
                        var realSsidVal = $("input[name='ssidValue']").val();
                        pskMessage = "";
                        if (ssid.val().trim() != realSsidVal.trim()) {
                            ssid.removeClass("invalidVal");
                            isChanged = true;
                            var realSsidName = $("input[name='ssidName']").val();
                            var realSsidType = $("input[name='ssidType']").val();
                            paramNames.push(realSsidName);
                            paramValues.push(ssid.val());
                            paramTypes.push(realSsidType);
                        }
                        
                        var wpaReneval = $("input[name='wpaReneval']");
                        var wpaRenevalVal = wpaReneval.val().trim();
                        var realWpaRenevalVal = $("input[name='wpaRenevalValue']").val().trim();
                        if(authVal1 != 'OPEN'){
                            if (wpaRenevalVal != realWpaRenevalVal) {
                                isChanged = true;
                                var realWpaRenevalName = $("input[name='wpaRenevalName']").val();
                                var realWpaRenevalType = $("input[name='wpaRenevalType']").val();
                                paramNames.push(realWpaRenevalName);
                                paramValues.push(wpaRenevalVal);
                                paramTypes.push(realWpaRenevalType);
                            }
                        }
                        

//                        var interfaceType = $("#interfaceType option:selected").val();
//                        var realinterfaceType = $("input[name='interfaceTypeValue']").val();
//                        if (interfaceType != realinterfaceType) {
//                            isChanged = true;
                            //var realInterfaceTypeName = $("input[name='realInterfaceTypeName']").val();
                             //var realInterfaceTypeType = $("input[name='realInterfaceTypeType']").val();
                             //paramNames.push(realInterfaceTypeName);
                             //paramValues.push(interfaceType);
                             //paramTypes.push(realInterfaceTypeType);
//                        }
                        
                        var encrypVal = "";
                        var encrypValBeacon="";
                        var IEEE11Name = '';
                        var IEEE11Val = '';
                        var encrypSelectVal = $(".encryptionType option:selected").val();
                        var realEncrypVal = $("input[name='encryptionValue']").val();
                        var authSelectVal = $(".netAuthType option:selected").val();
                        
                        if(authVal1 != 'OPEN'){
                            if (encrypSelectVal != realEncrypVal) {
                                isChanged = true;
                                var realencrypName = '';
                                var encryptionType = $("input[name='encryptionType']").val();
                                if (authSelectVal == "WPA2" || authSelectVal == "WPA2-PSK") {
                                    if(encrypSelectVal == 'TKIPEncryption'){
                                        realencrypName = 'IEEE11iEncryptionModes';
                                        encrypVal = 'TKIPEncryption';

                                        paramNames.push(realencrypName);
                                        paramValues.push(encrypVal);
                                        paramTypes.push(encryptionType);

                                    }else if(encrypSelectVal == 'AESEncryption'){
                                        realencrypName = 'IEEE11iEncryptionModes';
                                        encrypVal = 'AESEncryption';

                                        paramNames.push(realencrypName);
                                        paramValues.push(encrypVal);
                                        paramTypes.push(encryptionType);

                                    }else if(encrypSelectVal == 'TKIPandAESEncryption'){
                                        realencrypName = 'IEEE11iEncryptionModes';
                                        encrypVal = 'TKIPandAESEncryption';

                                        paramNames.push(realencrypName);
                                        paramValues.push(encrypVal);
                                        paramTypes.push(encryptionType);
                                    }
                                }else if(authSelectVal == "WPA" || authSelectVal == "WPA-PSK"){

                                        if(encrypSelectVal == 'TKIPEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'TKIPEncryption';

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);
                                        }else if(encrypSelectVal == 'AESEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'AESEncryption';

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);

                                        }else if(encrypSelectVal == 'TKIPandAESEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'TKIPandAESEncryption';

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);
                                        } 

                                }else if(authSelectVal == "WPA/WPA2 mixed" || authSelectVal == "WPA-PSK/WPA2-PSK mixed"){

                                        if(encrypSelectVal == 'TKIPEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'TKIPEncryption';
                                            IEEE11Name = 'IEEE11iEncryptionModes';
                                            IEEE11Val = 'TKIPEncryption';

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);
                                            paramNames.push(IEEE11Name);
                                            paramValues.push(IEEE11Val);
                                            paramTypes.push(encryptionType);

                                        }else if(encrypSelectVal == 'AESEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'AESEncryption';
                                            IEEE11Name = 'IEEE11iEncryptionModes';
                                            IEEE11Val = 'AESEncryption';    

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);
                                            paramNames.push(IEEE11Name);
                                            paramValues.push(IEEE11Val);
                                            paramTypes.push(encryptionType);

                                        }else if(encrypSelectVal == 'TKIPandAESEncryption'){
                                            realencrypName = 'WPAEncryptionModes';
                                            encrypVal = 'TKIPandAESEncryption';
                                            IEEE11Name = 'IEEE11iEncryptionModes';
                                            IEEE11Val = 'TKIPandAESEncryption';  

                                            paramNames.push(realencrypName);
                                            paramValues.push(encrypVal);
                                            paramTypes.push(encryptionType);
                                            paramNames.push(IEEE11Name);
                                            paramValues.push(IEEE11Val);
                                            paramTypes.push(encryptionType);
                                        } 
                                }
                            }
                        }
                        
                        if(maxAssocClient != ''){
                            var maxAssociatedClients = $("input[name='maxAssociatedClients']").val().trim();
                            var maxAssociatedClientsName = $("input[name='maxAssociatedClientsName']").val().trim();
                            var maxAssociatedClientsValue = $("input[name='maxAssociatedClientsValue']").val().trim();
                            var maxAssociatedClientsType = $("input[name='maxAssociatedClientsType']").val().trim();
                            
                            if(maxAssociatedClients != maxAssociatedClientsValue){
                                isChanged = true;
                                paramNames.push(maxAssociatedClientsName);
                                paramValues.push(maxAssociatedClients);
                                paramTypes.push(maxAssociatedClientsType);
                            }
                        }
                        
                        var transmitPower = $(".transmitPower option:selected").val();
                        var realTransmitPowerVal = $("input[name='transmitPowerValue']").val();
                        if (transmitPower != realTransmitPowerVal) {
                            isChanged = true;
                            var realTransmitPowerName = $("input[name='transmitPowerName']").val();
                            var realTransmitPowerType = $("input[name='transmitPowerType']").val();
                            paramNames.push(realTransmitPowerName);
                            paramValues.push(transmitPower);
                            paramTypes.push(realTransmitPowerType);
                        }
                        
                        if (paramNames.length != 0 && isValid && isChanged) {
                            var index = $("input[name='numIndex']").val();
                            var wlanID = $("input[name='wlanID']").val();

                            if($('#refreshButton').css('display') == 'none') {
                                addWLAN(devId, serialN, paramNames, paramValues, paramTypes, index);
                            } else {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                swal({
                                    title: titleMsg,
                                    text: msgOffOn,
                                    showCancelButton: true,
                                    closeOnConfirm: true,
                                    confirmButtonText: rmMsg,
                                    cancelButtonText: cancelMsg,
                                    confirmButtonColor: "#008DA9"
                                }, function (isConfirm) {
                                    if (isConfirm) {
                                        addWLAN(devId, serialN, paramNames, paramValues, paramTypes, index);
                                    } else {
                                        th.removeAttr("disabled");
                                    }
                                });
                            }
//                            $.ajax({
//                                type: "POST",
//                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
//                                data: {
//                                    'deviceID': devId,
//                                    'serialN': serialN,
//                                    'changedParamNames': paramNames,
//                                    'changedParamValues': paramValues,
//                                    'changedParamTypes': paramTypes,
////                                    'interface_type': interfaceType,
//                                    'index': index,
//                                    'actionName': "setWLan",
//                                    'fromApp': true
//                                },
//                                async: false,
//                                success: function (result) {
//                                    if (result == 'true') {
//                                        var success = getMssg['action_succeed'];
//                                        $("#actionResWan").removeClass("errorMessage");
//                                        $("#actionResWan").addClass("infoMessage");
//                                        $("#actionResWan").empty();
//                                        $("#actionResWan").html(success);
//                                        setTimeout(function () {
//                                            updateActivities(devId);
//                                            getCorrentTaskIdByTab(devId,'wireless');
//                                            $('body').css("cursor", "default");
//                                        }, 2000);
//
////                                        setTimeout(function () {
////                                            intervalSetTypeWifi = setInterval(function(){
////                                                getTaskStatus(devId,'wireless');
////                                            }, 2000);
////                                        }, 3000);
//
//                                        setTimeout(function () {
//                                            intervalRefresh = setInterval(function(){
//                                                getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
//                                            }, 2000);
//                                        }, 3000);
//
//                                        setTimeout(function () {
////                                            updateAfterTheAction();
//                                            $("#actionResWan").empty();
//                                        }, 10000);
//                                    } else if (result == 'false') {
//                                            $('body').css("cursor", "default");
//                                            var failed = getMssg['action_failed'];
//                                            $("#actionResWan").removeClass("infoMessage");
//                                            $("#actionResWan").addClass("errorMessage");
//                                            $("#actionResWan").empty();
//                                            $("#actionResWan").html(failed);
//
//                                            setTimeout(function () {
//                                                updateAfterTheAction();
//                                            }, 10000);
//                                    } else if (result == 'logged_out') {
//                                            document.location.href = $basepath + 'login';
//                                    }
//                                },
//                                error: function(xhr, status, error) {
//                                    document.location.href = $basepath + '500';
//                                }
//                            });
                        }else if(isValid && !isChanged){
                                var failed = th.parent().find("input[name='nothingChange']").val();
                                $("#actionResWan").removeClass("infoMessage");
                                $("#actionResWan").addClass("errorMessage");
                                $("#actionResWan").empty();
                                $("#actionResWan").html(failed);
                                $("#enRes").empty();
//                                presharedKey.removeClass("invalidVal");
                                th.removeAttr("disabled");
//                                th.css("opacity","1");
                        } else if(!isValid && pskMessage!=''){
                                var failed = th.parent().find("input[name='nothingChange']").val();
                                $("#actionResWan").removeClass("infoMessage");
                                $("#actionResWan").addClass("errorMessage");
                                $("#actionResWan").empty();
                                $("#enRes").html(pskMessage);
                                th.removeAttr("disabled");
//                                th.css("opacity","1");
                        }else {
                            th.removeAttr("disabled");
//                            th.css("opacity","1");
                            $("#actionResWan").empty();
                        }
            //         } else if (result == 'false') {
            //                 $("input").attr("disabled", "disabled");
            //                 $("select").attr("disabled", "disabled");
            //                 $("#divForAdd").hide();
            //                 var msg = getMssg['dev_unavailable'];
            //                 $("#actionResWan").removeClass("infoMessage");
            //                 $("#actionResWan").addClass("errorMessage");
            //                 $("#actionResWan").empty();
            //                 $("#actionResWan").html(msg);
            //
            //                 setTimeout(function () {
            //                     updateAfterTheAction();
            //                 }, 10000);
            //         } else if (result = 'logged_out') {
            //                 document.location.href = $basepath + 'login';
            //         }
            //     },
            //     error: function(xhr, status, error) {
            //         document.location.href = $basepath + '500';
            //     }
            // });
        }
    });

    function addWLAN(devId, serialN, paramNames, paramValues, paramTypes, index) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            // url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'token': token_cookie,
                'deviceID': devId,
                // 'serialN': serialN,
                'changedParamNames': paramNames,
                'changedParamValues': paramValues,
                'changedParamTypes': paramTypes,
//                                    'interface_type': interfaceType,
                'index': index,
                // 'wlanID': wlanID,
                'actionName': "setWLan",
                // 'method': "setWLAN",
                'fromApp': true
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                if (result.result != 'false') {
                    var success = getMssg['action_succeed'];
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").addClass("infoMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'wireless');
                        $('body').css("cursor", "default");
                    }, 2000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
                        $("#actionResWan").empty();
                    }, 10000);
                } else if (result.result == 'false') {
                    $('body').css("cursor", "default");
                    var failed = getMssg['action_failed'];
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(failed);

                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);
                } else if (result.result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    $(document).on("change",".transmitPower",function(){
        var th = $(this);
        var transmitPower = $(".transmitPower option:selected").val();
        if(transmitPower == '300'){
            var info = getMssg["message_tx_power"];
            swal({
                title: '',
                text: info
            });
        }
    });
    
    $(document).on("click","#cancelWLAN",function(e){
        $("#forReset").validate().resetForm();
        $('#actionResWan').empty();
    });
//------------------------ end wirelessPageForDevice.php -----------------------

//------------------------ Devices Task ----------------------------------------
//------------------------ updatePageForDevice.php -----------------------------
    
    var tasksStatus = '';

    $(document).on("change", ".changeAction", function () {
        $("#resDev").empty();
        $("body").css("cursor", "wait");
        var action = $('option:selected',this).val();
        if(action == 0) {
            clearInterval(interval);
            $('.applyTask').hide();
            $("#contentUpdate").empty();
            $('.search-Task').hide();
            $('.taskIntSec').hide();
        }
        if (action == 'updateConfig') {
            clearInterval(interval);
            $('.applyTask').hide();
            $('.search-Task').hide();
            $('.taskIntSec').hide();
             $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
                data: {
                    'taskName':"'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",
                    'deviceID': devId,
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    var disabled = false;
                    if (result =='logged_out') {
                        document.location.href = $basepath + 'login';
                    }else if(result == 0 || result == 1){
                        disabled = true;
                    } else {disabled = false;}
                    tasksStatus = disabled;
                    
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/getConfigs.php",
                        data: {
                            'deviceID': devId,
                            'actionName': "getConfigs",
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if(result!='logged_out'){
                                $("#contentUpdate").html("");
                                $("#contentUpdate").html(result);
                                $("body").css("cursor", "default");
                                if(tasksStatus){
                                    $('.updateConfig').attr('disabled','disabled');
                                    $('.changeDeviceConfig').attr('disabled','disabled');
                                }
                            } else {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            
        } else if (action == 'upgradeDevice') {
                clearInterval(interval);
                $('.applyTask').hide();
                $('.search-Task').hide();
                $('.taskIntSec').hide();
                
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
                    data: {
                        'taskName':"'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",
                        'deviceID': devId,
                        'fromApp':true
                    },
                    async: true,
                    success: function (result) {
                        var disabled = false;
                        if (result =='logged_out') {
                            document.location.href = $basepath + 'login';
                        }else if(result == 0 || result == 1){
                            disabled = true;
                        } else {disabled = false;}
                        tasksStatus = disabled;
                        
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getFWs.php",
                            data: {
                                'deviceID': devId,
                                'actionName': "getFirmwares",
                                'fromApp':true
                            },
                            async: false,
                            success: function (result) {
                                if(result!='logged_out'){
                                    $("#contentUpdate").html("");
                                    $("#contentUpdate").html(result);
                                    $("body").css("cursor", "default");
                                    if(tasksStatus){
                                        $('.updateFW').attr('disabled','disabled');
                                        $('.changeDeviceFw').attr('disabled','disabled');
                                    }
                                } else {
                                    document.location.href = $basepath + 'login';
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
        } else if(action=='log' || action=='config' || action=='custom'){
                $("body").css("cursor", "default");
                window.clearInterval(interval);
                var applyId = '';
//                if(action == 'refresh'){
//                    applyId = 'refreshDev';
//                } else 
                if(action == 'log'){
                    applyId = 'logDev';
                } else if(action == 'configconfig'){
                    applyId = 'configDev';
                } else if(action == 'custom'){
                    applyId = 'customDev';
                }
                
                interval = setInterval(function(){
                    getTaskStatusOfTheDevice("'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",devId);
                },1000);
                showTaskApplyButton(action);
//                $('.applyTaskbtn').attr('id',applyId);
//                $('.applyTaskbtn').removeAttr("disabled");
//                $('.applyTaskbtn').css("opacity","1");
//                $('.applyTaskbtn').css("cursor","default");
//                $('.search-Task').hide();
                $('.taskIntSec').hide();
//                $("#contentUpdate").empty();
//                $('.applyTask').show();
        } else if(action == 'reboot' || action == 'reset' || action == 'refresh'){
                clearInterval(interval);
                $('.search-Task').hide();
                $('.taskIntSec').hide();
                
                interval = setInterval(function(){
                    getTaskStatusOfTheDevice("'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",devId);
                },1000);
                showTaskApplyButton(action);
        } else if(action=='owner'){
                clearInterval(interval);
                $('.applyTask').hide();
                $('.taskIntSec').hide();
                $('.search-Task').show();
                $("#contentUpdate").empty();
                $("body").css("cursor", "default");
        } else if(action=='informTime'){
                clearInterval(interval);
                $('.applyTask').hide();
                $('.search-Task').hide();
                $('.taskIntSec').show();
                $("#contentUpdate").empty();
                $("body").css("cursor", "default");
        }
    });

    function showTaskApplyButton(taskName){
        $("body").css("cursor", "default");
        var applyId = '';
        if(taskName == 'reboot'){
            applyId = 'rebootDev';
        } else if(taskName == 'reset'){
            applyId = 'resetDev';
        } else if(taskName == 'refresh'){
            applyId = 'refreshDev';
        } else if(taskName == 'log'){
            applyId = 'logDev';
        } else if(taskName == 'config'){
            applyId = 'configDev';
        } else if(taskName == 'custom'){
            applyId = 'customDev';
        }
        
        $('.applyTaskbtn').attr('id',applyId);
        $("#contentUpdate").empty();
        $('.applyTask').show();
        $('.search-Task').hide();
    }

    function getTaskStatusOfTheDevice(taskName,deviceId){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName':taskName,
                'deviceID': deviceId,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                var disabled = false;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result == 0 || result == 1){
                    disabled = true;
                }else { 
                    disabled = false;
                }
                
                tasksStatus = disabled;
                
                if(disabled){
                    $('.applyTaskbtn').attr('disabled','disabled');
                    $('.updateFW').attr('disabled','disabled');
                    $('.changeDeviceFw').attr('disabled','disabled');
                }else {
                    $('.applyTaskbtn').removeAttr("disabled");
                    $('.updateFW').removeAttr("disabled");
                    $('.changeDeviceFw').removeAttr("disabled");
                    $('.changeDeviceFw').css("cursor", "pointer");
                    $('.updateConfig').removeAttr("disabled");
                }
            },
            error: function(xhr, status, error) {
                // alert(error);
                // document.location.href = $basepath + '500';
            }
        });
    }
    
    function getTaskStatusOfTheDeviceForAutoRefresh(th,taskName,deviceId){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName':taskName,
                'deviceID': deviceId,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                var disabled = false;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result == 0 || result == 1 || result == 3){
                    disabled = true;
                }else { 
                    disabled = false;
                }
                
                tasksStatus = disabled;
                
                if(disabled){
                    th.attr('disabled','disabled');
//                    th.css("opacity", "0.5");
//                    th.css("cursor", "default");
                }else {
//                    th.css("opacity", "1");
//                    th.css("cursor", "pointer");
                    th.removeAttr("disabled");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    function getTaskStatusForRefresh(th,taskName,deviceId){
        th.attr("disabled", "disabled");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName':taskName,
                'deviceID': deviceId,
                'fromApp':true
            },
            async: true,
            success: function (result) {
                var changed = true;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result == 2){
                    changed = true;
                }else if(result == 1 || result == 0 || result == -1) { 
                    changed = false;
                }else {
                    changed = true;
                }
                
                if(changed){
                    th.hide();
                    th.removeAttr("disabled");
                    clearInterval(intervalTaskRefresh);
                    updateAfterTheAction();
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    function getTaskStatusOfTheDeviceForRefreshButton(taskName,deviceId,tab){
        var i=0;
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName': taskName,
                'deviceID': deviceId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                var changed = true;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result == 2){
                    changed = true;
                }else if(result == 1 || result == 0) { 
                    changed = false;
                }else {
                    changed = false;
                    clearInterval(intervalRefresh);
                    if(tab == 'wifi'){
                        $('#changeWifiStatuses').removeAttr("disabled");
                        $('#forReset').find(".wlanParam").removeClass("templateInGroup");
                        $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
                    }
                }

                if(changed){
                    setTimeout(function () {
                        $('#refreshButton').show();
                    }, 1000);

                    intervalWireless.forEach(function(e){
                        clearInterval(e);
                    });
                    delete intervalWireless;
                    if(tab == 'wifi'){
                        $('#changeWifiStatuses').removeAttr("disabled");
                        $('#forReset').find(".wlanParam").removeClass("templateInGroup");
                        $('#forReset').find("input[name='enableMbssid']").removeAttr('disabled');
                        var th = '';
                        $('.nav-tabs').find(".fragment").each(function() {
                            if($(this).attr('id') == 'wireless'){
                                th = $(this);
                            }
                        });
                        if(th.parent().hasClass('activeTabLi')){
                            $('body').oLoader('show');
                            getSettiongsByTab(th,'wireless',true,false);
                        }
                    }
                }
            },
            error: function(xhr, status, error) {
                if (i==3) {
                    document.location.href = $basepath + '500';
                } else {
                    i++;
                    getTaskStatusOfTheDeviceForRefreshButton(taskName,deviceId,tab);
                }
            }
        });
    }

    $(document).on("click","#searchClientForChangeOwner",function () {
        $("body").css("cursor", "wait");
        var firstName = $("input[name='searchFirstName']").val();
        var surName = $("input[name='searchSurName']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForChangeOwner.php",
            data: {
                'deviceId':devId,
                'firstName': firstName,
                'surName': surName,
                'page': 1,
                'fromApp':true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#searchedClients").empty();
                    $("#searchedClients").show();
                    $("#searchedClients").html(data);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click","#rebootDev",function(){
        var th = $(this);
        applyTasksActions(th,'reboot');
    });

    $(document).on("click","#resetDev",function(){
        var th = $(this);
        applyTasksActions(th,'reset');
    });
    $(document).on("click","#refreshDev",function(){
        var th = $(this);
        clearInterval(intervalSetTypeInfo);
        clearInterval(intervalSetTypeLan);
        clearInterval(intervalSetTypeWan);
        clearInterval(intervalSetTypeWifi);
        clearInterval(intervalSetTypeVlan);
        clearInterval(intervalSetTypeStatistics);
        clearInterval(intervalSetTypeStatisticRouting);
        clearInterval(intervalSetTypeStatisticInterfaces);
        clearInterval(intervalSetTypeStatisticClients);
        clearInterval(intervalSetTypeVoip);
        clearInterval(intervalRefresh);
       
        $('.nav-tabs').find(".fragment").each(function() {
            $(this).removeClass('hasChanged');
            $(this).attr('title', '');
        });

        if($('#refreshButton').css('display') != 'none'){
            $('#refreshButton').hide();
        }
        
        applyTasksActions(th,'refresh');
    });

    $(document).on("click","#autoRefreshDev",function(){
	var th = $(this);
	applyTasksActions(th,'auto_refresh');
    });
    
    $(document).on("click","#refreshButton",function(){
        var devId = $("input[name='devID']").val();
	    var th = $(this);
        th.attr("disabled", "disabled");
        ajaxRequest.send({
            type: globalVar.HTTP.POST,
            data: {
                'deviceID': devId,
                'actionName': globalVar.TASKS.REFRESH,
                'fromApp':true
            },
            response: function (respons) {
                updateActivities(devId);
                var success = getMssg['action_succeed'];
                $("#actionRes").empty();
                $("#actionRes").addClass('infoMessage');
                $("#actionRes").html(success);
                $("body").css("cursor", "default");
                updateActivities(devId);
                var id = devId;
                $("body").css("cursor", "default");
            },
            getStatus: function (status) {
                $("#getAllParams").hide();
                $("#refresh_page").show();
                $("#actionRes").empty();
            }
        });
	    //applyTasksActions(th,'refreshButton');
    });

    $(".devices_bl").on("click","#logDev",function(){
        var th = $(this);
        applyTasksActions(th,'log');
    });

    $(".devices_bl").on("click","#configDev",function(){
        var th = $(this);
        applyTasksActions(th,'configUp');
    });

    $(".devices_bl").on("click","#customDev",function(){
        var th = $(this);
        applyTasksActions(th,'custom');
    });

    function applyTasksActions(th,actionName){
        if(actionName == 'reboot' || actionName == 'reset' || actionName=='refresh'){
            if(th.attr("disabled")!="disabled"){
                th.attr("disabled", "disabled");
//                th.css("opacity", "0.5");
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': actionName,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#resDev").empty();
                            $("#resDev").html(success);
                            $("#resDev").removeClass("errorMessage");
                            $("#resDev").addClass("infoMessage");
                            interval = setInterval(function(){
                                getTaskStatusOfTheDevice("'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",devId);
                            },1000);
                            setTimeout(function () {
                                updateActivities(devId);
    //                            th.removeAttr("disabled");
    //                            th.css("opacity","1");
    //                            th.css("cursor","default");
                                $("#resDev").empty();
                            }, 3000);
                            
                        } else if (result == 'false'){
                                $("body").css("cursor", "default");
                                var failed = getMssg['action_failed'];
                                $("#resDev").removeClass("infoMessage");
                                $("#resDev").addClass("errorMessage");
                                $("#resDev").empty();
                                $("#resDev").html(failed);
                        } else if (result = 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        } else if(actionName == 'log' || actionName == 'configUp' || actionName == 'custom'){
            if(th.attr("disabled")!="disabled"){
                th.attr("disabled", "disabled");
//                th.css("opacity", "0.5");
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': actionName,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#resDev").empty();
                            $("#resDev").html(success);
                            $("#resDev").removeClass("errorMessage");
                            $("#resDev").addClass("infoMessage");
                            setTimeout(function () {
                                updateActivities(devId);
                                // th.removeAttr("disabled");
//                                th.css("opacity","1");
//                                th.css("cursor","default");
                                $("#resDev").empty();
                            }, 3000);
                        } else if (result == 'false'){
                                $("body").css("cursor", "default");
                                var failed = getMssg['action_failed'];
                                $("#resDev").removeClass("infoMessage");
                                $("#resDev").addClass("errorMessage");
                                $("#resDev").empty();
                                $("#resDev").html(failed);
                        } else if (result = 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }else if(actionName == 'auto_refresh'){
             if(th.attr("disabled")!="disabled"){
                th.attr("disabled", "disabled");
//                th.css("opacity", "0.5");
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': actionName,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#resDev").empty();
                            $("#resDev").html(success);
                            $("#resDev").removeClass("errorMessage");
                            $("#resDev").addClass("infoMessage");
                            intervalAutoRefresh = setInterval(function(){
                                getTaskStatusOfTheDeviceForAutoRefresh(th,"'autoRefresh'",devId);
                            },1000);
                            setTimeout(function () {
                                updateActivities(devId);
//                                th.removeAttr("disabled");
//                                th.css("opacity","1");
//                                th.css("cursor","default");
                                $("#resDev").empty();
                            }, 3000);

                        } else if (result == 'false'){
                                $("body").css("cursor", "default");
                                var failed = getMssg['action_failed'];
                                $("#resDev").removeClass("infoMessage");
                                $("#resDev").addClass("errorMessage");
                                $("#resDev").empty();
                                $("#resDev").html(failed);
                        } else if (result = 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }else if(actionName == 'refreshButton'){
            
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': 'refresh',
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
//                            var success = $('#succeed').data('succeed');
//                            $("#resDev").empty();
//                            $("#resDev").html(success);
//                            $("#resDev").removeClass("errorMessage");
//                            $("#resDev").addClass("infoMessage");
                            intervalTaskRefresh = setInterval(function(){
                                getTaskStatusForRefresh(th,"'refresh'",devId);
                            },1000);
                            setTimeout(function () {
                                updateActivities(devId);
    //                            th.removeAttr("disabled");
    //                            th.css("opacity","1");
    //                            th.css("cursor","default");
//                                $("#resDev").empty();
                            }, 3000);
                            
                        } else if (result == 'false'){
//                                $("body").css("cursor", "default");
//                                var failed = $('#acctionfailed').data('acctionfailed');
//                                $("#resDev").removeClass("infoMessage");
//                                $("#resDev").addClass("errorMessage");
//                                $("#resDev").empty();
//                                $("#resDev").html(failed);
                        } else if (result = 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
        }
    }

    
//------------- pagination for searchedClientsForChangeOwner.php ---------------

    $(document).on("click",".eachClientPage", function () {
        $("body").css("cursor", "wait");
        var firstName = $("input[name='searchFirstName']").val();
        var surName = $("input[name='searchSurName']").val();
        var page = $(this).find("input[name='page']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientsForChangeOwner.php",
            data: {
                'deviceId': devId,
                'firstName': firstName,
                'surName': surName,
                'page': page,
                'fromApp':true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#searchedClients").empty();
                    $("#searchedClients").html(data);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

//------------- end pagination for searchedClientsForChangeOwner.php -----------

    $(document).on("click", "#changeDeviceOwner", function () {
        $("body").css("cursor", "wait");
        if ($("input[name='clientID']:checked").length == 0) {
            var select_client = $("input[name='selectClient']").val();
            $("#errConnect").empty();
            $("#errConnect").removeClass("infoMessage");
            $("#errConnect").addClass("errorMessage");
            $("#errConnect").html(select_client);
            $("body").css("cursor", "default");
        } else {
            var clientId = $("input[name='clientID']:checked").val();
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'clientID': clientId,
                    'actionName': "changeClient",
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                            var success = $("input[name='ownerMessage']").val();
                            $("#errConnect").empty();
                            $("#errConnect").removeClass("errorMessage");
                            $("#errConnect").addClass("infoMessage");
                            $("#errConnect").html(success);
                            $("body").css("cursor", "default");
                            setTimeout(function () {
//                                var countForm = $("#infoId").length;
//                                if(countForm > 0){
//                                    $("#infoId").submit();
//                                } else {
//                                    var newForm='<form action="'+ $basepath +'devInfo/" id="infoId"  method="post" ><input type="hidden" name="devId" value="'+devId+'" /></form>';
//                                    $(".devices_bl").append(newForm);
//                                    $("#infoId").submit();
//                                }
                                location.reload(true);
                            }, 5000);
                    } else {
                        var failed = $("input[name='ownerFailMessage']").val();
                        $("#errConnect").empty();
                        $("#errConnect").removeClass("infoMessage");
                        $("#errConnect").addClass("errorMessage");
                        $("#errConnect").html(failed);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click","#setInfoTime",function(){
        var th = $(this);
        var time = document.getElementsByName('infTime')[0].value;
        if(time.trim() != ''){
            if(th.attr("disabled")!="disabled"){
                th.attr("disabled", "disabled");
//                th.css("opacity", "0.5");
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'informTime':time,
                        'deviceID': devId,
                        'actionName': "informTimeDev",
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            $("#resDev").removeClass("errorMessage");
                            $("#resDev").addClass("infoMessage");
                            $("#resDev").empty();
                            $("#resDev").html(success);
                            setTimeout(function () {
                                updateActivities(devId);
                                th.removeAttr("disabled");
                                $("#resDev").empty();
                            }, 3000);
                            // setTimeout(function () {
                            //     updateActivities(devId);
                            //     th.removeAttr("disabled");
//                                th.css("opacity","1");
//                                th.css("cursor","default");
//                                var countForm = $("#infoId").length;
//                                if(countForm > 0){
//                                    $("#infoId").submit();
//                                } else {
//                                    var newForm='<form action="'+ $basepath +'devInfo/" id="infoId"  method="post" ><input type="hidden" name="devId" value="'+devId+'" /></form>';
//                                    $(".devices_bl").append(newForm);
//                                    $("#infoId").submit();
//                                }
//                                 location.reload(true);
//                             }, 5000);
                        } else if (result == 'false'){
                                $("body").css("cursor", "default");
                                var failed = getMssg['action_failed'];
                                $("#resDev").removeClass("infoMessage");
                                $("#resDev").addClass("errorMessage");
                                $("#resDev").empty();
                                $("#resDev").html(failed);
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }else{
            $("body").css("cursor", "default");
            var failed = $("input[name='intervalMsg']").val();
            $("#resDev").removeClass("infoMessage");
            $("#resDev").addClass("errorMessage");
            $("#resDev").empty();
            $("#resDev").html(failed);
        }
    });

//------------------------ end updatePageForDevice.php -------------------------

//-------------------------- update_config.php ---------------------------------
    function updateConfigFirmware(th,fileId,actionname){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'token': token_cookie,
                'fileID': fileId,
                'actionName': actionname,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    setTimeout(function () {
                        updateActivities(devId);
                        th.attr("disabled","disabled");
                        $('.changeDeviceConfig').attr('disabled','disabled');
                    }, 2000);
                    var success = getMssg['action_succeed'];
                    $("#resDev").removeClass("errorMessage");
                    $("#resDev").addClass("infoMessage");
                    $("#resDev").empty();
                    $("#resDev").html(success);
                    
                    interval = setInterval(function(){
                        getTaskStatusOfTheDevice("'reboot','reset','refresh','config','firmware','logUp','configUp','customlogUp'",devId);
                    },1000);
                    
                    if(actionname == 'config'){
                        setTimeout(function () {
                            intervalRefresh = setInterval(function(){
                                getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                            }, 2000);
                        }, 3000); 
                    }
                    
                    setTimeout(function () {
                        $("body").css("cursor", "default");
//                        var updated_config = getMssg['updated_config'];
                        $(".addedTR").remove();
//                        th.removeAttr("disabled");
                        $("#resDev").empty();
//                        $("#resDev").html(updated_config);
                    }, 10000);
                } else if (result == 'false'){
                        var failed = getMssg['action_failed'];
                        $("#resDev").removeClass("infoMessage");
                        $("#resDev").addClass("errorMessage");
                        $("#resDev").empty();
                        $("#resDev").html(failed);
                        setTimeout(function () {
                            $("body").css("cursor", "default");
                            $(".addedTR").remove();
                            $("#resDev").empty();
                        }, 10000);
                } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    } 

        
    $(document).on("click", ".updateConfig", function () {
        var th = $(this);
        var fileId = $(".changeDeviceConfig option:selected").val();
        if (fileId == 0) {
            var noFileSelected = getMssg['select_device'];
            swal(' ', noFileSelected);
        } else {
            $("body").css("cursor", "wait");
            updateConfigFirmware(th,fileId,"config")
        }
    });

    function getConfigFwStatus(taskName,fileId){
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getConfigFwStatusOfTheDevice.php",
            data: {
                'taskName': taskName,
                'deviceID': devId,
                'fileId': fileId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                var disabled=false;
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                }else if(result==0 || result==1){
                    $(".updateConfig").attr("disabled","disabled");
                } else {
                    $(".updateConfig").removeAttr("disabled");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("change", ".changeDeviceConfig", function () {
        var configId = $("option:selected",this).val();
        if(configId != 0){
            getConfigFwStatus("config",configId);

        } else {
            $(".updateConfig").removeAttr("disabled");
        }
    });

//------------------------ end update_config.php -------------------------------

//--------------------------- update_fw.php ------------------------------------

    $(document).on("change", ".changeDeviceFw", function () {
//        $("body").css("cursor", "wait");
        var fwId = $("option:selected",this).val();
        if(fwId != 0){
            // $(".rmFwfile").css("visibility", "visible");
            getConfigFwStatus("fw",fwId);

        } else {
            // $(".rmFwfile").css("visibility", "hidden");
            $(".updateFW").removeAttr("disabled");
//            $(".updateFW").css("opacity","1");
//            $(".updateFW").css("cursor","pointer");
        }
    });

    $(document).on("click", ".updateFW", function () {
        var th = $(this);
        var fwId = $(".filesName option:selected").val();
        if (fwId == 0) {
            var noFileSelected = getMssg['select_device'];
            swal(' ', noFileSelected);
        } else {
            $("body").css("cursor", "wait");
            updateConfigFirmware(th,fwId,"firmware");      
        }
    });

    
//     $(document).on("click", ".rmFwfile", function () {
//         var th = $(this);
//         var fwSelectBox = $(".filesName");
//         var fwId = $(".filesName option:selected").val();
//
//         var titleMsg = getMssg['title_msg'];
//         var rmMsg =  getMssg['remove_msg'];
//         var cancelMsg = getMssg['cancel'];
//         var msg = getMssg['msg_fw'];
// //        var deviceID = th.parent().parent().find("input[name='devID']").val();
//         swal({
//             title: titleMsg,
//             text: msg,
//             showCancelButton: true,
//             closeOnConfirm: true,
//             confirmButtonText: rmMsg,
//             cancelButtonText: cancelMsg,
//             confirmButtonColor: "#008DA9"
//         }, function(isConfirm) {
//             if(isConfirm){
//                 $.ajax({
//                     type: "POST",
//                     url:  $basepath + "secureFiles/actions/ajaxActions/getFWs.php",
//                     data: {
//                         'deviceID': devId,
//                         'actionName': "removeFw",
//                         'firmwareId': fwId,
//                         'fromApp':true
//                     },
//                     async: false,
//                     success: function (result) {
//                         if (result == 'true') {
//                             $(".filesName option:selected").remove();
//                             $(".rmFwfile").css("visibility", "hidden");
//                             var msg = getMssg['no_fw'];
//                             if (fwSelectBox.find("option").length <= 1) {
//                                 $("#contentUpdate").empty();
//                                 $("#contentUpdate").html('<span style ="margin-left: 20px;">'+ msg +'</span>');
//                             }
//
//                         } else if (result == 'logged_out') {
//                             document.location.href = $basepath + 'login';
//                         }
//                     },
//                     error: function(xhr, status, error) {
//                         document.location.href = $basepath + '500';
//                     }
//                 });
//             }else{
//                 th.removeAttr("disabled");
// //                th.css("opacity","1");
// //                th.css("cursor","pointer");
//             }
//         });
//     });
    
//--------------------------- end update_fw.php --------------------------------
    
    $(document).on("click", "#addBridge", function (e) {
        e.preventDefault();
	var th = $(this);
        th.attr("disabled","disabled");
        $("#forVlanIdError").empty();
        var bridgeType = $("#bridgeType option:selected").val();
        var msgRequird = getMssg['error_message_required'];
	var msgNumber = getMssg['error_message_number'];
	var msgGe1 = getMssg['error_message_ge_1'];
	var msgLe4094 = getMssg['error_message_le_4094'];
	var msgPort = getMssg['error_message_port'];
        var noSpaces = getMssg['error_message_empty'];

        $('#createBridge').validate({
	    rules: {
		bridgeName: {
		    required: true,
            validateIsEmpty: true
		},
		vlanID: {
		    required: true,
            digits: true,
		    number: true,
		    min : 1,
		    max: 4094
		},
                port: {
                   required: true 
                },
                uport: {
                   required: true 
                }
	    },
	    messages: {
		bridgeName: {
		    required:  msgRequird,
            validateIsEmpty: noSpaces
		},
		vlanID: {
		    required: msgRequird,
		    number: msgNumber ,
		    min : msgGe1,
		    max: msgLe4094,
            digits: msgNumber
		},
                port: {
                   required: msgPort 
                },
                uport: {
                   required: msgPort 
                }
	    },
	    errorElement: "div",
	    errorClass: 'error_message error_messageVlan',
	    errorPlacement: function(error, element) {
		var placement = $(element).data('error');
		if (placement) {
		    $(placement).append(error);
		} else {
		error.insertAfter(element);
		}
	    }
	});

        if (!$("#createBridge").valid()) {
	    $('body').css("cursor", "default");
            th.attr("disabled",false);
	    return;
	}
	
        var bridgeName = th.parent().find("#bridgeName").val().trim();
	var vlanID = th.parent().find("#vlanID").val();
        var bridgePort = '';
            
        if(bridgeType == 'bridge' ){
            var selected = [];
            $('#forPort input:checked').each(function() {
                selected.push($(this).attr('id'));
            });
            bridgePort = selected;
            
        }else if(bridgeType == 'untaggedBridge'){
            var selected = [];
            $('#forUntagged input:checked').each(function() {
                selected.push($(this).attr('id'));
            });
            bridgePort = selected;
        }


        var VlanInterfaceType = new Array();
        for (var i = 0; i < bridgePort.length; i++){
            if (bridgePort[i] < 5) {
                VlanInterfaceType.push('LANETH');
            } else if (bridgePort[i] == 5) {
                VlanInterfaceType.push('WAN');
            } else if (bridgePort[i] > 5) {
                VlanInterfaceType.push('WLAN');
            }
        }


        if(bridgeType == 'bridge' || bridgeType == 'taggedNat'){
            var nameExist = checkIfVlanNameExist(bridgeName);
            if(nameExist == "true") {
                var fail = getMssg['msg_errorVan_Name'];
                $("#forVlanIdError").empty();
                $("#forVlanIdError").html(fail);
                $("#forVlanIdError").removeClass("infoMessage");
                $("#forVlanIdError").addClass("errorMessage");
                th.attr("disabled", false);
            } else {
                var ifExist = checkIfVlanIdExist(vlanID);
                if (ifExist == 'true') {
                    var fail = getMssg['msg_errorVan_id'];
                    $("#forVlanIdError").empty();
                    $("#forVlanIdError").html(fail);
                    $("#forVlanIdError").removeClass("infoMessage");
                    $("#forVlanIdError").addClass("errorMessage");
                    th.attr("disabled", false);

//                th.css("opacity","1");
//                th.css("cursor","pointer");
                } else {
                    $("#forVlanIdError").empty();
                    if ($('#refreshButton').css('display') == 'none') {
                        createBridge(th, bridgeName, vlanID, bridgePort, bridgeType, VlanInterfaceType);
                    } else {
                        var titleMsg = getMssg['title_msg'];
                        var rmMsg = getMssg['change_msg'];
                        var cancelMsg = getMssg['cancel'];
                        var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                        swal({
                            title: titleMsg,
                            text: msgOffOn,
                            showCancelButton: true,
                            closeOnConfirm: true,
                            confirmButtonText: rmMsg,
                            cancelButtonText: cancelMsg,
                            confirmButtonColor: "#008DA9"
                        }, function (isConfirm) {
                            if (isConfirm) {
                                createBridge(th, bridgeName, vlanID, bridgePort, bridgeType, VlanInterfaceType);
                            } else {
                                th.removeAttr("disabled");
                            }
                        });
                    }

                }
            }

        }else{
            $("#forVlanIdError").empty();
            if($('#refreshButton').css('display') == 'none') {
                createBridge(th,bridgeName,vlanID,bridgePort,bridgeType, VlanInterfaceType);
            } else {
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function (isConfirm) {
                    if (isConfirm) {
                        createBridge(th,bridgeName,vlanID,bridgePort,bridgeType);
                    } else {
                        th.removeAttr("disabled");
                    }
                });
            }
        }
    });

    function createBridge(th,bridgeName,vlanID,bridgePort,bridgeType, VlanInterfaceType){
        $.ajax({
	    type: "POST",
	    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
	    data: {
		'deviceID': devId,
		'actionName': "createBridge",
		'bridgeName': bridgeName,
		'vlanID': vlanID,
		'bridgePort': bridgePort,
        'bridgeType': bridgeType,
        'VlanInterfaceType' : VlanInterfaceType,
		'fromApp': true
	    },
	    async: true,
	    success: function (result) {
		if (result == 'logged_out') {
		    document.location.href = $basepath + 'login';
		} else if (result == 'true') {
		    var success = getMssg['action_succeed'];
		    $("#actionRes").empty();
		    $("#actionRes").html(success);
		    $("#actionRes").removeClass("errorMessage");
		    $("#actionRes").addClass("infoMessage");
		    setTimeout(function () {
			updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'vlan');
                        th.attr("disabled","disabled");
		    }, 2000);
                    
                    setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);  
                    
		    setTimeout(function () {
                        $("#actionRes").empty();
                        th.removeAttr('disabled');
//			updateAfterTheAction();
		    }, 10000);
		    
		} else {
		    var fail = getMssg['action_failed'];
		    $("#actionRes").empty();
		    $("#actionRes").html(fail);
		    $("#actionRes").removeClass("infoMessage");
		    $("#actionRes").addClass("errorMessage");
		}
	    },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
	});
    }
    
    function checkIfVlanIdExist(vlanID){
        var busy = '';
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getVlanPagesForDevice.php",
            data: {
                'deviceID': devId,
                'vlanId': vlanID,
                'forEditing' : false,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }else {
                    busy = result;
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        return busy;
    }

    function checkIfVlanNameExist(bridgeName){
        var busy = '';
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getVlanPagesForDevice.php",
            data: {
                'deviceID': devId,
                'bridgeName': bridgeName,
                'forName': true,
                'forEditing' : false,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }else {
                    busy = result;
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        return busy;
    }
    
    $(document).on("change", "#bridgeType", function () {
        if($('.createBridge .error_messageVlan').attr('id') && $.trim( $('.createBridge .error_messageVlan').text() ).length != 0){
            $('#createBridge').validate().resetForm();
        }
        var bridgeType = $("#bridgeType option:selected").val();
        var th = $(this);
        
        if(bridgeType == 'bridge'){
            $('#createBridge').find('#forName').show();
            $('#createBridge').find('#forVlanID').show();
            $('#createBridge').find('#forPort').show();
            $('#createBridge').find('#forUntagged').hide();
            $('#createBridge').find("#forVlanIdError").empty();
            $('#createBridge').find('.port').iCheck('update');
        }else if(bridgeType == 'taggedNat'){
            $('#createBridge').find('#forName').show();
            $('#createBridge').find('#forVlanID').show();
            $('#createBridge').find('#forPort').hide();
            $('#createBridge').find('#forUntagged').hide();
            $('#createBridge').find("#forVlanIdError").empty();
            $('#createBridge').find('.port').iCheck('update');
        }else if(bridgeType == 'untaggedBridge'){
            $('#createBridge').find('#forName').hide();
            $('#createBridge').find('#forVlanID').hide();
            $('#createBridge').find('#forPort').hide();
            $('#createBridge').find('#forUntagged').show();
            $('#createBridge').find("#forVlanIdError").empty();
            $('#createBridge').find('.port').iCheck('update');
        }
        $("#createBridge").data('validator').resetForm();
    });
    
    $(document).on("click", ".vlanParams", function () {
        var th = $(this);
        var vlanId = th.parent().find("input[name='vlanID']").val();
        var vlanType = th.parent().find("input[name='vlanType']").val();
        if(th.closest('tr').next('tr').find("#forVlanEdit").is(':empty')){

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getVlanPagesForDevice.php",
                data: {
                    'deviceID': devId,
                    'vlanId': vlanId,
                    'vlanType': vlanType,
                    'forEditing' : true,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }else{
                        th.closest('tr').next('tr').find("#forVlanEdit").empty();
                        th.closest('tr').next('tr').find("#forVlanEdit").html(result);
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });

    $(document).on("click", ".voipParam", function () {
        var voipnumIndex = $(this).find(".voipnumIndex").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getVOIPTabPageForDevice.php",
            data: {
                'voipnumIndex':voipnumIndex,
                'deviceID': devId,
                'serialNumber':serialN,
                'devStatus':devStatuss,
                'havPermissions':havePerm,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result =='logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $('.voipPage').empty();
                    $('.voipPage').html(result);
                    $("#VoipList").addClass("for_all_display_none");
                    ///$(".voipPage").removeClass("for_all_display_none");
                    // $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#editVoip", function (e) {
        e.preventDefault();
        var th = $(this);
        var voipEnable = $(".voip-content").find("input[name='voipEnable']").is(":checked");
        var voipnumIndex = $(".voipPage").find("input[name='numindex']").val();
        var sipProxy = $(".voip-content").find("input[name='sipProxy']").val().trim();
        var sipRegistrar = $(".voip-content").find("input[name='sipRegistrar']").val().trim();
        var voipId = $(".voip-content").find("input[name='voipId']").val().trim();
        var sipDomain = $(".voip-content").find("input[name='nameDomain']").val().trim();
	var sipProxyDef = document.getElementById("sipProxy").defaultValue;
	var sipRegistrarDef = document.getElementById("sipRegistrar").defaultValue;
	var voipEnableDef = document.getElementById("voipEnable").defaultChecked;
	var sipDomainDef = document.getElementById("sipDomain").defaultValue;

        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var nothingChange = getMssg['start_ip_outside'];
        var msgDom = getMssg['error_message_domain'];

        $('#voipSettings').validate({
	    rules: {
		    sipProxy: {
                required: true,
                validateIpAddress: true
		    },
            sipRegistrar: {
                required: true,
                validateIpAddress: true
            }
	    },
	    messages: {
		sipProxy: {
		    required: msgRequired,
		    validateIpAddress: msgIp
		},
		sipRegistrar: {
		    required: msgRequired,
		    validateIpAddress: msgIp
		}
        },
	    errorElement: "div",
	    errorPlacement: function(error, element) {
		var placement = $(element).data('error');
		if (placement) {
		    $(placement).append(error);
		} else {
		    error.insertAfter(element);
		}
	    }
	});

	if (!$("#voipSettings").valid()) {
	    $('body').css("cursor", "default");
	    return;
	} 

        var voipParams = [];
        var voipParamsValue = [];
        var voipParamsType = [];

	var flag = false;

	if (sipProxy != sipProxyDef) {
	    voipParams.push("SIP.ProxyServer");
	    voipParamsValue.push(sipProxy);
	    voipParamsType.push("string");
	    flag = true;
	}

	if (sipRegistrar != sipRegistrarDef) {
	    voipParams.push("SIP.RegistrarServer");
	    voipParamsValue.push(sipRegistrar);
	    voipParamsType.push("string");
	    flag = true;
	}

    if (sipDomain != sipDomainDef) {
        voipParams.push("SIP.UserAgentDomain");
        voipParamsValue.push(sipDomain);
        voipParamsType.push("string");
        flag = true;
    }





        if (voipEnable != voipEnableDef) {
	    voipParams.push("Enable");
	    var st = "Disabled";
	    if (voipEnable) {
		st = "Enabled";
	    }
	    voipParamsValue.push(st);
	    voipParamsType.push("string");
	    flag = true
	}

        if (! flag) {
	    $('body').css("cursor", "default");
	    $("#viopError").text(nothingChange);
	    return;
        }


	editVoip(th, voipParams, voipParamsValue, voipParamsType, voipnumIndex);
	document.getElementById("sipProxy").defaultValue = sipProxy;
	document.getElementById("sipRegistrar").defaultValue = sipRegistrar;
	document.getElementById("voipEnable").defaultChecked = voipEnable;
	document.getElementById("sipDomain").defaultValue = sipDomain;

    });
    
    $(document).on("click", "#cancelVoIP", function (e) {
	$("#voipSettings").validate().resetForm();
	$("#viopError").text('');
    });


    function editVoip(th, voipParams, voipParamsValue, voipParamsType, voipnumIndex) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
		'deviceID': devId,
        'voipnumIndex': voipnumIndex,
        'actionName': "editVoip",
		'voipParams': voipParams,
		'voipParamsValue': voipParamsValue,
		'voipParamsType': voipParamsType,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
		    $("#viopError").text('');
                    var success = getMssg['action_succeed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(success);
                    th.closest('td').find("#actionResCollapse").removeClass("errorMessage");
                    th.closest('td').find("#actionResCollapse").addClass("infoMessage");
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId,'voip');
                        th.attr("disabled","disabled");
//                        th.css("opacity","0.5");
//                        th.css("cursor","default");
                    }, 2000);
//                    setTimeout(function () {
//                        intervalSetTypeVoip = setInterval(function(){
//                            getTaskStatus(devId,'voip');
//                        }, 2000);
//                    }, 3000);
                     setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);  
                } else {
                    $('body').css("cursor", "default");
                    var fail = getMssg['action_failed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(fail);
                    th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                    th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    $(document).on("click", "[id*='cancelLineVoIP']", function (e) {
        var th = $(this);
	voipLineId = $(this).attr("voipLineId");
	$("#viopLineError" + voipLineId).text('');
        th.closest("form").find("div.error_message").remove();
	th.closest("form").find(".error_message").removeClass("error_message");
    });

    $(document).on("click", "[id*='editVoipLine']", function (e) {
        e.preventDefault();
	var th = $(this);
        th.attr("disabled","disabled");
	voipLineId = $(this).attr("voipLineId");
        var voipLineNumber = $(".voip-line" + voipLineId).find("input[name='voipLineNumber']").val().trim();
        var voipIndex = $(".voip-content").find("input[name='numindex']").val();
        var voipLineIndex = $(".voip-line" + voipLineId).find("input[name='linenumindex']").val();
        var voipLineRegistration = $(".voip-line" + voipLineId).find("input[name='voipLineRegistration" + voipLineId + "']").is(":checked");
        var voipLineEnable = $(".voip-line" + voipLineId).find("input[name='voipLineEnable" + voipLineId + "']").is(":checked");
        var username = $(".voip-line" + voipLineId).find("input[name='username']").val().trim();
        var password = $(".voip-line" + voipLineId).find("input[name='password']").val().trim();
        var uri = $(".voip-line" + voipLineId).find("input[name='uri']").val().trim();
        var voipLineRegDef = document.getElementById("voipLineRegistration" + voipLineId).defaultChecked;
        var voipLineEnableDef = document.getElementById("voipLineEnable" + voipLineId).defaultChecked;
        var usernameDef = document.getElementById("username" + voipLineId).defaultValue;
        var passwordDef = document.getElementById("password" + voipLineId).defaultValue;
        var uriDef = document.getElementById("uri" + voipLineId).defaultValue;
        
        var nothingChange = getMssg['nothing_changed'];
        var msgRequired = getMssg['error_message_required'];
        var msgEmpty = getMssg['error_message_empty'];
        var msgIp = getMssg['error_message_ip'];

        $('#voipLineSettings' + voipLineId).validate({
	    rules: {
		username: {
//		    required: true,
// 		    validateIsEmpty: true
		},
		password: {
//		    required: true,
// 		    validateIsEmpty: true
		},
		uri: {
//		    required: true,
// 		    validateIsEmpty: true
		}
	    },
	    messages: {
		username: {
//		    required: msgRequired,
// 		    validateIsEmpty: msgEmpty
		},
		password: {
//		    required: msgRequired,
// 		    validateIsEmpty: msgEmpty
		},
                uri: {
//		    required: true,
// 		    validateIsEmpty: msgEmpty
		}
	    },
	    errorElement: "div",
            errorClass: 'error_message voip_errormsg',
	    errorPlacement: function(error, element) {
		var placement = $(element).data('error');
		if (placement) {
		    $(placement).append(error);
		} else {
		    error.insertAfter(element);
		}
	    }
	});

	if (!$("#voipLineSettings" + voipLineId).valid()) {
            th.removeAttr('disabled');
	    return;
	} 

        var voipLineParams = [];
        var voipLineParamsValue = [];
        var voipLineParamsType = [];

	var flag = false;

	if (username != usernameDef) {
	    voipLineParams.push("SIP.AuthUserName");
	    voipLineParamsValue.push(username);
	    voipLineParamsType.push("string");
	    flag = true;
	}

	if (password != passwordDef) {
	    voipLineParams.push("SIP.AuthPassword");
	    voipLineParamsValue.push(password);
	    voipLineParamsType.push("string");
	    flag = true;

	}

	if (uri != uriDef) {
	    voipLineParams.push("SIP.URI");
	    voipLineParamsValue.push(uri);
	    voipLineParamsType.push("string");
	    flag = true;

	}


	if (voipLineRegistration != voipLineRegDef) {
	    voipLineParams.push("SIP.X_DLINK_Registration");
	    var st = "0";
	    if (voipLineRegistration) {
		st = "1";
	    }
	    voipLineParamsValue.push(st);
	    voipLineParamsType.push("boolean");
	    flag = true;
	}

        if (voipLineEnable != voipLineEnableDef) {
            voipLineParams.push("Enable");
            var st = "Disabled";
            if (voipLineEnable) {
                st = "Enabled";
            }
            voipLineParamsValue.push(st);
            voipLineParamsType.push("string");
            flag = true;
        }

        if (! flag) {
            th.removeAttr('disabled');
	    $("#viopLineError" + voipLineId).text(nothingChange);
	    return;
        }

	editVoipLine(th, voipLineNumber, voipLineParams, voipLineParamsValue, voipLineParamsType, voipIndex, voipLineIndex);
	document.getElementById("voipLineRegistration" + voipLineId).defaultChecked = voipLineRegistration;
	document.getElementById("voipLineEnable" + voipLineId).defaultChecked = voipLineEnable;
	document.getElementById("username" + voipLineId).defaultValue = username;
	document.getElementById("password" + voipLineId).defaultValue = password;
	document.getElementById("uri" + voipLineId).defaultValue = uri;
    });
    
    function editVoipLine(th, voipLineNumber, voipLineParams, voipLineParamsValue, voipLineParamsType, voipIndex, voipLineIndex) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
		'deviceID': devId,
        'actionName': "editVoipLine",
		'voipLineNumber': voipLineNumber,
        'voipIndex' : voipIndex,
        'voipLineIndex' : voipLineIndex,
		'voipLineParams': voipLineParams,
		'voipLineParamsValue': voipLineParamsValue,
		'voipLineParamsType': voipLineParamsType,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
		    $("#viopLineError" + voipLineId).text('');
                    var success = getMssg['action_succeed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(success);
                    th.closest('td').find("#actionResCollapse").removeClass("errorMessage");
                    th.closest('td').find("#actionResCollapse").addClass("infoMessage");
                    setTimeout(function () {
                        updateActivities(devId);
                    }, 2000);
                    setTimeout(function () {
                        th.removeAttr('disabled');
                    }, 7000);
                    clearInterval(intervalSetTypeVoip);
//                    setTimeout(function () {
//                        intervalSetTypeVoip = setInterval(function(){
//                            getTaskStatus(devId,'voip');
//                        }, 2000);
//                    }, 3000);
                     setTimeout(function () {
                        intervalRefresh = setInterval(function(){
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                        }, 2000);
                    }, 3000);

                } else {
                    $('body').css("cursor", "default");
                    th.removeAttr('disabled');
                    var fail = getMssg['action_failed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(fail);
                    th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                    th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
    
    $(document).on("click", "#editBridge", function (e) {
        e.preventDefault();
	    var th = $(this);
        var bridgeType = th.parent().find("input[name='vlanType']").val();
        var bridgeIndex = th.parent().find("input[name='bridgeIndex']").val();
        var vlanId = th.parent().find("input[name='vlanId']").val();
        var isChanged = false;

        var msgRequird = getMssg['error_message_required'];
	    var msgNumber = getMssg['error_message_number'];
	    var msgGe1 = getMssg['error_message_ge_1'];
	    var msgLe4094 = getMssg['error_message_le_4094'];
	    var msgEmpty = getMssg['error_message_empty'];
        var msgPort = getMssg['error_message_port'];
        
        $('#createBridge'+vlanId).validate({
	    rules: {
		bridgeName: {
		    required: true,
                    validateIsEmpty: true
		},
		vlanID: {
		    required: true,
                    validateIsEmpty: true,
		    number: true,
		    min : 1,
		    max: 4094,
            digits: true
		},
            portEdit: {
                  required: true
               }
	    },
	    messages: {
		bridgeName: {
		    required:  msgRequird,
                    validateIsEmpty: msgEmpty
		},
		vlanID: {
		    required: msgRequird,
                    validateIsEmpty: msgEmpty,
		    number: msgNumber ,
		    min : msgGe1,
		    max: msgLe4094,
            digits: msgNumber

		},
               portEdit: {
                  required: msgPort
               }
	    },
	    errorElement: "div",
	    errorClass: 'error_message',
	    errorPlacement: function(error, element) {
		var placement = $(element).data('error');
		if (placement) {
		    $(placement).append(error);
		} else {
		    // alert(element.parent().find(".VlanLabel"));
            if(element.val()=="on") {
                error.insertBefore(element);
            } else {
                error.insertBefore(element.parent().find(".VlanLabel"));
            }

            $("#bridgeName"+vlanId+"-error").addClass('editBridgeName');
            $("#vlanID"+vlanId+"-error").addClass('editBridgeID');
		}
	    }
	});
	if (!$("#createBridge"+vlanId).valid()) {
	    $('body').css("cursor", "default");
	    return;
	}
        
        var brigdeParams = [];
        var brigdeParamsValue = [];
        var brigdeParamsType = [];
        var checkboxesChecked = [];
        var checkboxesUnchecked = {};
        var bridgeName = '';
        var newName = '';
	    var vlanID = '';
	    var vlanIDVal = '';
        var enable = '';
        
        var state = document.getElementById("enableonoffswitch"+vlanId);
        if (state.checked != state.defaultChecked) {
            enable = state.checked ? 1 : 0;
            brigdeParams.push('BridgeEnable');
            brigdeParamsValue.push(enable);
            brigdeParamsType.push('boolean');
            isChanged = true;
        }
	
        if(bridgeType == 'Bridge'){
            bridgeName = document.getElementById("bridgeName"+vlanId);
            if (bridgeName.value != bridgeName.defaultValue) {
                brigdeParams.push('BridgeName');
                brigdeParamsValue.push(bridgeName.value);
                brigdeParamsType.push('string');
                newName = bridgeName.value;
                isChanged = true;
            }
            
            vlanID = document.getElementById("vlanID"+vlanId);
            if (vlanID.value != vlanID.defaultValue) {
                brigdeParams.push('VLANID');
                brigdeParamsValue.push(vlanID.value);
                brigdeParamsType.push('unsignedInt');
                vlanIDVal = vlanID.value;
                isChanged = true;
            }
            
           var checkboxes = document.getElementsByClassName("port");


            for (var i=0; i<checkboxes.length; i++) {
               if (checkboxes[i].checked != checkboxes[i].defaultChecked) {
                   if(checkboxes[i].checked){
                        checkboxesChecked.push(checkboxes[i].getAttribute('id'));
                        isChanged = true;
                   }else{
                        var markFil = {};
                        var id = checkboxes[i].getAttribute('id');
                        var markingId = $("input[name='markingId"+id+"']").val();
                        var filterId = $("input[name='filterId"+id+"']").val();
//                        var index = $("input[name='"+id+"']").val();
//                        checkboxesUnchecked.push(checkboxes[i].getAttribute('id'));
//                        checkboxesUnchecked.push({ id: id, index: index });
//                        checkboxesUnchecked.push(index);
                        markFil["markingId"+id] = markingId;
                        markFil["filterId"+id] = filterId;
                        checkboxesUnchecked['id'+id] = markFil;
                        isChanged = true;
                   }
               }
            }


            var VlanInterfaceType = new Array();
            for (var i = 0; i < checkboxesChecked.length; i++){
                if (checkboxesChecked[i] < 5) {
                    VlanInterfaceType.push('LANETH');
                } else if (checkboxesChecked[i] == 5) {
                    VlanInterfaceType.push('WAN');
                } else if (checkboxesChecked[i] > 5) {
                    VlanInterfaceType.push('WLAN');
                }
            }


        }else if(bridgeType == 'Tagged_NAT'){
            bridgeName = document.getElementById("bridgeName"+vlanId);
            if (bridgeName.value != bridgeName.defaultValue) {
                brigdeParams.push('BridgeName');
                brigdeParamsValue.push(bridgeName.value);
                brigdeParamsType.push('string');
                isChanged = true;
            }
            
            vlanID = document.getElementById("vlanID"+vlanId);
            if (vlanID.value != vlanID.defaultValue) {
                brigdeParams.push('VLANID');
                brigdeParamsValue.push(vlanID.value);
                brigdeParamsType.push('unsignedInt');
                vlanIDVal = vlanID.value;
                isChanged = true;
            }

        }else if(bridgeType == 'Untagged_NAT' || bridgeType == 'LAN'){
            bridgeName = document.getElementById("bridgeName"+vlanId);
            if (bridgeName.value != bridgeName.defaultValue) {
                brigdeParams.push('BridgeName');
                brigdeParamsValue.push(bridgeName.value);
                brigdeParamsType.push('string');
                isChanged = true;
            }
            
            var checkboxes = document.getElementById("vlan"+vlanId).getElementsByClassName("port");




            for (var i=0; i<checkboxes.length; i++) {
               if (checkboxes[i].checked != checkboxes[i].defaultChecked) {
                   if(checkboxes[i].checked){
                        checkboxesChecked.push(checkboxes[i].getAttribute('id'));
                        isChanged = true;
                   }else{
                        var markFil = {};
                        var id = checkboxes[i].getAttribute('id');
                        var markingId = $("input[name='markingId"+id+"']").val();
                        var filterId = $("input[name='filterId"+id+"']").val();
//                        var index = $("input[name='"+id+"']").val();
//                        checkboxesUnchecked.push(checkboxes[i].getAttribute('id'));
//                        checkboxesUnchecked.push(index);
                        markFil["markingId"+id] = markingId;
                        markFil["filterId"+id] = filterId;
                        checkboxesUnchecked['id'+id] = markFil;
                        isChanged = true;
                   }
               }
            }

            var VlanInterfaceType = new Array();
            for (var i = 0; i < checkboxesChecked.length; i++){
                if (checkboxesChecked[i] < 5) {
                    VlanInterfaceType.push('LANETH');
                } else if (checkboxesChecked[i] == 5) {
                    VlanInterfaceType.push('WAN');
                } else if (checkboxesChecked[i] > 5) {
                    VlanInterfaceType.push('WLAN');
                }
            }
        }
      
        if(isChanged){
            if(bridgeType == 'Bridge' || bridgeType == 'Tagged_NAT'){
                if(vlanIDVal != ''){
                    var ifExist = checkIfVlanIdExist(vlanIDVal);
                    if(ifExist == 'true') {
                        var fail = getMssg['msg_errorVan_id'];
                        th.closest('td').find("#actionResCollapse").empty();
                        th.closest('td').find("#actionResCollapse").html(fail);
                        th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                        th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                    } else {
                        var nameExist = checkIfVlanNameExist(newName);
                        if (nameExist == "true") {
                            var fail = getMssg['msg_errorVan_Name'];
                            th.closest('td').find("#actionResCollapse").empty();
                            th.closest('td').find("#actionResCollapse").html(fail);
                            th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                            th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                        } else {
                            th.closest('td').find("#actionResCollapse").empty();
                            if ($('#refreshButton').css('display') == 'none') {
                                editBridge(th, bridgeIndex, bridgeType, brigdeParams, brigdeParamsValue, brigdeParamsType, checkboxesChecked, checkboxesUnchecked, VlanInterfaceType);
                            } else {
                                var titleMsg = getMssg['title_msg'];
                                var rmMsg = getMssg['change_msg'];
                                var cancelMsg = getMssg['cancel'];
                                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                                swal({
                                    title: titleMsg,
                                    text: msgOffOn,
                                    showCancelButton: true,
                                    closeOnConfirm: true,
                                    confirmButtonText: rmMsg,
                                    cancelButtonText: cancelMsg,
                                    confirmButtonColor: "#008DA9"
                                }, function (isConfirm) {
                                    if (isConfirm) {
                                        editBridge(th, bridgeIndex, bridgeType, brigdeParams, brigdeParamsValue, brigdeParamsType, checkboxesChecked, checkboxesUnchecked, VlanInterfaceType);
                                    } else {
                                        th.removeAttr("disabled");
                                    }
                                });
                            }

                        }
                    }
                }else{
                    var nameExist = checkIfVlanNameExist(newName);
                    if (nameExist == "true") {
                        var fail = getMssg['msg_errorVan_Name'];
                        th.closest('td').find("#actionResCollapse").empty();
                        th.closest('td').find("#actionResCollapse").html(fail);
                        th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                        th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                    } else {
                        th.closest('td').find("#actionResCollapse").empty();
                        if ($('#refreshButton').css('display') == 'none') {
                            editBridge(th, bridgeIndex, bridgeType, brigdeParams, brigdeParamsValue, brigdeParamsType, checkboxesChecked, checkboxesUnchecked, VlanInterfaceType);
                        } else {
                            var titleMsg = getMssg['title_msg'];
                            var rmMsg = getMssg['change_msg'];
                            var cancelMsg = getMssg['cancel'];
                            var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                            swal({
                                title: titleMsg,
                                text: msgOffOn,
                                showCancelButton: true,
                                closeOnConfirm: true,
                                confirmButtonText: rmMsg,
                                cancelButtonText: cancelMsg,
                                confirmButtonColor: "#008DA9"
                            }, function (isConfirm) {
                                if (isConfirm) {
                                    editBridge(th, bridgeIndex, bridgeType, brigdeParams, brigdeParamsValue, brigdeParamsType, checkboxesChecked, checkboxesUnchecked, VlanInterfaceType);
                                } else {
                                    th.removeAttr("disabled");
                                }
                            });
                        }

                    }
                }
            }else{
                th.closest('td').find("#actionResCollapse").empty();
                if($('#refreshButton').css('display') == 'none') {
                    editBridge(th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType);
                } else {
                    var titleMsg = getMssg['title_msg'];
                    var rmMsg = getMssg['change_msg'];
                    var cancelMsg = getMssg['cancel'];
                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                    swal({
                        title: titleMsg,
                        text: msgOffOn,
                        showCancelButton: true,
                        closeOnConfirm: true,
                        confirmButtonText: rmMsg,
                        cancelButtonText: cancelMsg,
                        confirmButtonColor: "#008DA9"
                    }, function (isConfirm) {
                        if (isConfirm) {
                            editBridge(th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType);
                        } else {
                            th.removeAttr("disabled");
                        }
                    });
                }
            }
        }else{
            var msg = $("input[name='nothingChanged']").val();
            th.closest('td').find("#actionResCollapse").empty();
            th.closest('td').find("#actionResCollapse").html(msg);
            th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
            th.closest('td').find("#actionResCollapse").addClass("errorMessage");
        }
    });
    
    function editBridge(th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType){
        var brigdeEnable = brigdeParams[0];
        var brigdeEnableValue = brigdeParamsValue[0];
        if(brigdeEnable=='BridgeEnable' && brigdeEnableValue==0) {
            var titleMsg = getMssg['title_msg'];
            var changeMsg = getMssg['change_msg'];
            var cancelMsg = getMssg['cancel'];
            var msgOffOn = getMssg['access_lost'];

            swal({
                title: titleMsg,
                text: msgOffOn,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: changeMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    editBridgeValue(th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType);
                } else {
                    th.removeAttr("disabled");
                }
            });
        } else {
            editBridgeValue (th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType)
        }
    }

    function editBridgeValue (th,bridgeIndex,bridgeType,brigdeParams,brigdeParamsValue,brigdeParamsType,checkboxesChecked,checkboxesUnchecked,VlanInterfaceType) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': "editBridge",
                'bridgeIndex': bridgeIndex,
                'bridgeType': bridgeType,
                'brigdeParams': jQuery.isEmptyObject(brigdeParams) ? '' : brigdeParams,
                'brigdeParamsValue': jQuery.isEmptyObject(brigdeParamsValue) ? '' : brigdeParamsValue,
                'brigdeParamsType': jQuery.isEmptyObject(brigdeParamsType) ? '' : brigdeParamsType,
                'checkedPorts': jQuery.isEmptyObject(checkboxesChecked) ? '' : checkboxesChecked,
                'uncheckedPorts': jQuery.isEmptyObject(checkboxesUnchecked) ? '' : JSON.stringify(checkboxesUnchecked),
                'VlanInterfaceType': jQuery.isEmptyObject(VlanInterfaceType) ? '' : VlanInterfaceType,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(success);
                    th.closest('td').find("#actionResCollapse").removeClass("errorMessage");
                    th.closest('td').find("#actionResCollapse").addClass("infoMessage");
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId, 'vlan');
                        th.attr("disabled", "disabled");
//                        th.css("opacity","0.5");
//                        th.css("cursor","default");
                    }, 2000);
                    clearInterval(intervalSetTypeVlan);
//                    setTimeout(function () {
//                        intervalSetTypeVlan = setInterval(function(){
//                            getTaskStatus(devId,'vlan');
//                        }, 2000);
//                    }, 3000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function () {
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton', devId);
                        }, 2000);
                    }, 3000);

                    setTimeout(function () {
//                        updateAfterTheAction();
                        th.closest('td').find("#actionResCollapse").empty();
                    }, 10000);

                } else {
                    $('body').css("cursor", "default");
                    var fail = getMssg['action_failed'];
                    th.closest('td').find("#actionResCollapse").empty();
                    th.closest('td').find("#actionResCollapse").html(fail);
                    th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                    th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("click", "#cancelBridge", function (e) {
        e.preventDefault();
        $(this).closest('form').get(0).reset();
        $(this).closest('form').validate().resetForm();
        $('.port').iCheck('update');
        $(this).closest('td').find('#editBridge').removeAttr('disabled');
    });
    
    $(document).on("click", "#delBridge", function (e) {
        e.preventDefault();
        var th = $(this);
        var vlanType = th.parent().find("input[name='vlanType']").val();
        
        if(vlanType == 'Tagged_NAT'){
            var vlanId = th.parent().find("input[name='vlanId']").val();
            var connVlanId = th.closest('tr').find("#vlanID"+ vlanId).val();

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkVlanIdConnection.php",
                data: {
                    'deviceID': devId,
                    'connVlanId': connVlanId,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result != '') {
                        var info = getMssg["del_vlan_msg"];
                        swal({
                            title: '',
                            text:info + "(" + result + ")"
                        });
                    }else{
                       deleteVlan(th); 
                    } 
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
            
        }else {
            deleteVlan(th);
        }
    });
    
    function deleteVlan(th){
        var bridgeIndex = th.parent().find("input[name='bridgeIndex']").val();
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_delete_vlan'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function(isConfirm) {
            if(isConfirm){
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': "deleteBridge",
                        'bridgeIndex': bridgeIndex,
                        'fromApp': true
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else if (result == 'true') {
                            var success = getMssg['action_succeed'];
                            th.closest('td').find("#actionResCollapse").empty();
                            th.closest('td').find("#actionResCollapse").html(success);
                            th.closest('td').find("#actionResCollapse").removeClass("errorMessage");
                            th.closest('td').find("#actionResCollapse").addClass("infoMessage");
                            setTimeout(function () {
                                updateActivities(devId);
                                th.attr("disabled","disabled");
//                                th.css("opacity","0.5");
//                                th.css("cursor","default");
                            }, 2000);
                            
                            setTimeout(function () {
                                intervalRefresh = setInterval(function(){
                                    getTaskStatusOfTheDeviceForRefreshButton('refreshButton',devId);
                                }, 2000);
                                th.closest('td').find("#actionResCollapse").empty();
                            }, 3000); 
                            
//                            setTimeout(function () {
//                                updateAfterTheAction();
//                            }, 10000);

                        } else {
                            $('body').css("cursor", "default");
                            var fail = getMssg['action_failed'];
                            th.closest('td').find("#actionResCollapse").empty();
                            th.closest('td').find("#actionResCollapse").html(fail);
                            th.closest('td').find("#actionResCollapse").removeClass("infoMessage");
                            th.closest('td').find("#actionResCollapse").addClass("errorMessage");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        });
    }
    
//---------------------------DIAGNOSTIC-----------------------------------------

    $(document).on("click", "#addDiagnostic", function () {
        var host_value = $("#inputDiagnostic").val();
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgDns = getMssg['error_message_dns'];
        
        $("#forDiagnostic").validate({
            rules: {
                inputDiagnostic: {
                    required: true,
                    validateSingalDNS : true
                }

            },
            messages: {
                inputDiagnostic: {
                    required: msgRequired,
                    validateSingalDNS: msgDns
                }

            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error);
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forDiagnostic").valid())) {
            return false;
        }
        
        var hosts = []; 
        $("#selectForIp > option").each(function(){
           hosts.push(this.text);
        });

        if($.inArray(host_value, hosts) > -1){
            var msg = $("input[name='msg_forSameHost']").val();
            $("#actionResWan").removeClass("infoMessage");
            $("#actionResWan").addClass("errorMessage");
            $("#actionResWan").empty();
            $("#actionResWan").html(msg);
            return false;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
            data: {
                'host': host_value,
                'action': 'insert',
                'type': 'ping',
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if(result == 'logged_out'){
                    document.location.href = $basepath + 'login';
                } else if(result == 'false'){
                    var msg = $("input[name='msg_DBError']").val();
                    $("#actionResWan").removeClass("infoMessage");
                    $("#actionResWan").addClass("errorMessage");
                    $("#actionResWan").empty();
                    $("#actionResWan").html(msg);
                }else {
                    $("#actionResWan").removeClass("errorMessage");
                    $("#actionResWan").empty();
                    $('#selectForIp').append("<option class ='optionDiagnostic' value='" + result + "'>" + host_value + "</option>");
                    $('#inputDiagnostic').val('');
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#delDiagnostic", function () {
        
        var hostId = $(this).parent().find('#selectForIp').val();
        $("#inputDiagnostic").val('');
        
        if(hostId != null && hostId != ''){
        
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
                data: {
                    'host': hostId,
                    'action': 'delete',
                    'type': 'ping',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if(result == 'logged_out'){
                        document.location.href = $basepath + 'login';
                    } else if(result == 'false'){
                        var msg = $("input[name='msg_DBError']").val();
                        $("#actionResWan").removeClass("infoMessage");
                        $("#actionResWan").addClass("errorMessage");
                        $("#actionResWan").empty();
                        $("#actionResWan").html(msg);
                    }else {
                        $("#actionResWan").empty();
                        $("#selectForIp").find('option:selected').remove();
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_Host']").val();
            $("#actionResWan").removeClass("infoMessage");
            $("#actionResWan").addClass("errorMessage");
            $("#actionResWan").empty();
            $("#actionResWan").html(msg);
        }
    });


    $(document).on("click", "#addDownload", function () {
        var host_value = $("#downloadHost").val();
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgDns = getMssg['error_message_dns'];

        $("#forUploadDownload").validate({
            rules: {
                downloadHost: {
                    required: true,
                    // validateSingalDNS : true
                }

            },
            messages: {
                downloadHost: {
                    required: msgRequired,
                    // validateSingalDNS: msgDns
                }

            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error);
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forUploadDownload").valid())) {
            return false;
        }

        var hosts = [];
        $("#selectDownload > option").each(function(){
            hosts.push(this.text);
        });

        if($.inArray(host_value, hosts) > -1){
            var msg = $("input[name='msg_forSameHost']").val();
            $("#actionResWanDownload").removeClass("infoMessage");
            $("#actionResWanDownload").addClass("errorMessage");
            $("#actionResWanDownload").empty();
            $("#actionResWanDownload").html(msg);
            return false;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
            data: {
                'host': host_value,
                'action': 'insert',
                'type': 'download',
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if(result == 'logged_out'){
                    document.location.href = $basepath + 'login';
                } else if(result == 'false'){
                    var msg = $("input[name='msg_DBError']").val();
                    $("#actionResWanDownload").removeClass("infoMessage");
                    $("#actionResWanDownload").addClass("errorMessage");
                    $("#actionResWanDownload").empty();
                    $("#actionResWanDownload").html(msg);
                }else {
                    $("#actionResWanDownload").removeClass("errorMessage");
                    $("#actionResWanDownload").empty();
                    $('#selectDownload').append("<option class ='optionDiagnostic' value='" + result + "'>" + host_value + "</option>");
                    $('#downloadHost').val('');
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#delDownload", function () {

        var hostId = $(this).parent().find('#selectDownload').val();
        $("#downloadHost").val('');

        if(hostId != null && hostId != ''){

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
                data: {
                    'host': hostId,
                    'action': 'delete',
                    'type': 'download',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if(result == 'logged_out'){
                        document.location.href = $basepath + 'login';
                    } else if(result == 'false'){
                        var msg = $("input[name='msg_DBError']").val();
                        $("#actionResWanDownload").removeClass("infoMessage");
                        $("#actionResWanDownload").addClass("errorMessage");
                        $("#actionResWanDownload").empty();
                        $("#actionResWanDownload").html(msg);
                    }else {
                        $("#actionResWanDownload").empty();
                        $("#selectDownload").find('option:selected').remove();
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_Host']").val();
            $("#actionResWanDownload").removeClass("infoMessage");
            $("#actionResWanDownload").addClass("errorMessage");
            $("#actionResWanDownload").empty();
            $("#actionResWanDownload").html(msg);
        }
    });

    $(document).on("click", "#addUpload", function () {
        var host_value = $("#uploadHost").val();
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgDns = getMssg['error_message_dns'];

        $("#uploadDownloadDiagnostic").validate({
            rules: {
                uploadHost: {
                    required: true,
                    // validateSingalDNS : true
                }

            },
            messages: {
                uploadHost: {
                    required: msgRequired,
                    // validateSingalDNS: msgDns
                }

            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error);
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#uploadDownloadDiagnostic").valid())) {
            return false;
        }

        var hosts = [];
        $("#selectUpload > option").each(function(){
            hosts.push(this.text);
        });

        if($.inArray(host_value, hosts) > -1){
            var msg = $("input[name='msg_forSameHost']").val();
            $("#actionResWanUpload").removeClass("infoMessage");
            $("#actionResWanUpload").addClass("errorMessage");
            $("#actionResWanUpload").empty();
            $("#actionResWanUpload").html(msg);
            return false;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
            data: {
                'host': host_value,
                'action': 'insert',
                'type': 'upload',
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if(result == 'logged_out'){
                    document.location.href = $basepath + 'login';
                } else if(result == 'false'){
                    var msg = $("input[name='msg_DBError']").val();
                    $("#actionResWanUpload").removeClass("infoMessage");
                    $("#actionResWanUpload").addClass("errorMessage");
                    $("#actionResWanUpload").empty();
                    $("#actionResWanUpload").html(msg);
                }else {
                    $("#actionResWanUpload").removeClass("errorMessage");
                    $("#actionResWanUpload").empty();
                    $('#selectUpload').append("<option class ='optionDiagnostic' value='" + result + "'>" + host_value + "</option>");
                    $('#uploadHost').val('');
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#delUpload", function () {

        var hostId = $(this).parent().find('#selectUpload').val();
        $("#uploadHost").val('');

        if(hostId != null && hostId != ''){

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
                data: {
                    'host': hostId,
                    'action': 'delete',
                    'type': 'upload',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if(result == 'logged_out'){
                        document.location.href = $basepath + 'login';
                    } else if(result == 'false'){
                        var msg = $("input[name='msg_DBError']").val();
                        $("#actionResWanUpload").removeClass("infoMessage");
                        $("#actionResWanUpload").addClass("errorMessage");
                        $("#actionResWanUpload").empty();
                        $("#actionResWanUpload").html(msg);
                    }else {
                        $("#actionResWanUpload").empty();
                        $("#selectUpload").find('option:selected').remove();
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_Host']").val();
            $("#actionResWanUpload").removeClass("infoMessage");
            $("#actionResWanUpload").addClass("errorMessage");
            $("#actionResWanUpload").empty();
            $("#actionResWanUpload").html(msg);
        }
    });




    $(document).on("click", "#addTracert", function () {
        var tracert_value = $("#inputTracert").val();
        var msgRequired = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgNumber = getMssg['error_message_number'];
        var msgDns = getMssg['error_message_dns'];
        
        $("#fortracert2").validate({
            rules: {
                inputTracert: {
                    required: true,
                    validateSingalDNS : true
                }
            },

            messages: {
                inputTracert: {
                    required: msgRequired,
                    validateSingalDNS: msgDns
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#fortracert2").valid())) {
            return false;
        }
        
        var hosts = []; 
        $("#selectForIpTrac > option").each(function(){
           hosts.push(this.text);
        });
        
        if($.inArray(tracert_value, hosts) > -1){
            var msg = $("input[name='msg_forSameHost']").val();
            $("#actionResWanTracert").removeClass("infoMessage");
            $("#actionResWanTracert").addClass("errorMessage");
            $("#actionResWanTracert").empty();
            $("#actionResWanTracert").html(msg);
            return false;
        }
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
            data: {
                'host': tracert_value,
                'action': 'insert',
                'type': 'tracert',
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if(result == 'logged_out'){
                    document.location.href = $basepath + 'login';
                } else if(result == 'false'){
                    if($('#fortracert .error_message').attr('id') && $.trim( $('#fortracert .error_message').text() ).length != 0){
                        $('#fortracert').validate().resetForm();
                    }
                   
                    var msg = $("input[name='msg_DBError']").val();
                    $("#actionResWanTracert").removeClass("infoMessage");
                    $("#actionResWanTracert").addClass("errorMessage");
                    $("#actionResWanTracert").empty();
                    $("#actionResWanTracert").html(msg);
                }else {
                    if($('#fortracert .error_message').attr('id') && $.trim( $('#fortracert .error_message').text() ).length != 0){
                        $('#fortracert').validate().resetForm();
                    }
                    $("#actionResWanTracert").removeClass("errorMessage");
                    $("#actionResWanTracert").empty();
                    $('#selectForIpTrac').append("<option class ='optionDiagnostic' value='" + result + "'>" + tracert_value + "</option>");
                    $('#inputTracert').val('');
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#deleteTracert", function () {
        
        var hostId = $(this).parent().find('#selectForIpTrac').val();
        $("#inputTracert").val('');

        if(hostId != null && hostId != ''){
        
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/diagnostic.php",
                data: {
                    'host': hostId,
                    'action': 'delete',
                    'type': 'tracert',
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    if(result == 'logged_out'){
                        document.location.href = $basepath + 'login';
                    } else if(result == 'false'){
                        var msg = $("input[name='msg_DBError']").val();
                        $("#actionResWanTracert").removeClass("infoMessage");
                        $("#actionResWanTracert").addClass("errorMessage");
                        $("#actionResWanTracert").empty();
                        $("#actionResWanTracert").html(msg);
                    }else {
                        $("#actionResWanTracert").empty();
                        $("#selectForIpTrac").find('option:selected').remove();
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_tracert']").val();
            $("#actionResWanTracert").removeClass("infoMessage");
            $("#actionResWanTracert").addClass("errorMessage");
            $("#actionResWanTracert").empty();
            $("#actionResWanTracert").html(msg);
        }
    });
    $(document).on("click", "#selectForIp", function () {
        var checketIps = $(this).parent().find('#selectForIp option:selected').text().trim();
        $('#inputDiagnostic').val(checketIps);    })

    $(document).on("click", "#inputDiagnostic", function () {
        var selectedDiagnostic = $(this).parent().parent().find('#selectForIpTrac option:selected').text().trim();
        var newDiagnostic = $("inputDiagnostic");
        if (selectedDiagnostic != newDiagnostic){
            $(this).parent().parent().find('#selectForIp option:selected').attr('selected', false);
        }
    });
    
    $(document).on("click", "#pingDiagnostic", function (e) {
        e.preventDefault();
        var th = $(this);
//        var checketIps = $(this).parent().find('#selectForIp').val();
//         var checketIps = $(this).parent().find('#selectForIp option:selected').text();
        var checketIps = $('#inputDiagnostic').val();
        var interface = $("input[name='selectInterface']:checked");
        var interfaceCookie = $("input[name='selectInterface']:checked").val();
        $.cookie("conectionName",interfaceCookie);
        var failed = getMssg['action_failed'];
        var msgRequired = getMssg['error_message_required'];
        var msgNumber = getMssg['error_message_number'];

        $("#forDiagnostic").validate({
            rules: {
                numberRepetition: {
                    required: true,
                    number: true
                }
            },

            messages: {
                numberRepetition: {
                    required: msgRequired,
                    number: msgNumber
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#forDiagnostic").valid())) {
            return false;
        }

        if(interface.is(':checked') && checketIps != ''){
            th.attr('disabled','disabled');
            var index = interface.closest('td').find("input[name='index']").val();
            var connect_index = interface.closest('td').find("input[name='connect_index']").val();
            var connType = interface.closest('td').find("input[name='conType']").val();
            var numberRepetition = $('#numberRepetition').val();

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'host': checketIps,
                    'serialN': serialN,
                    'index': index,
                    'connectIndex': connect_index,
                    'actionName': "diagnostic",
                    'pingType': connType,
                    'fromPage': 'wan',
                    'numberRepetition': numberRepetition,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        $("#forDiagnostic").validate().resetForm();
                        var success = getMssg['action_succeed'];
                        $("#actionResWan").removeClass("errorMessage");
                        $("#actionResWan").addClass("infoMessage");
                        $("#actionResWan").empty();
                        $("#actionResWan").html(success);
//                        th.removeAttr("disabled");
                        setTimeout(function () {
                            updateActivities(devId);
                            $("#actionResWan").empty();
                            $('body').css("cursor", "default");
                        }, 2000);

    //------------- get the last 2 diagnostic activity status ---------------------
    //------------- if they are completed show the ping result --------------------

                        var interv = setInterval(function(){

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getLastActivityStatus.php",
                            data: {
                                'deviceID': devId,
                                'pingName': 'diagnostic',
                                'fromApp': true
                            },
                            async: true,
                            success: function (result) {
                                if(result == 'logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else if(result == 2){
                                    clearInterval(interv);
                                    location.reload(true);
//                                     $.ajax({
//                                         type: "POST",
//                                         url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
//                                         data: {
//                                             'index': index,
//                                             'connectionType': connType,
//                                             'deviceID': devId,
//                                             'host': checketIps,
//                                             'pingName': 'diagnostic',
//                                             'fromApp': true
//                                         },
//                                         async: true,
//                                         success: function (result) {
//                                             if(result == 'logged_out'){
//                                                 document.location.href = $basepath + 'login';
//                                             } else {
//                                                 // $("#pingResult").empty();
//                                                 // $("#pingResult").html(result).css('border','1px solid #dddddd');
//                                                 $("#resultForPingTest").empty();
//                                                 // $("#PingDiagnostics").reset();
//                                                 // $("#resultForPingTest").html(result).css('border','1px solid #dddddd');
//                                                 $("#actionResWan").empty();
//                                                 th.removeAttr("disabled");
// //                                                th.css("opacity", "1");
// //                                                th.addClass("active");
// //                                                th.addClass("ready");
//                                             }
//                                         },
//                                         error: function(xhr, status, error) {
//                                             document.location.href = $basepath + '500';
//                                         }
//                                     });
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        },5000);
                    } else if (result == 'false'){
                            $('body').css("cursor", "default");
                            $("#actionResWan").empty();
                            $("#actionResWan").html(failed);
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                    } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_interfaceHost']").val();
            $('body').css("cursor", "default");
            $("#actionResWan").removeClass("infoMessage");
            $("#actionResWan").addClass("errorMessage");
            $("#actionResWan").empty();
            $("#actionResWan").html(msg);
        }
    });

    $(document).on("click", "#selectForIpTrac", function () {
        var checketIps = $(this).parent().find('#selectForIpTrac option:selected').text().trim();
        $('#inputTracert').val(checketIps);    });

    $(document).on("click", "#inputTracert", function () {
        var selectedTracert = $(this).parent().parent().find('#selectForIpTrac option:selected').text().trim();
        var newTracert = $("inputTracert");
        if (selectedTracert != newTracert){
            $(this).parent().parent().find('#selectForIpTrac option:selected').attr('selected', false);
        }
           });

    $(document).on("click", "#pingTracert", function (e) {
        e.preventDefault();
        var th = $(this);
//        var checketIps = $(this).parent().find('#selectForIpTrac').val();
//         var checketIps = $(this).parent().find('#selectForIpTrac option:selected').text().trim();
        var checketIps = $('#inputTracert').val();
        var maxHopCount = $('#fortracert').find('#maxHopCount').val();
        var timeOut = $('#fortracert').find('#timeout').val();
        var interface = $("input[name='selectInterface']:checked");
        var interfaceCookie = $("input[name='selectInterface']:checked").val();
        $.cookie("conectionName",interfaceCookie);
        var failed = getMssg['action_failed'];
        var msgRequired = getMssg['error_message_required'];
        var msgNumber = getMssg['error_message_number'];

        $("#fortracert").validate({
            rules: {
                maxHopCount: {
                    required: true,
                    number: true
                },
                timeout: {
                    required: true,
                    number: true
                }
            },

            messages: {
                maxHopCount: {
                    required: msgRequired,
                    number: msgNumber
                },
                timeout: {
                    required: msgRequired,
                    number: msgNumber
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#fortracert").valid())) {
            return false;
        }

       if(interface.is(':checked') && checketIps != ''){
            th.attr('disabled','disabled');
            var index = interface.closest('td').find("input[name='index']").val();
            var connect_index = interface.closest('td').find("input[name='connect_index']").val();
            var connType = interface.closest('td').find("input[name='conType']").val();
            
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'host': checketIps,
                    'index': index,
                    'connectIndex': connect_index,
                    'actionName': "tracert",
                    'pingType': connType,
                    'fromPage': 'wan',
                    'maxHopCount': maxHopCount,
                    'timeOut': timeOut,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        if($('#fortracert2 .error_message').attr('id') && $.trim( $('#fortracert2 .error_message').text() ).length != 0){
                            $('#fortracert2').validate().resetForm();
                        }
                        
                        var success = getMssg['action_succeed'];
                        $("#actionResWanTracert").removeClass("errorMessage");
                        $("#actionResWanTracert").addClass("infoMessage");
                        $("#actionResWanTracert").empty();
                        $("#actionResWanTracert").html(success);
//                        th.removeAttr("disabled");
                        setTimeout(function () {
                            updateActivities(devId);
                            $('body').css("cursor", "default");
                            $("#actionResWanTracert").empty();
                        }, 2000);

    //------------- get the last 2 diagnostic activity status ---------------------
    //------------- if they are completed show the ping result --------------------

                        var interv = setInterval(function(){

                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getLastActivityStatus.php",
                            data: {
                                'deviceID': devId,
                                'pingName': 'tracert',
                                'fromApp': true
                            },
                            async: true,
                            success: function (result) {
                                if(result == 'logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else if(result == 2){
                                    clearInterval(interv);
                                    location.reload(true);

//                                     $.ajax({
//                                         type: "POST",
//                                         url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
//                                         data: {
//                                             'deviceID': devId,
//                                             'host': checketIps,
//                                             'pingName': 'tracert',
//                                             'fromApp': true
//                                         },
//                                         async: true,
//                                         success: function (result) {
//                                             if(result == 'logged_out'){
//                                                 document.location.href = $basepath + 'login';
//                                             } else {
//                                                 // $("#pingResultTracer").empty();
//                                                 // $("#pingResultTracer").html(result);
//                                                 $("#resultForPingTracert").empty();
//                                                 $("#TracertDiagnostic").empty();
//                                                 $("#TracertDiagnostic").html(result);
//                                                 $("#actionResWanTracert").empty();
//                                                 th.removeAttr("disabled");
// //                                                th.css("opacity", "1");
// //                                                th.addClass("active");
// //                                                th.addClass("ready");
//                                             }
//                                         },
//                                         error: function(xhr, status, error) {
//                                             document.location.href = $basepath + '500';
//                                         }
//                                     });
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        },5000);
                    } else if (result == 'false'){
                            $('body').css("cursor", "default");
                            $("#actionResWanTracert").empty();
                            $("#actionResWanTracert").html(failed);
                            th.removeAttr("disabled");
//                            th.css("opacity", "1");
                    } else if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }else{
            var msg = $("input[name='msg_interfaceHost']").val();
//            alert(msg);
            $('body').css("cursor", "default");
            $("#actionResWanTracert").removeClass("infoMessage");
            $("#actionResWanTracert").addClass("errorMessage");
            $("#actionResWanTracert").empty();
            $("#actionResWanTracert").html(msg);
           // $('#fortracert').validate().resetForm();
        }
    });

    $(document).on("click",".eachTracertDiagnosticPage",function(){
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
            data: {
                'deviceID':devId,
                'page': page,
                'diagnosticName':'tracert',
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#TracertDiagnostic").empty();
                    $("#TracertDiagnostic").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });


    $(document).on("click",".eachPingDiagnosticPage",function(){
        var page = $(this).find("input[name='page']").val();
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
            data: {
                'deviceID':devId,
                'page': page,
                'diagnosticName':'ping',
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $("#PingDiagnostics").empty();
                    $("#PingDiagnostics").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    //------------------------Upload Download Diagnostic in PPPoE---------------

    $(document).on("change", ".uploadDownload", function () {
        var action = $(this).find("option:selected").val();
        var actionText = $(this).find("option:selected").text();
        $("#upDwSubmit").html(actionText);
        $("#uploadDownloadSubmit").html(actionText);
        var msgRequired = getMssg['error_message_required'];
        var msgDns = getMssg['error_message_dns'];
        if(action == "0"){
            $("#downloadDiagnostic").hide();
            $("#uploadDiagnostic").hide();
            $("#submitButton").hide();
            $(".uploadFileSizeDiv").hide();
        }else if(action == "1"){
            $("#downloadDiagnostic").hide();
            $("#uploadDiagnostic").show();
            $("#submitButton").show();
            $("input[name='downloadHost']" ).val('');
            $(".uploadFileSizeDiv").show();
        }else if(action == "2"){
            $("#downloadDiagnostic").show();
            $("#uploadDiagnostic").hide();
            $("#submitButton").show();
            $("input[name='uploadHost']" ).val('');
            $(".uploadFileSizeDiv").hide();
        }
        $("div.error_message").remove();
	$(".error_message").removeClass("error_message");
        $("#message-diagnostic").removeClass("errorMessage");
        $("#message-diagnostic").empty();
    });

    $(document).on("click", "#enableHost", function () {
        if ($(this).is(":checked")) {
            $(".enableUploadButton").show();
            $(".hostDiv").hide();
            $(".hostForDiagnostic").hide();
        } else {
            $(".hostDiv").show();
            $(".hostForDiagnostic").show();
            $(".enableUploadButton").hide();

        }
    });

    $(document).on("click", "#selectDownload", function () {
        var checketIps = $(this).parent().find('#selectDownload option:selected').text().trim();
        $('#downloadHost').val(checketIps);    })

    $(document).on("click", "#downloadHost", function () {
        var selectedDownloadHost = $(this).parent().parent().find('#selectForIpTrac option:selected').text().trim();
        var newDownloadHost = $("downloadHost");
        if (selectedDownloadHost != newDownloadHost){
            $(this).parent().parent().find('#selectDownload option:selected').attr('selected', false);
        }
    });

    $(document).on("click", "#selectUpload", function () {
        var checketIps = $(this).parent().find('#selectUpload option:selected').text().trim();
        $('#uploadHost').val(checketIps);    })

    $(document).on("click", "#uploadHost", function () {
        var selectedUploadHost = $(this).parent().parent().find('#selectForIpTrac option:selected').text().trim();
        var newUploadHost = $("uploadHost");
        if (selectedUploadHost != newUploadHost){
            $(this).parent().parent().find('#selectUpload option:selected').attr('selected', false);
        }
    });



    $(document).on("click", "#uploadDownloadSubmit", function (e) {
        e.preventDefault();
        var th = $(this);
        var interface = $("input[name='selectInterface']:checked");
        var interfaceCookie = $("input[name='selectInterface']:checked").val();
        $.cookie("conectionName",interfaceCookie);
        var downloadHost = $("input[name='downloadHost']").val();
        var uploadHost = $("input[name='uploadHost']").val();
        var action = $(".uploadDownload option:selected").val();
        // var index = $("input[name='index']").val();
        // var connect_index = $("input[name='connect_index']").val();
        var msgRequired = getMssg['error_message_required'];
        var msgURL = getMssg['error_message_url'];
        var connType = '';

        $("#uploadDownloadDiagnostic").validate({
            rules: {
                uploadHost:{
                    required: true,
                    // validateURL : true
                }
            },
            messages: {
                uploadHost: {
                    required: msgRequired,
                    // validateURL: msgURL
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        $("#forUploadDownload").validate({
            rules: {
                downloadHost:{
                    required: true,
                    // validateURL : true
                },
            },
            messages: {
                downloadHost: {
                    required: msgRequired,
                    // validateURL: msgURL
                },
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });


        if(!($("#uploadDownloadDiagnostic").valid())) {
            th.removeAttr("disabled");
            return false;
        };

        if(!($("#forUploadDownload").valid())) {
            th.removeAttr("disabled");
            return false;
        }

        var enableHost = false;

        if ($("#enableHost").is(":checked")) {
            enableHost = true;
        }else {
            enableHost = false;
        }

        if(interface.is(':checked') && ((downloadHost != '' || uploadHost != '') || enableHost == true)) {
            th.attr("disabled","disabled");
            var index = interface.closest('td').find("input[name='index']").val();
            var connect_index = interface.closest('td').find("input[name='connect_index']").val();
            var connectionType = interface.closest('td').find("input[name='conType']").val();
            var fileSize = $(".uploadFileSize option:selected").val();
            if (fileSize == 0 || fileSize == "") {
                var fileSizeDefault = $("input[name='settingsFileSize']").val();
            } else {
                fileSizeDefault = fileSize * 1000000;
            }
            var host = '';
            var actionName = '';
            if (action == "1") {
                host = $("input[name='uploadHost']").val();
                if (host == '') {
                    host = $("input[name='settingsIp']").val();
                }
                actionName = 'uploadDiagnostics';
            } else if (action == "2") {
                host = $("input[name='downloadHost']").val();
                actionName = 'downloadDiagnostics';
            }

            // var connectionType = '';
            if (th.hasClass("forStatic")) {
                // connectionType = "Static";
                connType = 3;
            } else if (th.hasClass("forDynamic")) {
                // connectionType = "DHCP";
                connType = 3;
            } else if (th.hasClass("forPPPoE")) {
                // connectionType = "PPPoE";
                connType = 1;
            } else if (th.hasClass("forLTE")) {
                // connectionType = "LTE";
                connType = 2;
                index = $("input[name='cell_index']").val();
                connect_index = $("input[name='dev_index']").val();
            } else {
                // connectionType = "L2TP";
                connType = 1;
            }

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': devId,
                    'host': host,
                    'index': index,
                    'connectIndex': connect_index,
                    'upDwAction': action,
                    'actionName': "uplodDownloadDiagnostic",
                    'connectionType': connectionType,
                    'fileSize': fileSizeDefault,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
                        var success = getMssg['action_succeed'];
                        $("#message-diagnostic").empty();
                        $("#message-diagnostic").removeClass("errorMessage");
                        $("#message-diagnostic").addClass("infoMessage");
                        $("#message-diagnostic").html(success);
                        setTimeout(function () {
                            updateActivities(devId);
                            // $("#message-diagnostic").empty();
                        }, 2000);

                        var interv = setInterval(function () {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/getLastActivityStatus.php",
                                data: {
                                    'deviceID': devId,
                                    'pingName': actionName,
                                    'fromApp': true
                                },
                                async: true,
                                success: function (result) {
                                    if (result == 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    } else if (result == 2) {
                                        clearInterval(interv);
                                        location.reload(true);

                                        // $.ajax({
                                        //     type: "POST",
                                        //     url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
                                        //     data: {
                                        //         'deviceID': devId,
                                        //         'index': index,
                                        //         'connectionType': connType,
                                        //         'host': host,
                                        //         'pingName': actionName,
                                        //         'fromApp': true
                                        //     },
                                        //     async: true,
                                        //     success: function (result) {
                                        //         if (result == 'logged_out') {
                                        //             document.location.href = $basepath + 'login';
                                        //         } else {
                                        //             $("#message-diagnostic").empty();
                                        //             $("#resultForPingUploadDownload").empty();
                                        //             $("#UploadDownloadForDiagnostic").empty();
                                        //             $("#resultForPingUploadDownload").html(result);
                                        //             th.removeAttr("disabled");
                                        //         }
                                        //     },
                                        //     error: function (xhr, status, error) {
                                        //         document.location.href = $basepath + '500';
                                        //     }
                                        // });
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }, 5000);
                    } else if (result == 'false') {
                        th.removeAttr("disabled");
                        var failed = getMssg['connect_failed'];
                        $("#message-diagnostic").empty();
                        $("#message-diagnostic").removeClass("infoMessage");
                        $("#message-diagnostic").addClass("errorMessage");
                        $("#message-diagnostic").html(failed);
                    } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else {
            var msg = $("input[name='msg_interfaceHost']").val();
            $('body').css("cursor", "default");
            $("#message-diagnostic").removeClass("infoMessage");
            $("#message-diagnostic").addClass("errorMessage");
            $("#message-diagnostic").empty();
            $("#message-diagnostic").html(msg);
        }
    });

    $(document).on("click", "#upDwSubmit", function (e) {
        e.preventDefault();
        var th = $(this);
        th.attr("disabled","disabled");
        var action = $(".uploadDownload option:selected").val();
        var index = $("input[name='index']").val();
        var connect_index = $("input[name='connect_index']").val();
        var msgRequired = getMssg['error_message_required'];
        var msgURL = getMssg['error_message_url'];
        var connType = '';

        $("#uploadDownloadDiagnostic").validate({
            rules: {
                uploadHost:{
                    required: true,
                    // validateURL : true
                },
                downloadHost:{
                    required: true,
                    // validateURL : true
                },
            },
            messages: {
                uploadHost: {
                    required: msgRequired,
                    // validateURL: msgURL
                },
                downloadHost: {
                    required: msgRequired,
                    // validateURL: msgURL
                },
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($("#uploadDownloadDiagnostic").valid())) {
            th.removeAttr("disabled");
            return false;
        }

        var fileSize = $(".uploadFileSize option:selected").val();
        if(fileSize == 0 || fileSize == "") {
            var fileSizeDefault = $("input[name='settingsFileSize']").val();
        } else {
            fileSizeDefault = fileSize;
        }
        var host = '';
        var actionName = '';
        if(action == "1"){
            host = $("input[name='uploadHost']" ).val();
            if(host == '') {
                host = $("input[name='settingsIp']").val();
            }
            actionName = 'uploadDiagnostics';
        }else if(action == "2"){
            host = $("input[name='downloadHost']" ).val();
            actionName = 'downloadDiagnostics';
        }
        
        var connectionType = '';
        if(th.hasClass("forStatic")){
            connectionType = "Static";
            connType = 3;
        }else if(th.hasClass("forDynamic")){
            connectionType = "DHCP";
            connType = 3;
        }else if(th.hasClass("forPPPoE")){
            connectionType = "PPPoE";
            connType = 1;
        }else if(th.hasClass("forLTE")){
            connectionType = "LTE";
            connType = 2;
            index = $("input[name='cell_index']").val();
            connect_index = $("input[name='dev_index']").val();
        }else{
            connectionType = "L2TP";
            connType = 1;
        }
        
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'host': host,
                'index': index,
                'connectIndex': connect_index,
                'upDwAction' : action,
                'actionName': "uplodDownloadDiagnostic",
                'connectionType': connectionType,
                'fileSize': fileSizeDefault,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#message-diagnostic").empty();
                    $("#message-diagnostic").removeClass("errorMessage");
                    $("#message-diagnostic").addClass("infoMessage");
                    $("#message-diagnostic").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                    }, 2000);
                    
                    var interv = setInterval(function(){
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/getLastActivityStatus.php",
                            data: {
                                'deviceID': devId,
                                'pingName': actionName,
                                'fromApp': true
                            },
                            async: true,
                            success: function (result) {
                                 if(result == 'logged_out'){
                                    document.location.href = $basepath + 'login';
                                } else if(result == 2){
                                    clearInterval(interv);

                                    $.ajax({
                                        type: "POST",
                                        url: $basepath + "secureFiles/actions/ajaxActions/getPingResult.php",
                                        data: {
                                            'deviceID': devId,
                                            'index': index,
                                            'connectionType': connType,
                                            'host': host,
                                            'pingName': actionName,
                                            'fromApp': true
                                        },
                                        async: true,
                                        success: function (result) {
                                            if(result == 'logged_out'){
                                                document.location.href = $basepath + 'login';
                                            } else {
                                                $("#message-diagnostic").empty();
                                                $("#uploadDownloadResult").empty();
                                                $("#uploadDownloadResult").html(result);
                                                th.removeAttr("disabled");
                                                // if(action == "1") {
                                                //     $("#message-diagnostic").empty();
                                                //     $("#downloadResult").empty();
                                                //     $("#downloadResult").html(result);
                                                //     th.removeAttr("disabled");
                                                // } else if(action == "2"){
                                                //     $("#message-diagnostic").empty();
                                                //     $("#uploadResult").empty();
                                                //     $("#uploadResult").html(result);
                                                //     th.removeAttr("disabled");
                                                // }
                                            }
                                        },
                                        error: function(xhr, status, error) {
                                            document.location.href = $basepath + '500';
                                        }
                                    });
                                }
                            },
                            error: function(xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        },5000);
                } else if (result == 'false'){
                    th.removeAttr("disabled");
                    var failed = getMssg['connect_failed'];
                    $("#message-diagnostic").empty();
                    $("#message-diagnostic").removeClass("infoMessage");
                    $("#message-diagnostic").addClass("errorMessage");
                    $("#message-diagnostic").html(failed);
                } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
    $(document).on("input", "#configPassword", function (e) {
        $('#configApply').removeAttr("disabled");
    });

    $(document).click(function(e){
        var target = e.target?e.target:e.srcElement;
        if (target.id == 'configApply' || target.id == 'configPassword'){
            return false;
        } else{
           if(!$('#configApply').is(':disabled')){
                $("#configApply").attr("disabled","disabled");
                $("#actionResPassword").empty();
                $("#configPassword").val('');
            }
        }
    });
    
    $(document).on("click", "#configApply", function (e) {
        var th = $(this);
        th.attr("disabled","disabled");
        var password = th.parent().find("input[name='configPassword']").val().trim();
        var msgRequired = getMssg['error_message_required'];
        var msgPass = getMssg['wifi-ascii'];
        var msgEmpty = getMssg['error_message_empty'];

        $("#changePassword").validate({
            rules: {
                configPassword: {
                    required: true,
                    validateASCII: true,
                    validateIsEmpty: true
                }
            },

            messages: {
                configPassword: {
                    required: msgRequired,
                    validateASCII: msgPass,
                    validateIsEmpty: msgEmpty
                }
            },
            errorElement: "div",
            errorClass: 'error_messagePass',
            errorPlacement: function(error, element) {
                $("#actionResPassword").empty();
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter("#configApply");
                }
            }
        });


        if(!($("#changePassword").valid())) {
            $("#actionResPassword").empty();
            return false;
        }

            // if(password != ''){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'password': password,
                    'deviceID': devId,
                    'actionName': 'setConfigPassword',
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'true') {
//                        th.removeAttr("disabled");
                        th.parent().find("input[name='configPassword']").val('');
                        var success = getMssg['action_succeed'];
                        $("#actionResPassword").removeClass("errorMessage");
                        $("#actionResPassword").addClass("infoMessage");
                        $("#actionResPassword").empty();
                        $("#actionResPassword").html(success);

                        setTimeout(function () {
                            updateActivities(devId);
                        }, 3000);

                        setTimeout(function () {
                            $("#actionResPassword").empty();
                        }, 10000);

                    } else if (result == 'false') {
//                        th.removeAttr("disabled");
                        th.parent().find("input[name='configPassword']").val('');
                        var failed = getMssg['connect_failed'];
                        $("#actionResPassword").removeClass("infoMessage");
                        $("#actionResPassword").addClass("errorMessage");
                        $("#actionResPassword").empty();
                        $("#actionResPassword").html(failed);
                        setTimeout(function () {
                            updateAfterTheAction();
                        }, 10000);

                    } else if (result = 'logged_out') {
                        document.location.href = $basepath + 'login';
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });

        // }else{
        //     th.removeAttr("disabled");
        //     var fail = getMssg['error_message_empty'];
        //     $("#actionResPassword").removeClass("infoMessage");
        //     $("#actionResPassword").addClass("errorMessage");
        //     $("#actionResPassword").empty();
        //     $("#actionResPassword").html(fail);
        // }
    });

    $(document).on("click", "#stunApply", function () {
        var stunEnable = $("input[name='stunOnoffswitch']");
        var connType= "";
        var actionName = "";
        if (stunEnable.is(":checked")) {
            connType = "UDP";
            actionName = "stunEnable";
        } else {
            connType = "TCP";
            actionName = "stunDisable";
        }
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            $('#stunOnoffswitch').attr("disabled", "disabled");
            if ($('#refreshButton').css('display') == 'none') {
                StunAccessApply(th,devId,actionName,connType);
            } else {
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function (isConfirm) {
                    if (isConfirm) {
                        StunAccessApply(th,devId,actionName,connType);
                    } else {
                        th.removeAttr("disabled");
                    }

                });
            }
        }
    });

    $(document).on("click", "#reconnect", function () {

        var connType = "UDP";
        var actionName = "stunEnable";

        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            if ($('#refreshButton').css('display') == 'none') {
                StunAccessApply(th, devId,actionName,connType);
            } else {
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function (isConfirm) {
                    if (isConfirm) {
                        StunAccessApply(th, devId,actionName,connType);
                    } else {
                        th.removeAttr("disabled");
                    }

                });
            }
        }
    });

    function StunAccessApply(th, devId,actionName,connType) {
        $('.stunStatus').addClass('offlinei');
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/stunConnection.php",
            data: {
                'deviceID': devId,
                'connType': connType,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                var success = getMssg['action_succeed'];
                $("#actionResSTUN").removeClass("errorMessage");
                $("#actionResSTUN").addClass("infoMessage");
                $("#actionResSTUN").empty();
                $("#actionResSTUN").html(success);
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'deviceID': devId,
                        'actionName': actionName,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        //if (result == 'true') {
                        var success = getMssg['action_succeed'];
                        $("#actionResSTUN").removeClass("errorMessage");
                        $("#actionResSTUN").addClass("infoMessage");
                        $("#actionResSTUN").empty();
                        $("#actionResSTUN").html(success);
                        setTimeout(function () {
                            updateActivities(devId);
                            getCorrentTaskIdByTab(devId, 'info');
                            $('body').css("cursor", "default");
                        }, 2000);

                        setTimeout(function () {
                            $("#actionResSTUN").empty();
                            location.reload(true);
                        }, 5000);
                        applyTasksActions(th,'refreshButton');
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
                // setTimeout(function () {
                //     intervalRefresh = setInterval(function () {
                //         getTaskStatusOfTheDeviceForRefreshButton('refreshButton', devId);
                //     }, 2000);
                // }, 3000);
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });


    }

    $(document).on("click", "input[name='remotOnoffswitch']", function () {
        var remoteAccessPort = $("input[name='remoteAccessInput']").val();
        var realRemotAccess = $("input[name='accessValue']").val();
        var realValuRemot = $("input[name='portValue']").val();
        if ($(this).is(":checked")) {
            $(".remoteAccessInput").show();
            $(".remoteAccessApply").show();
            $(".remoteAccessApply").removeClass("remoteAccessButton");
        } else if (realValuRemot == 0 && realRemotAccess == 0) {
            $(".remoteAccessInput").hide();
            $(".remoteAccessApply").hide();
            $(".errorMsgRemoteAccess").empty();
        } else if ($(this).is(":unchecked")) {
            $(".remoteAccessInput").hide();
            $(".remoteAccessApply").show();
            $(".remoteAccessApply").addClass("remoteAccessButton");
            $(".errorMsgRemoteAccess").empty();
        }

    });

    $(document).on("click", "#remoteAccessApply", function (e) {

        var msgRequird = getMssg['error_message_required'];
        var msgNumber =getMssg['error_message_number'];
        var msgGe1 = getMssg['error_message_ge_1'];
        var msgLe65535 = getMssg['error_message_le_65535'];
        var msgForPort = getMssg['error_message_for_port'];

        $('#remotAccess').validate({
            rules: {
                remoteAccessInput: {
                    required: true,
                    digits: true,
                    min: 1,
                    max: 65535,
                    validatePort: true
                }
            },
            messages: {
                remoteAccessInput: {
                    required: msgRequird,
                    digits: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgForPort
                }
            },
            errorElement: "div",
            errorClass: 'error_msg errorMsgRemoteAccess',
            errorPlacement: function(error, element) {
                $("#actionResRemoteAccess").empty();
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter("#remoteAccessApply");
                }
            }

        });

        if (!$("#remotAccess").valid()) {
            $('body').css("cursor", "default");
            return false;
        }

        e.preventDefault();
        var th = $(this);
        var remoteAccess = '';
        var remoteAccessPort = $("input[name='remoteAccessInput']").val();
        var realRemotAccess = $("input[name='accessValue']").val();
        var realValuRemot = $("input[name='portValue']").val();
        if ($("input[name='remotOnoffswitch']").is(":checked")) {
            remoteAccess = 1;
        } else {
            remoteAccessPort = '0';
            remoteAccess = '0';
        }
        if (remoteAccessPort == realValuRemot && remoteAccess == 1) {
                var failed = getMssg["nothing_changed"];
                $("#actionResRemoteAccess").removeClass("infoMessage");
                $("#actionResRemoteAccess").addClass("errorMessage");
                $("#actionResRemoteAccess").empty();
                $("#actionResRemoteAccess").html(failed);
        } else {
            if (th.attr("disabled") != "disabled") {
                th.attr("disabled", "disabled");
                if($('#refreshButton').css('display') == 'none') {
                    remoteAccessApply(remoteAccess, remoteAccessPort);
                } else {
                    var titleMsg = getMssg['title_msg'];
                    var rmMsg = getMssg['change_msg'];
                    var cancelMsg = getMssg['cancel'];
                    var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                    swal({
                        title: titleMsg,
                        text: msgOffOn,
                        showCancelButton: true,
                        closeOnConfirm: true,
                        confirmButtonText: rmMsg,
                        cancelButtonText: cancelMsg,
                        confirmButtonColor: "#008DA9"
                    }, function (isConfirm) {
                        if (isConfirm) {
                            remoteAccessApply(remoteAccess, remoteAccessPort);
                        } else {
                            th.removeAttr("disabled");
                        }
                    });
                }
            }
        }
    });

    function remoteAccessApply(remoteAccess, remoteAccessPort) {
        ajaxRequest.send({
            type:globalVar.HTTP.POST,
            name:globalVar.TASKS.SET_REMOTE_ACCESS,
            chack:globalVar.TASKS.SET,
            data: {
                'deviceID': devId,
                'remoteAccess': remoteAccess,
                'remoteAccessPort': remoteAccessPort,
                'fromApp':true,
            },
            response:function(respons) {
                var success = getMssg['action_succeed'];
                $("#actionResRemoteAccess").empty();
                $("#actionResRemoteAccess").addClass('mainColor');
                $("#actionResRemoteAccess").html(success);
                setTimeout(function () {
                    getCorrentTaskIdByTab(devId,'info');
                    $("body").css("cursor", "default");
                }, 2000);
            },
            getStatus:function(status){
                $("#actionResRemoteAccess").empty();
                //task was done
            }
        });
        // $.ajax({
        //     type: "POST",
        //     url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        //     data: {
        //         'deviceID': devId,
        //         'remoteAccess': remoteAccess,
        //         'remoteAccessPort': remoteAccessPort,
        //         'actionName': 'setRemoteAccess',
        //         'fromApp': true
        //     },
        //     async: false,
        //     success: function (result) {
        //         if (result == 'true') {
        //             var success = getMssg['action_succeed'];
        //             $("#actionResRemoteAccess").empty();
        //             $("#actionResRemoteAccess").html(success);
        //             $("#actionResRemoteAccess").removeClass("errorMessage");
        //             $("#actionResRemoteAccess").addClass("infoMessage");
        //             setTimeout(function () {
        //                 updateActivities(devId);
        //                 getCorrentTaskIdByTab(devId, 'info');
        //                 $('body').css("cursor", "default");
        //             }, 2000);
        //
        //             setTimeout(function () {
        //                 $("#actionResRemoteAccess").empty();
        //             }, 10000);
        //
        //             setTimeout(function () {
        //                 intervalRefresh = setInterval(function () {
        //                     getTaskStatusOfTheDeviceForRefreshButton('refreshButton', devId);
        //                 }, 2000);
        //             }, 3000);
        //
        //         } else if (result == 'false') {
        //             $("body").css("cursor", "default");
        //             var failed = getMssg['connect_failed'];
        //             $("#actionResRemoteAccess").empty();
        //             $("#actionResRemoteAccess").html(failed);
        //             setTimeout(function () {
        //                 updateAfterTheAction();
        //             }, 10000);
        //
        //         } else if (result = 'logged_out') {
        //             document.location.href = $basepath + 'login';
        //         }
        //     },
        //     error: function (xhr, status, error) {
        //         document.location.href = $basepath + '500';
        //     }
        // });
    }

    $(document).on("click", "#lteApply", function () {
        var th = $(this);
        var autoconect ='';
        var cellIndex = $("input[name='cell_index']").val();
        if ($("input[name='LTEOnoffswitch']").is(":checked")) {
            autoconect = '1';
        } else {
            autoconect = '0';
        }
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            if ($('#refreshButton').css('display') == 'none') {
                lteApply(cellIndex, autoconect);
            } else {
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['change_msg'];
                var cancelMsg = getMssg['cancel'];
                var msgOffOn = getMssg['msg_mbssid_whatever_change'];

                swal({
                    title: titleMsg,
                    text: msgOffOn,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function (isConfirm) {
                    if (isConfirm) {
                        lteApply(cellIndex, autoconect);
                    } else {
                        th.removeAttr("disabled");
                    }

                });
            }
        }
    });

    function lteApply(cellIndex, autoconect) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': 'autoConnectLte',
                'cellIndex': cellIndex,
                'autoconect': autoconect,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#actionResLte").empty();
                    $("#actionResLte").html(success);
                    $("#actionResLte").removeClass("errorMessage");
                    $("#actionResLte").addClass("infoMessage");
                    setTimeout(function () {
                        updateActivities(devId);
                        getCorrentTaskIdByTab(devId, 'lte');
                        $('body').css("cursor", "default");
                    }, 2000);

                    setTimeout(function () {
                        $("#actionResLte").empty();
                    }, 10000);

                    setTimeout(function () {
                        intervalRefresh = setInterval(function () {
                            getTaskStatusOfTheDeviceForRefreshButton('refreshButton', devId);
                        }, 2000);
                    }, 3000);

                } else if (result == 'false') {
                    $("body").css("cursor", "default");
                    var failed = getMssg['connect_failed'];
                    $("#actionResLte").empty();
                    $("#actionResLte").html(failed);
                    setTimeout(function () {
                        updateAfterTheAction();
                    }, 10000);

                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("click", ".refreshDeviceTab", function () {
        var th = $(this);
        var tabName = $(this).parent().find("input[name='tabName']").val();
        var devIndex = $("input[name='dev_index']").val();
        var connIndex= $("input[name='connIndex']").val();
        if(tabName == "lte"){
            connIndex = devIndex;
        }
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': "refreshDeviceTab",
                'tabName': tabName,
                'connIndex': connIndex,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'true') {
                    var success = getMssg['action_succeed'];
                    $("#resDev").empty();
                    $("#resDev").html(success);
                    setTimeout(function () {
                        updateActivities(devId);
                        $(this).attr("disabled","disabled");
                        $("#resDev").empty();
                    }, 2000);
                    intervalTaskRefresh = setInterval(function(){
                        getTaskStatusForRefresh(th,"refreshButton",devId);
                    },2000);
                } else if (result == 'false'){
                    $("body").css("cursor", "default");
                    var failed = getMssg['connect_failed'];
                    $("#resDev").empty();
                    $("#resDev").html(failed);
                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    if (navigator.userAgent.indexOf("Firefox") < 60) {
        $(".legendTracertDiagnostic").css("paddingTop", "20px");
        $(".legendUploadDownloadDiagnostic").css("paddingTop", "20px");

    }
});
