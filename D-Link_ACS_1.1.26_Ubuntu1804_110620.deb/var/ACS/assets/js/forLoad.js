window.onload=function(){
    document.getElementById("hh").submit();
    };

