function initPopoverFile() {
    if($('.container_file .popover').hasClass('in')) {
        ishidden = false;
    } else {
        ishidden = true;
    }

    if(ishidden == true) {

        var content = $('.container_file .popover-content');
        var html = content.html();

        $('.fileSettingPopover').html(html);

        $('.fileSettingPopover select').each(function(i){

            var sel = $('.container_file .popover-content select').eq(i).val();
            if (sel == null){
                sel = 0;
                setTimeout(function () {
                    $(this).val(sel);;
                }, 1);
            }else {
                $(this).val(sel);
            }
        });
    } else {
        $('.container_file .popover-content select').each(function(i){
            var sel = $('.fileSettingPopover select').eq(i).val();
            $(this).val(sel);
        })
    }
}

$(document).ready(function () {

    $('#filePopover').popover({
        html: true,
        content: function () {
            html = $('.fileSettingPopover').html();
            return html;
        }
    });

    $('#filePopover').on('click', function (e) {
        initPopoverFile();
    });

    $('#filePopover').on('shown.bs.popover', function () {

        $('.fields').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });

        $('.file').find('.popover-content select').each(function (i) {
            var sel = $('.fileSettingPopover select').eq(i).val();
            $(this).val(sel);
        });

        $('.popover-content .fields').on('ifChecked ifUnchecked', function (event) {
            var page = $(".curPage").find("input[name='page']").val();

            if (event.type == 'ifChecked') {
                this.setAttribute("checked", "checked");

            } else {
                this.removeAttribute("checked");
            }
            var cooki_array = new Array();
            var i = 0;
            $('.popover-content .fields').each(function () {
                if ($(this).is(':checked')) {
                    cooki_array[i] = 1;
                } else {
                    cooki_array[i] = 0;
                }
                i++;
            });
            var model = $('.file').find(".modelTypeActivity option:selected").val();
            var type = $('.file').find(".FileType option:selected").val();


            filteredFiles(model, type, cooki_array,page,'');
        });
    });

    $(document).on('click', '.rowCountFile', function () {

        $(this).parent().find('.active').removeClass('active');
        $(this).addClass('active');

        $("body").css("cursor", "wait");

        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var type = $(".FileType option:selected").val();
        var fileCount = $(this).data('row');
        var cooki_array = new Array();
        var i = 0;
        $('.popover-content .fields').each(function () {
            if ($(this).is(':checked')) {
                cooki_array[i] = 1;
            } else {
                cooki_array[i] = 0;
            }
            i++;
        });

        filteredFiles(model, type,cooki_array,page,fileCount);
    });





    $('#filePopover').popover().on('hide.bs.popover', function () {
        var model = $(".modelTypeActivity option:selected").val();
        var type = $(".FileType option:selected").val();

        $(".modelTypeActivity option").each(function () {
            if ($(this).val() == model) {
                $(this).attr("selected", "true");
            }
        });
        $(".FileType option").each(function () {
            if ($(this).val() == type) {
                $(this).attr("selected", "true");
            }
        });

        setTimeout(function () {
            $('.popover-content .fields').iCheck('destroy');
            $('.fields').iCheck('update');
            $(".fileSettingPopover").html($('.file').find(".popover-content").html());
            $('.fileSettingPopover select').each(function (i) {
                var sel = $('.file').find('#alert-content select').eq(i).val();
                $(this).val(sel);
            });
        }, 100);
    });

    $(document).on('click', function (e) {
        var $popover ;
        var $target = $(e.target);

        //do nothing if there was a click on popover content
        if ($target.hasClass('popover') || $target.closest('.popover').length) {
            return;
        }
        initPopoverFile();
        $('[data-toggle="popover"]').each(function () {
            $popover = $(this);

            if (!$popover.is(e.target) &&
                $popover.has(e.target).length === 0 &&
                $('.popover').has(e.target).length === 0){
                $popover.popover('hide');
            }
        });
    });

    $(window).resize(function () {
        $(".popover").each(function () {
            var popover = $(this);

            if (popover.is(":visible")) {
                var ctrl = $(popover.context);
                ctrl.popover('hide');

                initPopoverFile();
            }
        });
    });

    $(document).on("click", ".eachFilePage", function () {
        var page = $(this).find("input[name='page']").val();
        var model = $(".modelTypeActivity option:selected").val();
        var type = $(".FileType option:selected").val();
        var cooki_array = new Array();
        var i = 0;
        $('.fieldsetDevice .fields').each(function () {
            if ($(this).is(':checked')) {
                cooki_array[i] = 1;
            } else {
                cooki_array[i] = 0;
            }
            i++;
        });
        filteredFiles(model, type,cooki_array,page,'');
    });

    $(document).on("change", ".modelTypeActivity", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var type = $(".FileType option:selected").val();
        var cooki_array = new Array();
        var i = 0;
        $('.popover-content .fields').each(function () {
            if ($(this).is(':checked')) {
                cooki_array[i] = 1;
            } else {
                cooki_array[i] = 0;
            }
            i++;
        });

        filteredFiles(model, type,cooki_array,page,'');
    });

    $(document).on("change", ".FileType", function () {
        var page = 1;
        var model = $(".modelTypeActivity option:selected").val();
        var type = $(".FileType option:selected").val();
        var cooki_array = new Array();
        var i = 0;
        $('.popover-content .fields').each(function () {
            if ($(this).is(':checked')) {
                cooki_array[i] = 1;
            } else {
                cooki_array[i] = 0;
            }
            i++;
        });

        filteredFiles(model, type,cooki_array,page,'');
    });


    function filteredFiles(model, type, cooki_array,page,fileCount) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredFiles.php",
            data: {
                'model': model,
                'type': type,
                'cooki_array': cooki_array,
                'page': page,
                'fileCount': fileCount,
                // 'functionName': 'FilteredFiles',
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    if (model == 0 && type == 0) {
                        $("#resetfile").css("display", "none");
                    } else {
                        $("#resetfile").css("display", "block");
                        $('.deleteAll').html('<i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>' + getMssg['delete_filtered']);
                    }
                    $("body").css("cursor", "default");

                    $("#forFiles").empty();
                    $("#forFiles").html(result);
                    if(model == '0' && type == '0'){
                        $('.deleteAll').html('<i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>' + getMssg['delete_all']);
                    }else{
                        $('.deleteAll').html('<i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>' + getMssg['delete_filtered']);
                    }
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on("click","#resetfile",function(){

        $("body").css("cursor","wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/files.php",
            data: {
                'fromApp':true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forActivities").empty();
                    $("#forActivities").html(result);
                    location.reload(true);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('click','#searchFile', function () {
        searchFile();
    });

    function searchFile(){
        var searchVal = $("input[name='fileInfo']").val();
        var page = $(".curPage").find("input[name='page']").val();
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchFiles.php",
            data: {
                'searchVal': searchVal,
                'actionName': "searchedFiles",
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forFiles").empty();
                    $("#forFiles").html(result);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
});





