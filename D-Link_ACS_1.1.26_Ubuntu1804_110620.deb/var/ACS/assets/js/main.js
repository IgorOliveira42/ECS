var intervalTaskRefresh = '';

var text = $('.highlight').text();
$('.highlight').html(text.replace('*', '<span>*</span>'));

var getMessage = null;

function isCreateVlan(actType){
    if(actType.trim().indexOf("createBridge") == 0 && actType.trim().length == 12 || actType.trim().indexOf("taggedNat") == 0 && actType.trim().length == 9 || actType.trim().indexOf("taggedNatParam") == 0 && actType.trim().length == 14 || actType.trim().indexOf("untaggedBridge") == 0 && actType.trim().length == 14) {

        return true;
    } else {
        return false;
    }

}

function isDeleteVlanOrPort(actType){
    if(actType.trim().indexOf("deleteVlan") == 0 && actType.trim().length == 10 || actType.trim().indexOf("deleteVlanPort") == 0 && actType.trim().length == 14 || actType.trim().indexOf("deleteObject") == 0 && actType.trim().length == 12) {

        return true;
    } else {
        return false;
    }
}

$(document).ready(function () {
//   global variable

    $basepath = $('#basepath').data('bpath');
    $getMssg = '';

    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
        data: {
//            'message': msg,
            'fromApp': true
        },
        dataType: 'json',
        async: false,
        success: function (result) {
            getMssg = result;
        }
    });
    // Disable key 13 (enter)

    $(document).on('keyup keypress', 'form input[type="text"]', function (e) {
        if (e.which == 13) {
            e.preventDefault();
            return false;
        }
    });

    getMessage = function (key) {
        return getMssg[key];
    }

    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
        data: {
            'actionName': "ForServer",
            'fromApp': true
        },
        async: true,
        success: function (result) {
            if (result == "1") {
                $("#statusON").removeClass("for_all_display_none");
            } else {
                $("#statusOFF").removeClass("for_all_display_none");
            }
        },
        error: function (xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });


//    ----------------- Devices page  -----------------

//   ֊֊֊֊֊֊֊֊֊֊֊֊---- Setting display ----֊֊֊֊֊֊֊֊֊֊֊֊֊

    $('.devField').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#setPopover').popover({
        html: true,
        content: function () {
            return $('#setting_popover').html();
        }
    });

    $('#setPopover').on('shown.bs.popover', function () {

        $('.fields').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });

        $('.setPopCont').find('.popover-content select').each(function (i) {
            var sel = $('#setting_popover select').eq(i).val();
            $(this).val(sel);
        });

        $('.popover-content .fields').on('ifChecked ifUnchecked', function (event) {

            if (event.type == 'ifChecked') {
                this.setAttribute("checked", "checked");

            } else {
                this.removeAttribute("checked");
            }
//            $('.fields').iCheck('update');
            var cooki_array = new Array();
            var i = 0;
            $('.popover-content .fields').each(function () {
                if ($(this).is(':checked')) {
                    cooki_array[i] = 1;
                } else {
                    cooki_array[i] = 0;
                }
                i++;
            });
            fiterDevicesTable(cooki_array);
            console.log(cooki_array);

//            $.ajax({
//                type: "POST",
//                url: $basepath + "secureFiles/actions/ajaxActions/changeFields.php",
//                data: {
//                    'cooki_array': cooki_array,
//                    'fromApp':true
//                },
//                async: false,
//                success: function (data) {
//                    if (data == 'logged_out') {
//                        document.location.href = $basepath + 'login';
//                    } else {
//                        location.reload(true);
//                        $("body").css("cursor", "default");
//                    }
//                },
//                error: function(xhr, status, error) {
//                    document.location.href = $basepath + '500';
//                }
//            });
        });
    });

    $('#setPopover').popover().on('hide.bs.popover', function () {

        setTimeout(function () {
            $('.popover-content .fields').iCheck('destroy');
            $('.fields').iCheck('update');
            $("#setting_popover").html($('.setPopCont').find(".popover-content").html());
            $('#setting_popover select').each(function (i) {
                var sel = $('.setPopCont').find('#alert-content select').eq(i).val();
                $(this).val(sel);
            });
        }, 100);
    });

    function initPopoverMain() {
        if ($('.container_activity .popover').hasClass('in')) {
            ishidden = true;
        } else {
            ishidden = false;
        }

        if (ishidden == true) {

            var content = $('.container_activity .popover-content');
            var html = content.html();

            $('.activitySettingPopover').html(html);

            $('.activitySettingPopover select').each(function (i) {
                var sel = $('.container_activity .popover-content select').eq(i).val();
                $(this).val(sel);
            });

        } else {

            $('.container_activity .popover-content select').each(function (i) {
                var sel = $('.activitySettingPopover select').eq(i).val();
                $(this).val(sel);
            })
            //$('.activitySettingPopover').empty();
        }
    }

    $(document).on('click', function (e) {
        var $popover;
        var $target = $(e.target);

        //do nothing if there was a click on popover content
        if ($target.hasClass('popover') || $target.closest('.popover').length) {
            return;
        }
        initPopoverMain();
        $('[data-toggle="popover"]').each(function () {
            $popover = $(this);

            if (!$popover.is(e.target) &&
                $popover.has(e.target).length === 0 &&
                $('.popover').has(e.target).length === 0) {
                $popover.popover('hide');
            }
        });
    });

    function fiterDevicesTable(cooki_array) {
        if ($("#statusonoffswitch").is(":checked") == true) {
            $("#statusonoffswitch").prop('checked', false).iCheck('update');
            setStatusCheckDevice(false, "devStatus", true);
        }
        $checked_array = new Array();
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        $("body").css("cursor", "wait");
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getFWsByModel.php",
            data: {
                'getFirmware': false,
                'forFWFilter': true,
                'modelID': modelID,
                'groupId': groupID,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var fwVersion = $(".changeFirmwareFilter option:selected").val();
                    if (fwVersion == '0') {
                        $('.changeFirmwareFilter :not(:first-child)').remove();
                        $(".changeFirmwareFilter").append(data);
                        $(".changeFirmwareFilter option[value='0']").prop('selected', true);
                        var fwVersion = $(".changeFirmwareFilter option:selected").val();
                    } else {
                        $('.changeFirmwareFilter :not(:first-child)').remove();
                        $(".changeFirmwareFilter").append(data);
                        $(".changeFirmwareFilter option[value='" + fwVersion + "']").prop('selected', true);
                    }

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/devices.php",
                        data: {
                            'modelId': modelID,
                            'devCount': devCount,
                            'groupId': groupID,
                            'fwVersion': fwVersion,
                            'cooki_array': cooki_array,
                            'page': 0,
                            'fromApp': true
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                $("#deviceTable").html("");
                                $("#deviceTable").html(data);
                                $("body").css("cursor", "default");
                                $("#forSearchingDev").find("input[name='clientInfo']").val("");
                                $("#forSearchingDev").find("input[name='clientInfo']").empty();
                                $(".subClients").empty();
                                if (deviceScrollPage == 2) {
                                    $(".pageForDevice").hide();
                                    var showScroll = $(".inputForScroll").val();
                                    if (showScroll == 3) {
                                        $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                                    } else {
                                        $(".fa-arrow-circle-down").remove();
                                    }
                                }
                                if (groupID != 0 || modelID != 0) {
                                    $('#deviceTable .groupTaskForDev').css('display', 'block');
                                } else {
                                    $('#deviceTable .groupTaskForDev').css('display', 'none');
                                }


                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
    }

    function getDashboard(divNAme, arrOfDeviceModel, color) {
        if (color != '') {
            Highcharts.setOptions({
                colors: color
            });
        }

        Highcharts.chart(divNAme, {
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    // alpha: 45,
                    beta: 0
                },
                backgroundColor: 'none',

            },
            title: {
                text: ''
            },
            tooltip: {
                pointFormat: '{point.y} pcs</br> <b style="font-style: normal">({point.percentage:.1f} %)</b>'
            },
            plotOptions: {
                pie: {
                    allowPointSelect: true,
                    cursor: 'pointer',
                    depth: 30,
                    dataLabels: {
                        enabled: true,
                        format: '<b>{point.name}</b> : {point.y} pcs</br> <b style="font-style: normal">({point.percentage:.1f} %)</b>',
                    }
                }
            },
            series: [{
                type: 'pie',
                name: ' ',
                showInLegend: "true",
                legendText: "{label}",
                innerSize: '50%',
                data: arrOfDeviceModel
            }]
        });
    }

    $(document).on('click', '.update_dashboard', function () {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getModelChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var color = [];
                    var result = JSON.parse(data);
                    $("#containerForModel").html("");

                    for (var i = 0; i < result.length; i++) {
                        color.push("#" + (17 * (i + 6 * i + 5) * (i * i) + "abcde").slice(0, 6));
                    }
                    getDashboard("containerForModel", result, color)
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });


    $(document).on('click', '.update_heartbeat', function () {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getHeartbeatChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var color = ["#3DAD6A", "#FFA500", "#AD3D40"];
                    var result = JSON.parse(data);
                    var realresult = [];
                    var realcolor = [];
                    $("#containerForHeartbeat").html("");
                    for (var i = 0; i < result.length; i++) {
                        if (result[i][1] != 0) {
                            realresult.push(result[i]);
                            realcolor.push(color[i]);
                        }
                    }
                    getDashboard("containerForHeartbeat", realresult, realcolor)
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('click', '.update_unknown_devices', function () {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getDashboard.php",
            data: {
                'actionName': "getUnknownPendingChart",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var color = ["#FFA500", "#3DAD6A"];
                    var result = JSON.parse(data);
                    var realresult = [];
                    var realcolor = [];
                    $("#containerForUnknownPendingDev").html("");
                    for (var i = 0; i < result.length; i++) {
                        if (result[i][1] != 0) {
                            realresult.push(result[i]);
                            realcolor.push(color[i]);
                        }
                    }
                    getDashboard("containerForUnknownPendingDev", realresult, realcolor)
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('change', '.groupType', function () {
        fiterDevicesTable('');
        setDefaultSortVals($(".sortDevs"));
//        $("body").css("cursor", "wait");
//        var modelID = $(".modelType option:selected").val();
//        var devCount = $('.pagelimit').find('.active').data('row');
//        var groupID = $(".groupType option:selected").val();
//        var fwVersion = $(".changeFirmwareFilter option:selected").val();
//        
//        $.ajax({
//            type: "POST",
//            url: $basepath + "secureFiles/actions/ajaxActions/getFWsByModel.php",
//            data: {
//                'getFirmware' : false,
//                'forFWFilter' : true,
//                'modelID': modelID,
//                'groupId' : groupID,
//                'fromApp':true
//            },
//            async: false,
//            success: function (data) {
//                if (data == 'logged_out') {
//                    document.location.href = $basepath + 'login';
//                } else {
//                    $('.changeFirmwareFilter :not(:first-child)').remove();
//                    $(".changeFirmwareFilter").append(data);
//                    $(".changeFirmwareFilter option[value='0']").prop('selected', true);
//                    var fwVersion = $(".changeFirmwareFilter option:selected").val();
//        
//                    $.ajax({
//                        type: "POST",
//                        url: $basepath + "secureFiles/actions/ajaxActions/devices.php",
//                        data: {
//                            'modelId':  modelID,
//                            'devCount': devCount,
//                            'groupId':  groupID,
//                            'fwVersion':  fwVersion,
//                            'page': 0,
//                            'fromApp':true
//                        },
//                        async: false,
//                        success: function (data) {
//                            if (data == 'logged_out') {
//                                document.location.href = $basepath + 'login';
//                            } else {
//                                $("#deviceTable").html("");
//                                $("#deviceTable").html(data);
//                                $("body").css("cursor", "default");
//                                $("#forSearchingDev").find("input[name='clientInfo']").val("");
//                                $("#forSearchingDev").find("input[name='clientInfo']").empty();
//                                $(".subClients").empty();
//                            }
//                        },
//                        error: function(xhr, status, error) {
//                            document.location.href = $basepath + '500';
//                        }
//                    });
//                }
//            },
//            error: function(xhr, status, error) {
//                document.location.href = $basepath + '500';
//            }
//        });
    });

    $(document).on('change', '.modelType', function () {
        fiterDevicesTable('');
        setDefaultSortVals($(".sortDevs"));
//        $("body").css("cursor", "wait");
//        var modelID = $(".modelType option:selected").val();
//        var devCount = $('.pagelimit').find('.active').data('row');
//        var groupID = $(".groupType option:selected").val();
//        var fwVersion = $(".changeFirmwareFilter option:selected").val();
//        
//        $.ajax({
//            type: "POST",
//            url: $basepath + "secureFiles/actions/ajaxActions/getFWsByModel.php",
//            data: {
//                'getFirmware' : false,
//                'forFWFilter' : true,
//                'modelID': modelID,
//                'groupId' : groupID,
//                'fromApp':true
//            },
//            async: false,
//            success: function (data) {
//                if (data == 'logged_out') {
//                    document.location.href = $basepath + 'login';
//                } else {
//                    $('.changeFirmwareFilter :not(:first-child)').remove();
//                    $(".changeFirmwareFilter").append(data);
//                    $(".changeFirmwareFilter option[value='0']").prop('selected', true);
//                    var fwVersion = $(".changeFirmwareFilter option:selected").val();
//                    
//                    $.ajax({
//                        type: "POST",
//                        url: $basepath + "secureFiles/actions/ajaxActions/devices.php",
//                        data: {
//                            'modelId': modelID,
//                            'devCount': devCount,
//                            'groupId':  groupID,
//                            'fwVersion':  fwVersion,
//                            'page': 0,
//                            'fromApp':true
//                        },
//                        async: false,
//                        success: function (data) {
//                            if (data == 'logged_out') {
//                                document.location.href = $basepath + 'login';
//                            } else {
//                                $("#deviceTable").html("");
//                                $("#deviceTable").html(data);
//                                $("body").css("cursor", "default");
//                                $("#forSearchingDev").parent().find("input[name='clientInfo']").val("");
//                                $(".subClients").empty();
//                            }
//                        },
//                        error: function(xhr, status, error) {
//                            document.location.href = $basepath + '500';
//                        }
//                    });
//                }
//            },
//            error: function(xhr, status, error) {
//                document.location.href = $basepath + '500';
//            }
//        });
    });

    function checkTimeOut() {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/checkTimeOut.php",
            data: {
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'true') {
                    location.reload(true);
                    return false;
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on('mousedown', 'button', function () {
        checkTimeOut();
    });

    $(document).on('mousedown', 'i', function () {
        checkTimeOut();
    });

    $(document).on('mousedown', 'input', function () {
        checkTimeOut();
    });

    $(document).on('mousedown', 'a', function () {
        checkTimeOut();
    });

    $(document).on('mousedown', 'select', function () {
        checkTimeOut();
    });

    $(document).on('mousedown', '.onoffswitch', function () {
        checkTimeOut();
    });

    $(document).on('change', '.changeFirmwareFilter', function () {
        var modelID = $(".modelType option:selected").val();
        var devCount = $('.pagelimit').find('.active').data('row');
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/devices.php",
            data: {
                'modelId': modelID,
                'devCount': devCount,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'cooki_array': '',
                'page': 0,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("#forSearchingDev").parent().find("input[name='clientInfo']").val("");
                    $(".subClients").empty();
                }

                setDefaultSortVals($(".sortDevs"));
                if (groupID != 0 || modelID != 0) {
                    $('#deviceTable .groupTaskForDev').css('display', 'block');
                } else {
                    $('#deviceTable .groupTaskForDev').css('display', 'none');
                }

            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $('#btnFlag').popover({
        html: true,
        content: function () {
            return $('#language_bar').html();
        }
    });


//  This function is not used,because Apply button is removed from Settings Display

    $(document).on('click', '#okFields', function () {

        $("body").css("cursor", "wait");
        var cooki_array = new Array(9);
        var n = $(this).parent().find("input[name='n']");
        if ($(n).is(':checked')) {
            cooki_array[0] = 1;
        } else {
            cooki_array[0] = 0;
        }
        var sN = $(this).parent().find("input[name='sN']");
        if ($(sN).is(':checked')) {
            cooki_array[1] = 1;
        } else {
            cooki_array[1] = 0;
        }
        var mF = $(this).parent().find("input[name='mF']");
        if ($(mF).is(':checked')) {
            cooki_array[2] = 1;
        } else {
            cooki_array[2] = 0;
        }
        var oui = $(this).parent().find("input[name='port']");
        if ($(oui).is(':checked')) {
            cooki_array[3] = 1;
        } else {
            cooki_array[3] = 0;
        }
        var ip = $(this).parent().find("input[name='ip']");
        if ($(ip).is(':checked')) {
            cooki_array[4] = 1;
        } else {
            cooki_array[4] = 0;
        }
        var mN = $(this).parent().find("input[name='mN']");
        if ($(mN).is(':checked')) {
            cooki_array[5] = 1;
        } else {
            cooki_array[5] = 0;
        }
        var mac = $(this).parent().find("input[name='mac']");
        if ($(mac).is(':checked')) {
            cooki_array[6] = 1;
        } else {
            cooki_array[6] = 0;
        }
        var clientName = $(this).parent().find("input[name='clientName']");
        if ($(clientName).is(':checked')) {
            cooki_array[7] = 1;
        } else {
            cooki_array[7] = 0;
        }
        var devId = $(this).parent().find("input[name='dI']");
        if ($(devId).is(':checked')) {
            cooki_array[8] = 1;
        } else {
            cooki_array[8] = 0;
        }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeFields.php",
            data: {
                'cooki_array': cooki_array,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    location.reload(true);
                    $("body").css("cursor", "default");
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on('click', '.rowCount', function () {
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        $(this).parent().find('.active').removeClass('active');
        $(this).addClass('active');

        $("body").css("cursor", "wait");
        var modelID = $(".modelType option:selected").val();
        var devCount = $(this).data('row');
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/devices.php",
            data: {
                'modelId': modelID,
                'devCount': devCount,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'cooki_array': '',
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    $('#forSearchingDev').find("input[name='clientInfo']").val("");
                    $('#forSearchingDev').find("input[name='clientInfo']").empty();
                    $(".subClients").empty();
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
    });

//      ------------- Search devices ----------------

    $(document).on('change', '.searchType', function () {
//        $searchedval = $(this).data('d');
//        $searchedvalrus = $(this).data('rus');

        $searchedval = $('.searchType option:selected').val();

//      $('.search_actionbtn').html($searchedvalrus + '<i class="fa fa-angle-down angledown"></i>');

        if ($searchedval == 'clients') {
            $('.linkForSearchDev').attr('id', 'searchDeviByClient');

        } else if ($searchedval == 'ip') {
            $('.linkForSearchDev').attr('id', 'searchDevByIp');
            // $(".subClients").empty();

        } else if ($searchedval == 'username') {
            $(".linkForSearchDev").attr("id", "searchDevByUsername");
            // $(".subClients").empty();

        } else if ($searchedval == 'serial') {
            $('.linkForSearchDev').attr('id', 'searchDevBySerial');
            // $(".subClients").empty();

        } else if ($searchedval == 'mac') {
            $('.linkForSearchDev').attr('id', 'searchDevByMac');
            // $(".subClients").empty();
        }
    });

    $("#forSearchingDev").on("click", "#searchDeviByClient", function () {
        $checked_array = [];
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        var clientInfo = $('#forSearchingDev').find("input[name='clientInfo']").val().trim();

        $("body").css("cursor", "wait");
        var page = 1;
        searchByClient(page, clientInfo);
        setDefaultSortVals($(".sortDevs"));
    });


    $("#forSearchingDev").on("click", "#searchDevByIp", function () {
        $checked_array = [];
        $(".subClients").empty();
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        var th = $('#forSearchingDev').find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        searchByIp(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");
        setDefaultSortVals($(".sortDevs"));
    });

    function setDefaultSortVals(element) {
        element.val("last_inform_time");
        $(".sort_device_by").attr("id", "ASC");
        $(".sort_device_by").attr("src", $basepath + "assets/images/down_arrow_34.png");
        $(".sort_device_by").attr("title", getMessage("by_desc"));

    }

    $("#forSearchingDev").on("click", "#searchDevBySerial", function () {
        $checked_array = [];
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        $(".subClients").empty();
        var th = $('#forSearchingDev').find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();

        searchBySerial(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");
        setDefaultSortVals($(".sortDevs"));
    });

    $("#forSearchingDev").on("click", "#searchDevByMac", function () {
        $checked_array = [];
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        $(".subClients").empty();
        var th = $('#forSearchingDev').find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();

        searchByMac(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");
        setDefaultSortVals($(".sortDevs"));
    });

    $("#forSearchingDev").on("click", "#searchDevByUsername", function () {
        $checked_array = [];
        var th = $(this).parent().find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();

        searchByUsername(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");
        setDefaultSortVals($(".sortDevs"));
    });

    $(document).on('change', '.sortDevs', function () {
        $checked_array = [];
        $(".subClients").empty();
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        var th = $('#forSearchingDev').find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();

        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var sortedVal = $(".sortDevs option:selected").val();

        var sortBy = $(".sort_device_by").attr("id");

        if (sortBy == "DESC") {
            sortBy = "ASC";
        } else {
            sortBy = "DESC";
        }

        sortedVal = sortedVal + ":" + sortBy;

        var searchedval = $('.searchType option:selected').val();

//      $('.search_actionbtn').html($searchedvalrus + '<i class="fa fa-angle-down angledown"></i>');
        if (clientInfo != "") {

            if (searchedval == 'clients') {
                var clientId = $(this).parent().find("input[name='selectedClientId']").val();
                var page = 1;
             //  alert(clientId);
                var firstName = th.find("input[name='firstName']").val();
                var surName = th.find("input[name='surName']").val();
                var address = th.find("input[name='address']").val();
                var email = th.find("input[name='email']").val();
                getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, sortedVal);

            } else if (searchedval == 'ip') {
                searchByIp(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);

            } else if (searchedval == 'username') {
                searchByUsername(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);

            } else if (searchedval == 'serial') {

                searchBySerial(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            } else if (searchedval == 'mac') {
                searchByMac(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            }
        } else {

            var clientId = $(this).parent().find("input[name='selectedClientId']").val();
            if (searchedval == 'clients' && clientId != "") {
                var page = 1;
                var firstName = th.find("input[name='firstName']").val();
                var surName = th.find("input[name='surName']").val();
                var address = th.find("input[name='address']").val();
                var email = th.find("input[name='email']").val();
                getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, sortedVal);
            } else {
                searchByIp("", devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            }

        }


    });

    $(document).on('click', '#dev_arrow', function () {
        $checked_array = [];
        $(".subClients").empty();
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        var th = $('#forSearchingDev').find("input[name='clientInfo']");
        var clientInfo = th.val().trim();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        $("body").css("cursor", "wait");
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();

        if (deviceScrollPage == 2) {
            var devCount = 10;
        } else {
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var sortedVal = $(".sortDevs option:selected").val();

        var searchedval = $('.searchType option:selected').val();
        var sortBy = $(".sort_device_by").attr("id");
        if (sortBy == "DESC") {
            $(".sort_device_by").attr("id", "ASC");
            $(".sort_device_by").attr("src", $basepath + "assets/images/down_arrow_34.png");
            $(".sort_device_by").attr("title", getMessage("by_desc"));
        } else {
            $(".sort_device_by").attr("id", "DESC");
            $(".sort_device_by").attr("src", $basepath + "assets/images/up_arrow_34.png");
            $(".sort_device_by").attr("title", getMessage("by_asc"));
        }
        sortedVal = sortedVal + ":" + sortBy;
        //      $('.search_actionbtn').html($searchedvalrus + '<i class="fa fa-angle-down angledown"></i>');

       // alert(clientInfo);
        if (clientInfo != "") {

            if (searchedval == 'clients') {
                var clientId = $(this).parent().find("input[name='selectedClientId']").val();
                var page = 1;
               // alert(clientId);

                var firstName = th.find("input[name='firstName']").val();
                var surName = th.find("input[name='surName']").val();
                var address = th.find("input[name='address']").val();
                var email = th.find("input[name='email']").val();
                getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, sortedVal);

            } else if (searchedval == 'ip') {
                searchByIp(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);

            } else if (searchedval == 'username') {
                searchByUsername(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);

            } else if (searchedval == 'serial') {

                searchBySerial(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            } else if (searchedval == 'mac') {
                searchByMac(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            }
        } else {

            var clientId = $(".sortDevs").parent().find("input[name='selectedClientId']").val();

            if (searchedval == 'clients' && clientId != "") {
                var page = 1;
                var firstName = th.find("input[name='firstName']").val();
                var surName = th.find("input[name='surName']").val();
                var address = th.find("input[name='address']").val();
                var email = th.find("input[name='email']").val();
                getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, sortedVal);
            } else {
                searchByIp("", devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal);
            }

        }
    });

    function searchByUsername(clientInfo, devCount, modelID, groupID, fwVersion, searchByUsername, sortedval) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchDeviceByUsername.php",
            data: {
                'username': clientInfo,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedval,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(result);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByClient(page, clientInfo) {
        var devCount = $('.pagelimit').find('.active').data('row');
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        var sortedVal = '';

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClientFromDevices.php",
            data: {
                'page': page,
                'clientInfo': clientInfo,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(result);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                }

                // if (result == 'logged_out') {
                //     document.location.href = $basepath + 'login';
                // } else {
                //     $(".subClients").empty();
                //     $(".subClients").html(result);
                //     $("#deviceTable").empty();
                //     $(".sort-devices").hide();
                //     $("body").css("cursor", "default");
                // }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $("#forSearchingDev").on("keypress", "input[name='clientInfo']", function (e) {
        var key = e.which;
        if (key == 13) { // the enter key code

            var modelID = $(".modelType option:selected").val();
            var groupID = $(".groupType option:selected").val();
            var searchElem = $(".linkForSearchDev");
            var clientInfoVal = $('#forSearchingDev').find("input[name='clientInfo']").val().trim();
            var fwVersion = $(".changeFirmwareFilter option:selected").val();
            var deviceScrollPage = $(".deviceScrollPage option:selected").val();
            if (deviceScrollPage == 2) {
                var devCount = 10;
            } else {
                var devCount = $('.pagelimit').find('.active').data('row');
            }
            if (searchElem.attr("id") == 'searchDeviByClient') {

                var page = 1;
                searchByClient(page, clientInfoVal);

            } else if (searchElem.attr("id") == 'searchDevByIp') {

                searchByIp(clientInfoVal, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");

            } else if (searchElem.attr("id") == 'searchDevByMac') {

                searchByMac(clientInfoVal, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");

            } else if (searchElem.attr("id") == 'searchDevByUsername') {
                searchByUsername(clientInfoVal, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");

            } else if (searchElem.attr("id") == 'searchDevBySerial') {
                searchBySerial(clientInfoVal, devCount, modelID, groupID, fwVersion, deviceScrollPage, "");
            }
            setDefaultSortVals($(".sortDevs"));
            return false;
        }
    });

    function searchByIp(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchDeviceByIp.php",
            data: {
                'ip': clientInfo,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(result);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchBySerial(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchDevicesBySerial.php",
            data: {
                'serialNumber': clientInfo,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(result);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByMac(clientInfo, devCount, modelID, groupID, fwVersion, deviceScrollPage, sortedval) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchDevicesByMac.php",
            data: {
                'serialNumber': clientInfo,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedval,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(result);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }


//   -------------- Group tasks --------------

    $('#group_pop').popover({
        html: true,
        content: function () {
            return $('#group_popover').html();
        }

    });

    $('#group_pop').popover().on('hide.bs.popover', function () {

        $('.btnapply').css('display', 'none');
        $(".GroupTaskPasswd").css('display', 'none');
        $('.interval-second').css('display', 'none');
        $(".divForLater").hide();
    });


    $('#group_pop').popover().on('shown.bs.popover', function () {
        var language = '';
        var KalendarLang = $("input[name='KalendarLanguage']").val();
        if (KalendarLang == 'ru') {
            language = 'de';
        } else {
            language = 'en';
        }

        function logEvent(type, date) {
            $("<div class='log__entry'/>").hide().html("<strong>" + type + "</strong>: " + date).prependTo($('#eventlog')).show(200);
        }

        $('#clearlog').click(function () {
            $('#eventlog').html('');
        });
        $('#demo1-1').datetimepicker({
            language: language,
            //date: new Date(),
            viewMode: 'YMDHMS',
            onDisplayUpdate: function () {
                logEvent('onDisplayUpdate', this.getDisplayDate());
            },
            //date selection event
            onDateChange: function () {
                logEvent('onDateChange', this.getValue());

                $('#datetimepicker_mask').val(this.getText('yyyy-MM-dd HH:mm:ss'));
                $('#date-text-ymd1-1').text(this.getText('yyyy-MM-dd'));
                $('#date-value1-1').text(this.getValue());
            },
            //clear button click event
            onClear: function () {
                logEvent('onClear', this.getValue());
            },
            //ok button click event
            onOk: function () {
                logEvent('onOk', this.getValue());
            },
            //close button click event
            onClose: function () {
                logEvent('onClose', this.getValue());
            },
            //today button click event
            onToday: function () {
                logEvent('onToday', this.getValue());
            },
        });
    });

    $(document).on('click', '.tasktime', function () {
        $("#demo1-1").removeClass("for_all_display_none");
    });

    $(document).on('click', '.ok', function () {
        $("#demo1-1").addClass("for_all_display_none");
    });

    $(document).on('change', '.changeGroupingTime', function () {
        var changeTime = $(".changeGroupingTime option:selected").val();
        if (changeTime == 'later') {
            $(document).on('click', '.ok', function () {
                $("#demo1-1").addClass("for_all_display_none");
            });
            $('.divForLater').show();
        } else if (changeTime == 'now') {
            $('.divForLater').hide();
            $("#demo1-1").addClass("for_all_display_none");
        }
    });

    $(document).on('change', '.changeGroupingAction', function () {
        var action = $(this).val();
        var exists = $('.changeGroupingModel option').filter(function () {
            return $(this).val() == 'all';
        }).length;
        if ($(this).val() == 'group_task_passwd') {
            $('.GroupTaskPasswd').show();
        }
        else {$('.GroupTaskPasswd').hide();
        }
        if (action == 'informTime' || action == 'reboot' || action == 'reset' || action == 'refresh' || action == 'group_task_passwd') {
            if (!exists) {
                var allValue = getMssg['all'];

                $('<option value="all">' + allValue + '</option>').insertAfter(".changeGroupingModel option:first");

            }
            $(".taskByGroup option[value='0']").prop('selected', true);
            getModelsByGroup('0');
            $(".changeGroupingModel option[value='all']").prop('selected', true);
        } else {
            if (exists) {
                $(".changeGroupingModel option[value='all']").remove();
            }
            $(".taskByGroup option[value='0']").prop('selected', true);
            getModelsByGroup('0');
        }
        if (action != 0) {
            $("body").css("cursor", "wait");
            var model = $(".changeGroupingModel option:selected").val();
            // alert(model)
            if (model != 0) {
                GrouptasksRequests(action, model);

            } else {
                $("body").css("cursor", "default");
                $('.interval-second').css('display', 'none');
            }
        } else {
            $("#contentFirmware").html("");
            $("#contentGrouping").html("");
            $('.btnapply').css('display', 'none');
            $('.interval-second').css('display', 'none');
        }
        $("#resDev").empty();
    });

    $(document).on('change', '.changeGroupingModel', function () {

        var model = $(".changeGroupingModel option:selected").val();
        if (model != 0) {

            $("body").css("cursor", "wait");
            var action = $(".changeGroupingAction option:selected").val();
            if (action != 0) {

                GrouptasksRequests(action, model);
                $(".changeFirmware option[value='0']").prop('selected', true);
            } else {
                $("#resDev").empty();
                $("body").css("cursor", "default");
            }
        } else {
            $("#resDev").empty();
            $("#contentFirmware").html("");
            $("#contentGrouping").html("");
            $('.btnapply').css('display', 'none');
            $('.interval-second').css('display', 'none');
        }
    });

    $(document).on('change', '.changeFirmware', function () {
        $("#resDev").empty();
    });

    $(document).on('change', '.taskByGroup', function () {
        var th = $(this);
        var groupId = th.val();
        $("#resDev").empty();
        $('.btnapply').css('display', 'none');
        if (groupId != -1) {
            getModelsByGroup(groupId);
        } else {
            $('.changeGroupingModel :not(:first-child)').remove();
        }
    });

    function getModelsByGroup(groupId) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllModelsByGroup.php",
            data: {
                'groupId': groupId,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#contentGrouping").empty();
                    $("#contentFirmware").empty();
                    var action = $(".changeGroupingAction option:selected").val();
                    if (action == 'informTime' || action == 'reboot' || action == 'reset' || action == 'refresh' || action == 'group_task_passwd') {
                        $('.changeGroupingModel :not(:first-child)').remove();
                        var allValue = getMssg['all'];

                        $('<option value="all">' + allValue + '</option>').insertAfter(".changeGroupingModel option:first");
                        $('.changeGroupingModel').append(data);
                    } else {
                        $('.changeGroupingModel :not(:first-child)').remove();
                        $('.changeGroupingModel').append(data);
                    }

                    if (data == '') {
                        $('.changeGroupingModel :not(:first-child)').remove();
                        var msg = getMssg["no_device_inGroup"];
                        $("#contentGrouping").empty();
                        $("#contentFirmware").empty();
                        $("#contentGrouping").html(msg);
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function GrouptasksRequests(action, model) {
        $("#contentFirmware").html("");
        if (action == 'updateConfig') {
            $('.btnapply').css('display', 'none');
            $('.interval-second').css('display', 'none');
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getConfigsByModel.php",
                data: {
                    'modelID': model,
                    'fromApp': true
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("#contentGrouping").html("");
                        $("#contentGrouping").html(data);
                        $("body").css("cursor", "default");
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if (action == 'upgradeDevice') {
            $('.btnapply').css('display', 'none');
            $('.interval-second').css('display', 'none');
            var groupId = $(".taskByGroup option:selected").val();
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getFWsByModel.php",
                data: {
                    'getFirmware': true,
                    'modelID': model,
                    'groupId': groupId,
                    'fromApp': true
                },
                async: false,
                success: function (data) {
                    if (data == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("#contentGrouping").html("");
                        $("#contentGrouping").html(data);
                        $("body").css("cursor", "default");
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });

            getFirmwareByModel(model, groupId);

        } else if (action == 'informTime' || action == 'reboot' || action == 'reset' || action == 'refresh' || action == 'group_task_passwd') {
            var groupId = $(".taskByGroup option:selected").val();
            $('.btnapply').css('display', 'block');
            $hiddeninput = "<input type='hidden' name='modID' value='" + model + "' /> ";
            $('.interval-second').append($hiddeninput);
            $("#contentGrouping").html("");
            $("body").css("cursor", "default");
            if (model != 'all') {
                getFirmwareByModel(model, groupId);
            }
            if (action == 'informTime') {
                $('.interval-second').css('display', 'block');
                $('.action_apply').attr('id', 'groupInfTime');
            } else if (action == 'reboot') {
                $('.interval-second').css('display', 'none');
                $('.action_apply').attr('id', 'rebootGroupDev');
            } else if (action == 'reset') {
                $('.interval-second').css('display', 'none');
                $('.action_apply').attr('id', 'resetGroupDev');
            } else if (action == 'refresh') {
                $('.interval-second').css('display', 'none');
                $('.action_apply').attr('id', 'refreshGroupDev');
            } else if (action = 'group_task_passwd') {
                $('.interval-second').css('display', 'none');
                $('.action_apply').attr('id', 'setGroupTaskPass');

            }
        }
//        }else if (action == 'reboot') {
//            $('.interval-second').css('display','none');
//            $('.btnapply').css('display','block');
//            $('.action_apply').attr('id', 'rebootGroupDev');
//            $hiddeninput = "<input type='hidden' name='modID' value='" + model + "' /> ";
//            $("#contentGrouping").html("");
//            $('.btnapply').append($hiddeninput);
//            $("body").css("cursor", "default");
//            getFirmwareByModel(model);
//
//        } else if (action == 'reset') {
//            $('.interval-second').css('display','none');
//            $('.btnapply').css('display','block');
//            $('.action_apply').attr('id', 'resetGroupDev');
//            $hiddeninput = "<input type='hidden' name='modID' value='" + model + "' /> ";
//            $("#contentGrouping").html("");
//            $('.btnapply').append($hiddeninput);
//            $("body").css("cursor", "default");
//            getFirmwareByModel(model);
//
//        } else if (action == 'refresh') {
//            $('.interval-second').css('display','none');
//            $('.btnapply').css('display','block');
//            $('.action_apply').attr('id', 'refreshGroupDev');
//            $hiddeninput = "<input type='hidden' name='modID' value='" + model + "' /> ";
//            $("#contentGrouping").html("");
//            $('.btnapply').append($hiddeninput);
//            $("body").css("cursor", "default");
//            getFirmwareByModel(model);
//        }
    }

    function getFirmwareByModel(model, groupId) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getFWsByModel.php",
            data: {
                'getFirmware': false,
                'modelID': model,
                'groupId': groupId,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#contentFirmware").html("");
                    $("#contentFirmware").html(data);
                    $("body").css("cursor", "default");
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function validateDateTime() {
        var msgRequired = getMssg['error_message_required'];
        var msgDateTime = getMssg['date_time_format'];
        var msgExpiredDate = getMssg['expired_date'];
        var msgValidDay = getMssg['valid_day'];

        $("#dateTimeForm").validate({
            rules: {
                taskname: {
                    required: true
                },
                tasktime: {
                    required: true,
                    validateDateTime: true,
                    dateTimeLength: true,
                    invalidDate: true
                }
            },

            messages: {
                taskname: {
                    required: msgRequired
                },
                tasktime: {
                    required: msgRequired,
                    validateDateTime: msgDateTime,
                    dateTimeLength: msgExpiredDate,
                    invalidDate: msgValidDay
                }
            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });
        if (!($("#dateTimeForm").valid())) {
            return false;
        } else {
            return true;
        }
    }

    $(document).on('click', '.updateConfigGroup', function () {
        var status = true;
        var th = $(this);
        var fileId = $(".groupFilesName option:selected").val();
        var token = getTreeCookie("token");
        if (fileId == 0) {
            var noFileSelected = getMssg['select_device'];
            $("#resDev").empty();
            $("#resDev").html(noFileSelected);
        } else {
            var taskName = $('.taskname').val();
            var taskTime = $('.tasktime').val();
            var groupId = $(".taskByGroup option:selected").val();
            var model = $(".changeGroupingModel option:selected").val();
            if (model != 0) {
                status = validateDateTime();
                if (status) {
                    if ($('.divForLater').is(':visible')) {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                            data: {
                                'taskName': taskName,
                                'taskTime': taskTime,
                                'fileID': fileId,
                                'modelID': model,
                                'groupId': groupId,
                                'actionName': 'groupConfig',
                                'token': token,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'true') {
                                    th.attr("disabled", "disabled");
                                    th.css("opacity", "0.5");
                                    th.css("cursor", "default");
                                    var success = getMssg['action_succeed'];
                                    $("#resMsgForDev").empty();
                                    $(".subClients").empty();
                                    $("#resMsgForDev").html(success);
                                    setTimeout(function () {
                                        $("body").css("cursor", "default");
                                        $("#resMsgForDev").empty();
                                        th.removeAttr("disabled");
                                        th.css("opacity", "1");
                                        th.css("cursor", "pointer");
                                        location.reload(true);
                                    }, 10000);
                                } else if (result == 'false') {
                                    var failed = getMssg['action_failed'];
                                    $("#resMsgForDev").empty();
                                    $(".subClients").empty();
                                    $("#resMsgForDev").html(failed);

                                    setTimeout(function () {
                                        $("body").css("cursor", "default");
                                        $("#resMsgForDev").empty();
                                        location.reload(true);
                                    }, 10000);

                                } else if (result = 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    } else {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                            data: {
                                'fileID': fileId,
                                'modelID': model,
                                'groupId': groupId,
                                'actionName': 'groupConfig',
                                'token': token,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'true') {
                                    th.attr("disabled", "disabled");
                                    th.css("opacity", "0.5");
                                    th.css("cursor", "default");
                                    var success = getMssg['action_succeed'];
                                    $("#resMsgForDev").empty();
                                    $(".subClients").empty();
                                    $("#resMsgForDev").html(success);
                                    setTimeout(function () {
                                        $("body").css("cursor", "default");
                                        $("#resMsgForDev").empty();
                                        th.removeAttr("disabled");
                                        th.css("opacity", "1");
                                        th.css("cursor", "pointer");
                                        location.reload(true);
                                    }, 10000);
                                } else if (result == 'false') {
                                    var failed = getMssg['action_failed'];
                                    $("#resMsgForDev").empty();
                                    $(".subClients").empty();
                                    $("#resMsgForDev").html(failed);

                                    setTimeout(function () {
                                        $("body").css("cursor", "default");
                                        $("#resMsgForDev").empty();
                                        location.reload(true);
                                    }, 10000);

                                } else if (result = 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                    }
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '.updateFWGroup', function () {
        var status = true;
        var th = $(this);
        var fileId = $(".groupFilesName option:selected").val();
        var token = getTreeCookie("token");
        if (fileId == 0) {
            var noFileSelected = getMssg['select_device'];

            swal({
                title: '',
                text: noFileSelected
            });
        } else {

            var taskName = $('.taskname').val();
            var taskTime = $('.tasktime').val();
            var model = $(".changeGroupingModel option:selected").val();
            var fwVersion = $(".changeFirmware option:selected").val();
            var groupId = $(".taskByGroup option:selected").val();
            if (model != 0) {
                if (fwVersion != "-1") {
                    status = validateDateTime();
                    if (status) {
                        if ($('.divForLater').is(':visible')) {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'taskName': taskName,
                                    'taskTime': taskTime,
                                    'fileID': fileId,
                                    'modelID': model,
                                    'fwVersion': fwVersion,
                                    'groupId': groupId,
                                    'token': token,
                                    'actionName': 'groupFW',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);
                                        setTimeout(function () {
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        var failed = getMssg['action_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'fileID': fileId,
                                    'modelID': model,
                                    'fwVersion': fwVersion,
                                    'groupId': groupId,
                                    'token': token,
                                    'actionName': 'groupFW',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);
                                        setTimeout(function () {
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        var failed = getMssg['action_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_fw_version'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '#rebootGroupDev', function () {
        var status = true;
        var th = $(this);
        if (th.attr("disabled") != 'disabled') {
            // var model = $(".btnapply").find("input[name='modID']").val();
            var taskName = $('.taskname').val();
            var taskTime = $('.tasktime').val();
            var model = $(".changeGroupingModel option:selected").val();
            var groupId = $(".taskByGroup option:selected").val();
            var fwVersion = $(".changeFirmware option:selected").val();
            if (typeof fwVersion == 'undefined') {
                fwVersion = '0';
            }
            if (model != 0) {
                if (fwVersion != "-1") {
                    status = validateDateTime();
                    if (status) {
                        if ($('.divForLater').is(':visible')) {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'taskName': taskName,
                                    'taskTime': taskTime,
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupReboot',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupReboot',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_fw_version'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '#resetGroupDev', function () {
        var status = true;
        var th = $(this);
        if (th.attr("disabled") != 'disabled') {
//            var model = $(".btnapply").find("input[name='modID']").val();
            var taskName = $('.taskname').val();
            var taskTime = $('.tasktime').val();
            var model = $(".changeGroupingModel option:selected").val();
            var groupId = $(".taskByGroup option:selected").val();
            var fwVersion = $(".changeFirmware option:selected").val();
            if (typeof fwVersion == 'undefined') {
                fwVersion = '0';
            }
            if (model != 0) {
                if (fwVersion != "-1") {
                    status = validateDateTime();
                    if (status) {
                        if ($('.divForLater').is(':visible')) {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'taskName': taskName,
                                    'taskTime': taskTime,
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupReset',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupReset',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_fw_version'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '#refreshGroupDev', function () {
        var status = true;
        var th = $(this);
        if (th.attr("disabled") != 'disabled') {
//            var model = $(".btnapply").find("input[name='modID']").val();
            var taskName = $('.taskname').val();
            var taskTime = $('.tasktime').val();
            var model = $(".changeGroupingModel option:selected").val();
            var groupId = $(".taskByGroup option:selected").val();
            var fwVersion = $(".changeFirmware option:selected").val();
            if (typeof fwVersion == 'undefined') {
                fwVersion = '0';
            }
            if (model != 0) {
                if (fwVersion != "-1") {
                    status = validateDateTime();
                    if (status) {
                        if ($('.divForLater').is(':visible')) {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'taskName': taskName,
                                    'taskTime': taskTime,
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupRefresh',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'modelID': model,
                                    'groupId': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'groupRefresh',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_fw_version'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '#setGroupTaskPass', function () {
        var status = true;
        var th = $(this);
        // th.attr("disabled","disabled");
        var password = $('#newPasswordInGroupTask').val();
        if(password == ""){
            $( "#error_mssg" ).append( "<p class='errorMsg'>This field is required</p>" );
        } else {
            $("#error_mssg").empty();
        }
        var taskName = $('.taskname').val();
        var taskTime = $('.tasktime').val();
        var model = $(".changeGroupingModel option:selected").val();
        var groupId = $(".taskByGroup option:selected").val();
        var fwVersion = $(".changeFirmware option:selected").val();
        if (typeof fwVersion == 'undefined') {
            fwVersion = '0';
        }
        if (password != '') {
            if (model != 0) {
                if (fwVersion != "-1") {
                    status = validateDateTime();
                    if (status) {
                        if ($('.divForLater').is(':visible')) {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'password': password,
                                    'taskName': taskName,
                                    'taskTime': taskTime,
                                    'modelID': model,
                                    'groupID': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'setPasswordGroupTask',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        } else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                data: {
                                    'password': password,
                                    'modelID': model,
                                    'groupID': groupId,
                                    'fwVersion': fwVersion,
                                    'actionName': 'setPasswordGroupTask',
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'true') {
                                        th.attr("disabled", "disabled");
                                        th.css("opacity", "0.5");
                                        th.css("cursor", "default");
                                        var success = getMssg['action_succeed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(success);

                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            th.removeAttr("disabled");
                                            th.css("opacity", "1");
                                            th.css("cursor", "pointer");
                                            location.reload(true);
                                        }, 10000);
                                    } else if (result == 'false') {
                                        $("body").css("cursor", "default");
                                        var failed = getMssg['connect_failed'];
                                        $("#resMsgForDev").empty();
                                        $(".subClients").empty();
                                        $("#resMsgForDev").html(failed);
                                        setTimeout(function () {
                                            $("body").css("cursor", "default");
                                            $("#resMsgForDev").empty();
                                            location.reload(true);
                                        }, 10000)
                                    } else if (result = 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_fw_version'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            } else {
                var noFileSelected = getMssg['pls_select_model'];
                $("#resDev").empty();
                $("#resDev").html(noFileSelected);
            }
        }
    });

    $(document).on('click', '#groupInfTime', function () {
        var status = true;
        var th = $(this);
        var groupID = $(".taskByGroup option:selected").val();
//        var deviceID = $(this).parent().parent().find("input[name='infTime']").val();
        var time = document.getElementsByName('infTime')[0].value;
        if (time.trim() != '') {
            if (th.attr("disabled") != 'disabled') {
                var taskName = $('.taskname').val();
                var taskTime = $('.tasktime').val();
                var model = $(".changeGroupingModel option:selected").val();
                var fwVersion = $(".changeFirmware option:selected").val();
                if (typeof fwVersion == 'undefined') {
                    fwVersion = '0';
                }
                if (model != 0) {
                    if (fwVersion != "-1") {
                        status = validateDateTime();
                        if (status) {
                            if ($('.divForLater').is(':visible')) {
                                $.ajax({
                                    type: "POST",
                                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                    data: {
                                        'taskName': taskName,
                                        'taskTime': taskTime,
                                        'informTime': time,
                                        'modelID': model,
                                        'groupID': groupID,
                                        'fwVersion': fwVersion,
                                        'actionName': 'groupInfTime',
                                        'fromApp': true
                                    },
                                    async: false,
                                    success: function (result) {
                                        if (result == 'true') {
                                            th.attr("disabled", "disabled");
                                            th.css("opacity", "0.5");
                                            th.css("cursor", "default");
                                            var success = getMssg['action_succeed'];
                                            $("#resMsgForDev").empty();
                                            $(".subClients").empty();
                                            $("#resDev").empty();
                                            $("#resMsgForDev").html(success);

                                            setTimeout(function () {
                                                $("#resMsgForDev").empty();
                                                th.removeAttr("disabled");
                                                th.css("opacity", "1");
                                                th.css("cursor", "pointer");
                                                location.reload(true);
                                            }, 10000);
                                        } else if (result == 'false') {
                                            var failed = getMssg['connect_failed'];
                                            $("#resMsgForDev").empty();
                                            $(".subClients").empty();
                                            $("#resDev").empty();
                                            $("#resMsgForDev").html(failed);
                                            setTimeout(function () {
                                                $("body").css("cursor", "default");
                                                $("#resMsgForDev").empty();
                                                location.reload(true);
                                            }, 10000)
                                        } else if (result = 'logged_out') {
                                            document.location.href = $basepath + 'login';
                                        }
                                    },
                                    error: function (xhr, status, error) {
                                        document.location.href = $basepath + '500';
                                    }
                                });
                            } else {
                                $.ajax({
                                    type: "POST",
                                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                                    data: {
                                        'informTime': time,
                                        'modelID': model,
                                        'groupID': groupID,
                                        'fwVersion': fwVersion,
                                        'actionName': 'groupInfTime',
                                        'fromApp': true
                                    },
                                    async: false,
                                    success: function (result) {
                                        if (result == 'true') {
                                            th.attr("disabled", "disabled");
                                            th.css("opacity", "0.5");
                                            th.css("cursor", "default");
                                            var success = getMssg['action_succeed'];
                                            $("#resMsgForDev").empty();
                                            $(".subClients").empty();
                                            $("#resDev").empty();
                                            $("#resMsgForDev").html(success);

                                            setTimeout(function () {
                                                $("#resMsgForDev").empty();
                                                th.removeAttr("disabled");
                                                th.css("opacity", "1");
                                                th.css("cursor", "pointer");
                                                location.reload(true);
                                            }, 10000);
                                        } else if (result == 'false') {
                                            var failed = getMssg['connect_failed'];
                                            $("#resMsgForDev").empty();
                                            $(".subClients").empty();
                                            $("#resDev").empty();
                                            $("#resMsgForDev").html(failed);
                                            setTimeout(function () {
                                                $("body").css("cursor", "default");
                                                $("#resMsgForDev").empty();
                                                location.reload(true);
                                            }, 10000)
                                        } else if (result = 'logged_out') {
                                            document.location.href = $basepath + 'login';
                                        }
                                    },
                                    error: function (xhr, status, error) {
                                        document.location.href = $basepath + '500';
                                    }
                                });
                            }
                        }
                    } else {
                        var noFileSelected = getMssg['pls_select_fw_version'];
                        $("#resDev").empty();
                        $("#resDev").html(noFileSelected);
                    }
                } else {
                    var noFileSelected = getMssg['pls_select_model'];
                    $("#resDev").empty();
                    $("#resDev").html(noFileSelected);
                }
            }
        } else {
            var failed = getMssg['interval_empty'];
            $("#resDev").removeClass("infoMessage");
            $("#resDev").addClass("errorMessage");
            $("#resDev").empty();
            $("#resDev").html(failed);
        }
    });
    $(document).on("keypress", "input[name='infTime']", function (e) {
        var chrTyped = 0;
        var chrCode = 0;
        var evt = e ? e : event;

        if (evt.charCode != null)
            chrCode = evt.charCode;
        else if (evt.which != null)
            chrCode = evt.which;
        else if (evt.keyCode != null)
            chrCode = evt.keyCode;
        if (chrCode == 0) chrTyped = 'SPECIAL KEY';
        else chrTyped = String.fromCharCode(chrCode);
        //[test only:] display chrTyped on the status bar
        self.status = 'inputDigitsOnly: chrTyped = ' + chrTyped;

        //Digits, special keys & backspace [\b] work as usual:
        if (chrTyped.match(/\d|[\b]|SPECIAL/)) return true;
        if (evt.altKey || evt.ctrlKey || chrCode < 28) return true;

        //Any other input? Prevent the default response:
        if (evt.preventDefault)
            evt.preventDefault();
        evt.returnValue = false;
        return false;
    });

//  ------------------- Upload button -----------------------

    $('#Upload').popover({
        html: true,
        content: function () {
            return $('#upload-popover').html();
        }
    });

    $('#Upload').popover().on('hide.bs.popover', function () {
        $('.versionDiv').css('display', 'none');
        $('.tarifDiv').css('display', 'none');
        $('.descDiv').css('display', 'none');
    });

    $checked_array_ = new Array();

    $('#Upload').popover().on('shown.bs.popover', function () {
        $('.devField').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });

        // $('.popover-content .userFields').on('ifChecked ifUnchecked', function(event){
        //     $name = $(this).attr('id');
        //     if (event.type == 'ifChecked') {
        //         if(!$(this).hasClass('allField')){
        //             $checked_array.push($name);
        //         }
        //     } else {
        //         $checked_array.removeByVal($name);
        //     }
        // });

    });

    $(document).on('change', '#uploadBtn', function () {
        $("#uploadFile-error").hide();
        $("#uploadFile").val($(this).val());
    });

    $(document).on('change', '#uploadDevInform', function () {
        $("#importFile").val($(this).val());
    });

    $(document).on('click', '.resetUploadDevInfo', function () {
        $('#changeDevInform').trigger('reset');
    });

    $(document).on('change', '.changeUploadType', function () {
        var uploadType = $(".changeUploadType option:selected").val();
        var msgRequird = getMssg['error_message_required'];
        var msgVersionLength = getMssg['error_message_version_length'];
        if (uploadType == "uploadConfig" || uploadType == "") {
            $('.versionDiv').css('display', 'none');
            $('.tarifDiv').css('display', 'none');
            $('.descDiv').css('display', 'none');
        } else if (uploadType == 'uploadFW') {
            $('.versionDiv').css('display', 'block');
            $('.tarifDiv').css('display', 'none');
            $('.descDiv').css('display', 'none');
//            $("input[name='version']").rules('add', {
//		    required: true,
//		    validateVersionLength: true,
//                messages: {
//		    required: msgRequird,
//		    validateVersionLength:  msgVersionLength
//                }
//            });
        } else if (uploadType == 'uploadTarif') {
            $('.versionDiv').css('display', 'none');
            $('.tarifDiv').css('display', 'block');
            $('.descDiv').css('display', 'block');
//            $("input[name='tarifName']").rules('add', {
//		    required: true,
//                messages: {
//		    required: msgRequird
//                }
//            });
        } else if (uploadType == 'uploadDescription') {
            $('.versionDiv').css('display', 'block');
            $('.tarifDiv').css('display', 'block');
            $('.descDiv').css('display', 'none');
//            $("input[name='version']").rules('add', {
//		    required: true,
//		    validateVersionLength: true,
//                messages: {
//		    required: msgRequird,
//		    validateVersionLength:  msgVersionLength
//                }
//            });
            $("input[name='tarifName']").rules('add', {
                required: true,
                messages: {
                    required: msgRequird
                }
            });
        }
        $("div.error_msg").remove();
        $(".error_msg").removeClass("error");
    });

    function OnProgress(event, position, total, percentComplete) {
        //Progress bar
        $('#progressbox').width(percentComplete + '%'); //update progressbar percent complete
        $('#statustxt').html(percentComplete + '%'); //update status text
        if (percentComplete > 50) {
            $('#statustxt').css('color', '#fff'); //change status text to white after 50%
        }
    }

    var options = {
        type: 'POST',
        target: '#resMsgForDev',
        data: {fromApp: 'true'},   // target element(s) to be updated with server response
        beforeSubmit: beforeSubmit,  // pre-submit callback
        uploadProgress: OnProgress,
//        success: afterSuccess,  // post-submit callback
        resetForm: false     // reset the form after successful submit
    };

    var options1 = {
        type: 'POST',
        data: {fromApp: 'true'},   // target element(s) to be updated with server response
        resetForm: false,     // reset the form after successful submit
        success: function (result) {
            if (result == '-1') {
                var msgCreateDyrectori = getMssg['cannot_create_dir'];
                $("#msgUploadFile").empty();
                $("#msgUploadFile").removeClass("mainColor");
                $("#msgUploadFile").addClass("errorMessage");
                $("#msgUploadFile").html(msgCreateDyrectori);
                return false;
            } else {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'actionName': "UploadCSV",
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                            var success = getMssg['upload_success'];
                            $("#msgUploadFile").empty();
                            $("#msgUploadFile").removeClass("errorMessage");
                            $("#msgUploadFile").addClass("mainColor");
                            $("#msgUploadFile").html(success);
                            $('#changeDevInform').trigger('reset');
                            setTimeout(function () {
                                location.reload(true);
                            }, 1000);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }
    };


    function beforeSubmit() {
        //check whether browser fully supports all File API
        if (window.File && window.FileReader && window.FileList && window.Blob) {
            //Progress bar
            $('#progressbox').show(); //show progressbar
            $('#progressbar').width('0%'); //initial value 0% of progressbar
            $('#statustxt').html('0%'); //set status text
            $('#statustxt').css('color', '#fff'); //initial color of status text

//        $('.uploadForGroup').hide(); //hide submit button
            $("#resMsgForDev").html("");

        } else {
            //Output error to older unsupported browsers that doesn't support HTML5 File API
            $("#resMsgForDev").html("Please upgrade your browser, because your current browser lacks some new features we need!");
            return false;
        }
    }

    $(document).on("submit", "#changeDevInform", function () {

        var msgRequird = getMssg['error_message_required'];
        var msgUploadFile = getMssg['uploaded_file_type'];

        $('#changeDevInform').validate({
            rules: {
                uploaded_file: {
                    required: true,
                    // validateDevInfoUploadFileType: {
                    //     uploadRealFile: "#uploadDevInform"
                    // }
                }
            },
            messages: {
                uploaded_file: {
                    required: msgRequird,
                    // validateDevInfoUploadFileType: msgUploadFile
                }
            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function (error, element) {
                $("#msgUploadFile").empty();
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter("#msgUploadFile");
                }
            }
        });

        if (!$("#changeDevInform").valid()) {
            $('body').css("cursor", "default");
            return false;
        }
        var filename = $('#uploadDevInform').val().replace(/C:\\fakepath\\/i, '');
        var extension = filename.replace(/^.*\./, '');
        if (extension != "xlsx" && extension != "csv") {
            $("#msgUploadFile").empty();
            $("#msgUploadFile").removeClass("mainColor");
            $("#msgUploadFile").addClass("errorMessage");
            $("#msgUploadFile").html(msgUploadFile);
            return false;
        } else {
            $(this).ajaxSubmit(options1);


        }

    });


    $(document).on("submit", "#MyUploadForm", function () {
        var uploadType = $(".changeUploadType option:selected").val();
        var fileName = $("#uploadFile").val().replace(/.*(\/|\\)/, '');
        var type_error = getMssg["file_type_error"];
        var msgRequird = getMssg['error_message_required'];
        var msgUploadedFileType = getMssg['uploaded_file_type'];
        var msgVersionLength = getMssg['error_message_version_length'];

        $('#MyUploadForm').validate({
            rules: {
                uploadType: {
                    required: true
                },
                model: {
                    required: true
                },
                uploadFile: {
                    required: true,
                    validateFirmwareFileType: {
                        uploadType: "#uploadType",
                        uploadRealFile: "#uploadBtn"
                    }
                },
                newModel: {
                    required: true
                },
                hwVersion: {
                    required: true
                },
                version: {
                    required: true,
                    validateVersionLength: true,
                },
                tarifName: {
                    required: true,
                }
            },
            messages: {
                uploadType: {
                    required: msgRequird
                },
                model: {
                    required: msgRequird
                },
                uploadFile: {
                    required: msgRequird,
                    validateFirmwareFileType: msgUploadedFileType
                },
                newModel: {
                    required: msgRequird
                },
                hwVersion: {
                    required: msgRequird
                },
                version: {
                    required: msgRequird,
                    validateVersionLength: msgVersionLength,
                },
                tarifName: {
                    required: msgRequird,
                }
            },
            errorElement: "div",
            errorClass: 'error_msg',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        var th = $(this);
        if (!$("#MyUploadForm").valid()) {
            $('body').css("cursor", "default");
            return false;
        }
        var changeTemplate = false;
        if (uploadType == "uploadTarif") {
            var msg = getMssg["teplate_file_exist"];
            var tempName = $("input[name='tarifName']").val();
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkTarifNameExist.php",
                data: {
                    'templateName': tempName,
                    'fileName': fileName,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = 'login';
                    } else {
                        if (result != '') {
                            $("#resMsgForDev").empty();
                            $("#resMsgForDev").html(result);
                            $("#resMsgForDev").addClass("errorMessage");
                            th.addClass("invalidVal");
                        } else {
                            th.removeClass("invalidVal");
                            $("#resMsgForDev").empty();
                            changeTemplate = true;
                        }
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });

        } else {
            $('#forExtensionError').empty();
            $(this).ajaxSubmit(options);
            var stopInterval = false;
            var reloadInterval = function(){
                if (stopInterval){
                    clearInterval(stopReloadInterval)
                    location.reload(true);
                }
                if ($('#statustxt').html() == '100%'){
                    stopInterval = true;
                }

            }
            var stopReloadInterval = setInterval(reloadInterval,500)


            // setTimeout(function () {
            //     location.reload(true);
            // }, 30000);
        }
        if (changeTemplate) {
            $('#forExtensionError').empty();
            $(this).ajaxSubmit(options);
            var stopInterval = false;
            var reloadInterval = function(){
                if (stopInterval){
                    clearInterval(stopReloadInterval)
                    location.reload(true);
                }
                if ($('#statustxt').html() == '100%'){
                    stopInterval = true;
                }

            }
            var stopReloadInterval = setInterval(reloadInterval,500)


            // setTimeout(function () {
            //     location.reload(true);
            // }, 30000);
        }
        // return false to prevent standard browser submit and page navigation
        //        return false;
    });

//    $(document).on("change", 'INPUT[type="file"]', function () {
//
//        var ext = this.value.match(/\.(.+)$/)[1];
//        switch (ext) {
//            case 'ini':
//                break;
//            default:
//                alert('This is not an allowed file type.');
//                this.value = '';
//                $('#uploadFile').val('');
//        }
//    });

//   ------------------ Other functions in device page----------------------

//     --------- Remove device ------------

    $("#deviceTable").on("click", ".removeDevice", function () {
        var th = $(this);
        if (th.attr("disabled") != "disabled") {
            th.attr("disabled", "disabled");
            th.css("opacity", "0.5");
            th.css("cursor", "default");
            //if(swal){
            var titleMsg = getMssg['title_msg'];
            var rmMsg = getMssg['remove_msg'];
            var cancelMsg = getMssg['cancel'];
            var msg = getMssg['remove_device_msg'];
            var deviceID = th.parent().parent().find("input[name='devID']").val();
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function (isConfirm) {
                if (isConfirm) {
                    $("body").css("cursor", "wait");
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'deviceId': deviceID,
                            'actionName': "removeDevice",
                            'fromApp': true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'true') {
                                // var success = getMssg['action_succeed'];
                                // $("#resMsgForDev").empty();
                                // $("#resMsgForDev").html(success);
                                setTimeout(function () {
                                    location.reload(true);
                                }, 10000);
                            } else if (result == 'false') {
                                var failed = getMssg['connect_failed'];
                                $("#resMsgForDev").empty();
                                $("#resMsgForDev").html(failed);
                                $("body").css("cursor", "default");
                                setTimeout(function () {
                                    location.reload(true);
                                }, 10000)
                            } else if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    th.removeAttr("disabled");
                    th.css("opacity", "1");
                    th.css("cursor", "pointer");
                }
            });

            //$(this).removeAttr("disabled");
            //$(this).css("opacity","1");
            //$(this).css("cursor","pointer");
        } else {
            th.removeAttr("disabled");
            th.css("opacity", "1");
            th.css("cursor", "pointer");
        }
        //}
    });

//    -------------- Pagination. page number click function in devices table -----------------

    $(document).on("click", ".eachPage", function () {
        $checked_array = new Array();
        $("body").css("cursor", "wait");
        var page = $(this).find("input[name='page']").val();
        var modelID = $(".modelType option:selected").val();
        var devCount = $('.pagelimit').find('.active').data('row');
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        var searchElem = $(".linkForSearchDev");
        var clientInfo = $("#forSearchingDev").find("input[name='clientInfo']");
        var clientInfoVal = $("#forSearchingDev").find("input[name='clientInfo']").val();
        var clientId=0;
        var sortedVal = $(".sortDevs option:selected").val();
        var sortBy=$(".sort_device_by").attr("id");
        var sortBy1;
               if(sortBy=="DESC") {
                   sortBy1='ASC';
                   } else {
                   sortBy1='DESC';
                 }
          sortedVal=sortedVal+":"+sortBy1;
            //   alert(sortedVal);
            //   alert(searchElem.attr("id") );
        if (searchElem.attr("id") == 'searchDeviByClient') {
            if (clientInfo.find("input[name='firstName']").length != 0) {
                var firstN = clientInfo.find("input[name='firstName']").val();
                var surN = clientInfo.find("input[name='surName']").val();
                var address = clientInfo.find("input[name='address']").val();
                var email = clientInfo.find("input[name='email']").val();
            } else {
                var firstN = '';
                var surN = '';
                var address = '';
                var email = '';
            }


            var clientInfo = $("#forSearchingDev").find("input[name='clientInfo']").val();
            // if(clientInfo!=''){
                 clientId=$(".sortDevs").parent().find("input[name='selectedClientId']").val();
            // }





            searchByClientForEachPage(page, modelID, groupID, fwVersion, devCount, firstN, surN, address, email, '',sortedVal,clientId);

        } else if (searchElem.attr("id") == 'searchDevByIp') {
            searchByIpForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, '', sortedVal);

        } else if (searchElem.attr("id") == 'searchDevByMac') {
            searchByMacForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, '', sortedVal);

        } else if (searchElem.attr("id") == 'searchDevByUsername') {
            searchByUsernameForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, '', sortedVal);

        } else if (searchElem.attr("id") == 'searchDevBySerial') {
            searchBySerialForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, '', sortedVal);

        }
    });

//      Find device for each client in table after searching client


    $(".subClients").on("click", ".eachClientForDev", function () {

        $("body").css("cursor", "wait");
        var firstName = $(this).find("input[name='firstName']").val();
        var surName = $(this).find("input[name='surName']").val();
        var address = $(this).find("input[name='address']").val();
        var email = $(this).find("input[name='email']").val();

        var clientId = $(this).find("input[name='clientId']").val();

        var devCount = $('.pagelimit').find('.active').data('row');
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();

        var page = 1;
        getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, "");

    });

// -------------------- Pagination click function -----------------------------

    $(".subClients").on("click", ".eachClientPage", function () {

        var page = $(this).find("input[name='page']").val();

//        var searchElem=$(".linkForSearchDev");
//        var clientInfo = $(".linkForSearchDev").parent().find("input[name='clientInfo']");
//        var clientInfoVal=clientInfo.val();
        var clientInfo = $("#forSearchingDev").find("input[name='clientInfo']").val();

        searchByClient(page, clientInfo);
    });

    function getAllDevicesOfTheClient(page, firstName, surName, address, email, clientId, devCount, modelID, groupID, fwVersion, sortedVal) {
        var clientInfo = firstName + ' ' + surName + ' ' + address + ' ' + email;

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchDeviceByClientInfo.php",
            data: {
                "page": page,
                'clientId': clientId,
                'devCount': devCount,
                'modelID': modelID,
                'groupID': groupID,
                'fwVersion': fwVersion,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var eachInfo = "<input name='firstName' value='" + firstName + "' type='hidden'/>\n\
                                    <input name='surName' value='" + surName + "' type='hidden'/>\n\
                                    <input name='address' value='" + address + "' type='hidden'/>\n\
                                    <input name='email' value='" + email + "' type='hidden'/>";
//                    $("input[name='clientInfo']").val(clientInfo);

                    if ($("input[name='clientInfo']").find("input[name='firstName']").length == 0) {
                        $("input[name='clientInfo']").append(eachInfo);
                    } else {
                        $("input[name='clientInfo']").find("input[name='firstName']").val(firstName);
                        $("input[name='clientInfo']").find("input[name='surName']").val(surName);
                        $("input[name='clientInfo']").find("input[name='address']").val(address);
                        $("input[name='clientInfo']").find("input[name='email']").val(email);
                    }
                    $(".subClients").empty();
                    $("#deviceTable").empty();
                    $("#deviceTable").html(data);
                    $(".sortDevs").parent().find("input[name='selectedClientId']").val(clientId);
                    $("body").css("cursor", "default");
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByMacForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePage.php",
            data: {
                'page': page,
                'modelID': modelID,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'devCount': devCount,
                'mac': clientInfoVal,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchBySerialForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePage.php",
            data: {
                'page': page,
                'modelID': modelID,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'devCount': devCount,
                'serial': clientInfoVal,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByClientForEachPage(page, modelID, groupID, fwVersion, devCount, firstN, surN, address, email, deviceScrollPage,sortedVal,clientId) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePage.php",
            data: {
                'page': page,
                'modelID': modelID,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'devCount': devCount,
                'firstName': firstN,
                'surName': surN,
                'address': address,
                'email': email,
                'sortedVal': sortedVal,
                'clientId':clientId,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByIpForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePage.php",
            data: {
                'page': page,
                'modelID': modelID,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'devCount': devCount,
                'ip': clientInfoVal,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function searchByUsernameForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage, sortedVal) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePage.php",
            data: {
                'page': page,
                'modelID': modelID,
                'groupId': groupID,
                'fwVersion': fwVersion,
                'devCount': devCount,
                'username': clientInfoVal,
                'sortedVal': sortedVal,
                'fromApp': true
            },
            async: true,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#deviceTable").html("");
                    $("#deviceTable").html(data);
                    $("body").css("cursor", "default");
                    if (deviceScrollPage == 2) {
                        $(".pageForDevice").hide();
                        var showScroll = $(".inputForScroll").val();
                        if (showScroll == 3) {
                            $("#deviceTable").append('<i class="fa fa-arrow-circle-down mainColor" style="font-size: 40px; float:right"></i>');
                        } else {
                            $(".fa-arrow-circle-down").remove();
                        }
                    }
                    if (groupID != 0 || modelID != 0) {
                        $('#deviceTable .groupTaskForDev').css('display', 'block');
                    } else {
                        $('#deviceTable .groupTaskForDev').css('display', 'none');
                    }
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

// ---------------------------  End Device Page  -------------------------------

// -------------------------- Profile page -------------------------------------

    $(document).on('click', '#chngeProfile', function () {
        $('#chngeProfile').attr("href", $basepath + "profile/changeProfile");

        // if ($(".profileDiv").css("display") == "none") {
        //     $('.profileNav li a').removeClass('activeTab');
        //     $(this).addClass('activeTab');
        //     $('.profileDiv').show();
        //     $('.passwordDiv').hide();
        //     $('.HeartBeatDiv').hide();
        //     $('.passwordDiv').hide()
        //     $('.importDiv').hide();
        //     $("#failAddProfile").empty();
        // }
    });

    $(document).on('click', '#changePassword', function () {
        $('#changePassword').attr("href", $basepath + "profile/changePassword");

        // if ($(".passwordDiv").css("display") == "none") {
        //     $('.profileNav li a').removeClass('activeTab');
        //     $(this).addClass('activeTab');
        //     $('.profileDiv').hide();
        //     $('.importDiv').hide();
        //     $('.passwordDiv').show();
        //     $('.HeartBeatDiv').hide();
        //     $("#failAddProfile").empty();
        // }
    });

    $(document).on('click', '#changeHeartBeat', function () {
        $('#changeHeartBeat').attr("href", $basepath + "profile/changeHeartBeat");

        // if ($(".HeartBeatDiv").css("display") == "none") {
        //     $('.profileNav li a').removeClass('activeTab');
        //     $(this).addClass('activeTab');
        //     $('.importDiv').hide();
        //     $('.profileDiv').hide();
        //     $('.passwordDiv').hide();
        //     $('.HeartBeatDiv').show();
        //     $("#failAddProfile").empty();
        // }
    });

    $(document).on('click', '#importDevice', function () {
        $('#importDevice').attr("href", $basepath + "profile/importDevice");

        // if ($(".importDiv").css("display") == "none") {
        //     $('.profileNav li a').removeClass('activeTab');
        //     $(this).addClass('activeTab');
        //     $('.HeartBeatDiv').hide();
        //     $('.profileDiv').hide();
        //     $('.passwordDiv').hide();
        //     $('.importDiv').show();
        //     $("#failAddProfile").empty();
        // }
    });

    $(document).on('click', '.heartBeatStatus', function () {
        $('.heartBeatStatus').attr("href", $basepath + "profile/changeHeartBeat");
    });

    $(document).on('click', '#showToken', function () {
        var show = getMssg['show'];
        var hide = getMssg['hide'];
        if ($('.divForShoeToken').is(":hidden")) {
            $("#showToken").html(hide);
            $('.divForShoeToken').removeClass('for_all_display_none');
        } else {
            $("#showToken").html(show);
            $('.divForShoeToken').addClass('for_all_display_none');
        }

    });


    $(document).on('click', '#cancelSettings', function () {
        $('#chngeProfile').attr("href", $basepath + "profile/changeProfile");
        if ($.trim($('.error_message').text()).length != 0) {
            $('#updateSettings').validate().resetForm();
        }
        $('#showReWritePass').hide();
        $('#showReWriteDevPass').hide();
    });

    $(document).on('click', '#changeSettings', function () {


        var msgRequird = getMssg['error_message_required'];
        var msgNumber = getMssg['error_message_number'];
        var msgGe1 = getMssg['error_message_ge_1'];
        var msgLe65535 = getMssg['error_message_le_65535'];
        var msgDns = getMssg['error_message_dns'];
        var msgSettingsUpdated = getMssg['settings_updated'];
        var msgSettingsNotUpdated_1 = getMssg['settings_not_updated_1'];
        var msgSettingsNotUpdated_2 = getMssg['settings_not_updated_2'];
        var msgRepassword = getMssg['error_message_repassword'];
        var msgNoChanges = getMssg['no_changes'];
        var notificationToAcsServer = getMssg['notification_to_acs_server'];
        var paswSpace = getMssg['error_message_password'];
        var msg = getMssg['settings_reboot'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['snmp_yes'];
        var cancelMsg = getMssg['snmp_no'];
        var msgIp = getMssg['error_message_ip'];
        var saveSettings = getMssg['save_setting'];
        var msgPort = getMssg['error_message_for_port'];

        $('#updateSettings').validate({
            rules: {
                databasePort: {
                    required: true,
                    number: true,
                    min: 1,
                    max: 65535,
                    validatePort: true
                },
                password: {
                    validateIsEmpty: true,
                    required: true
                },
                host: {
                    required: true,
                    validateDNS: true
                },
                databaseName: {
                    required: true
                },
                username: {
                    required: true
                },
                serverport: {
                    required: true,
                    number: true,
                    min: 1,
                    max: 65535,
                    validatePort: true
                },
                reWritePass: {
                    equalTo: "#settingPass"
                },
                reWriteDevPass: {
                    equalTo: "#settingDevPass"
                },
                auto_ref_time: {
                    number: true
                },
                stunIP: {
                    required: true,
                },
                stunPort: {
                    required: true,
                    digits: true,
                    min: 1,
                    max: 65535,
                    validatePort: true
                },
                // IPSLA: {
                //     validateIpAddress : true,
                // },
                portSLA: {
                    number: true,
                    min: 1,
                    max: 65535,
                    validatePort: true
                }
            },
            messages: {
                databasePort: {
                    required: msgRequird,
                    number: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgPort
                },
                password: {
                    required: msgRequird,
                    validateIsEmpty: paswSpace
                },
                host: {
                    required: msgRequird,
                    validateDNS: msgDns
                },
                databaseName: {
                    required: msgRequird
                },
                username: {
                    required: msgRequird
                },
                serverport: {
                    required: msgRequird,
                    number: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgPort
                },
                reWritePass: {
                    equalTo: msgRepassword
                },
                reWriteDevPass: {
                    equalTo: msgRepassword
                },
                stunIP: {
                    required: msgRequird,
                },
                stunPort: {
                    required: msgRequird,
                    digits: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgPort
                },
                // IPSLA: {
                //     validateIpAddress: msgIp
                // },
                portSLA: {
                    number: msgNumber,
                    min: msgGe1,
                    max: msgLe65535,
                    validatePort: msgPort
                }

            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if (!$("#updateSettings").valid()) {
            $('body').css("cursor", "default");
            return false;
        }

        // var DatabaseType = $('#databaseType option:selected').text();
        // var DatabasePort = $("input[name='databasePort']").val().trim();
        // var host = $("input[name='host']").val().trim();
        // var DatabaseName = $("input[name='databaseName']").val().trim();
        // var username = $("input[name='username']").val().trim();
        // var password = $("input[name='password']").val().trim();
        var serverport = $("input[name='serverport']").val().trim();
        var dev_usname = $("input[name='dev_usname']").val().trim();
        var dev_pass = $("input[name='dev_pass']").val().trim();
        // var auto_ref_time = $("input[name='auto_ref_time']").val().trim();
        var slaIp = $("input[name='IPSLA']").val().trim();
        var slaPort = $("input[name='portSLA']").val().trim();
        var stunIp = $("input[name='stunIP']").val().trim();
        var stunPort = $("input[name='stunPort']").val().trim();
        var reportAddrAPI = $("input[name='address_api']").val().trim();
        // var stunIp_2 = $("input[name='stunIP_2']").val().trim();
        // var stunPort_2 = $("input[name='stunPort_2']").val().trim();


        // var x = document.getElementById("databaseType").selectedIndex;
        var y = document.getElementsByTagName("option");
        // var isDatabaseTypeChanged = y[x].defaultSelected;
        // var DatabasePortDef = document.getElementById("databasePort").defaultValue;
        // var hostDef = document.getElementById("host").defaultValue;
        // var DatabaseNameDef = document.getElementById("databaseName").defaultValue;
        // var usernameDef = document.getElementById("username").defaultValue;
        // var passwordDef = document.getElementById("settingPass").defaultValue;
        var serverportDef = document.getElementById("serverport").defaultValue;
        var devUsernameDef = document.getElementById("dev_usname").defaultValue;
        var devPasswordDef = document.getElementById("settingDevPass").defaultValue;
        // var autoRefTimeDef = document.getElementById("auto_ref_time").defaultValue;
        var slaIpDef = document.getElementById("IPSLA").defaultValue;
        var slaPortDef = document.getElementById("portSLA").defaultValue;
        var reportAddrAPIDef = document.getElementById("address_api").defaultValue;
        var rebootServer = "true";

        // var stunIPDef = document.getElementById("stunIP").defaultValue;
        // var stunPortDef = document.getElementById("stunPort").defaultValue;

        if (
            // DatabasePort == DatabasePortDef && host == hostDef && DatabaseName == DatabaseNameDef &&
        // username == usernameDef && password == passwordDef &&
            serverport == serverportDef && dev_usname == devUsernameDef && dev_pass == devPasswordDef /*&& auto_ref_time == autoRefTimeDef*/ &&
            slaIp == slaIpDef && slaPort == slaPortDef && reportAddrAPI == reportAddrAPIDef/*&& stunIp==stunIPDef && stunPort==stunPortDef*/) {
            swal({
                title: '',
                text: msgNoChanges
            });
            return false;
        }
        if (
            // DatabasePort == DatabasePortDef && host == hostDef && DatabaseName == DatabaseNameDef &&
        // username == usernameDef && password == passwordDef &&
            serverport == serverportDef && dev_usname == devUsernameDef && dev_pass == devPasswordDef /*&& auto_ref_time == autoRefTimeDef*/ &&
            (slaIp != slaIpDef || slaPort != slaPortDef)) {
            rebootServer = "false";
            msg = getMssg['success'];
        }

        swal({
            title: '',
            text: saveSettings,
            showCancelButton: true,
            closeOnConfirm: false,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function () {

            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/changeSettings.php",
                data: {
                    // 'DatabaseType': DatabaseType,
                    // 'DatabasePort': DatabasePort,
                    // 'host': host,
                    // 'DatabaseName': DatabaseName,
                    // 'username': username,
                    // 'password': password,
                    'serverport': serverport,
                    'dev_usname': dev_usname,
                    'dev_pass': dev_pass,
                    // 'auto_ref_time': auto_ref_time,
                    'stun_server_addr': stunIp,
                    'stun_server_port': stunPort,
                    'sla_ip': slaIp,
                    'sla_port': slaPort,
                    'rebootServer': rebootServer,
                    'reportAddress': reportAddrAPI,
                    // 'stun_server_addr_2': stunIp_2,
                    // 'stun_server_port_2': stunPort_2,
                    'fromApp': true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        if (result == 0) {
                            // swal({
                            //     title: '',
                            //     text: msgSettingsUpdated
                            // }, function (isConfirm) {
                            window.location.reload();
                            // });
                        } else if (result == 1) {
                            swal({
                                title: '',
                                text: msgSettingsNotUpdated_1
                            });
                        } else if (result == 2) {
                            swal({
                                title: '',
                                text: msgSettingsNotUpdated_2
                            });
                        } else if (result == 3) {
                            swal({
                                title: '',
                                text: notificationToAcsServer
                            });
                        }
                    }
                }
            });
        });
    });

    $(document).on('click', '#changeProf', function () {
        var msgRequired = getMssg['error_message_required'];
        $("#changeProfForm").validate({
            rules: {
                username: {
                    required: true
                },
                email: {
                    required: true
                }
            },

            messages: {
                username: {
                    required: msgRequired
                },
                email: {
                    required: msgRequired
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if (!($("#changeProfForm").valid())) {
            $("#failAddProfile").empty();
            return false;
        }

        var userName = $("input[name='username']").val();
        var email = $("input[name='email']").val();
        var realUsername = $("input[name='realUsername']").val();
        var realEmail = $("input[name='realEmail']").val();
        var checkForParams = '';
        if (userName != '') {
            var resFailAction = '';
            if (email != '') {
                if (userName != realUsername && email == realEmail) {
                    checkForParams = "onlyUser";

                    resFailAction = checkUsernameEmail(userName, '');

                } else if (userName == realUsername && email != realEmail) {
                    checkForParams = "onlyEmail";
                    if (email != '') {
                        resFailAction = checkUsernameEmail('', email);

                    }
                } else if (userName != realUsername && email != realEmail) {
                    checkForParams = "onlyEmail";
                    checkForParams = "userEmail";
                    if (email != '') {
                        resFailAction = checkUsernameEmail(userName, email);

                    } else {
                        resFailAction = checkUsernameEmail(userName, '');
                    }
                } else {
                    $("#failAddProfile").text('');
                    $("body").css("cursor", "default");
                    return false;
                }
            }
//            else {
//                resFailAction = getMssg['email_required'];
//                $("#failAddProfile").empty();
//                $("#failAddProfile").html(resFailAction);
//                $("#failAddProfile").addClass("errorMessage");
//                return false;
////                if (userName != realUsername){
////                    if(email == realEmail){
////                        checkForParams = "onlyUser";
////                    }
////                    resFailAction = checkUsernameEmail(userName,'');
////                }
//            }

            if (resFailAction != '') {
                $("#failAddProfile").empty();
                $("#failAddProfile").html(resFailAction);
                $("#failAddProfile").addClass("errorMessage");
                $("body").css("cursor", "default");
                return false;
            } else {
                if (checkForParams == 'onlyUser') {
                    email = '';
                } else if (checkForParams == 'onlyEmail') {
                    userName = '';
                }

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/changeProf.php",
                    data: {
                        'userName': userName,
                        'email': email,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            location.reload(true);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }
        /*else{
            resFailAction = getMssg['userName_required'];
            $("#failAddProfile").empty();
            $("#failAddProfile").html(resFailAction);
            $("#failAddProfile").addClass("errorMessage");
        }*/
    });


    function checkUsernameEmail(userName, email) {
        var result;
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/checkUserNameEmail.php",
            data: {
                'email': email,
                'userName': userName,
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    result = data;
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        return result;
    }

    $(document).on('click', '#changePass', function () {
        var msgRequired = getMssg['error_message_required'];
        var msgSpace = getMssg['error_message_password'];

        $("#changePassForm").validate({
            rules: {
                oldPassword: {
                    required: true,
                    validateIsEmpty: true
                },
                newPassword: {
                    required: true,
                    validateIsEmpty: true
                },
                confPassword: {
                    required: true,
                    validateIsEmpty: true
                }
            },

            messages: {
                oldPassword: {
                    required: msgRequired,
                    validateIsEmpty: msgSpace
                },
                newPassword: {
                    required: msgRequired,
                    validateIsEmpty: msgSpace
                },
                confPassword: {
                    required: msgRequired,
                    validateIsEmpty: msgSpace
                }
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if (!($("#changePassForm").valid())) {
            $("#failAddProfile").empty();
            return false;
        }
        var oldPass = $("input[name='oldPassword']").val();
        var newPass = $("input[name='newPassword']").val();
        var confPass = $("input[name='confPassword']").val();

        if (oldPass != '' && newPass != '' && confPass != '') {
            var resFailAction = '';
            if (newPass != oldPass) {

                //if(newPass.replace(/\s/g, "").length > 0) {
                if (newPass == confPass) {

                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkOldPass.php",
                        data: {
                            'oldPassword': oldPass,
                            'page': 'profile',
                            'fromApp': true
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                resFailAction = data;
                                return false;
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else {
                    resFailAction = getMssg['conf_pass'];
                }
                /* } else {
                     resFailAction = getMssg['error_message_password'];
                     $("#failAddProfile").empty();
                     $("#failAddProfile").addClass("errorMessage");
                     $("#failAddProfile").html(resFailAction);
                     $("body").css("cursor", "default");
                 }*/

            } else {
                resFailAction = getMssg['new_pass_old'];
            }

            if (resFailAction != '') {
                $("#failAddProfile").empty();
                $("#failAddProfile").addClass("errorMessage");
                $("#failAddProfile").html(resFailAction);
                $("body").css("cursor", "default");
                return false;
            } else {

                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/changePass.php",
                    data: {
                        'password': newPass,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            location.reload(true);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }
        /*else {
            resFailAction = getMssg['all_fields_required'];
            $("#failAddProfile").empty();
            $("#failAddProfile").addClass("errorMessage");
            $("#failAddProfile").html(resFailAction);
            $("body").css("cursor", "default");
        }*/
    });

    $(document).on('click', '#HeartBeatClick', function () {
        var heartInterval = $("input[name='heartInterval']").val();
        var heartWarning = $("input[name='heartWarning']").val();
        var heartError = $("input[name='heartError']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeProf.php",
            data: {
                'heartInterval': heartInterval,
                'heartWarning': heartWarning,
                'heartError': heartError,
                'actionName': "DeviceHeartbeats",
                'fromApp': true
            },
            async: false,
            success: function (data) {
                if (data == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    var meratMsg = getMssg['changed_saved'];
                    $('#heartMsg').addClass('infoMessage');
                    $('#heartMsg').html(meratMsg);
                    setTimeout(function () {
                        $("#heartMsg").empty();
                    }, 3000);
                    // resFailAction = data;
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("change", ".deviceScrollPage", function () {
        $checked_array = new Array();
        // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
        scrolingDevices.countDev = 10;
        scrolingDevices.inProcesForDev = false;
        var deviceScrollPage = $(".deviceScrollPage option:selected").val();
        if (deviceScrollPage == 2) {
            var devCount = 10;
            $(".pagelimit").hide();
        } else {
            $(".pagelimit").show();
            var devCount = $('.pagelimit').find('.active').data('row');
        }
        $("body").css("cursor", "wait");
        // var page = $(".eachPage").find("input[name='page']").val();
        var page = 1;
        var modelID = $(".modelType option:selected").val();
        var groupID = $(".groupType option:selected").val();
        var fwVersion = $(".changeFirmwareFilter option:selected").val();
        var searchElem = $(".linkForSearchDev");
        var clientInfo = $("#forSearchingDev").find("input[name='clientInfo']");
        var clientInfoVal = $("#forSearchingDev").find("input[name='clientInfo']").val();
        var sortedVal = $(".sortDevs option:selected").val();
        var clientId=0;
        var sortBy=$(".sort_device_by").attr("id");
        // if(sortBy=="DESC"){
        //     $(".sort_device_by").attr("id","ASC");
        //     $(".sort_device_by").attr("src",$basepath + "assets/images/down_arrow_34.png");
        //     $(".sort_device_by").attr("title",getMessage("by_desc"));
        // } else {
        //     $(".sort_device_by").attr("id","DESC");
        //     $(".sort_device_by").attr("src",$basepath + "assets/images/up_arrow_34.png");
        //     $(".sort_device_by").attr("title",getMessage("by_asc"));
        // }
        var sortBy1="";
        if(sortBy=="DESC") {
            sortBy1='ASC';
        } else {
            sortBy1='DESC';
        }
        sortedVal=sortedVal+":"+sortBy1;


        if (searchElem.attr("id") == 'searchDeviByClient') {
            if (clientInfo.find("input[name='firstName']").length != 0) {
                var firstN = clientInfo.find("input[name='firstName']").val();
                var surN = clientInfo.find("input[name='surName']").val();
                var address = clientInfo.find("input[name='address']").val();
                var email = clientInfo.find("input[name='email']").val();
            } else {
                var firstN = '';
                var surN = '';
                var address = '';
                var email = '';
            }

            var clientInfo = $("#forSearchingDev").find("input[name='clientInfo']").val();
            if(clientInfo!=''){
                clientId=$(".sortDevs").parent().find("input[name='selectedClientId']").val();
            }

            searchByClientForEachPage(page, modelID, groupID, fwVersion, devCount, firstN, surN, address, email, deviceScrollPage,sortedVal,clientId);
        } else if (searchElem.attr("id") == 'searchDevByIp') {
            searchByIpForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage,sortedVal);
        } else if (searchElem.attr("id") == 'searchDevByMac') {
            searchByMacForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage,sortedVal);
        } else if (searchElem.attr("id") == 'searchDevByUsername') {
            searchByUsernameForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage,sortedVal);
        } else if (searchElem.attr("id") == 'searchDevBySerial') {
            searchBySerialForEachPage(page, modelID, groupID, fwVersion, devCount, clientInfoVal, deviceScrollPage,sortedVal);
        }


    });

    $(document).on("click", "#statusonoffswitch", function () {
        var checked = '';
        var action = "devStatus";
        var reload = true;
        if ($(this).is(":checked")) {
            checked = true;
        } else {
            checked = false;
        }
        setStatusCheckDevice(checked, action, reload);
    });

    $(document).on("click", "#SLAstatusonoffswitch", function () {
        // $.cookie("SlaStatus",'');
        var checked = '';
        var action = "SlaStatus";
        var reload = true;
        if ($(this).is(":checked")) {
            checked = true;
            // $.cookie("SlaStatus",'true');
        } else {
            checked = false;
            // $.cookie("SlaStatus",'false');
        }
        setStatusCheckDevice(checked, action, reload);

    });

    function setStatusCheckDevice(status, action, reload) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/setVariableInSession.php",
            data: {
                'checked': status,
                'action': action,
                'fromApp': true
            },
            dataType: 'json',
            async: true,
            success: function (result) {
                if (jQuery.parseJSON(result) == 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
                if(reload) {
                    location.reload(true);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $('#settingss').popover({
        html: true,
        content: function () {
            return $('#settings_bar').html();
        }
    });


    $('#statistics').popover({
        html: true,
        content: function () {
            return $('#statistic_bar').html();
        }
    });

    $(document).on('change', '.versionSelect', function () {
        var version = $(".versionSelect option:selected").val();
        // var enableEncrypt = $(".encryptSelect option:selected").val();

        if (version == '3') {
            //     $("#encript").removeAttr("disabled");
            //     $("#encript").css("opacity", "1");
            //     if(enableEncrypt == 1) {
            $("#privProtocol").removeAttr("disabled");
            $("#authProtocol").removeAttr("disabled");
            $("#passAuth").removeAttr("readonly");
            $("#userName").removeAttr("readonly");
            $("#passPriv").removeAttr("readonly");
            $("#passAuth").removeAttr("disabled");
            $("#passPriv").removeAttr("disabled");
            $("#userName").removeAttr("disabled");
            $("#privProtocol").css("opacity", "1");
            $("#authProtocol").css("opacity", "1");
            $("#passAuth").css("opacity", "1");
            $("#userName").css("opacity", "1");
            $("#passPriv").css("opacity", "1");
            $("#settingsSNMPpart2").css("opacity", "1");
            //     }
            // $('.encript').iCheck({
            //     checkboxClass: 'icheckbox_square-blue',
            //     increaseArea: '20%' // optional
            // });
            // $('.encript').on('ifChecked ifUnchecked', function(event){

            // if (event.type == 'ifChecked') {

        } else {
            // if ($("#encript").is(":checked")) {
            //     $("#encript").removeAttr("checked");
            //     $('#encript').iCheck('update');
            // }

            $("#encript").prop("disabled", true);
            $("#encript").css("opacity", "0.5");
            $("#privProtocol").prop("disabled", true);
            $("#authProtocol").prop("disabled", true);
            $("#passAuth").prop("readonly", true);
            $("#userName").prop("readonly", true);
            $("#passPriv").prop("readonly", true);
            $("#passAuth").prop("disabled", true);
            $("#passPriv").prop("disabled", true);
            $("#userName").prop("disabled", true);
            $("#privProtocol").css("opacity", "0.5");
            $("#authProtocol").css("opacity", "0.5");
            $("#passAuth").css("opacity", "0.5");
            $("#userName").css("opacity", "0.5");
            $("#passPriv").css("opacity", "0.5");
            $("#settingsSNMPpart2").css("opacity", "0.5");

            // $("#settingsSNMPpart2").css("display","none");
        }

    });

    // $(document).on('change','.encryptSelect',function () {
    //     var enableEncrypt = $(".encryptSelect option:selected").val();
    //
    //     if(enableEncrypt == 1) {
    //         $("#privProtocol").removeAttr("disabled");
    //         $("#authProtocol").removeAttr("disabled");
    //         $("#passAuth").removeAttr("readonly");
    //         $("#userName").removeAttr("readonly");
    //         $("#passPriv").removeAttr("readonly");
    //         $("#passAuth").removeAttr("disabled");
    //         $("#passPriv").removeAttr("disabled");
    //         $("#privProtocol").css("opacity", "1");
    //         $("#authProtocol").css("opacity", "1");
    //         $("#passAuth").css("opacity", "1");
    //         $("#userName").css("opacity", "1");
    //         $("#passPriv").css("opacity", "1");
    //     } else {
    //         $("#privProtocol").prop("disabled", true);
    //         $("#authProtocol").prop("disabled", true);
    //         $("#passAuth").prop("readonly", true);
    //         $("#userName").prop("readonly", true);
    //         $("#passPriv").prop("readonly", true);
    //         $("#passAuth").prop("disabled", true);
    //         $("#passPriv").prop("disabled", true);
    //         $("#privProtocol").css("opacity", "0.5");
    //         $("#authProtocol").css("opacity", "0.5");
    //         $("#passAuth").css("opacity", "0.5");
    //         $("#userName").css("opacity", "0.5");
    //         $("#passPriv").css("opacity", "0.5");
    //     }
    // });

    $(document).on('change', '.editVersionSelect', function () {
        var version = $(this, 'option:selected').val();
        var id = '#' + ($(this).attr('3'));
        if (version == '3') {
            $(id).css("display", "block");
            $("#editSettingsSNMPpart2").css("display", "block");
        } else {
            $(id).css("display", "none");
            $("#editSettingsSNMPpart2").css("display", "none");
        }
    });

    $(document).on('change', '#privProtocol', function () {
        var privProtocol = $(this, 'option:selected').val();

        if (privProtocol == "DES") {
            $(".privProtocolDiv").show();
        } else {
            $(".privProtocolDiv").hide();
        }

    });

    // TODO need updated below case 
    $(document).on('change', '#uploadBtnSNMP', function () {
        $("#uploadFileSNMP").val($(this).val());
    });

    $(document).on('change', '.upload', function () {
        var id = '#' + $(this).attr('inputID');
        $(id).val($(this).val());
    });

    $(document).on('click', '.checkTaskStatus', function () {
        var devId = $(this).parent().find("input[name='devID']").val();
        var th = $(this);
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/checkTaskStatus.php",
            data: {
                'deviceID': devId,
                'actionName': "lastTaskNames",
                'fromApp': true
            },
            async: false,
            success: function (result) {
                var result = JSON.parse(result);
                // alert(result.result);
                if (result.result == "true") {
                    $(".checkTaskStatus").css("cursor", "wait");
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'deviceID': devId,
                            'actionName': 'refresh',
                            'fromApp': true
                        },
                        async: false,
                        success: function (result) {
                            if (result == 'true') {
                                intervalTaskRefresh = setInterval(function () {
                                    getTaskStatusForRefresh(th, "'refresh'", devId);
                                }, 1000);
                                setTimeout(function () {
                                    updateActivities(devId);
                                }, 3000);

                            } else if (result == 'false') {
                            } else if (result = 'logged_out') {
                                document.location.href = $basepath + 'login';
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                } else if (result.result == "false") {
                    var newTitle = getMssg['created_refresh_task'];
                    th.attr('title', newTitle);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });

    });

    function updateActivities(deviceID) {
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/eachDevActivity.php",
            data: {
                'deviceID': deviceID,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forDActiv").empty();
                    $("#forDActiv").html(result);
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    function getTaskStatusForRefresh(th, taskName, deviceId) {
        th.attr("disabled", "disabled");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getTaskStatusOfTheDevice.php",
            data: {
                'taskName': taskName,
                'deviceID': deviceId,
                'fromApp': true
            },
            async: true,
            success: function (result) {
                var changed = true;
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 2) {
                    $(".checkTaskStatus").css("cursor", "default");
                    $(".checkTaskStatus").css("display", "inline");
                    changed = true;
                } else if (result == 1 || result == 0 || result == -1) {
                    changed = false;
                } else {
                    changed = true;
                }

                if (changed) {
                    // th.hide();
                    th.removeAttr("disabled");
                    clearInterval(intervalTaskRefresh);
                    // updateAfterTheAction();
                }
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }

    $(document).on('click', '.checkStatus', function () {
        var devId = $(this).parent().find("input[name='devID']").val();
        var th = $(this);
        $('body').oLoader({
            image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'
        });

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
            data: {
                'deviceID': devId,
                'actionName': "connection",
                'fromApp': true
            },
            async: true,
            success: function (result) {
                if (result == 'true') {
                    th.removeClass('offline');
                    th.addClass('online');
                    th.attr("title", getMssg['device_ready']);
//                        $("body").css("cursor", "default");
                } else if (result == 'false') {
                    th.removeClass('online');
                    th.addClass('offline');
                    th.attr("title", getMssg['device_not_ready']);
//                        $("body").css("cursor", "default");
                } else if (result = 'logged_out') {
                    document.location.href = $basepath + 'login';
                }
                $('body').oLoader('hide');
            },
            error: function (xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    //function for SNMP
    $('#addSwitchNetworkTopolagy').popover({
        html: true,
        content: function () {
            return $('.addSwitchPopover').html();
        }
    });

    $(document).on('click', '#addSwitch', function (e) {
        e.preventDefault();
        var msgRequird = getMssg['error_message_required'];
        var msgIp = getMssg['error_message_ip'];
        var msgEmpty = getMssg['error_message_empty'];

        $('#addSwitchForm').validate({
            rules: {
                ip: {
                    required: true,
                    validateIpAddress: true
                },
                community: {
                    required: true,
                    validateIsEmpty: true
                },
                userName: {
                    required: true
                },
                password: {
                    required: true,
                    validateIsEmpty: true
                },
                secname: {
                    validateIsEmpty: true,
                    required: true
                },
                seclevel: {
                    validateIsEmpty: true,
                    required: true
                },
                autopro: {
                    validateIsEmpty: true,
                    required: true
                },
                passwordAuth: {
                    required: true,
                    validateIsEmpty: true
                },
                passwordPriv: {
                    required: true,
                    validateIsEmpty: true
                },
            },
            messages: {
                ip: {
                    required: msgRequird,
                    validateIpAddress: msgIp
                },
                community: {
                    required: msgRequird
                },
                userName: {
                    required: msgRequird
                },
                password: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                secname: {
                    required: msgRequird
                },
                seclevel: {
                    required: msgRequird
                },
                autopro: {
                    required: msgRequird
                },
                passwordAuth: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
                passwordPriv: {
                    required: msgRequird,
                    validateIsEmpty: msgEmpty
                },
            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if (!($("#addSwitchForm").valid())) {
            return false;
            location.reload(true);
        } else {
            var data = $('#addSwitchForm').serialize();
            drawNetworkTopology.addSwitch(data);
            $(".popover").each(function () {
                var popover = $(this);
                $('.fields').iCheck('destroy');
                $('.port').iCheck('destroy');
                var ctrl = $(popover.context);
                ctrl.popover('hide');
            });
        }

    });

    function getTreeCookie(name) {
        //var a=""+name;
        //a.replace("a","");
        //return $.cookie(name);
        var matches = document.cookie.match(new RegExp(
            "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
        ));
        return matches ? decodeURIComponent(matches[1]) : undefined;
    }

    $(document).on("click", ".downloadFile", function () {
        var href = $(this).attr('name');
        let url = $basepath + "secureFiles/actions/ajaxActions/downloadFiles.php";
        let token = getTreeCookie("token");
        let data = {
            'token': token,
            'actionName': href
        };
        redirectPost(url, data);
    });
});


// -------------------------- end Profile page ---------------------------------

// -------------------------- For position to popover resize -------------------

$(window).resize(function () {
    $(".popover").each(function () {
        var popover = $(this);
        if (popover.is(":visible")) {
            $('.fields').iCheck('destroy');
            $('.port').iCheck('destroy');
            var ctrl = $(popover.context);
            ctrl.popover('hide');
        }
    });
});
// --------------------------End For position to popover resize ----------------

//---------------------------For rePassword in Settings page -------------------

$(document).on('input', '#settingPass', function () {
    $('#showReWritePass').show();
});

setTimeout(function () {
    $(document).on('input', '#settingDevPass', function () {
        $('#showReWriteDevPass').show();
    });
}, 1000);


function getSwitchsFromDataBase() {
    var url = window.location.href;
    $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
    $.ajax({
        method: "POST",
        url: url,
        data: {action: 'getDev'},
        success: function (data) {
            if (data == "error") {
                window.location.href = "error500";
            }
            getIniDescriptions();
            getIniDescriptionsForTable();
            $('#tbodySettingsSNMP').html(data);

            $('.fieidss').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                increaseArea: '20%' // optional
            });
            $('.sw_status').click(function () {
                var aTag = this;
                var id = $(this).attr('tid');
                $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
                setTimeout(function () {
                    $.ajax({
                        method: "POST",
                        url: url,
                        data: {action: 'checkStatus', id: id},
                        success: function (data) {
                            $('body').oLoader('hide');
                            var obj = jQuery.parseJSON(data);
                            if (obj != undefined && obj.status == 'enable') {
                                $(aTag).removeClass('offline').addClass('online');
                            } else {
                                $(aTag).removeClass('online').addClass('offline');
                            }
                        }
                    });
                }, 600);
            });
            $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
            if ($('.forFieldsCheck').find('.fieidss').filter(':checked').length != $countOfUncheckeds) {
                $('#all_fields').prop('checked', false).iCheck('update');
            }
            $('#all_fields').on('ifChecked ifUnchecked', function (event) {

                if (event.type == 'ifChecked') {
                    $('.fieidss').iCheck('check');
                    $('.trash-select-all').css('display', 'block');
                } else {
                    $('.fieidss').iCheck('uncheck');
                    $('.trash-select-all').css('display', 'none');
                }
            });

            $('.fieidss').on('ifChecked ifUnchecked', function (event) {
                if (event.type == 'ifChecked') {

                    $(this).closest('tr').css("background-color", "#EDF1F2");
                    $('.trash-select-all').css('display', 'block');
                    if ($('.forFieldsCheck').find('.fieidss').filter(':checked').length == $countOfUncheckeds) {
                        $('#all_fields').prop('checked', true).iCheck('update');
                    }
                } else {

                    if ($('#all_fields').is(':checked')) {
                        $('#all_fields').prop('checked', false).iCheck('update');
                    }

                    if (!$('.fieidss').is(':checked')) {

                        $('.trash-select-all').css('display', 'none');
                        $('#all_fields').iCheck('uncheck');
                    }
                    $(this).closest('tr').css("background-color", "#FFFFFF");
                }
            });

            if ($countOfUncheckeds == 0) {
                $('.checkOfSNMPall').css('display', 'none');
            }

            // click edit button 
            $('.editSwitch').click(function () {
                var id = $(this).attr('tid');
                $.ajax({
                    method: "POST",
                    url: url + '/updatedSwitch',
                    data: {id: id},
                    success: function (data) {
                        $('.container_top').html(data);
                        $('.encript').iCheck({
                            checkboxClass: 'icheckbox_square-blue',
                            increaseArea: '20%' // optional
                        });
                        $(document).on('change', '.editVersionSelect', function () {
                            var enableEncrypt = $(".editEncryptSelect option:selected").val();

                            var version = $(".editVersionSelect option:selected").val();
                            // if(version == 'v3'){
                            if (version == '3') {
                                // $("#encript").removeAttr("disabled");
                                // $("#encript").css("opacity", "1");
                                // if(enableEncrypt == 1) {
                                $("#privProtocol").removeAttr("disabled");
                                $("#authProtocol").removeAttr("disabled");
                                $("#passAuth").removeAttr("readonly");
                                $("#userName").removeAttr("disabled");
                                $("#userName").removeAttr("readonly");
                                $("#passPriv").removeAttr("disabled");
                                $("#passAuth").removeAttr("disabled");
                                $("#passPriv").removeAttr("disabled");
                                $("#settingsSNMPpart2").css("opacity", "1");
                                // $("#privProtocol").css("opacity", "1");
                                // $("#authProtocol").css("opacity", "1");
                                // $("#passAuth").css("opacity", "1");
                                // $("#userName").css("opacity", "1");
                                // $("#passPriv").css("opacity", "1");
                                // }
                            } else {
                                $("#encript").prop("disabled", true);
                                $("#encript").css("opacity", "0.5");
                                $("#privProtocol").prop("disabled", true);
                                $("#authProtocol").prop("disabled", true);
                                $("#passAuth").prop("readonly", true);
                                $("#userName").prop("readonly", true);
                                $("#passPriv").prop("readonly", true);
                                $("#userName").prop("disabled", true);
                                $("#passAuth").prop("disabled", true);
                                $("#passPriv").prop("disabled", true);
                                $("#settingsSNMPpart2").css("opacity", "0.5");
                                // $("#privProtocol").css("opacity", "0.5");
                                // $("#authProtocol").css("opacity", "0.5");
                                // $("#passAuth").css("opacity", "0.5");
                                // $("#userName").css("opacity", "0.5");
                                // $("#passPriv").css("opacity", "0.5");
                            }
                            // $("#encript").removeAttr("disabled");
                            // $('.encript').iCheck({
                            //     checkboxClass: 'icheckbox_square-blue',
                            //     increaseArea: '20%' // optional
                            // });
                            //     $('.encript').on('ifChecked ifUnchecked', function(event){
                            //         if (event.type == 'ifChecked') {
                            //             $("#privProtocol").removeAttr("disabled");
                            //             $("#authProtocol").removeAttr("disabled");
                            //             $("#passAuth").removeAttr("readonly");
                            //             $("#passPriv").removeAttr("readonly");
                            //             $("#privProtocol").css("opacity", "1");
                            //             $("#authProtocol").css("opacity", "1");
                            //         } else {
                            //             $("#privProtocol").prop("disabled", true);
                            //             $("#authProtocol").prop("disabled", true);
                            //             $("#passAuth").prop("readonly", true);
                            //             $("#passPriv").prop("readonly", true);
                            //             $("#privProtocol").css("opacity", "0.5");
                            //             $("#authProtocol").css("opacity", "0.5");
                            //         }
                            //     });
                            // } else {
                            //     if ($("#encript").is(":checked")) {
                            //         $("#encript").removeAttr("checked");
                            //         $('#encript').iCheck('update');
                            //     }
                            //     $("#encript").prop("disabled", true);
                            //     $("#privProtocol").prop("disabled", true);
                            //     $("#authProtocol").prop("disabled", true);
                            //     $("#passAuth").prop("readonly", true);
                            //     $("#passPriv").prop("readonly", true);
                            //     $("#privProtocol").css("opacity", "0.5");
                            //     $("#authProtocol").css("opacity", "0.5");
                            //     }

                        });

                        // $(document).on('change','.editEncryptSelect',function () {
                        //     var enableEncrypt = $(".editEncryptSelect option:selected").val();
                        //
                        //     if(enableEncrypt == 1) {
                        //         $("#privProtocol").removeAttr("disabled");
                        //         $("#authProtocol").removeAttr("disabled");
                        //         $("#passAuth").removeAttr("readonly");
                        //         $("#userName").removeAttr("readonly");
                        //         $("#passPriv").removeAttr("readonly");
                        //         $("#passAuth").removeAttr("disabled");
                        //         $("#passPriv").removeAttr("disabled");
                        //         $("#privProtocol").css("opacity", "1");
                        //         $("#authProtocol").css("opacity", "1");
                        //         $("#passAuth").css("opacity", "1");
                        //         $("#userName").css("opacity", "1");
                        //         $("#passPriv").css("opacity", "1");
                        //     } else {
                        //         $("#privProtocol").prop("disabled", true);
                        //         $("#authProtocol").prop("disabled", true);
                        //         $("#passAuth").prop("readonly", true);
                        //         $("#userName").prop("readonly", true);
                        //         $("#passPriv").prop("readonly", true);
                        //         $("#passAuth").prop("disabled", true);
                        //         $("#passPriv").prop("disabled", true);
                        //         $("#privProtocol").css("opacity", "0.5");
                        //         $("#authProtocol").css("opacity", "0.5");
                        //         $("#passAuth").css("opacity", "0.5");
                        //         $("#userName").css("opacity", "0.5");
                        //         $("#passPriv").css("opacity", "0.5");
                        //     }
                        // });

                        $('#cancelSettingsSNMP1').click(function () {
                            $(".updateSettingsSNMPEdit").validate().resetForm();
                            setTimeout(function () {
                                var version = $("#SNMP_version option:selected").val();
                                $(".privProtocolDiv").show();
                                console.log(version);
                                // if ($("#encript").is(":checked")) {
                                $("#encript").removeAttr("checked");
                                $('#encript').iCheck('update');
                                // }
                                $("#encript").prop("disabled", true);
                                $("#privProtocol").prop("disabled", true);
                                $("#authProtocol").prop("disabled", true);
                                $("#passAuth").prop("readonly", true);
                                $("#userName").prop("readonly", true);
                                $("#passPriv").prop("readonly", true);
                                $("#passAuth").prop("disabled", true);
                                $("#passPriv").prop("disabled", true);
                                $("#privProtocol").css("opacity", "0.5");
                                $("#authProtocol").css("opacity", "0.5");
                                $("#passAuth").css("opacity", "0.5");
                                $("#userName").css("opacity", "0.5");
                                $("#passPriv").css("opacity", "0.5");
                                // if(version == '3'){
                                //     $("#editSettingsSNMPpart1").css("display","block");
                                // }else {
                                //     $("#editSettingsSNMPpart1").css("display","none");
                                // }
                            }, 100)
                        });
                        $('#backSettingsSNMP1').click(function () {
                            location.reload(true);
                        });
                        // click  button.
                        //$('.settingsApplyForEdit').click(function () {
                        //    if( !validationAddSwitch() ) return;
                        //    var id = '#' + $(this).attr('selfFormID');
                        //    var formData = new FormData();
                        //    //formData.append('file', $('input[type=file]', id)[0].files[0]);
                        //    $.each($(id).serializeArray(), function() {
                        //        if(this.value.trim().length > 0 ){
                        //            formData.append(this.name, this.value);
                        //        }
                        //    }); 
                        //    $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
                        //    $.ajax({
                        //        method: "POST",
                        //        processData: false,
                        //        contentType: false,
                        //        url: url,
                        //        data: formData,
                        //        success: function(data){
                        //            $('body').oLoader('hide');
                        //        }
                        //    });
                        //}); 
                    }

                });

            });
            // click edit button end
            $('body').oLoader('hide');

            $('.fa-refresh').click(function () {
                getSwitchsFromDataBase(window.location.href);
            });
            $('.deleteAllSwitch').click(function () {
                var msg = getMssg['remove_device_msg'];
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['remove_msg'];
                var cancelMsg = getMssg['cancel'];
                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    $('.checked').each(function () {
                        var index = $(this).parents().parent().attr('index');
                        var devID = $(this).parents().parent().attr('devid');
                        if (devID != undefined) {
                            removeRAWFromSwitch(devID, index);
                        }
                    });
                });

            });
            $('.deleteAllSescriptor').click(function () {
                // TODO need implement below case for remove all descriptors.
                var titleMsg = getMssg['title_msg'];
                var msg = getMssg['conf_rem_descrip'];
                var rmMsg = getMssg['remove_msg'];
                var cancelMsg = getMssg['cancel'];
                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    $('.checked').each(function () {
                        var id = $(this).parents().parent().attr('tidt');
                        if (id != undefined) {
                            removeRawIni(id);
                        }
                    });

                    //var ip = $('#ip'+index).html();
                    //removeRAWFromSwitch(ip, index);
                });
            });

            $('.removeRAW').click(function () {
                var id = '#' + $(this).attr('ipID');
                var devID = $(this).attr('devid');
                var index = $(this).attr('index');
                var ip = $(id).html();
                var msg = getMssg['remove_device_msg'];
                var titleMsg = getMssg['title_msg'];
                var rmMsg = getMssg['remove_msg'];
                var cancelMsg = getMssg['cancel'];
                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    removeRAWFromSwitch(devID, index);
                });

            });

        }
    });
}

//function initRequiredFields(isEdit) {
//    if(isEdit == undefined) {
//        sufix = "#add";
//    } else {
//        sufix = "#edit";
//    }
//    $(sufix + '_ip_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_ip_format').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_comm_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_pass_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_secname_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_seclevel_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//    $(sufix + '_autopro_error').addClass('for_all_display_none').removeClass('for_all_display_block');
//
//}

function validationAddSwitch() {
    var msgRequired = getMssg['error_message_required'];
    var msgIp = getMssg['error_message_ip'];
    var msgReserved = getMssg['error_message_net_address'];
    var msgEmpty = getMssg['error_message_empty'];
    $(".updateSettingsSNMPEdit").validate({
        rules: {
            ip: {
                required: true,
                validateIpAddress: true,
                validateReservedIp: true
            },
            community: {
                required: true,
                validateIsEmpty: true
            },
            userName: {
                required: true
            },
            passwordAuth: {
                required: true,
                validateIsEmpty: true
            },
            passwordPriv: {
                required: true,
                validateIsEmpty: true
            },
            secname: {
                required: true,
                validateIsEmpty: true
            },
            seclevel: {
                required: true,
                validateIsEmpty: true
            },
            autopro: {
                required: true,
                validateIsEmpty: true
            }
        },
        messages: {
            ip: {
                required: msgRequired,
                validateIpAddress: msgIp,
                validateReservedIp: msgReserved
            },
            community: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            },
            userName: {
                required: msgRequired
            },
            passwordAuth: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            },
            passwordPriv: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            },
            secname: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            },
            seclevel: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            },
            autopro: {
                required: msgRequired,
                validateIsEmpty: msgEmpty
            }

        },
        errorElement: "div",
        errorClass: 'error_message',
        errorPlacement: function (error, element) {
            var placement = $(element).data('error');
            if (placement) {
                $(placement).append(error)
            } else {
                error.insertAfter(element);
            }
        }
    });
    if (!($(".updateSettingsSNMPEdit").valid())) {
        $(this).removeAttr("disabled");
        return false;
    } else {
        return true;
    }
}


function removeRAWFromSwitch(id, index) {
    var data = {action: 'removeSwitch', id: id};
    $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
    $.ajax({
        method: "POST",
        url: url,
        data: data,
        success: function (data) {
            $("body").css("cursor", "wait");
            //var tr1  = '#trHeIndex' + index;
            //var tr2 = '#editsettSNMP'+ index;
            //$(tr1).remove();
            //$(tr2).remove();
            //$('body').oLoader('hide');
            $(".indexDevices").each(function (index) {
                $(this).html(index + 1);
            });
            setTimeout(function () {
                location.reload(true);
            }, 5000);
        }
    });
}


$(document).ready(function () {
    $('.encript').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });


    $('#buttonFind').click(function () {
        var msgIp = getMssg['error_message_ip'];
        var msgStartIp = getMssg['error_message_startip'];
        var msgEndIp = getMssg['error_message_endip'];
        var msgRequired = getMssg['error_message_required'];
        var msgReserved = getMssg['error_message_net_address'];

        $('#rangefinding').validate({
            rules: {
                inputSnmpFindStartIp: {
                    required: true,
                    validateIpAddress: true,
                    validateStartEndIP: {
                        from: "#inputSnmpFindStartIp",
                        to: "#inputSnmpFindEndIp"
                    },
                    validateReservedIp: true
                },

                inputSnmpFindEndIp: {
                    required: true,
                    validateIpAddress: true,
                    validateStartEndIP: {
                        from: "#inputSnmpFindStartIp",
                        to: "#inputSnmpFindEndIp"
                    },
                    validateReservedIp: true
                }
            },
            messages: {
                inputSnmpFindStartIp: {
                    required: msgRequired,
                    validateIpAddress: msgIp,
                    validateStartEndIP: msgStartIp,
                    validateReservedIp: msgReserved
                },

                inputSnmpFindEndIp: {
                    required: msgRequired,
                    validateIpAddress: msgIp,
                    validateStartEndIP: msgEndIp,
                    validateReservedIp: msgReserved
                }
            },
            errorElement: "div",
            errorClass: 'error_message error_msg',
            errorPlacement: function (error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });
        $('#inputSnmpFindStartIp').on('input', function (e) {
            $("#inputSnmpFindEndIp").valid();
        });
        $('#inputSnmpFindEndIp').on('input', function (e) {
            $("#inputSnmpFindStartIp").valid();
        });
        if (!$("#rangefinding").valid()) {
            $('body').css("cursor", "default");
            return false;
        }
        $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
        setTimeout(function () {
            $.ajax({
                async: true,
                cache: false,
                timeout: 30 * 60 * 1000,
                method: "POST",
                url: url,
                data: {
                    action: 'find',
                    startIP: $('#inputSnmpFindStartIp').val(),
                    endIP: $('#inputSnmpFindEndIp').val()
                },
                success: function (data) {
                    $('body').oLoader('hide');
                    setTimeout(function () {
                        location.reload(true);
                    });
                }
            });
        }, 542);

    });
});

function isFileChoose() {
    $('#add_file_error').addClass('for_all_display_none').removeClass('for_all_display_block');
    var f = $('#uploadBtnSNMP')[0].files[0];
    console.log(f);
    if (f == undefined) {
        $('#add_file_error').addClass('for_all_display_block').removeClass('for_all_display_none');
        return false;
    }
    return true;

}

function ifFileIni() {
    $('#add_file_ini_error').addClass('for_all_display_none').removeClass('for_all_display_block');
    var f = $('#uploadBtnSNMP').val();
    var f = f.search(/^.*\.(?:ini)\s*$/ig);
    if (f != 0) {
        $('#add_file_ini_error').addClass('for_all_display_block').removeClass('for_all_display_none');
        return false;
    }
    return true;
}


function addDescriptor(url) {
    if (!isFileChoose()) return;
    if (!ifFileIni()) return;
    var formData = new FormData();
    formData.append('file', $('#uploadBtnSNMP')[0].files[0]);
    $.each($('#addDescriptor').serializeArray(), function () {
        formData.append(this.name, this.value);
    });
    $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
    $.ajax({
        method: "POST",
        url: url,
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            $('body').oLoader('hide');
            try {
                var data = $.parseJSON(data);
                if (data.status == 'error') {

                    swal({
                        title: data.title,
                        text: data.result
                    });
                } else if (data.status == 'ok') {
                    getIniDescriptionsForTable();
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                }

            } catch (e) {
                window.location.href = "error500";
            }
        }
    });
}

function updateDescriptor(url) {
    var formData = new FormData();
    formData.append('file', $('#updateDes')[0].files[0]);
    $.each($('#updateDescriptor').serializeArray(), function () {
        formData.append(this.name, this.value);
    });
    $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
    $.ajax({
        method: "POST",
        url: url,
        data: formData,
        processData: false,
        contentType: false,
        success: function (data) {
            $('body').oLoader('hide');
        }
    });
}

function redirectPost(url, args) {
    var form = '';
    $.each(args, function (key, value) {
        form += '<input type="hidden" name="' + key + '" value="' + value + '">';
    });
    $('<form action="' + url + '" method="POST">' + form + '</form>').appendTo('body').submit();
}

$(document).ready(function () {
    $('.encript').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });
    $('#downloadSNMPDescriptor').click(function () {
        redirectPost(document.location.href, {action: 'downloadDescriptor'});
    });
    $('#ScanButton').click(function () {

        $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
        $.ajax({
            method: "POST",
            url: window.location.href,
            data: {action: 'scan'},
            success: function (data) {
                $('body').oLoader('hide');
                location.reload(true);
            }
        });

    });
});

function getIniDescriptions(url) {
    var data = {action: 'getDescriptions'};
    url = url != undefined ? url : window.location.href;
    $.ajax({
        method: "POST",
        url: url,
        data: data,
        success: function (data) {
            $('#selectDescriptor').html(data);
        }
    });
}

function getAllSwitches(url) {
    var data = {action: 'getAllSwitches'};
    url = url != undefined ? url : window.location.href;
    $.ajax({
        method: "POST",
        url: url,
        data: data,
        success: function (data) {
            if (data != '') {
                var all = getMssg['all'];
                var checkSwitch = getMssg['select_switch'];
                $('.allSwitches').append("<label class='userGroupLabel'>" + checkSwitch + ":<span>*</span></label><br>");
                $('.allSwitches').append("<input type='checkbox' class='switches allSwitchesField'>" + "    " + all, data);
            } else {
                var noAnySwitch = getMssg['no_any_switch'];
                $('.allSwitches').append("<span>" + noAnySwitch + "</span>");
                $('#scaneSwitchNetworkTopolagy').hide();
            }
        }
    });
}

function getIniDescriptionsForTable() {
    var data = {action: 'getDescriptionsForTable'};
    $.ajax({
        method: "POST",
        url: window.location.href,
        data: data,
        success: function (data) {
            if (data == "error") {
                window.location.href = "error500";
            }
            $('#tbodySettingsSNMPDescriptor').html(data);

            $('.fieids').iCheck({
                checkboxClass: 'icheckbox_square-blue',
                increaseArea: '20%' // optional
            });
            $countOfUncheckedss = $('.forFieldsCheckDesc').find("input:checkbox:not(:checked)").length;

            if ($('.forFieldsCheckDesc').find('.fieids').filter(':checked').length != $countOfUncheckedss) {
                $('#allfields').prop('checked', false).iCheck('update');
            }
            $('#allfields').on('ifChecked ifUnchecked', function (event) {

                if (event.type == 'ifChecked') {
                    $('.fieids').iCheck('check');
                    $('.trash-select-desc').css('display', 'block');
                } else {
                    $('.fieids').iCheck('uncheck');
                    $('.trash-select-desc').css('display', 'none');
                }
            });

            $('.fieids').on('ifChecked ifUnchecked', function (event) {
                if (event.type == 'ifChecked') {

                    $(this).closest('tr').css("background-color", "#EDF1F2");
                    $('.trash-select-desc').css('display', 'block');
                    if ($('.forFieldsCheckDesc').find('.fieids').filter(':checked').length == $countOfUncheckedss) {
                        $('#allfields').prop('checked', true).iCheck('update');
                    }
                } else {

                    if ($('#allfields').is(':checked')) {
                        $('#allfields').prop('checked', false).iCheck('update');
                    }

                    if (!$('.fieids').is(':checked')) {

                        $('.trash-select').css('display', 'none');
                        $('#allfields').iCheck('uncheck');
                    }
                    $(this).closest('tr').css("background-color", "#FFFFFF");
                }
            });

            if ($countOfUncheckedss == 0) {
                $('.checkOfSNMP').css('display', 'none');
            }
            // Click edit start
            $('.editDescriptor').click(function () {
                var id = $(this).attr('tid');
                console.log(id);
                $.ajax({
                    method: "POST",
                    url: window.location.href + '/updatedDescription',
                    data: {id: id},
                    success: function (data) {
                        $('.container_top').html(data);
                        $(document).on('change', '.inputFileUpdateDescriptor', function () {
                            var id = '#' + $(this).attr('inputID');
                            $(id).val($(this).val());
                        });
                        $('.updateDiscriptor').click(function () {
                            var formID = '#' + $(this).attr('formID');
                            var inputFileID = '#' + $(this).attr('inputFileID');
                            var formData = new FormData();
                            formData.append('file', $(inputFileID)[0].files[0]);
                            $.each($(formID).serializeArray(), function () {
                                formData.append(this.name, this.value);
                            });
                            $('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
                            $.ajax({
                                method: "POST",
                                url: url,
                                data: formData,
                                processData: false,
                                contentType: false,
                                success: function (data) {
                                    $('body').oLoader('hide');
                                }
                            });
                        });

                    }
                })

            });
            // Click edit end 
            $('.fa-download-ini').click(function () {
                var id = $(this).attr('tIdT');
                redirectPost(document.location.href, {action: 'downloadDescriptor', id: id});
            });
            $('.remove_raw_ini').click(function () {
                var id = $(this).attr('tIdT');
                var titleMsg = getMssg['title_msg'];
                var msg = getMssg['conf_rem_descrip'];
                var rmMsg = getMssg['remove_msg'];
                var cancelMsg = getMssg['cancel'];
                swal({
                    title: titleMsg,
                    text: msg,
                    showCancelButton: true,
                    closeOnConfirm: true,
                    confirmButtonText: rmMsg,
                    cancelButtonText: cancelMsg,
                    confirmButtonColor: "#008DA9"
                }, function () {
                    removeRawIni(id);
                });
            });
        }
    });
}


function removeRawIni(id) {
    //$('body').oLoader({image: '/assets/js/oLoder/images/ownageLoader/myloader.gif'});
    $.ajax({
        method: "POST",
        url: window.location.href,
        data: {action: 'removeDescriptor', id: id},
        success: function (result) {

            if (result == 'false') {
                var fail = getMssg['failed_remove_descriptor'];
                $("#failRemoveDescriptor").empty();
                $("#failRemoveDescriptor").html(fail);
                $("#failRemoveDescriptor").addClass("errorMessage");
                $("body").css("cursor", "default");
            } else {
                $("body").css("cursor", "wait");
                //$('tr[tidt="' + id + '"]').remove();
                //$('body').oLoader('hide');
                //$(".indexDescriptor").each(function (index) {
                //    $(this).html(index + 1);
                //});
                setTimeout(function () {
                    location.reload(true);
                }, 5000);
            }
        }
    });

}

$(document).ready(function () {
    $('.encript').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });
    var ptrDescriptor = $('.fieldsetSettingsSNMP');
    var ptrSettingsSNMPdiv = $('#addSwitchSection');
    var ptrShowSwitchTableSection = $('#showSwitchTableSection');
    var ptrBackSettingsSNMPButton = $('#backSettingsSNMP');
    ptrDescriptor.hide();
    $('#showDescritor').click(function () {
        ptrDescriptor.show();
        ptrSettingsSNMPdiv.hide();
        ptrShowSwitchTableSection.hide();
        ptrBackSettingsSNMPButton.addClass('for_all_display_block').removeClass('for_all_display_none');
    });

    ptrBackSettingsSNMPButton.click(function () {
        ptrDescriptor.hide();
        ptrSettingsSNMPdiv.show();
        ptrShowSwitchTableSection.show();
        ptrBackSettingsSNMPButton.addClass('for_all_display_none').removeClass('for_all_display_black');

    });
    $('#cancelSettingsSNMP').click(function () {
        $("div.error_message").remove();
        setTimeout(function () {
            var version = $("#SNMP_version option:selected").val();
            // if ($("#encript").is(":checked")) {
            $("#encript").removeAttr("checked");
            $('#encript').iCheck('update');
            // }
            $(".privProtocolDiv").show();
            $("#encript").prop("disabled", true);
            $("#privProtocol").prop("disabled", true);
            $("#authProtocol").prop("disabled", true);
            $("#passAuth").prop("readonly", true);
            $("#userName").prop("readonly", true);
            $("#passPriv").prop("readonly", true);
            $("#userName").prop("disabled", true);
            $("#passAuth").prop("disabled", true);
            $("#passPriv").prop("disabled", true);
            $("#privProtocol").css("opacity", "0.5");
            $("#authProtocol").css("opacity", "0.5");
            $("#passAuth").css("opacity", "0.5");
            $("#userName").css("opacity", "0.5");
            $("#passPriv").css("opacity", "0.5");
            // if(version == 'v3'){
            // $("#settingsSNMPpart2").css("display","block");
            // }else {
            // $("#settingsSNMPpart2").css("display","none");
            // }
        }, 100)
    });
});


function getCookie() {
    var cname = "language=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(cname) == 0) {
            return c.substring(cname.length, c.length);
        }
    }
    return null;
}

var G_LANGUAGE = null;
$(document).ready(function () {
    G_LANGUAGE = getCookie();
    checkLanguage();
});

function checkLanguage() {
    var langue = getCookie();
    if (G_LANGUAGE !== langue) {
        G_LANGUAGE = langue;
        location.reload();
    }
    setTimeout(checkLanguage, 100);
}

$(document).on("click", ".removeFiles", function () {

    var titleMsg = getMssg['title_msg'];
    var rmMsg = getMssg['remove_msg'];
    var cancelMsg = getMssg['cancel'];
    var msg = getMssg['msg_remove_config'];
    var str = $(this).find("input[name='removeLog']").val();
    var path = str.substring(0, str.lastIndexOf("\/") + 1);
    var fileNameForDb = $(this).find("input[name='removeLogPath']").val();
    swal({
        title: titleMsg,
        text: msg,
        showCancelButton: true,
        closeOnConfirm: true,
        confirmButtonText: rmMsg,
        cancelButtonText: cancelMsg,
        confirmButtonColor: "#008DA9"
    }, function (isConfirm) {
        if (isConfirm) {
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
                data: {
                    'functionName': 'removeLogFile',
                    'fileName': str,
                    'dirPath': path,
                    'fileNameForDb': fileNameForDb,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    location.reload(true);
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });
});

function ForLogFiles() {
    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function (event) {

        if (event.type == 'ifChecked') {
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {
            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $('.fieids').on('ifChecked ifUnchecked', function (event) {
        var $FileID = $(this).closest('tr').find("input[name='removeLog']").val();
        if (event.type == 'ifChecked') {
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');

            if (!$(this).hasClass('allFields')) {
                $checked_array.push($FileID);
            }
            if ($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds) {
                $('#all_fields').prop('checked', true).iCheck('update');
            }
            console.log($checked_array);
        } else {

            if ($('#all_fields').is(':checked')) {
                $('#all_fields').prop('checked', false).iCheck('update');
            }

            if (!$('.forFieldsCheck').find('.fieids').is(':checked')) {
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($FileID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
            console.log($checked_array);

        }
    });

    Array.prototype.removeByVal = function (val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".trash20", function () {
        var msg = getMssg['conf_rem_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function () {
            removeLogFiles($checked_array);
        });
    });

    function removeLogFiles(fileName) {
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_remove_config'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }),
            // function(isConfirm) {
            // if(isConfirm){
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
                data: {
                    'functionName': 'DeleteSomeLogFiles',
                    'fileName': fileName,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                    location.reload(true);
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        // }
        // });
    }
}

function ForCustomLogFiles() {
    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function (event) {

        if (event.type == 'ifChecked') {
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {
            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $('.fieids').on('ifChecked ifUnchecked', function (event) {
        var $FileID = $(this).closest('tr').find("input[name='removeLog']").val();
        if (event.type == 'ifChecked') {
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');

            if (!$(this).hasClass('allFields')) {
                $checked_array.push($FileID);
            }
            if ($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds) {
                $('#all_fields').prop('checked', true).iCheck('update');
            }
            console.log($checked_array);
        } else {

            if ($('#all_fields').is(':checked')) {
                $('#all_fields').prop('checked', false).iCheck('update');
            }

            if (!$('.forFieldsCheck').find('.fieids').is(':checked')) {
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($FileID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
            console.log($checked_array);

        }
    });

    Array.prototype.removeByVal = function (val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".trash20", function () {
        var msg = getMssg['conf_rem_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function () {
            removeCustomLogFiles($checked_array);
        });
    });

    function removeCustomLogFiles(fileName) {
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_remove_config'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }),
            // function(isConfirm) {
            // if(isConfirm){
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
                data: {
                    'functionName': 'DeleteSomeCustomLogFiles',
                    'fileName': fileName,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                    location.reload(true);
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        // }
        // });
    }
}


function ForDumpFiles() {
    $checked_array = new Array();
    $countOfUncheckeds = $('.forFieldsCheck').find("input:checkbox:not(:checked)").length;
    $('.fieids').iCheck({
        checkboxClass: 'icheckbox_square-blue',
        increaseArea: '20%' // optional
    });

    $('#all_fields').on('ifChecked ifUnchecked', function (event) {

        if (event.type == 'ifChecked') {
            $('.fieids').iCheck('check');
            $('.trash-select').css('display', 'block');
        } else {
            $('.fieids').iCheck('uncheck');
            $('.trash-select').css('display', 'none');
        }
    });

    $('.fieids').on('ifChecked ifUnchecked', function (event) {
        var $FileID = $(this).closest('tr').find("input[name='removeLog']").val();
        if (event.type == 'ifChecked') {
            $(this).closest('tr').css("background-color", "#EDF1F2");
            $('.trash-select').css('display', 'block');

            if (!$(this).hasClass('allFields')) {
                $checked_array.push($FileID);
            }
            if ($('.forFieldsCheck').find('.fieids').filter(':checked').length == $countOfUncheckeds) {
                $('#all_fields').prop('checked', true).iCheck('update');
            }
            console.log($checked_array);
        } else {

            if ($('#all_fields').is(':checked')) {
                $('#all_fields').prop('checked', false).iCheck('update');
            }

            if (!$('.forFieldsCheck').find('.fieids').is(':checked')) {
                $('.trash-select').css('display', 'none');
                $('#all_fields').iCheck('uncheck');
                $checked_array.length = 0;
//                console.log($checked_array);
            }
            $checked_array.removeByVal($FileID);
//            console.log($checked_array);
            $(this).closest('tr').css("background-color", "#FFFFFF");
            console.log($checked_array);

        }
    });

    Array.prototype.removeByVal = function (val) {
        for (var i = 0; i < this.length; i++) {
            if (this[i] === val) {
                this.splice(i, 1);
                i--;
            }
        }
        return this;
    }

    $(document).on("click", ".trash20", function () {
        var msg = getMssg['conf_rem_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }, function () {
            removeDumpFiles($checked_array);
        });
    });

    function removeDumpFiles(fileName) {
        var titleMsg = getMssg['title_msg'];
        var rmMsg = getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
        var msg = getMssg['msg_remove_config'];

        swal({
            title: titleMsg,
            text: msg,
            showCancelButton: true,
            closeOnConfirm: true,
            confirmButtonText: rmMsg,
            cancelButtonText: cancelMsg,
            confirmButtonColor: "#008DA9"
        }),
            // function(isConfirm) {
            // if(isConfirm){
            $.ajax({
                type: "POST",
                url: $basepath + 'secureFiles/actions/ajaxActions/functions.php',
                data: {
                    'functionName': 'DeleteSomeDumpFiles',
                    'fileName': fileName,
                    'fromApp': true
                },
                async: true,
                success: function (result) {
                    setTimeout(function () {
                        location.reload(true);
                    }, 1000);
                    location.reload(true);
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        // }
        // });
    }
}

class scrolingConf {
    constructor() {
        if (scrolingConf.num == undefined) {
            scrolingConf.num = 20;
            scrolingConf.numDev = 10;
            scrolingConf.inProces = false;
            scrolingConf.inProcesDev = false;
        }
    }
}

class scrolingDevices {
    constructor() {
        if (scrolingDevices.countDev == undefined) {
            // scrolingDevices.countDev = $('.pagelimit').find('.active').data('row');
            scrolingDevices.countDev = 10;
            scrolingDevices.inProcesForDev = false;
        }
    }
}

function download(filename) {
    var element = document.createElement('a');
    element.setAttribute('href', filename);
    element.setAttribute('download', "file.xlsx");

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}

$(document).on("click", "#downloadDevices", function () {
    $("#downloadLoader").show();
    $.ajax({
        type: "POST",
        url: $basepath + 'secureFiles/actions/import_devices_information.php',
        data: {
            'fromApp': true,
            'actionName': "downloadFile"
        },
        success: function (result) {

            // var text = document.getElementById("text-val").value;
            var filename = result;

            download(filename);
            $("#downloadLoader").hide();
            setTimeout(function () {
                $.ajax({
                    type: "POST",
                    url: $basepath + 'secureFiles/actions/import_devices_information.php',
                    data: {
                        'fromApp': true,
                        'actionName': "delateFile"
                    },
                    success: function (result) {
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                })
            }, 10000)
        },
        error: function (xhr, status, error) {
            document.location.href = $basepath + '500';
        }
    });
})

function scrolled(o, k) {
    if (o.offsetHeight + o.scrollTop == o.scrollHeight) {
        var devInfo = $("input[name='devInfo']").val();
        var searchVal = $('.searchType option:selected').val();
        var numberDev = o.childNodes[1].value;
        var numDev = Number(numberDev);
        var model = $("input[name='deviceGroupingModel']").val();
        var ip_mask = $("input[name='deviceGroupingIpMask']").val();
        var firmware = $("input[name='deviceGroupingFirmware']").val();
        var manufacturer = $("input[name='deviceGroupingManufacturer']").val();
        groupId = k;

        if (model != '' || ip_mask != '' || firmware != '' || manufacturer != '') {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/devicesForGroup.php",
                data: {
                    'numDev': numDev,
                    'model': model,
                    'ip_mask': ip_mask,
                    'firmware': firmware,
                    'manufacturer': manufacturer,
                    'groupId': groupId,
                    'fromApp': true
                },
                beforeSend: function () {
                    scrolingConf.inProcesDev = true
                },
                async: false,
                success: function (data) {
                    if (data == 1) {
                        return false;
                    } else {
                        $('.devScrol' + groupId).append(data);

                        scrolingConf.inProcesDev = false;
                        numDev += 10;
                        o.childNodes[1].value = '';
                        o.childNodes[1].value = numDev;
                    }
                }
            });
        } else {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/devicesForGroup.php",
                data: {
                    'numDev': numDev,
                    'searchVal': searchVal,
                    'devInfo': devInfo,
                    'groupId': groupId,
                    'fromApp': true
                },
                beforeSend: function () {
                    scrolingConf.inProcesDev = true
                },
                async: false,
                success: function (data) {
                    if (data == 1) {
                        return false;
                    } else {
                        $('.devScrol' + groupId).append(data);

                        scrolingConf.inProcesDev = false;
                        numDev += 10;
                        o.childNodes[1].value = '';
                        o.childNodes[1].value = numDev;
                    }
                }
            });
        }
    }
}

