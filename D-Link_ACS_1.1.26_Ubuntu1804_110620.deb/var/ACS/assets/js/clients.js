$basepath = $('#basepath').data('bpath');



var idClient ;

function drop(ev, clientId) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("Text");

    $("input[name='clientID']").each(function () {
        if ($(this).val() == clientId) {
            $(this).parent().parent().removeClass("activeGr");
        }
    });
    if(data.length > 0){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                data: {
                    'deviceID': data,
                    'clientID': clientId,
                    'actionName': "changeClient",
                    'fromApp':true
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = 'login';
                    } else if (result == 'true') {
                        var success = getMssg["connect_succeed"];
                        $("#failAddClient").empty();
                        $("#failAddClient").html(success);
                        $("#failAddClient").removeClass("errorMessage");
                        $("#failAddClient").addClass("infoMessage");
                        $("body").css("cursor", "default");
                        setTimeout(function () {
                            $(".eachClient").removeClass("clickedGr");
                            $(this).parent().parent().addClass("clickedGr");
                            $("body").css("cursor", "wait");
                            var clientID = idClient;
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheClient.php",
                                data: {
                                    'clientID': clientID,
                                    'page': 1,
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if(result=='logged_out'){
                                        document.location.href = $basepath + 'login';
                                    } else {
                                        $("body").css("cursor", "default");
                                        $(".forEachGroup").empty();
                                        $(".forEachGroup").html(result);
                                    }
                                },
                                error: function(xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }, 100);
                    } else {
                        var faild = getMssg["action_failed"];
                        $("#failAddClient").empty();
                        $("#failAddClient").html(faild);
                        $("#failAddClient").removeClass("infoMessage");
                        $("#failAddClient").addClass("errorMessage");
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
    }

}

function allowDrop(ev, clientId) {
    ev.preventDefault();
    $("input[name='clientID']").each(function () {
        if ($(this).val() == clientId) {
            $(this).parent().parent().addClass("activeGr");
        }
    })
}

function removeDrop(ev, clientId) {
    ev.preventDefault();
    $("input[name='clientID']").each(function () {
        if ($(this).val() == clientId) {
            $(this).parent().parent().removeClass("activeGr");
        }
    })
}

function getNotEmptyRowsCount(sortedVal,clientInfo,searchVal){
    var resultAction='';
    $("body").css("cursor", "wait");
    $.ajax({
        type: "POST",
        url: $basepath + "secureFiles/actions/ajaxActions/getNotEmptyRowsCount.php",
        data: {
            'clientInfo':clientInfo,
            'sortedVal': sortedVal,
            'searchVal':searchVal,
            'fromApp':true
        },
        async: false,
        success: function (result) {
            resultAction=result;
        },
        error: function(xhr, status, error) {
            resultAction='error';
        }
    });
    return resultAction;

}

function changeSortstatus(sortOption){
    var clientInfo = $("input[name='clientInfo']").val();
    var searchVal = $('.searchType option:selected').val();
    var resultAction=getNotEmptyRowsCount(sortOption,clientInfo,searchVal);
 //   alert(resultAction);
    if(resultAction=='logged_out'){
        document.location.href = $basepath + 'login';
    } else  if(resultAction=='error'){
        document.location.href = $basepath + '500';
    }  else if(resultAction==0){

if(sortOption=='patronymic_name') {
    $(".sortClient option[value='patronymic_name']").attr("disabled", "disabled");
}else if(sortOption=='address'){

    $(".sortClient option[value='address']").attr("disabled", "disabled");
}

    } else {
        if(sortOption=='patronymic_name') {
            $(".sortClient option[value='patronymic_name']").removeAttr("disabled");
        }else if(sortOption=='address'){
            $(".sortClient option[value='address']").removeAttr("disabled");
        }

    }

}
function sortByChange(searchedVal,clientInfo,searchVal,previous){

    $("body").css("cursor", "wait");
   var resultAction=getNotEmptyRowsCount(searchedVal,clientInfo,searchVal);

//alert(resultAction);

    if(resultAction=='logged_out'){
        document.location.href = $basepath + 'login';
    } else  if(resultAction=='error'){
        document.location.href = $basepath + '500';
    }  else if(resultAction==0){

        if(previous==searchedVal){
            //disable the
            // var dd=$('.sortClient option[value=patronymic_name]').val();
            // alert(dd);
            if(previous=='address'){
                $(".sortClient option[value='address']").attr("disabled","disabled");

            }else if(previous=='patronymic_name'){
                $(".sortClient option[value='patronymic_name']").attr("disabled","disabled");

            }


            previous='first_name';
            searchedVal=previous;
            var sortBy=$(".sort_client_by").attr("id");
            if(sortBy=="DESC"){
                sortBy="ASC";
            }else {
                sortBy="DESC";
            }
            searchedVal=searchedVal+":"+sortBy;
            $("body").css("cursor", "wait");
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/sortedClients.php",
                data: {
                    'clientInfo':clientInfo,
                    'sortedVal': searchedVal,
                    'searchVal':searchVal,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if(result=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        $("#forClients").empty();
                        $("#forClients").html(result);
                        $(".forEachGroup").empty();
                        $("body").css("cursor", "default");
}
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });

        }


        $('.sortClient').val(previous);
        $("body").css("cursor", "default");
    } else {

        if(previous=='address'){
            $(".sortClient option[value='address']").removeAttr("disabled");

        }else if(previous=='patronymic_name'){
            $(".sortClient option[value='patronymic_name']").removeAttr("disabled");

        }

        var sortBy=$(".sort_client_by").attr("id");
        if(sortBy=="DESC"){
            sortBy="ASC";
        }else {
            sortBy="DESC";
        }
        searchedVal=searchedVal+":"+sortBy;
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/sortedClients.php",
            data: {
                'clientInfo':clientInfo,
                'sortedVal': searchedVal,
                'searchVal':searchVal,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forClients").empty();
                    $("#forClients").html(result);
                    $(".forEachGroup").empty();
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    }
}

$(document).ready(function () {
    var token_cookie = $("input[name='token_cookie']").val();

    $('#clientpopover').popover({
        html : true,
        content: function() {
            return $('.addClientPopover').html();
        }
    });

    $('#clientpopover').on('hidden.bs.popover', function () {
        $('#failAddClient').empty();
    });

    $('#clientpopover').on('shown.bs.popover', function () {
        $('.forAddClient').reset();
    });


    $(document).on('click','#searchClient', function () {
        searchClient();
    });

    $(".search-button").on("keypress","input[name='clientInfo']",function(e){
        var key = e.which;
        if(key == 13) { // the enter key code
            searchClient();
            return false;
        }
    });

    function searchClient(){
        var searchVal = $('.searchType option:selected').val();
        var clientInfo = $("input[name='clientInfo']").val();
        $("body").css("cursor", "wait");
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchClients.php",
            data: {
                'searchVal': searchVal,
                'clientInfo': clientInfo,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forClients").empty();
                    $("#forClients").html(result);
                    $(".forEachGroup").empty();
                    $("body").css("cursor", "default");
                    setDefaultSortValsClients($(".sortClient"));
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        $("#failAddClient").empty();
    }

    function showInputs(th,id) {
        var havePerm = $('#havePermission').val();
        if(havePerm == 'true'){
//            if ($(this).find("input").length == 0) {
            $(".forChange").hide();
            $(".defaultText").show();
            $(th).find(".forChange").show();
            $(th).find(".defaultText").hide();
            var currName = $(th).find(".defaultText").html();
            $(th).find("input").val(currName);
            $(th).find("a").attr('id',id);
//            }
        }
    }
    
    $(document).on("dblclick", ".clName", function () {
        var th = $(this);
        showInputs(th,'changeClientName');
    });
    
    $(document).on("dblclick", ".clSurName", function () {
        var th = $(this);
        showInputs(th,'changeClientSName');
    });
    
    $(document).on("dblclick", ".clAddress", function () {
        var th = $(this);
        showInputs(th,'changeClientAddress');
    });
    
    $(document).on("dblclick", ".clEmail", function () {
        var th = $(this);
        showInputs(th,'changeClientEmail');
    });

    $(document).on("dblclick", ".clPartName", function () {
        var th = $(this);
        showInputs(th,'changeClientPatronymicName');
    });

    $(document).on("dblclick", ".clContNum", function () {
        var th = $(this);
        showInputs(th,'changeClientContractNumber');
    });
    
    $(document).on("click",".changeData",function(e) {
        e.stopPropagation(); // watch out here...
    });
    
    $(document).on("click",".defaultText",function(e) {
        e.stopPropagation(); // watch out here...
    });

    
    $(document).on("click", "#resetClient", function (e){
        var target = e.target?e.target:e.srcElement;
        if (target.id == 'changeClientImg'){
            return false;
        } else{
            $(".forChange").hide();
            $(".defaultText").show();
        }
        
//        var e = e || window.e;
//        var tagName = (e.target || e.srcElement).tagName;
        
//        alert(target);
        if (target.id == 'clientDev'){
            return false;
        } else if(!$(".forEachGroup").is(':empty')){
            $(".forEachGroup").empty();
        }
    });
    
    $(document).on("click","#searchedDevice",function(e) {
        e.stopPropagation(); // watch out here...
    });
    
    $(document).on("click", "#changeClientName", function () {
        var th = $(this);
        var clientName = $(this).parent().find("input").val().trim();
        if (clientName.indexOf(" ") < 0 && clientName != '') {
            $("body").css("cursor", "wait");
            var clientID = $(this).closest("tr").find("input[name='clientID']").val();
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
                data: {
                    'clientName': clientName,
                    'clientSurName': 'empty1',
                    'clientAddress': 'empty1',
                    'clientEmail': 'empty1',
                    'clientPatName': 'empty1',
                    'clientContNumber': 'empty1',
                    'cID': clientID,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        th.closest("td").find('.defaultText').html(clientName);
                        $(".forChange").hide();
                        $(".defaultText").show();
                        $("body").css("cursor", "default");
                        $("#failAddClient").empty();

                        var sortVal = $('.sortClient option:selected').val();
                        if (sortVal == 'first_name') {

                            $(".sortClient").change();
                        }
                    } else {
                        var faild = getMssg['action_failed'];
                        $("#failAddClient").empty();
                        $("#failAddClient").removeClass("infoMessage");
                        $("#failAddClient").addClass("errorMessage");
                        $("#failAddClient").html(faild);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else {
            var faild = getMssg['client_required_fields'];
            $("#failAddClient").empty();
            $("#failAddClient").removeClass("infoMessage");
            $("#failAddClient").addClass("errorMessage");
            $("#failAddClient").html(faild);
            $("body").css("cursor", "default");
        }
    });

    
    $(document).on("click", "#changeClientSName", function () {
        var th = $(this);
        var clientSName = $(this).parent().find("input").val();
        if (clientSName.indexOf(" ") < 0 && clientSName != '') {
            $("body").css("cursor", "wait");
            var clientID = $(this).closest("tr").find("input[name='clientID']").val();
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
                data: {
                    'clientName': 'empty1',
                    'clientSurName': clientSName,
                    'clientAddress': 'empty1',
                    'clientEmail': 'empty1',
                    'clientPatName': 'empty1',
                    'clientContNumber': 'empty1',
                    'cID': clientID,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        th.closest("td").find('.defaultText').html(clientSName);
                        $(".forChange").hide();
                        $(".defaultText").show();
                        $("body").css("cursor", "default");
                        $("#failAddClient").empty();

                        var sortVal = $('.sortClient option:selected').val();
                        if (sortVal == 'sur_name') {

                            $(".sortClient").change();
                        }
                    } else {
                        var faild = getMssg['action_failed'];
                        $("#failAddClient").empty();
                        $("#failAddClient").removeClass("infoMessage");
                        $("#failAddClient").addClass("errorMessage");
                        $("#failAddClient").html(faild);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else {
            var faild =  getMssg['client_required_fields'];
            $("#failAddClient").empty();
            $("#failAddClient").removeClass("infoMessage");
            $("#failAddClient").addClass("errorMessage");
            $("#failAddClient").html(faild);
            $("body").css("cursor", "default");
        }
    });
    
    $(document).on("click", "#changeClientAddress", function () {
        var th = $(this);
        var clientAddress = $(this).parent().find("input").val();
        $("body").css("cursor", "wait");
        var clientID = $(this).closest("tr").find("input[name='clientID']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
            data: {
                'clientName': 'empty1',
                'clientSurName': 'empty1',
                'clientAddress': clientAddress,
                'clientEmail': 'empty1',
                'clientPatName': 'empty1',
                'clientContNumber': 'empty1',
                'cID': clientID,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    th.closest("td").find('.defaultText').html(clientAddress);
                    $(".forChange").hide();
                    $(".defaultText").show();
                    $("body").css("cursor", "default");
                    $("#failAddClient").empty();

                    var sortVal = $('.sortClient option:selected').val();
                    if (sortVal == 'address') {

                    $(".sortClient").change();
                }else {
                        changeSortstatus("address");
                    }
                    $("body").css("cursor", "default");

                } else {
                    var faild = getMssg['action_failed'];
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("infoMessage");
                    $("#failAddClient").addClass("errorMessage");
                    $("#failAddClient").html(faild);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#changeClientPatronymicName", function () {
        var th = $(this);
        var clientPatName = $(this).parent().find("input").val();
        $("body").css("cursor", "wait");
        var clientID = $(this).closest("tr").find("input[name='clientID']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
            data: {
                'clientName': 'empty1',
                'clientSurName': 'empty1',
                'clientAddress': 'empty1',
                'clientEmail': 'empty1',
                'clientPatName': clientPatName,
                'clientContNumber': 'empty1',
                'cID': clientID,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    th.closest("td").find('.defaultText').html(clientPatName);
                    $(".forChange").hide();
                    $(".defaultText").show();
                    $("body").css("cursor", "default");
                    $("#failAddClient").empty();

                    var sortVal = $('.sortClient option:selected').val();
                    if (sortVal == 'patronymic_name') {
//var previous='first_name';
                       $(".sortClient").change();
                    } else {

                        changeSortstatus("patronymic_name");

                            }
                    $("body").css("cursor", "default");
                } else {
                    var faild = getMssg['action_failed'];
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("infoMessage");
                    $("#failAddClient").addClass("errorMessage");
                    $("#failAddClient").html(faild);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("click", "#changeClientContractNumber", function () {
        var th = $(this);
        var clientContNumber = $(this).parent().find("input").val();
        $("body").css("cursor", "wait");
        var clientID = $(this).closest("tr").find("input[name='clientID']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
            data: {
                'clientName': 'empty1',
                'clientSurName': 'empty1',
                'clientAddress': 'empty1',
                'clientEmail': 'empty1',
                'clientPatName': 'empty1',
                'clientContNumber': clientContNumber,
                'cID': clientID,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else if (result == 'true') {
                    th.closest("td").find('.defaultText').html(clientContNumber);
                    $(".forChange").hide();
                    $(".defaultText").show();
                    $("body").css("cursor", "default");
                    $("#failAddClient").empty();
                } else {
                    var faild = getMssg['action_failed'];
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("infoMessage");
                    $("#failAddClient").addClass("errorMessage");
                    $("#failAddClient").html(faild);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
    $(document).on("click", "#changeClientEmail", function () {
        var th = $(this);
        var clientEmail = $(this).parent().find("input").val();
        $("body").css("cursor", "wait");
        var clientID = $(this).closest("tr").find("input[name='clientID']").val();
        if(clientEmail == ""){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
                data: {
                    'clientName': 'empty1',
                    'clientSurName': 'empty1',
                    'clientAddress': 'empty1',
                    'clientEmail': clientEmail,
                    'clientPatName': 'empty1',
                    'clientContNumber': 'empty1',
                    'cID': clientID,
                    'fromApp':true
                },
                async: false,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else if (result == 'true') {
                        th.closest("td").find('.defaultText').html(clientEmail);
                        $(".forChange").hide();
                        $(".defaultText").show();
                        $("body").css("cursor", "default");
                        $("#failAddClient").empty();
                    } else {
                        var faild = getMssg['action_failed'];
                        $("#failAddClient").empty();
                        $("#failAddClient").removeClass("infoMessage");
                        $("#failAddClient").addClass("errorMessage");
                        $("#failAddClient").html(faild);
                        $("body").css("cursor", "default");
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else {
            var resEmail="";
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/checkEmail.php",
                data: { 'email': clientEmail ,'fromApp':true},
                async: false,
                success: function (data) {
                    if(data=='logged_out'){
                        document.location.href = $basepath + 'login';
                    } else {
                        resEmail = data;
                    }
                },
                error: function(xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });

            if (resEmail != '') {
                $("#failAddClient").empty();
                $("#failAddClient").removeClass("infoMessage");
                $("#failAddClient").addClass("errorMessage");
                $("#failAddClient").html(resEmail);
                $("body").css("cursor", "default");
            } else {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/changeClient.php",
                    data: {
                        'clientName': 'empty1',
                        'clientSurName': 'empty1',
                        'clientAddress': 'empty1',
                        'clientEmail': clientEmail,
                        'clientPatName': 'empty1',
                        'clientContNumber': 'empty1',
                        'cID': clientID,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else if (result == 'true') {
                            th.closest("td").find('.defaultText').html(clientEmail);
                            $(".forChange").hide();
                            $(".defaultText").show();
                            $("body").css("cursor", "default");
                            $("#failAddClient").empty();
                        } else {
                            var faild = getMssg['action_failed'];
                            $("#failAddClient").empty();
                            $("#failAddClient").removeClass("infoMessage");
                            $("#failAddClient").addClass("errorMessage");
                            $("#failAddClient").html(faild);
                            $("body").css("cursor", "default");
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        }
    });
    
    $(document).on('click','#addClientClick', function () {
        var msgRequired = getMssg['error_message_required'];
        var msgNoSpaces = getMssg['name_required_field'];
        var msgInvalidEmail = getMssg['invalid_email'];
        $(".forAddClient").validate({
            rules: {
                firstName: {
                    required: true,
                    noSpace: true
                },
                surName: {
                    required: true,
                    noSpace: true
                },
                email: {
                    email: true
                },
            },

            messages: {
                firstName: {
                    required: msgRequired,
                    noSpace: msgNoSpaces
                },
                surName: {
                    required: msgRequired,
                    noSpace: msgNoSpaces
                },
                email: {
                    email: msgInvalidEmail
                },

            },
            errorElement: "div",
            errorClass: 'error_message',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    error.insertAfter(element);
                }
            }
        });

        if(!($(".forAddClient").valid())) {
            return false;
        }

        var fName = $("input[name='firstName']").val().trim();
        var sName = $("input[name='surName']").val().trim();
        var email = $("input[name='email']").val().trim();
        var address = $("input[name='address']").val().trim();
        var patronymicName = $("input[name='patronymicName']").val().trim();
        var contractNumber = $("input[name='contractNumber']").val().trim();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/api/acs_api.php",
            data: {
                'method': 'addClient',
                'token': token_cookie,
                'firstName': fName,
                'surName': sName,
                'email': email,
                'address': address,
                'patronymicName': patronymicName,
                'contractNumber': contractNumber
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    location.reload(true);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        
        /*if (fName.indexOf(" ") < 0 && fName != '' && sName.indexOf(" ") < 0 && sName != '') {
            var email = $("input[name='email']").val();
            var address = $("input[name='address']").val();
            var patronymicName = $("input[name='patronymicName']").val();
            var contractNumber = $("input[name='contractNumber']").val();
            if (email != '') {
                var chEmm = '';
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/checkEmail.php",
                    data: { 'email': email,'fromApp':true },
                    async: false,
                    success: function (data) {
                        if(data=='logged_out'){
                            document.location.href = $basepath + 'login';
                        } else {
                            chEmm = data;
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
                if (chEmm != '') {
		    if (($("#forClients").html()).search("<table") == -1) {
			$("#forClients").html("");
		    }
                    $("#failAddClient").empty();
                    $("#failAddClient").removeClass("infoMessage");
                    $("#failAddClient").addClass("errorMessage");
                    $("#failAddClient").html(chEmm);
                    $("body").css("cursor", "default");
                } else {
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/addClient.php",
                        data: {
                            'firstName': fName,
                            'surName': sName,
                            'email': email,
                            'address': address,
                            'patronymicName': patronymicName,
                            'contractNumber': contractNumber,
                            'fromApp':true
                        },
                        async: false,
                        success: function (result) {
                            if(result=='logged_out'){
                                document.location.href = $basepath + 'login';
                            } else {
                                location.reload(true);
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                }
            } else {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/addClient.php",
                    data: {
                        'firstName': fName,
                        'surName': sName,
                        'email': email,
                        'address': address,
                        'patronymicName': patronymicName,
                        'contractNumber': contractNumber,
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if(result=='logged_out'){
                            document.location.href = $basepath + 'login';
                        } else {
                            location.reload(true);
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            }
        } else {
	    // if (($("#forClients").html()).search("<table") == -1) {
        // $("#forClients").html("");
        // }
            var fail = getMssg['client_required_fields'];
            $("#failAddClient").empty();
            $("#failAddClient").removeClass("infoMessage");
            $("#failAddClient").addClass("errorMessage");
            $("#failAddClient").html(fail);
            $("body").css("cursor", "default");
        }*/
    });
    
// --------------------- pagination  ------------------------------------------   
    
    $(document).on("click", ".eachClientPage", function () {
        $("body").css("cursor", "wait");
        var page = $(this).find("input[name='page']").val();
        var clientInfo = $("input[name='clientInfo']").val();
        var sortedVal = $('.sortClient option:selected').val();
        var sortBy=$(".sort_client_by").attr("id");
        var searchVal = $('.searchType option:selected').val();
        if(sortBy=="DESC"){
                    sortBy="ASC";
                 }else {
                      sortBy="DESC";
                   }
               sortedVal=sortedVal+":"+sortBy;
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/changePageForClients.php",
            data: {
                'page': page,
                'clientInfo': clientInfo,
                'sortedVal':sortedVal,
                'searchVal':searchVal,
                'fromApp':true
            },
            async: false,
            success: function (data) {
                if(data=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("#forClients").empty();
                    $("#forClients").html(data);
                    $("body").css("cursor", "default");}
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
//----------------------- end pagination --------------------------------------   
    

    $(document).on("click", ".removeClient", function () {
        var msg = getMssg['remove_client_msg'];
        var th = $(this);
        var clientID = $(this).parent().find("input[name='clientID']").val();
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var cancelMsg = getMssg['cancel'];
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                    $("body").css("cursor", "wait");
                    $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                    data: {
                        'clientID': clientID,
                        'actionName': "removeClient",
                        'fromApp':true
                    },
                    async: false,
                    success: function (result) {
                        if (result == 'true') {
                          var success = getMssg['connect_succeed'];
                            $("#failAddClient").empty();
                            $("#failAddClient").removeClass("errorMessage");
                            $("#failAddClient").addClass("infoMessage");
                            $("#failAddClient").html(success);
                            setTimeout(function () {
                                location.reload(true);
                            }, 1000);
                        } else if (result == 'false') {
                                var failed = getMssg['action_failed'];
                                $("#failAddClient").empty();
                                $("#failAddClient").removeClass("infoMessage");
                                $("#failAddClient").addClass("errorMessage");
                                $("#failAddClient").html(failed);
                                $("body").css("cursor", "default");
                        } else if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            });
    });
    
    $(document).on("click", ".clientDev", function () {
        $(".eachClient").removeClass("clickedGr");
        $(this).parent().parent().addClass("clickedGr");
        $("body").css("cursor", "wait");
        var clientID = $(this).parent().find("input[name='clientID']").val();
        idClient = clientID;
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheClient.php",
            data: {
                'clientID': clientID,
                'page': 1,
                'fromApp': true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $(".forEachGroup").empty();
                    $(".forEachGroup").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
//------------------- pagination for clientDevices.php--------------------------    
    
    $(document).on("click", ".eachClientDevPage", function () {
        $("body").css("cursor", "wait");
        var page = $(this).find("input[name='page']").val();
        var clientID = $('#clientDevTable').find("input[name='clientID']").val();
        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/getAllDevicesOfTheClient.php",
            data: {
                'clientID': clientID,
                'page': page,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    $(".forEachGroup").empty();
                    $(".forEachGroup").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });
    
//------------------- end pagination for clientDevices.php----------------------

    
//---------------- show device information (clientDevices.php) -----------------

    $(document).on("click",".config",function (){
        var devId = $(this).parent().find("input[name='devID']").val();
        $("#infoId").find("input[name='devId']").val(devId);
        $("#infoId").submit();
    });

//----------------end show device information (clientDevices.php) --------------

//----------------Help Client page Info-----------------------------------------

    $(document).on("click", ".clientInform", function () {
        var helpClient = getMssg['help_info_change_client'];
        var help = getMssg['help'];
        swal({
            title: help,
            text:helpClient
        });
    });

//------------End  Help  Client  page Info--------------------------------------



//---add client sort

   (function () {
        var previous='';

        $(".sortClient").on('focus', function (e) {
           previous = $('.sortClient option:selected').val();
        }).change(function() {
            var searchedVal = $('.sortClient option:selected').val();
     //  alert(previous);
       //     alert(searchedVal);

            var clientInfo = $("input[name='clientInfo']").val();
            var searchVal = $('.searchType option:selected').val();
            sortByChange(searchedVal,clientInfo,searchVal,previous);
            previous = $('.sortClient option:selected').val();

        });
   })();



    $("#client_sort").bind("click",function () {
        var clientInfo = $("input[name='clientInfo']").val();
        var searchVal = $('.searchType option:selected').val();
        var searchedVal = $('.sortClient option:selected').val();

        var resultAction=getNotEmptyRowsCount(searchedVal,clientInfo,searchVal);
        if(resultAction=='logged_out'){
            document.location.href = $basepath + 'login';
        } else if(resultAction=='error'){
            document.location.href = $basepath + '500';
        }else if(resultAction==0){
            $("body").css("cursor", "default");
        } else {

        var sortBy=$(".sort_client_by").attr("id");

            if(sortBy=="DESC"){
                     $(".sort_client_by").attr("id","ASC");
                   $(".sort_client_by").attr("src",$basepath + "assets/images/down_arrow_34.png");

                   $(".sort_client_by").attr("title",getMessage("by_desc"));
                 }else {
                    $(".sort_client_by").attr("id","DESC");
                   $(".sort_client_by").attr("src",$basepath + "assets/images/up_arrow_34.png");
                  $(".sort_client_by").attr("title",getMessage("by_asc"));
               }
            searchedVal=searchedVal+":"+sortBy;


       	      $("body").css("cursor", "wait");
             $.ajax({
           	          type: "POST",
            	          url: $basepath + "secureFiles/actions/ajaxActions/sortedClients.php",
            	          data: {
               	              'clientInfo':clientInfo,
                              'sortedVal': searchedVal,
               	              'searchVal':searchVal,
                	              'fromApp':true
                	          },
          	          async: false,
          	          success: function (result) {
              	              if(result=='logged_out'){
                  	                  document.location.href = $basepath + 'login';
                  	              } else {
                   	                  $("#forClients").empty();
                   	                  $("#forClients").html(result);
                   	                  $(".forEachGroup").empty();
                   	                  $("body").css("cursor", "default");
                   	              }
                	          },
                     error: function(xhr, status, error) {
                	              document.location.href = $basepath + '500';
               	          }
            	      });
       }
        });
    function setDefaultSortValsClients(element){
               element.val("first_name");
              $(".sort_client_by").attr("id","DESC");
               $(".sort_client_by").attr("src",$basepath + "assets/images/up_arrow_34.png");
                $(".sort_client_by").attr("title",getMessage("by_asc"));

           }

});