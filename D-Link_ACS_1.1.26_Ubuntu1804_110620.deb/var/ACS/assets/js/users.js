//function getMssg(msg){
//
//    var retMsg='';
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
//            'message': msg,
//            'fromApp':true
//        },
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                retMsg = result;
//            }
//        }
//    });
//    return retMsg;
//}

$(document).ready(function(){

//    var getMssg = '';
//
//    $.ajax({
//        type: "POST",
//        url: $basepath + "secureFiles/actions/ajaxActions/getMsg.php",
//        data: {
////            'message': msg,
//            'fromApp':true
//        },
//        dataType: 'json',
//        async: false,
//        success: function (result) {
//            if (result == 'logged_out') {
//                document.location.href = 'login';
//            } else {
//                getMssg = result;
//            }
//        }
//    });
    
    $('#userPopover').popover({
        html : true,
        content: function() {
            return $('.addUsersPopover').html();
        }
    });

    $('#userPopover').on('hidden.bs.popover', function () {
        $('#failAddUser').empty();
    });

    $checked_array = new Array();

    $('#userPopover').popover().on('shown.bs.popover', function () {
        $('.userFields').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });

        $('.popover-content .userFields').on('ifChecked ifUnchecked', function(event){
            $name = $(this).attr('id');
            if (event.type == 'ifChecked') {
                if(!$(this).hasClass('allField')){
                    $checked_array.push($name);
                }
            } else {
                $checked_array.removeByVal($name);
            }
        });

    });

    $('#userPopover').popover().on('hide.bs.popover', function () {
        $('.userGroup').css('display','none');
        if ($('.popover-content').find('.userFields').is(':checked')) {
            $('.userFields').iCheck('uncheck');
        }
        setTimeout(function(){
            $('.userFields').iCheck('destroy');
            $('.userFields').iCheck('update');
            $(".userPopover").html($(".userPopover .popover-content").html());
        }, 100);
    });


    $(document).on('click','#searchUser', function () {
        searchUsers();

        $('.userFieldss').iCheck({
            checkboxClass: 'icheckbox_square-blue',
            increaseArea: '20%' // optional
        });

        $checked_array_edit = new Array();
        $unchecked_array_edit = new Array();

        $('.userGroupsForEdit .userFieldss').on('ifChecked ifUnchecked', function(event){
            $nameGroup = $(this).attr('id');
            $UncheckGroups = $(this).attr('id');
            $a = $(this).attr('id');
            $parentId = $(this).closest('tr').attr('id');
            if(!$checked_array_edit.hasOwnProperty($parentId)){
                $checked_array_edit[$parentId];
                $temp = new Array();
            }else{
                $temp = $checked_array_edit[$parentId];
            }
            if(!$unchecked_array_edit.hasOwnProperty($parentId)){
                $unchecked_array_edit[$parentId];
                $uncheckeds = new Array();
            }else{
                $uncheckeds = $unchecked_array_edit[$parentId];
            }
            if (event.type == 'ifChecked') {
                if(!$(this).hasClass('allField')){
                    // $uncheckeds.removeByVal($UncheckGroups);
                    $temp.push($nameGroup);
                }
            } else {
                if(!$(this).hasClass('allField')) {
                    $temp.removeByVal($nameGroup);
                    $uncheckeds.push($UncheckGroups);
                }
            }


            $checked_array_edit[$parentId] = $temp;
            $unchecked_array_edit[$parentId] = $uncheckeds;

        });


        Array.prototype.removeByVal = function(val) {
            for (var i = 0; i < this.length; i++) {
                if (this[i] === val) {
                    this.splice(i, 1);
                    i--;
                }
            }
            return this;
        }

    });
    
    $(document).on("keypress","input[name='userInfo']",function(e){
        var key = e.which;
        var clientInfo = $(this).val();
        if(key == 13){  // the enter key code
            searchUsers();
            return false;
        }
    });

    $(document).on('change','.userGroups',function ()  {
        var uploadType = $(".userGroups option:selected").text();
        if(uploadType == 'Group manager'){
            $('.userGroup').css('display','block');
            $('.onoffswitchUserGroup').css('display','block');
            $('.manageGroups').css('display','block');
        } else if (uploadType == 'Group Viewer') {
            $('.userGroup').css('display','block');
            $('.onoffswitchUserGroup').css('display','none');
            $('.manageGroups').css('display','block');
        }else if (uploadType == 'Manager'){
            $('.userGroup').css('display','block');
            $('.onoffswitchUserGroup').css('display','block');
            $('.manageGroups').css('display','none');
        }else {
            $('.userGroup').css('display','none');
        }
    });

    $(document).on('change','.userGroupsEdit',function ()  {
        var uploadType = $(this).parent().find(".userGroupsEdit option:selected").attr('label');
        var userID = $(this).parent().find("input[name='userID']").val();
        if(uploadType == 'Group manager'){
            $('.userGroupsForEdit'+userID).css('display','block');
            $('.forCheckBoxGroupTasks').css('display','block');
            $('.manageGroups').css('display','block');
        } else if (uploadType == 'Group Viewer'){
            $('.userGroupsForEdit'+userID).css('display','block');
            $('.forCheckBoxGroupTasks').css('display','none');
            $('.manageGroups').css('display','block');
        }else if (uploadType == 'Manager'){
            $('.userGroupsForEdit'+userID).css('display','block');
            $('.forCheckBoxGroupTasks').css('display','block');
            $('.manageGroups').css('display','none');
        }else {
            $('.userGroupsForEdit'+userID).css('display','none');
        }
    });

    $(document).on("click","#groupTasksonoffswitch",function() {
        if ($(this).is(":checked")) {
            $("input[name='forCheckGroupTasksEnable']").val(1);
        } else {
            $("input[name='forCheckGroupTasksEnable']").val(0);
        }
    });

    $(document).on("click","#groupTasksEditonoffswitch",function() {
        if ($(this).is(":checked")) {
            $("input[name='forCheckGroupTasksEnable']").val(1);
        } else {
            $("input[name='forCheckGroupTasksEnable']").val(0);
        }
    });
        
    function searchUsers(){
        var clientInfo = $("input[name='userInfo']").val();
        var searchVal = $('.searchType option:selected').val();
        var action = $(".UsersType").val();
        $("body").css("cursor", "wait");

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/searchUsers.php",
            data: {
                'searchVal': searchVal,
                'userInfo': clientInfo,
                'userType': action,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if(result=='logged_out'){
                    document.location.href = $basepath + 'login';
                } else {
                    $(".usersTable").empty();
                    $(".usersTable").html(result);
                    $("body").css("cursor", "default");
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
        $("#failAddUser").empty();
    }
    
    $(document).on('click','#addUser', function () {
        var msgRequired = getMssg['error_message_required'];
        var msgInvalidEmail = getMssg['invalid_email'];
        var msgRepassword = getMssg['error_message_repassword'];
        var msgEmpty = getMssg['error_message_empty'];
        var msgRequiredGroup = getMssg['error_message_group'];
        var noSpaceUserName = getMssg['user_name_required_field'];

        $(".forAddUser").validate({
            rules: {
                username: {
                    required: true,
                    noSpace: true
                },
                email: {
                    required: true,
                    email: true
                },
                userGroups: {
                    required: true
                },
                userGroup: {
                    required: true
                },
                password: {
                    required: true,
                    validateIsEmpty: true
                },
                re_password: {
                    equalTo: "#password"
                }
            },

            messages: {
                username: {
                    required: msgRequired,
                    noSpace: noSpaceUserName
                },
                email: {
                    required: msgRequired,
                    email: msgInvalidEmail
                },
                userGroups: {
                    required: msgRequired
                },
                userGroup: {
                    required: msgRequiredGroup
                },
                password: {
                    required: msgRequired,
                    validateIsEmpty: msgEmpty
                },
                re_password: {
                    equalTo: msgRepassword
                }

            },
            errorElement: "div",
            errorClass: 'error_message_users',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');

                if (placement) {
                    $(placement).append(error)
                } else {
                    if (element[0].name == 'userGroup') {
                        error.insertBefore(element[0].parentElement.parentElement);
                    }else {
                        error.insertAfter(element);
                    }
                }
            }
        });


        if(!($(".forAddUser").valid())) {
            $("#actionMsgWithUser").empty();
            $("#failAddactionMsgWithUserEmailUser").empty();
            return false;
        }

        setTimeout(function () {
            $("#actionMsgWithUserEmail").empty();
            $("#actionMsgWithUser").empty();
        },10000)

        var userName = $("input[name='username']").val();
        var email = $("input[name='email']").val();
        var password = $("input[name='password']").val();
        var re_password = $("input[name='re_password']").val();
        var selecteds = $(".userGroups option:selected").val();
        var groupTaskAllow = $("input[name='forCheckGroupTasksEnable']").val();
        var userGroupId = 0;
        if (groupTaskAllow != 1){
            groupTaskAllow = 0;
        }
        if(selecteds != 0){
            userGroupId = selecteds;
        }


                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/checkUserNameEmail.php",
                            data: {
                                'email': email,
                                'userName': userName,
                                'fromApp': true
                            },
                            async: false,
                            success: function (data) {
                                if (data == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    resFailAction = data;
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });

                        if (resFailAction == '1' || resFailAction == '2' ) {
                            $("#actionMsgWithUser").empty();
                            $("#actionMsgWithUser").addClass('errorMessage');
                            $("#failAddactionMsgWithUserEmailUser").empty();
                            if (resFailAction == '1') {
                                $("#actionMsgWithUser").html(getMssg['username_exist']);
                            } else if (resFailAction == '2') {
                                $("#actionMsgWithUser").html(getMssg['username_deleted_status']);
                            }
                            if ($('.usersTable').text().trim() == 'Users not found' || $('.usersTable').text().trim() == 'Пользователи не найдены') {
                                $('.usersTable').empty();
                            }
                        } else if(resFailAction == '3' || resFailAction == '4' ) {
                            $("#actionMsgWithUserEmail").empty();
                            $("#actionMsgWithUserEmail").addClass('errorMessage');
                            $("#actionMsgWithUser").empty();
                            if(resFailAction == '3') {
                                $("#actionMsgWithUserEmail").html(getMssg['email_exist']);
                            } else if (resFailAction == '4') {
                                $("#actionMsgWithUserEmail").html(getMssg['username_deleted_status']);
                            }
                            if ($('.usersTable').text().trim() == 'Users not found' || $('.usersTable').text().trim() == 'Пользователи не найдены') {
                                $('.usersTable').empty();
                            }
                        }else {
                            $.ajax({
                                type: "POST",
                                url: $basepath + "secureFiles/actions/ajaxActions/addUser.php",
                                data: {
                                    'userName': userName,
                                    'email': email,
                                    'password': password,
                                    'userGrId': userGroupId,
                                    'groups':$checked_array,
                                    'actionName': 'addUser',
                                    'groupTaskAllow': groupTaskAllow,
                                    'fromApp': true
                                },
                                async: false,
                                success: function (result) {
                                    if (result == 'logged_out') {
                                        document.location.href = $basepath + 'login';
                                    } else {
                                        location.reload(true);
                                    }
                                },
                                error: function (xhr, status, error) {
                                    document.location.href = $basepath + '500';
                                }
                            });
                        }
    });
        
    
    $(document).on('click','#editUser', function () {
        var th = $(this);

        var editFails= th.closest('tr').find(".editFails");
        editFails.empty();
        var userName = th.closest('tr').find("input[name='editUsername']").val();
        var email = th.closest('tr').find("input[name='editEmail']").val().trim();
        var password = th.closest('tr').find("input[name='editPassword']").val();
        var oldPassword = th.closest('tr').find("input[name='oldPassword']").val();
        var re_password = th.closest('tr').find("input[name='editRe_password']").val();
        var selecteds = th.closest('tr').find(".userGroupsEdit option:selected").val();
        var userGroupId = 0;
        var userID = th.parent().find("input[name='userID']").val();
        var oldUserName = th.closest('tr').find("input[name='oldUsername']").val();
        var oldEmail = th.closest('tr').find("input[name='oldEmail']").val();
        var parentId = $(this).closest('tr').attr('id');
        var groupNameArray = [];
        var uncheckedGroups = [];
        var groupTaskAllow = th.closest('tr').find("input[name='forCheckGroupTasksEnable']").val();
        if (groupTaskAllow != 1){
            groupTaskAllow = 0;
        }
        groupNameArray = $checked_array_edit[parentId];
        uncheckedGroups = $unchecked_array_edit[parentId];
        if(selecteds != 0){
            userGroupId = selecteds;
        }
        var resFailAction = '';
        var msgRequired = getMssg['error_message_required'];
        var msgInvalidEmail = getMssg['invalid_email'];
        var msgRepassword = getMssg['error_message_repassword'];
        var msgEmpty = getMssg['error_message_empty'];
        var noSpaceUserName = getMssg['user_name_required_field'];
        var msgRequiredGroup = getMssg['error_message_group'];


        $(".editUsers" + userID).validate({
            rules: {
                editUsername: {
                    required: true,
                    noSpace: true
                },
                editEmail: {
                    required: true,
                    email: true,
                    noSpace: true
                },
                userGroup: {
                    required: true
                },
                editPassword: {
                    noSpace: true
                },
                editRe_password: {
                    equalTo: ".editPassword"+ userID
                }
            },

            messages: {
                editUsername: {
                    required: msgRequired,
                    noSpace: noSpaceUserName
                },
                editEmail: {
                    required: msgRequired,
                    email: msgInvalidEmail,
                    noSpace: msgEmpty
                },
                userGroup: {
                    required: msgRequiredGroup
                },
                editPassword: {
                    noSpace: msgEmpty
                },
                editRe_password: {
                    equalTo: msgRepassword
                }

            },
            errorElement: "div",
            errorClass: 'error_message_editUsers',
            errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                    $(placement).append(error)
                } else {
                    if (element[0].name == 'userGroup') {
                        error.insertBefore(element[0].parentElement.parentElement.parentElement.parentElement);
                    }else {
                        error.insertAfter(element);
                    }
                }


            }
        });

        if(!($(".editUsers" + userID).valid())) {

            return false;
        }

        // if (userName != '' && email != '' /*&& password != '' && re_password != ''*/ && selecteds > 0) {

            if((typeof(oldPassword) != "undefined" && oldPassword !== null)){
                if(oldPassword != ''){
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkOldPass.php",
                        data: {
                            'oldPassword': oldPassword,
                            'userId': userID,
                            'page': 'userPage',
                            'fromApp':true
                        },
                        async: false,
                        success: function (data) {
                            if(data == 'logged_out'){
                                document.location.href = $basepath + 'login';
                            } else {
                                resFailAction = data;
                            }
                        },
                        error: function(xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
                   if (resFailAction != '') {
                        th.closest('tr').find(".editOldUsername").empty();
                        th.closest('tr').find(".editOldUsername").addClass('errorMessage');
                        th.closest('tr').find(".editOldUsername").html(resFailAction);
                        $("body").css("cursor", "default");
                        return false;
                    }
                    // if(password == '') {
                    //     resFailAction = getMssg['all_fields_required'];
                    //     th.closest('tr').find(".editFails").empty();
                    //     th.closest('tr').find(".editFails").addClass('errorMessage');
                    //     th.closest('tr').find(".editFails").html(resFailAction);
                    //     $("body").css("cursor", "default");
                    //     return false;
                    // } else if(password.trim()=='') {
                    //     resFailAction = getMssg['error_message_password'];
                    //     th.closest('tr').find(".editFails").empty();
                    //     th.closest('tr').find(".editFails").addClass('errorMessage');
                    //     th.closest('tr').find(".editFails").html(resFailAction);
                    //     $("body").css("cursor", "default");
                    //     return false;
                    // }

                }/*else {
                    resFailAction = getMssg['all_fields_required'];
                    th.closest('tr').find(".editFails").empty();
                    th.closest('tr').find(".editFails").addClass('errorMessage');
                    th.closest('tr').find(".editFails").html(resFailAction);
                    $("body").css("cursor", "default");
                    return false;
                }*/
            }
            //
            // if (password.replace(/\s/g, "").length > 0) {

//                var resFailAction = '';
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/checkUserNameEmail.php",
                        data: {
                            'email': email,
                            'userName': userName,
                            'oldEmail': oldEmail,
                            'oldUserName': oldUserName,
                            'fromApp': true
                        },
                        async: false,
                        success: function (data) {
                            if (data == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                resFailAction = data;
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
               /* $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/checkEmail.php",
                    data: {
                        'email': email,
                        'fromApp':true
                    },
                    async: false,
                    success: function (data) {
                        if(data=='logged_out'){
                            document.location.href = $basepath + 'login';
                        } else {
                            resFailAction = data;
                        }
                    },
                    error: function(xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });*/
                // if (userName.indexOf(" ") < 0) {
        if (resFailAction == '1' || resFailAction == '2' ) {
            editFails.empty();
            editFails.addClass('errorMessage');
            $("body").css("cursor", "default");
            if (resFailAction == '1') {
                editFails.html(getMssg['username_exist'])
            } else if (resFailAction == '2') {
                editFails.html(getMssg['username_deleted_status']);
            }
        } else if(resFailAction == '3' || resFailAction == '4' ) {
            editFails.empty();
            editFails.addClass('errorMessage');
            $("body").css("cursor", "default");
            if(resFailAction == '3') {
                editFails.html(getMssg['email_exist']);
            } else if (resFailAction == '4') {
                editFails.html(getMssg['username_deleted_status']);
            }
        } else {
                        //     if (password == re_password) {
                        //         if (password.length > 0) {
                        //             if(password.trim()=='') {
                        //                 resFailAction = getMssg['error_message_password'];
                        //                 th.closest('tr').find(".editFails").empty();
                        //                 th.closest('tr').find(".editFails").addClass('errorMessage');
                        //                 th.closest('tr').find(".editFails").html(resFailAction);
                        //                 $("body").css("cursor", "default");
                        //                 return false;
                        //             } else {
                        $.ajax({
                            type: "POST",
                            url: $basepath + "secureFiles/actions/ajaxActions/addUser.php",
                            data: {
                                'edit': 'edit',
                                'user_ID': userID,
                                'editUserName': userName,
                                'oldUserName': oldUserName,
                                'editEmail': email,
                                'editPassword': password,
                                'editUserGrId': userGroupId,
                                'groupName': groupNameArray,
                                'uncheckedGroups': uncheckedGroups,
                                'actionName': 'editUser',
                                'groupTaskAllow': groupTaskAllow,
                                'fromApp': true
                            },
                            async: false,
                            success: function (result) {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    location.reload(true);
                                }
                            },
                            error: function (xhr, status, error) {
                                document.location.href = $basepath + '500';
                            }
                        });
                        // }
                        // } else {
                        // } else {
                        //     resFailAction = getMssg['conf_pass'];
                        //     th.closest('tr').find(".editFails").empty();
                        //     th.closest('tr').find(".editFails").addClass('errorMessage');
                        //     th.closest('tr').find(".editFails").html(resFailAction);
                        //     $("body").css("cursor", "default");
                        // }

                        // } else {
                        //     alert(11);
                        //     var fail = getMssg['user_name_required_field'];
                        //     th.closest('tr').find(".editFails").empty();
                        //     th.closest('tr').find(".editFails").removeClass("infoMessage");
                        //     th.closest('tr').find(".editFails").addClass("errorMessage");
                        //     th.closest('tr').find(".editFails").html(fail);
                        //     $("body").css("cursor", "default");
                        // }

                        // } else {
                        //     var fail = getMssg['error_message_password'];
                        //     th.closest('tr').find(".editFails").empty();
                        //     th.closest('tr').find(".editFails").removeClass("infoMessage");
                        //     th.closest('tr').find(".editFails").addClass("errorMessage");
                        //     th.closest('tr').find(".editFails").html(fail);
                        //     $("body").css("cursor", "default");
                        // }
                        // } else {
                        //     resFailAction = getMssg['all_fields_required'];
                        //     th.closest('tr').find(".editFails").empty();
                        //     th.closest('tr').find(".editFails").addClass('errorMessage');
                        //     th.closest('tr').find(".editFails").html(resFailAction);
                        //     $("body").css("cursor", "default");
                        // }|/
                    }
    });

    $(document).on("click", ".oldPassword", function () {
        $(".editOldUsername").removeClass("errorMessage").html("");
        $('.editOldUsername').trigger('reset');
    });

    $(document).on("click", ".eachUsersPage", function () {
        var action = $(".UsersType").val();
            var page = $(this).find("input[name='page']").val();
            $("body").css("cursor", "wait");
            if(action=="DeletedUsers") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredUsersByPage.php",
                data: {
                    'page': page,
                    'fromApp': true,
                    'actionName': "deletedUser"
                },
                async: true,
                success: function (result) {
                    if (result == 'logged_out') {
                        document.location.href = $basepath + 'login';
                    } else {
                        $("body").css("cursor", "default");
                        $(".usersTable").empty();
                        $(".usersTable").html(result);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if(action=="AllUsers"){
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredUsersByPage.php",
                    data: {
                        'page': page,
                        'fromApp': true,
                        'actionName': "AllUsers"
                    },
                    async: true,
                    success: function (result) {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            $("body").css("cursor", "default");
                            $(".usersTable").empty();
                            $(".usersTable").html(result);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
        }
    });
    
    $(document).on("click",".rmUser",function () {
        var action = $(".UsersType").val();
        var userID = $(this).parent().find("input[name='userID']").val();
        var msg = getMssg['conf_rem_user'];
        var Dmsg = getMssg['conf_rem_deactivated_user'];
        var titleMsg = getMssg['title_msg'];
        var rmMsg =  getMssg['remove_msg'];
        var acMsg =  getMssg['deactivate_msg'];
        var cancelMsg = getMssg['cancel'];
        if (action == "DeletedUsers") {
            swal({
                title: titleMsg,
                text: msg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: rmMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                    $.ajax({
                        type: "POST",
                        url: $basepath + "secureFiles/actions/ajaxActions/sendXML.php",
                        data: {
                            'userID': userID,
                            'fromApp': true,
                            'actionName': "deletedUser"
                        },
                        async: false,
                        success: function (result) {
                            if (result != '') {
                                if (result == 'logged_out') {
                                    document.location.href = $basepath + 'login';
                                } else {
                                    $("#failAddUser").empty();
                                    $("#failAddUser").addClass("errorMessage");
                                    $("#failAddUser").html(result);
                                    location.reload(true);
                                }
                            }
                        },
                        error: function (xhr, status, error) {
                            document.location.href = $basepath + '500';
                        }
                    });
            });
                } else if (action=="AllUsers") {
            swal({
                title: titleMsg,
                text: Dmsg,
                showCancelButton: true,
                closeOnConfirm: true,
                confirmButtonText: acMsg,
                cancelButtonText: cancelMsg,
                confirmButtonColor: "#008DA9"
            }, function() {
                $.ajax({
                    type: "POST",
                    url: $basepath + "secureFiles/actions/ajaxActions/removeUser.php",
                    data: {
                        'userID': userID,
                        'fromApp': true
                    },
                    async: false,
                    success: function (result) {
                        if (result != '') {
                            if (result == 'logged_out') {
                                document.location.href = $basepath + 'login';
                            } else {
                                $("#failAddUser").empty();
                                $("#failAddUser").addClass("errorMessage");
                                $("#failAddUser").html(result);
                            }
                        } else {
                            location.reload(true);
                        }
                    },
                    error: function (xhr, status, error) {
                        document.location.href = $basepath + '500';
                    }
                });
            });
        }

    });

    $(document).on("click",".showUserParam",function () {
        var userId = $(this).parent().find("input[name='userID']").val();
        setTimeout(function () {
            $('.editUsers'+userId).trigger('reset');
            $('.editUsers'+userId).validate().destroy();
            $(userParam).find(".editFails").removeClass("errorMessage").html("");
            $(userParam).find(".editOldUsername").removeClass("errorMessage").html("");
        }, 500);
        var th = $(this);
        $(".eachUser").removeClass("clickedGr");
        th.closest('tr').addClass("clickedGr");
        
        if ($('.editUsers'+userId).find("input[name='forCheckGroupTasksEnable']").val() == 1) {
            $('#groupTasksEditonoffswitch').change();
        }else {
            $('#groupTasksEditonoffswitch').is

        }

        var userParam = ($(this).attr("data-target"));
	    var rowId = $(this).closest('tr').next('tr').attr('id');
        var count = $(this).closest('tr').next('tr').find(".groupCount").val();
        // if(!$checked_array_edit.hasOwnProperty(rowId)){
        //     $checked_array_edit[rowId];
        //     $tempInColapse = new Array();
        //     for(var i = 0; i<count; i++) {
        //         var userFieldss = $(this).closest('tr').next('tr').find(".userFieldss"+i);
        //         if ($('.userFieldss'+i).is(':checked')) {
        //             $tempInColapse.push(userFieldss.attr('id'));
        //         }
        //     }
        //     $checked_array_edit[rowId] = $tempInColapse;
        // }

        $.ajax({
            type: "POST",
            url: $basepath + "secureFiles/actions/ajaxActions/groupsForUser.php",
            data: {
                'userId': userId,
                'fromApp':true
            },
            async: false,
            success: function (result) {
                if (result == 'logged_out') {
                    document.location.href = $basepath + 'login';
                } else {
                    $("body").css("cursor", "default");
                    th.closest('tr').next('tr').find(".forEachUser").html(result);
                }
            },
            error: function(xhr, status, error) {
                document.location.href = $basepath + '500';
            }
        });
    });

    $(document).on("change", ".UsersType", function () {
        $("input[name='userInfo']").val('');
        var action = $('option:selected',this).val();
        if(action=="DeletedUsers") {
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredUsersByPage.php",
                data: {
                    'fromApp': true,
                    'actionName': "deletedUser"
                },
                async: false,
                success: function (result) {
                    if (result != '') {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            $("body").css("cursor", "default");
                            $(".usersTable").empty();
                            $(".usersTable").html(result);
                        }
                    } else {
                        location.reload(true);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        } else if(action=="AllUsers"){
            $.ajax({
                type: "POST",
                url: $basepath + "secureFiles/actions/ajaxActions/getAllFilteredUsersByPage.php",
                data: {
                    'fromApp': true,
                    'actionName': "AllUsers"
                },
                async: false,
                success: function (result) {
                    if (result != '') {
                        if (result == 'logged_out') {
                            document.location.href = $basepath + 'login';
                        } else {
                            $("body").css("cursor", "default");
                            $(".usersTable").empty();
                            $(".usersTable").html(result);
                        }
                    } else {
                        location.reload(true);
                    }
                },
                error: function (xhr, status, error) {
                    document.location.href = $basepath + '500';
                }
            });
        }
    });


});
