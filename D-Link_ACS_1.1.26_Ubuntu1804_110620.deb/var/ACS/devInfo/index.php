<?php
/*
if(session_id() == '') {
    session_start();
}
if(isset($_SESSION['logged_in'])){

$lang = $_SESSION['lang'];

if ($lang == 'en') {
    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
} else {
    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
}

if(isset($_POST['devId'])){
    $devID=$_POST['devId'];
    $_SESSION['deviceId']=$devID;
    
} else if(isset($_SESSION['deviceId'])){
            $devID=$_SESSION['deviceId'];
            
    } else {$devID=0;}
    
include $_SESSION['APPPATH']."models/modelUser.php";
//define('BASEPATH', $_SESSION['BASEPATH']);
if(!defined('BASEPATH')){define('BASEPATH', $_SESSION['BASEPATH']);}

$user=new ModelUser();
    $username=$_SESSION['logged_in'];
    $permissions=$user->getPermissionsByUsername($username);
    $permissionsArray=array();
    if($permissions){
        for($ii=0;$ii<count($permissions);$ii++){
            $permissionsArray[]=$permissions[$ii]->name;
        }
        $_SESSION['permissions']=$permissionsArray;
        include '../secureFiles/actions/eachDevInfo.php';
    } else {
        include '../secureFiles/actions/unknownUserType.php';
    }
} else {
    if (isset($_SERVER['HTTP_HOST'])) {
        $site_url = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ? 'https' : 'http';
        $site_url .= '://' . $_SERVER['HTTP_HOST'];
        $site_url .= str_replace('devInfo/'.basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    } else {
        $site_url = 'http://localhost/';
    }
    header('Location: ' . $site_url . 'secureFiles/actions/login.php');
}
*/
?>