<?php
//$ipaddress = shell_exec("/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d : -f2 | awk '{print $1}'");

$currentDate = date("Y-m-d-H-i-s");
$putdata = fopen("php://input", "r");
$dir = dirname(__FILE__) . "/putConfigs";
if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}
$dir = $dir . "/" . $_GET['MAC'] . "_" . $currentDate . "_config.tar.gz";
$fileName = $_GET['MAC'] . "_" . $currentDate . "_config.tar.gz";
$dirName = "/putConfigs/" . $fileName;
$mac = $_GET['MAC'];
$fp = fopen($dir, "w");

while ($data = fread($putdata, 1024))
    fwrite($fp, $data);

fclose($fp);
fclose($putdata);
$fileSize = filesize($dir);
$app_path = "secureFiles";
$app_path = realpath($app_path).'/';
include $app_path.'models/fwConfigFile.php';
include $app_path.'models/device.php';
$dev = new Device();
$fwConfig = new FwConfigFile();
$modelName = $dev->getModelIdBySerialNumber($mac);
$resForInsert = $fwConfig->addConfig($modelName[0]->model_id, $fileSize, $dirName, $fileName);

?>

