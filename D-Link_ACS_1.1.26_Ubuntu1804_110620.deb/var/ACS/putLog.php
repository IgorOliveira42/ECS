<?php
//$ipaddress = shell_exec("/sbin/ifconfig eth0 | grep 'inet addr:' | cut -d : -f2 | awk '{print $1}'");

$currentDate = date("Y-m-d-H-i-s");
$putdata = fopen("php://input", "r");
$dir=dirname(__FILE__)."/logUpload";
if (!is_dir($dir)) {
    mkdir($dir, 0777, true);
}
$dir=$dir."/".$_GET['MAC']."_".$currentDate."_custom_log.tar.gz";
$fp = fopen($dir, "w");

while ($data = fread($putdata, 1024))
    fwrite($fp, $data);

fclose($fp);
fclose($putdata);
?>

