<?php
if (session_id() == '') {
    session_start();
}

if (isset($_SESSION['logged_in'])) {
    require_once 'secureFiles/views/content/admin/error404.php';
} else {
    require_once 'secureFiles/actions/login.php';
}

