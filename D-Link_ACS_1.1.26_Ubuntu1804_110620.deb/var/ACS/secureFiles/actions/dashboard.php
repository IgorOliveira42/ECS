<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        require_once $_SESSION['APPPATH'].'models/device.php';
        require_once $_SESSION['APPPATH'] . 'models/modelClient.php';
        $dev = new Device();
        $client = new ModelClient();
        /*-----------------------for devices model diagram-----------------*/
        $models = $dev->getAllModelsId();
        $countDev = array();
        $nameModel = array();
        $hwVersionModel = array();
        $x=0;
        $modelsCount = $dev->getAllModelsCount();
        for ($i = 0; $i < $modelsCount[0]->count; $i++) {
            $index = $models[$i]->id;
            $count = $dev->getDevicesByModels($index);
            if ($count[0]->count > 0) {
                $name = $dev->getAllModelsName($index);
                $countDev[$x] = $count[0]->count;
                $nameModel[$x] = $name[0]->name;
                $hwVersionModel[$x] = $name[0]->hw_version;
                //$a = array($nameModel[$x] ." - ". $hwVersionModel[$x] , $countDev[$x]);
                $x++;
            }
        }
        $noHaveModel = $dev->getAllDevCountIsModelNull();
        if(!empty($noHaveModel) && $noHaveModel[0]->count > 0) {
            $countDev[$x] = $noHaveModel[0]->count;
            $hwVersionModel[$x] = '';
            $nameModel[$x] = "Other";
        }



        $resulta = count($countDev);
        $resultName = count($nameModel);

        ;

        /*-----------------------------------------------------------------*/

        /*----------------------for heartbeat diagram----------------------*/
        $HeartINT = $dev->getDevHeartInter()[0]->settings_value;
        $HeartWAR = $dev->getDevHeartWar()[0]->settings_value;
        $HeartERR = $dev->getDevHeartErr()[0]->settings_value;
        $statusHeartbeath = array();
        $nameHeartbeath = array();
        $colorHeartbeath = array();
        $getDevLastTime = $dev->getDevWithInterval();
        $getDevicesStatusOfSuccess = 0;
        $getDevicesStatusOfWeting = 0;
        $getDevicesStatusOfError = 0;
        $CurrentTime = strtotime(date("M d Y H:i:s")) / 60;
        for($i=0; $i <count($getDevLastTime); $i++) {
            $DeviceLastInfTime = strtotime($getDevLastTime[$i]->last_inform_time) / 60;
            $lastInfTime = $CurrentTime - $DeviceLastInfTime;
            if ($lastInfTime < ($HeartINT + $HeartWAR)) {
                $getDevicesStatusOfSuccess +=1;
            } else if ($lastInfTime >= ($HeartINT + $HeartWAR) && $lastInfTime < ($HeartWAR + $HeartERR + $HeartINT)) {
                $getDevicesStatusOfWeting +=1;
            } else if ($lastInfTime >= ($HeartWAR + $HeartERR + $HeartINT)) {
                $getDevicesStatusOfError +=1;
            }
        }
        array_push($statusHeartbeath, $getDevicesStatusOfSuccess);
        array_push($statusHeartbeath, $getDevicesStatusOfWeting);
        array_push($statusHeartbeath, $getDevicesStatusOfError);
        array_push($nameHeartbeath, "Success");
        array_push($nameHeartbeath, "Waiting");
        array_push($nameHeartbeath, "Error");
        array_push($colorHeartbeath, "#3DAD6A");
        array_push($colorHeartbeath, "#FFA500");
        array_push($colorHeartbeath, "#AD3D40");




        ///
        /*-------------------------------------------------------------*/

        /* -----------------------end heartbeat status diagram-----------------------*/
        $countDevUnkn = true;
        $UnknownPendingDevices = array();
        $getUnknownDevices = $client->getAllUnknowns();
        $getPendingDevices = $client->getAllPending();
        $getUnknownDevicesCount = count($getUnknownDevices);
        $getPendingDevicesCount = count($getPendingDevices);
        if($getUnknownDevicesCount == 0 && $getPendingDevicesCount==0) {
            $countDevUnkn = false;
        } else {
            $countDevUnkn = true;
        }
        array_push($UnknownPendingDevices, $getUnknownDevicesCount);
        array_push($UnknownPendingDevices, $getPendingDevicesCount);

//        $UnknownPendingDevices=array();
//        $countDevUnkn = false;

        /*-------------------Unknown/Pending devicec count diagram--------------------*/
        include $_SESSION['APPPATH'].'views/tiles/admin/dashboard_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';

}