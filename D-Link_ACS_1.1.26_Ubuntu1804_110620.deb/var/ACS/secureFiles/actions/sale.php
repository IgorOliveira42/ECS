<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        include $_SESSION['APPPATH'].'models/modelClient.php';
        include $_SESSION['APPPATH'].'models/modelParams.php';
        include $_SESSION['APPPATH'].'models/device.php';
        include $_SESSION['APPPATH'].'util/pagingConstants.php';

        $device = new Device();
        $models = $device->getAllModels();
        $groups=$device->getAllGroups();
        $tarifs=$device->getAllTarifs();
        $client = new ModelClient();
        $profilesList = $client->getAllProfiles();
        $page = 1;
        $limit = PagingConstants::$clientsCount;
        $offset = ($page - 1) * $limit;
        $clientsList = $client->getAllClients($limit, $offset);

        $modParams = new ModelParams();
        $params = $modParams->conectionType();

        include $_SESSION['APPPATH'].'views/tiles/admin/sales_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';

}