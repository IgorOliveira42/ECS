<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        if(!class_exists("ModelUser")){
            include $_SESSION['APPPATH'].'models/modelUser.php';
        }
        include $_SESSION['APPPATH'].'util/pagingConstants.php';
//        require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//        require_once $_SESSION['APPPATH']."actions/api/token.php";
        $page = 1;
        $limit = PagingConstants::$activityCount;
        $offset = ($page - 1) * $limit;

        $user = new ModelUser();
        $users = $user->getAllUsersByPage($limit, $offset);
        $userGroups = $user->getAllUserGroups();
        $groupss =$user->getGroupsForUserGroup();
        $ungrouped = $user->getUngrouped();
//        $ungroup=false;
//        for($i=0;$i<count($users);$i++){
//            $groupList=$user->getGroupsSelectedUser($users[$i]->id);
//            $username = $users[$i]->username;
////            $token = token::create_token($username);
//            if(!$groupList){
//                $groupList=array();
//                $ungroup = false;
//            }
//            for($j=0; $j<count($groupList); $j++) {
//                if($groupList[$j]->default==1){
//                    $ungroup = true;
//                    break;
//                } else {
//                    $ungroup = false;
//                }
//            }
//            $users[$i] = (object) array_merge((array)$users[$i], array( 'groupList' => $groupList));
//            $users[$i] = (object) array_merge((array)$users[$i], array( 'ungrouped' => $ungroup));
//            $groupN = $users[$i]->groupList;
//            $uncheckedArray = array();
//            for($k = 0; $k < count($groupN); $k++) {
//                array_push($uncheckedArray, $groupN[$k]->id);
//            }
//            $uncheckedGroups = $user->getUncheckedGroups($uncheckedArray);
//            $users[$i] = (object) array_merge((array)$users[$i], array( 'uncheckedGroups' => $uncheckedGroups));
////            $users[$i] = (object) array_merge((array)$users[$i], array( 'token' => $token));
//        }


    //        $userTypes = $user->getAllUsersTypes();

        $allUsersCount = $user->getAllUsersCount();
        $usersCount = $allUsersCount[0]->count;
        if ($usersCount < $limit) {
            $pagesCount = 1;
        } else {
            if ($usersCount % $limit == 0) {
                $pagesCount = $usersCount / $limit;
            } else {
                $pagesCount = ($usersCount / $limit - ($usersCount % $limit) * (1 / $limit)) + 1;
            }
        }
        include $_SESSION['APPPATH'].'views/tiles/admin/users_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}

