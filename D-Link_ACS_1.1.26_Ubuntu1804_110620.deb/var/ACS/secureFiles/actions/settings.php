<?php
if (session_id() == '') {
    session_start();
}

function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

function readAcsServerSettings()
{
    $versionPath = '/etc/acs/config/version.info';
    $content = file_get_contents($versionPath);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode(':', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

function readSettings() {
    if(!class_exists("ModelParams")){require_once  $_SESSION['APPPATH'] . 'models/modelParams.php';}
    $modParams = new ModelParams();
    $params = $modParams->getReportAddressForAPI();
    return $params;
}

if (isset($_SESSION['logged_in'])) {
    $userName = $_SESSION['logged_in'];

    $acsSettings = readAcsSettings();
    $versionInfo = readAcsServerSettings();
    $reportAddressAPI = readSettings();

    include $_SESSION['APPPATH'].'views/tiles/admin/settings_view.php';
} else {
    require_once 'secureFiles/actions/login.php';
}
