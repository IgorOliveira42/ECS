<?php
        function getAllModelAndTypeAndHwVersion($userSettings, $device){

            $dirNameLogUpload = $_SESSION['REALPATH'] . "/" . "logUpload";
            $dirNameDump = $_SESSION['REALPATH'] . "/" . "dump";
            $dirNamePutConfigs = $_SESSION['REALPATH'] . "/" . "putConfigs";
            $dirNameConfigs = $_SESSION['REALPATH'] . "/" . "config";
            $dirNameFirmware = $_SESSION['REALPATH'] . "/" . "fw";
            $fullPath = array();
            $fileType = array();
            $countFileList = array();

            $allSerialNumber = array();
            $allModelName = array();
            $allHwVersion = array();
            $fileListIsEmpty = true;
            $allPath = array();

            array_push($fullPath, $dirNameLogUpload);
            array_push($fullPath, $dirNameDump);
            array_push($fullPath, $dirNamePutConfigs);
            array_push($fullPath, $dirNameConfigs);

            if (file_exists($dirNameLogUpload)) {
                $files = scandir($dirNameLogUpload);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f))) {
                        array_push($countFileList, $f);
                        array_push($fileType, 'log');
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNameDump)) {
                $files = scandir($dirNameDump);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && $f != "example.ini" && (preg_match("/\.dump/", $f))) {
                        array_push($countFileList, $f);
                        array_push($fileType, 'dump');
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNamePutConfigs)) {
                $files = scandir($dirNamePutConfigs);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                        array_push($countFileList, $f);
                        array_push($fileType, 'config');
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (is_dir($dirNameFirmware) && file_exists($dirNameFirmware)) {
                $root = $dirNameFirmware;
                $iter = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST,
                    RecursiveIteratorIterator::CATCH_GET_CHILD
                );
                $paths = array($root);
                foreach ($iter as $path => $dir) {
                    if ($dir->isDir()) {
                        $paths[] = $path;
                    }
                }
                for ($a = 0; $a < count($paths); $a++) {
                    $files = scandir($paths[$a]);
                    $i = 1;
                    foreach ($files as $f) {
                        if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {
                            array_push($countFileList, $f);
                            array_push($fileType, 'bin');
                            $filepath = explode("ACS/",$paths[$a]);
                            $modelsPath = substr($filepath[1],3);
                            $modelId = explode("/", $modelsPath);
                            $modelNames = $device->getModelNameByID($modelId[0]);
                            $modelsCount = $device->getAllModelsCount();
                            $models = $device->getAllModels();
                            $modName = $modelNames[0]->name;
                            $hwVersion = $modelNames[0]->hw_version;
                            array_push($allModelName, $modName);
                            array_push($allHwVersion, $hwVersion);

                            $fileListIsEmpty = false;
                            $i++;
                        }
                    }
                }
            }

            if (file_exists($dirNameConfigs)) {
                $files = scandir($dirNameConfigs);
                $i = 1;
                foreach ($files as $file) {
                    if ($file != "." && $file != ".."){
                        $filePhat = scandir($dirNameConfigs . "/" . $file);
                        foreach ($filePhat as $f) {
                            if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                                array_push($countFileList, $f);
                                array_push($fileType, 'config');
                                $modelName = $device->getModelNameByID($file);
                                array_push($allModelName, $modelName[0]->name);
                                $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                                array_push($countFileList, $f);
                                array_push($fileType, 'config');
                                array_push($allModelName, "");
                                array_push($allHwVersion, "");
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
            $FilteredModels = array();
            $FilteredTypes = array();
            $FilteredHwVersion = array();
            $FilteredAllModelTypeHw = array();
            $FilteredModels = array_unique($allModelName);
            $FilteredHwVersion = array_unique($allHwVersion);
            $FilteredTypes = array_unique($fileType);

            array_push($FilteredAllModelTypeHw,$FilteredModels);
            array_push($FilteredAllModelTypeHw,$FilteredTypes);
            array_push($FilteredAllModelTypeHw,$FilteredHwVersion);
            array_push($FilteredAllModelTypeHw,$countFileList);

            return $FilteredAllModelTypeHw;
        }


        function getFile($userSettings,$filesTableColumns,$fileCount){

            include $_SESSION['APPPATH'] . 'models/device.php';
            include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
            include $_SESSION['APPPATH'] . 'util/paging.php';

            $device = new Device();
            $getAllModelAndTypeAndHwVersion = getAllModelAndTypeAndHwVersion($userSettings,$device);

            $dirNameLogUpload = $_SESSION['REALPATH'] . "/" . "logUpload";
            $dirNameDump = $_SESSION['REALPATH'] . "/" . "dump";
            $dirNamePutConfigs = $_SESSION['REALPATH'] . "/" . "putConfigs";
            $dirNameConfigs = $_SESSION['REALPATH'] . "/" . "config";
            $dirNameFirmware = $_SESSION['REALPATH'] . "/" . "fw";
            $needFilesList1 = array();
            $fullPath = array();
            $fileType = array();
            $allSerialNumber = array();
            $allModelName = array();
            $allHwVersion = array();
            $fileListIsEmpty = true;
            $allPath = array();

            array_push($fullPath, $dirNameLogUpload);
            array_push($fullPath, $dirNameDump);
            array_push($fullPath, $dirNamePutConfigs);
            array_push($fullPath, $dirNameConfigs);
            if(is_dir($dirNameFirmware)) {
                $root = $dirNameFirmware;
                $iter = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST,
                    RecursiveIteratorIterator::CATCH_GET_CHILD
                );
                $paths = array($root);
                foreach ($iter as $path => $dir) {
                    if ($dir->isDir()) {
                        $paths[] = $path;
                    }
                }
                for ($a = 0; $a < count($paths); $a++) {
                    array_push($fullPath, $paths[$a]);
                }
            }

            if (file_exists($dirNameLogUpload)) {
                $files = scandir($dirNameLogUpload);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f))) {
                        array_push($needFilesList1, $f);
                        array_push($fileType, 'log');
                        array_push($allPath, "/logUpload/");
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber);
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNameDump)) {
                $files = scandir($dirNameDump);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && $f != "example.ini" && (preg_match("/\.dump/", $f))) {
                        array_push($needFilesList1, $f);
                        array_push($fileType, 'dump');
                        array_push($allPath, "/dump/");
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber);
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNamePutConfigs)) {
                $files = scandir($dirNamePutConfigs);
                $i = 1;
                foreach ($files as $f) {
                    if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                        array_push($needFilesList1, $f);
                        array_push($fileType, 'config');
                        array_push($allPath, "/putConfigs/");
                        $serialNumberss = explode("_", $f);
                        $serialNumber = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber);
                        $modelId = $device->getModelIdBySerialNumber($serialNumber);
                        $modelName = $device->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (is_dir($dirNameFirmware) && file_exists($dirNameFirmware)) {
                $root = $dirNameFirmware;
                $iter = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::SELF_FIRST,
                    RecursiveIteratorIterator::CATCH_GET_CHILD
                );
                $paths = array($root);
                foreach ($iter as $path => $dir) {
                    if ($dir->isDir()) {
                        $paths[] = $path;
                    }
                }
                for ($a = 0; $a < count($paths); $a++) {
                    $files = scandir($paths[$a]);
                    $i = 1;
                    foreach ($files as $f) {
                        if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {


                            array_push($needFilesList1, $f);
                            array_push($fileType, 'bin');
                            $filepath = explode("ACS/",$paths[$a]);
                            $modelsPath = substr($filepath[1],3);
                            $modelId = explode("/", $modelsPath);
                            $modelNames = $device->getModelNameByID($modelId[0]);

                            array_push($allPath, "/".$filepath[1]);
                            $modelsCount = $device->getAllModelsCount();
                            $models = $device->getAllModels();
                            $modName = $modelNames[0]->name;
                            $hwVersion = $modelNames[0]->hw_version;
                            array_push($allModelName, $modName);
                            array_push($allHwVersion, $hwVersion);

                            $fileListIsEmpty = false;
                            $i++;
                        }
                    }
                }
            }

            if (file_exists($dirNameConfigs)) {
                $files = scandir($dirNameConfigs);
                $i = 1;
                foreach ($files as $file) {
                    if ($file != "." && $file != ".."){
                        $filePhat = scandir($dirNameConfigs . "/" . $file);
                        foreach ($filePhat as $f) {
                            if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                                array_push($needFilesList1, "/" . $file . "/" . $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/config/" . $file);
                                array_push($allSerialNumber, "");
                                $modelName = $device->getModelNameByID($file);
                                array_push($allModelName, $modelName[0]->name);
                                $hwVersion = $device->getHwVersionByModelName($modelName[0]->name);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                                    array_push($needFilesList1, "/" . $file . "/" . $f);
                                    array_push($fileType, 'config');
                                    array_push($allPath, "/config/" . $file);
                                    array_push($allModelName, "");
                                    array_push($allHwVersion, "");
                                    $fileListIsEmpty = false;
                                    $i++;
                            }
                        }
                    }
                }
            }

            $FilteredModels = $getAllModelAndTypeAndHwVersion[0];
            $FilteredTypes = $getAllModelAndTypeAndHwVersion[1];
            $FilteredHwVersion = $getAllModelAndTypeAndHwVersion[2];
            $countFileList = $getAllModelAndTypeAndHwVersion[3];


            $page = 1;
            $limit = $rowCountFile = $fileCount;
            $offset = ($page - 1) * $limit;

            $needFilesList = array_slice($needFilesList1, $offset, $limit);
            $fileType = array_slice($fileType,$offset,$limit);
            $allModelName = array_slice($allModelName,$offset,$limit);
            $allSerialNumber = array_slice($allSerialNumber,$offset,$limit);
            $pagesCount = Paging::getPagesCount(count($needFilesList1), $limit);

            include  $_SESSION['APPPATH'].'views/tiles/admin/files_view.php';
        }

function getAllFilteredFile($model,$type,$filesTableColumns,$fileCount){
    include $_SESSION['APPPATH'] . 'models/device.php';
    include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
    include $_SESSION['APPPATH'] . 'util/paging.php';

    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    $userSettings->fileFilter = array( 'model' => $model, 'type' => $type);
    setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');

    $dev = new Device();

    $getAllModelAndTypeAndHwVersion = getAllModelAndTypeAndHwVersion($userSettings,$dev);

    $dirNameLogUpload = $_SESSION['REALPATH'] . "/" . "logUpload";
    $dirNameDump = $_SESSION['REALPATH'] . "/" . "dump";
    $dirNamePutConfigs = $_SESSION['REALPATH'] . "/" . "putConfigs";
    $dirNameConfigs = $_SESSION['REALPATH'] . "/" . "config";
    $dirNameFirmware = $_SESSION['REALPATH'] . "/" . "fw";
    $fullPath = array();
    array_push($fullPath, $dirNameLogUpload);
    array_push($fullPath, $dirNameDump);
    array_push($fullPath, $dirNamePutConfigs);
    array_push($fullPath, $dirNameConfigs);
    if(is_dir($dirNameFirmware)) {
        $root = $dirNameFirmware;
        $iter = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST,
            RecursiveIteratorIterator::CATCH_GET_CHILD
        );
        $paths = array($root);
        foreach ($iter as $path => $dir) {
            if ($dir->isDir()) {
                $paths[] = $path;
            }
        }
        for ($a = 0; $a < count($paths); $a++) {
            array_push($fullPath, $paths[$a]);
        }
    }
    $needFilesList1 = array();
    $countFileList = array();
    $fileType = array();
    $allSerialNumber = array();
    $allModelName = array();
    $allHwVersion = array();
    $allPath = array();
    $allType = array();
    $modelNamesAll = array();
    $serialNamesAll = array();
    $fileListIsEmpty = true;

    if ($model != '0'  && $type == '0') {
        $fileType = [];
        $allSerialNumber = [];
        $allModelName = [];
        $allHwVersion = [];
        $modelId = $dev->getModelIdByModel($model);
        for ($k = 0; $k < count($fullPath); $k++) {
            $path = $fullPath[$k];
            if (file_exists($path)) {
                $files = scandir($path);
                $i = 1;
                foreach ($files as $f) {
                    if (file_exists($path . "/" . $f . "/") && $f != '.' && $f != '..' && preg_match("/config/", $path)){
                        $filePhat = scandir($path . "/" . $f);
                        for ($j = 0; $j < count($modelId); $j++){
                            if ($f == $modelId[$j]->id){
                                $filePhat = scandir($dirNameConfigs . "/" . $f);
                                foreach ($filePhat as $file) {
                                    if ($file != "." && $file != ".." && preg_match("/_config.tar.gz/", $file)) {
                                        array_push($needFilesList1, "/" . $f . "/" . $file);
                                        array_push($countFileList, $file);
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/config/" . $f);
                                        array_push($allSerialNumber, "");
                                        array_push($allModelName, $model);
                                        $hwVersion = $dev->getHwVersionByModelName($model);
                                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                                        $fileListIsEmpty = false;
                                        $i++;
                                    } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                                        array_push($needFilesList1, "/" . $file . "/" . $f);
                                        array_push($countFileList, $f);
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/config/" . $f);
                                        array_push($allModelName, "");
                                        array_push($allHwVersion, "");
                                        $fileListIsEmpty = false;
                                        $i++;
                                    }
                                }
                            }
                        }
                    }else{
                        for ($j = 0; $j < count($modelId); $j++) {
                            $serialNumbers = $dev->getSerialNumberByModelId($modelId[$j]->id);
                            for ($i = 0; $i < count($serialNumbers); $i++) {
                                $serialNumber = $serialNumbers[$i]->serial_number;
                                $serial = "/$serialNumber/";
                                if (preg_match($serial, $f) == 1) {
                                    array_push($needFilesList1, $f);
                                    array_push($countFileList, $f);
                                    if (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f)) {
                                        array_push($fileType, 'log');
                                        array_push($allPath, "/logUpload/");
                                    } else if (preg_match("/\.dump/", $f)) {
                                        array_push($fileType, 'dump');
                                        array_push($allPath, "/dump/");
                                    } else if (preg_match("/_config.tar.gz/", $f)) {
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/putConfigs/");
                                    }
                                    $serialNumberss = explode("_", $f);
                                    $serialNumber1 = $serialNumberss[0];
                                    array_push($allSerialNumber, $serialNumber1);
                                    array_push($allModelName, $model);
                                    $hwVersion = $dev->getHwVersionByModelName($model);
                                    array_push($allHwVersion, $hwVersion[0]->hw_version);
                                    $fileListIsEmpty = false;
                                    $i++;
                                }
                            }
                        }

                            $filepath = explode("ACS/",$fullPath[$k]);
                            $modelsPath = substr($filepath[1],3);
                            $modelId1 = explode("/", $modelsPath);


                        if (preg_match("/.bin/", $f)) {
                            for ($q = 0; $q <= count($modelId);$q++){
                                if ($modelId[$q]->id == $modelId1[0]){
                                    array_push($needFilesList1, $f);
                                    array_push($countFileList, $f);
                                    array_push($fileType, 'bin');
                                    array_push($allPath, "/".$filepath[1]);
                                    $modelNames = $dev->getModelNameByID($modelId1[0]);
                                    $modName = $modelNames[0]->name;
                                    $hwVersion = $modelNames[0]->hw_version;
                                    array_push($allModelName, $modName);
                                    array_push($allHwVersion, $hwVersion);
                                    $fileListIsEmpty = false;
                                    $i++;
                                }
                            }
                        }
                    }
                }
            }
        }
    } else if ($model == '0'  && $type != '0') {
        $fileType = [];
        $allSerialNumber = [];
        $allModelName = [];
        $allHwVersion = [];
        if ($type == 'log') {
            if (file_exists($dirNameLogUpload)) {
                $files = scandir($dirNameLogUpload);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f)) {
                        array_push($needFilesList1, $f);
                        array_push($countFileList, $f);
                        array_push($fileType, 'log');
                        array_push($allPath, "/logUpload/");
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $dev->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }
        } else if ($type == 'dump') {
            if (file_exists($dirNameDump)) {
                $files = scandir($dirNameDump);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/\.dump/", $f) && ($f != "example.ini")) {
                        array_push($fileType, 'dump');
                        array_push($allPath, "/dump/");
                        array_push($needFilesList1, $f);
                        array_push($countFileList, $f);
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $dev->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }
        } else if ($type == 'bin') {
            if(is_dir($dirNameFirmware)) {
                if (file_exists($dirNameFirmware)) {
                    $root = $dirNameFirmware;
                    $iter = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::SELF_FIRST,
                        RecursiveIteratorIterator::CATCH_GET_CHILD
                    );
                    $paths = array($root);
                    foreach ($iter as $path => $dir) {
                        if ($dir->isDir()) {
                            $paths[] = $path;
                        }
                    }
                    for ($a = 0; $a < count($paths); $a++) {
                        $files = scandir($paths[$a]);
                        $i = 1;
                        foreach ($files as $f) {
                            if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {
                                array_push($needFilesList1, $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'bin');
                                $filepath = explode("ACS/",$paths[$a]);

                                $modelsPath = substr($filepath[1],3);
                                $modelId = explode("/", $modelsPath);
                                $modelNames = $dev->getModelNameByID($modelId[0]);

                                array_push($allPath, "/".$filepath[1]);
                                $modelsCount = $dev->getAllModelsCount();
                                $models = $dev->getAllModels();
                                $modName = $modelNames[0]->name;
                                $hwVersion = $modelNames[0]->hw_version;
                                array_push($allModelName, $modName);
                                array_push($allHwVersion, $hwVersion);

                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
        } else if ($type == 'config') {
            if (file_exists($dirNamePutConfigs)) {
                $files = scandir($dirNamePutConfigs);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/_config.tar.gz/", $f)){
                        array_push($fileType, 'config');
                        array_push($allPath, "/putConfigs/");
                        array_push($needFilesList1, $f);
                        array_push($countFileList, $f);
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $hwVersion = $dev->getHwVersionByModelName($modelName[0]->name);
                        array_push($allHwVersion, $hwVersion[0]->hw_version);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNameConfigs)) {
                $files = scandir($dirNameConfigs);
                $i = 1;
                foreach ($files as $file) {
                    if ($file != "." && $file != ".."){
                        $filePhat = scandir($dirNameConfigs . "/" . $file);
                        foreach ($filePhat as $f) {
                            if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                                array_push($needFilesList1, "/" . $file . "/" . $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/config/" . $file);
                                array_push($allSerialNumber, "");
                                $modelName = $dev->getModelNameByID($file);
                                array_push($allModelName, $modelName[0]->name);
                                $hwVersion = $dev->getHwVersionByModelName($modelName[0]->name);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            } else if ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                                array_push($needFilesList1, "/" . $file . "/" . $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/config/" . $file);
                                array_push($allSerialNumber, "");
                                array_push($allModelName, "");
                                array_push($allHwVersion, "");
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
        }
    } else if ($model != '0'  && $type != '0') {
        $fileType = [];
        $allSerialNumber = [];
        $allModelName = [];
        $allHwVersion = [];
        $modelId = $dev->getModelIdByModel($model);
        for ($k = 0; $k < count($fullPath); $k++) {
            $path = $fullPath[$k];
            if (file_exists($path)) {
                $files = scandir($path);
                $i = 1;

                foreach ($files as $f) {
                    if (file_exists($path . "/" . $f . "/") && $f != '.' && $f != '..'){
                        $filePhat = scandir($path . "/" . $f);
                        for ($j = 0; $j < count($modelId); $j++){
                            if ($f == $modelId[$j]->id){
                                if (file_exists($dirNameConfigs . "/" . $f)) {
                                    $filePhat = scandir($dirNameConfigs . "/" . $f);
                                    foreach ($filePhat as $file) {
                                        if ($file != "." && $file != ".." && preg_match("/_config.tar.gz/", $file) && $type == 'config') {
                                            array_push($needFilesList1, "/" . $f . "/" . $file);
                                            array_push($countFileList, $f);
                                            array_push($fileType, 'config');
                                            array_push($allPath, "/config/" . $f);
                                            array_push($allSerialNumber, "");
                                            array_push($allModelName, $model);
                                            $hwVersion = $dev->getHwVersionByModelName($model);
                                            array_push($allHwVersion, $hwVersion[0]->hw_version);
                                            $fileListIsEmpty = false;
                                            $i++;
                                        } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)) {
                                            array_push($needFilesList1, "/" . $file . "/" . $f);
                                            array_push($countFileList, $f);
                                            array_push($fileType, 'config');
                                            array_push($allPath, "/config/" . $f);
                                            array_push($allModelName, "");
                                            array_push($allHwVersion, "");
                                            $fileListIsEmpty = false;
                                            $i++;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    for ($j = 0; $j < count($modelId); $j++) {
                        $serialNumbers = $dev->getSerialNumberByModelId($modelId[$j]->id);
                        for ($i = 0; $i < count($serialNumbers); $i++) {
                            $serialNumber = $serialNumbers[$i]->serial_number;
                            $serial = "/$serialNumber/";
                            if ((preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f)) && $type == 'log' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'log');
                                array_push($allPath, "/logUpload/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $hwVersion = $dev->getHwVersionByModelName($model);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            } else if ((preg_match("/\.dump/", $f) && $f != "example.ini") && $type == 'dump' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'dump');
                                array_push($allPath, "/dump/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $hwVersion = $dev->getHwVersionByModelName($model);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            } else if (preg_match("/_config.tar.gz/", $f) && $type == 'config' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/putConfigs/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $hwVersion = $dev->getHwVersionByModelName($model);
                                array_push($allHwVersion, $hwVersion[0]->hw_version);
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }


                    $filepath = explode("ACS/",$fullPath[$k]);
                    $modelsPath = substr($filepath[1],3);
                    $modelId1 = explode("/", $modelsPath);

                    if (preg_match("/.bin/", $f) && $type == 'bin') {
                        for ($q = 0; $q < count($modelId);$q++){
                            if ($modelId[$q]->id == $modelId1[0]){
                                array_push($needFilesList1, $f);
                                array_push($countFileList, $f);
                                array_push($fileType, 'bin');
                                array_push($allPath, "/".$filepath[1]);
                                $modelNames = $dev->getModelNameByID($modelId1[0]);
                                $modName = $modelNames[0]->name;
                                $hwVersion = $modelNames[0]->hw_version;
                                array_push($allModelName, $modName);
                                array_push($allHwVersion, $hwVersion);
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
        }
    }

    $FilteredModels = $getAllModelAndTypeAndHwVersion[0];
    $FilteredTypes = $getAllModelAndTypeAndHwVersion[1];
    $FilteredHwVersion = $getAllModelAndTypeAndHwVersion[2];
    $countFileList = $getAllModelAndTypeAndHwVersion[3];

    $page = 1;
    $limit = $rowCountFile = $fileCount;
    $offset = ($page - 1) * $limit;

    $needFilesList = array_slice($needFilesList1, $offset, $limit);
    $fileType = array_slice($fileType,$offset,$limit);
    $allModelName = array_slice($allModelName,$offset,$limit);
    $allSerialNumber = array_slice($allSerialNumber,$offset,$limit);
    $pagesCount = Paging::getPagesCount(count($needFilesList1), $limit);

    include  $_SESSION['APPPATH'].'views/tiles/admin/files_view.php';
}

if (session_id() == '') {
    session_start();
}

if (isset($_SESSION['logged_in'])) {
    try{
        if (isset($_POST['fromApp'])){
            $model = '0';
            $types = '0';
            $n = '1';
            $fN = '1';
            $sN = '1';
            $modN = '1';
            $fSize = '1';
            $type = '1';
            $fileCont = 10;

            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $userSettings->fileFilter = array('model' => $model, 'type' => $types);
            $fields = array('n' => $n, 'fN' => $fN, 'sN' => $sN, 'modN' => $modN, 'fSize' => $fSize,'type'=>$type);
            $userSettings->filesTableColumns = (object)$fields;
            $userSettings->rowCountFile = $fileCont;

            if(property_exists($userSettings, 'filesTableColumns')){
                $filesTableColumns = $userSettings->filesTableColumns;
            }
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');
        }else {
            if ($userSettings->fileFilter->model != '0' || $userSettings->fileFilter->type != '0') {

                $filesTableColumns = $userSettings->filesTableColumns;
                $model = $userSettings->fileFilter->model;
                $types = $userSettings->fileFilter->type;
                $fileCount = $userSettings->rowCountFile;

                setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');

                getAllFilteredFile($model, $types, $filesTableColumns,$fileCount);
            } else {
                $filesTableColumns = $userSettings->filesTableColumns;
                $fileCount = $userSettings->rowCountFile;

                setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');
                getFile($userSettings,$filesTableColumns,$fileCount);
            }
        }
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}