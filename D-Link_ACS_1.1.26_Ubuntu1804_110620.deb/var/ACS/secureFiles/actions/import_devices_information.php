<?php

if(isset($_POST['fromApp'])) {

    if (session_id() == '') {
        session_start();
    }
    define('BASEPATH', $_SESSION['BASEPATH']);

    require_once $_SESSION['APPPATH'] . 'models/PHPExcel-1.8/Classes/PHPExcel.php';
    require_once $_SESSION['APPPATH'].'models/device.php';
    if ($_POST['actionName'] == "downloadFile") {
        $dev = new Device();
        $getDevices = $dev->getDeviceMacClientIdTemplateId();
        $phpexcel = new PHPExcel();
        $DIRECTORY_SEPARATOR = '/';
        $filePath = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "CSV" . $DIRECTORY_SEPARATOR . "file.xlsx";
        $page = $phpexcel->setActiveSheetIndex(0);

        //    <?= BASEPATH.'CSV/'.$needFilesListDev[0]
        $realPath = $_SESSION['BASEPATH'] . "CSV/" . "file.xlsx";
        $page->setCellValue("A1", "Device ID");
        $page->setCellValue("B1", "Model");
        $page->setCellValue("C1", "Serial Number");
        $page->setCellValue("D1", "IP");
        $page->setCellValue("E1", "FW Version");
        $page->setCellValue("F1", "MAC Address");
        $page->setCellValue("G1", "SSID(Channel)");
        $page->setCellValue("H1", "Last Connection Time");
        $page->setCellValue("I1", "CPE Uptime (sec.)");

        for ($i = 0; $i < count($getDevices); $i++) {
            $k = $i + 2;

            $page->setCellValue("A$k", $getDevices[$i]->device_id);
            $page->setCellValue("B$k", $getDevices[$i]->model);
            $page->setCellValue("C$k", $getDevices[$i]->serial_number);
            $page->setCellValue("D$k", $getDevices[$i]->ip);
            $page->setCellValue("E$k", $getDevices[$i]->firmware);
            $page->setCellValue("F$k", $getDevices[$i]->mac);
            $page->setCellValue("G$k", $getDevices[$i]->ssid);
            $page->setCellValue("H$k", $getDevices[$i]->last_inform_time);
            $page->setCellValue("I$k", $getDevices[$i]->up_time);

        }
        $page->setTitle("Test");
        PHPExcel_Settings::setZipClass(PHPExcel_Settings::PCLZIP);
        $objWriter = PHPExcel_IOFactory::createWriter($phpexcel, 'Excel2007');
        //$objWriter->save($filePath);
        $objWriter->save('/var/ACS/CSV/file.xlsx');
        echo $realPath;
    }else if ($_POST["actionName"] == "delateFile"){
        $DIRECTORY_SEPARATOR = '/';
        $path = $_SESSION['REALPATH'] . "CSV" . $DIRECTORY_SEPARATOR . "file.xlsx";

        if (isset($path) && file_exists($path)){
            unlink($path);
        }
    }
}
