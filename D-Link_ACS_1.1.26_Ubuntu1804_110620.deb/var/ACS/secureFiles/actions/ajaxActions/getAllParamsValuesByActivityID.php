<?php
function getRec($childCou, $itemName, $chiItem, $type)
{
    $itemNodeName = $chiItem->nodeName;
    if ($childCou->length <= 1) {
        $itemNodeValue = $chiItem->nodeValue;
        if ($itemNodeName == "cwmp:ID") {
        } else {
            $arrr = array();
            if ($itemName == 'Name') {
                $serialN = strstr($itemNodeValue, "InternetGatewayDevice.");

                while (strpos($serialN, ".")) {
                    $serialN = substr($serialN, strpos($serialN, ".") + 1, strlen($serialN) - strpos($serialN, "."));
                }

                $lastPartOfTheName = $serialN;

                if ($type == 'nameVal') {

                    $arrr['name'] = $lastPartOfTheName;
                    $GLOBALS['myArr'][] = $arrr;
                } else {
                    if ($GLOBALS['names'] == '') {
                        $GLOBALS['names'] = $lastPartOfTheName;
                    } else {
                        $GLOBALS['names'] = $GLOBALS['names'] . ' , ' . $lastPartOfTheName;
                    }
                }


            } else if ($itemName == 'Value') {
                if ($type == 'nameVal') {
                    $GLOBALS['myArr'][count($GLOBALS['myArr']) - 1]['value'] = $itemNodeValue;
                }
            }
        }
    } else {
        foreach ($childCou AS $chiItem1) {
            if ($chiItem1->nodeName != "#text") {
                $childCou1 = $chiItem1->childNodes;
                if ($childCou1->length <= 1) {
                    foreach ($chiItem1->attributes as $attr) {
                        $name = $attr->nodeName;
                        $value = $attr->nodeValue;
                    }
                } else {
                    foreach ($chiItem1->attributes as $attr) {
                        $name = $attr->nodeName;
                        $value = $attr->nodeValue;
                    }
                }
                getRec($childCou1, $chiItem1->nodeName, $chiItem1, $type);
            }
        }
        if ($itemName !== "SOAP-ENV:Body") {
        }
    }
}

function getAllParamsValuesByWebTaskIDByPage($activityID)
{
    include $_SESSION['APPPATH'] . 'models/modelWebTask.php';
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
    }

    $webTask = new ModelWebTask();
    $xml = $webTask->getXmlOfTheWebTaskByTaskID($activityID);

    if ($xml != null) {
        $pos = strpos($xml[0]->xml, "SetParameterValues");
        $posDel = strpos($xml[0]->xml, "DeleteObject");
        $postAdd = strpos($xml[0]->xml, "AddObject");
        $posSetAttr = strpos($xml[0]->xml, "SetParameterAttributes");
        $notif = false;
        if ($pos) {
            $startPart = substr($xml[0]->xml, strlen("<cwmp:SetParameterValues"), strlen($xml[0]->xml));
            $endVersion = '<cwmp:SetParameterValues xmlns:soap="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cwmp="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' . $startPart;

            $xmlDoc = new DOMDocument();
            $xmlDoc->loadXML($endVersion);
            $xmlDoc->formatOutput = true;
            $x = $xmlDoc->documentElement;
            $GLOBALS['myArr'] = array();
            if ($x != '' && $x->nodeName != '') {
                foreach ($x->attributes as $attr) {
                    $name = $attr->nodeName;
                    $value = $attr->nodeValue;
                }
                foreach ($x->childNodes AS $item) {
                    $itemName = $item->nodeName;
                    if ($itemName != "#text") {
                        $childCo = $item->childNodes;
                        foreach ($childCo AS $chiItem) {
                            $chNodName = $chiItem->nodeName;
                            if ($chNodName != "#text") {
                                $childCou = $chiItem->childNodes;
                                if ($childCou->length <= 1) {
                                    foreach ($chiItem->attributes as $attr) {
                                        $name = $attr->nodeName;
                                        $value = $attr->nodeValue;
                                    }
                                } else {
                                    foreach ($chiItem->attributes as $attr) {
                                        $name = $attr->nodeName;
                                        $value = $attr->nodeValue;
                                    }
                                }
                                getRec($childCou, $itemName, $chiItem, 'nameVal');
                                if ($chNodName == "cwmp:GetParameterValuesResponse") {
                                }
                            }
                        }
                    }
                }
            }

            $params = $GLOBALS['myArr'];
            $count = count($GLOBALS['myArr']);

            include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
        } else if ($posSetAttr) {
            $startPart = substr($xml[0]->xml, strlen("<cwmp:SetParameterAttributes"), strlen($xml[0]->xml));
            $endVersion = '<cwmp:SetParameterAttributes xmlns:soap="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cwmp="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' . $startPart;
            $xml = simplexml_load_string($endVersion);


            $notificationChange = $xml->ParameterList->SetParameterAttributesStruct->NotificationChange;
            $notification = $xml->ParameterList->SetParameterAttributesStruct->Notification;
            $notif = true;
            $params = false;

            include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
        } else if ($posDel) {

            $GLOBALS['myArr'] = array();

            $startPart = substr($xml[0]->xml, strlen("<cwmp:DeleteObject"), strlen($xml[0]->xml));
            $endVersion = '<cwmp:DeleteObject xmlns:soap="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cwmp="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' . $startPart;
            $xml = simplexml_load_string($endVersion);
            $paramName = $xml->ObjectName;
            $paramName = strstr($paramName, "InternetGatewayDevice");

            $paramName = rtrim($paramName, '.');

            while (strpos($paramName, ".")) {

                $paramName = substr($paramName, strpos($paramName, ".") + 1, strlen($paramName) - strpos($paramName, "."));

            }

            $GLOBALS['myArr'][0]['name'] = $ini_array['param_name'];
            $GLOBALS['myArr'][0]['value'] = $paramName;

            $params = $GLOBALS['myArr'];
            $count = count($GLOBALS['myArr']);
            include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
        } else if ($postAdd) {
            $GLOBALS['myArr'] = array();

            $startPart = substr($xml[0]->xml, strlen("<cwmp:AddObject"), strlen($xml[0]->xml));
            $endVersion = '<cwmp:AddObject xmlns:soap="http://schemas.xmlsoap.org/soap/encoding/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:cwmp="http://schemas.xmlsoap.org/soap/envelope/" xmlns:soap-env="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" ' . $startPart;
            $xml = simplexml_load_string($endVersion);
            $paramName = $xml->ObjectName;
            $paramName = strstr($paramName, "InternetGatewayDevice");

            $paramName = rtrim($paramName, '.');

            while (strpos($paramName, ".")) {
                $paramName = substr($paramName, strpos($paramName, ".") + 1, strlen($paramName) - strpos($paramName, "."));
            }
            $GLOBALS['myArr'][0]['name'] = $ini_array['param_name'];
            $GLOBALS['myArr'][0]['value'] = $paramName;
            $params = $GLOBALS['myArr'];
            $count = count($GLOBALS['myArr']);
            include $_SESSION['APPPATH'] . 'views/content/admin/activityParamsValues.php';
        } else {
            $params = false;
        }
    } else {
        $params = false;
    }

}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        try {
            $activityID = $_POST['activityID'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getAllParamsValuesByWebTaskIDByPage($activityID);
        } catch (\Exception $e) {
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}