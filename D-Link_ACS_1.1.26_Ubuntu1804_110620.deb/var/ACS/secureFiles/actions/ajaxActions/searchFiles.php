<?php


function getAllSearchedFile($searchVal,$filesTableColumns,$fileCount){


       include $_SESSION['APPPATH'] . 'models/device.php';
       include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
       include $_SESSION['APPPATH'] . 'util/paging.php';

       $device = new Device();
       $page = 1;
       $dirNameLogUpload = $_SESSION['REALPATH'] . "/" . "logUpload";
       $dirNameDump = $_SESSION['REALPATH'] . "/" . "dump";
       $dirNamePutConfigs = $_SESSION['REALPATH'] . "/" . "putConfigs";
       $dirNameConfigs = $_SESSION['REALPATH'] . "/" . "config";
       $dirNameFirmware = $_SESSION['REALPATH'] . "/" . "fw";

       $needFilesList1 = array();
       $allFiles = array();
       $countFileList = array();
       $fullPath = array();
       $fileType = array();
       $allSerialNumber = array();
       $allModelName = array();
       $fileListIsEmpty = true;
       $allPath = array();

       array_push($fullPath, $dirNameLogUpload);
       array_push($fullPath, $dirNameDump);
       array_push($fullPath, $dirNamePutConfigs);
       array_push($fullPath, $dirNameConfigs);

       if (file_exists($dirNameLogUpload)) {
           $files = scandir($dirNameLogUpload);
           $i = 1;
           foreach ($files as $f) {
               if ($f != "." && $f != ".." && (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f))) {
                   if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                           array_push($needFilesList1, $f);
                           array_push($countFileList, $f);
                           array_push($fileType, 'log');
                           array_push($allPath, "/logUpload/");
                           $serialNumberss = explode("_", $f);
                           $serialNumber = $serialNumberss[0];
                           array_push($allSerialNumber, $serialNumber);
                           $modelId = $device->getModelIdBySerialNumber($serialNumber);
                           $modelName = $device->getModelNameByID($modelId[0]->model_id);
                           array_push($allModelName, $modelName[0]->name);
                           $fileListIsEmpty = false;
                           $i++;
                       }
                   }
               }
           }

       if (file_exists($dirNameDump)) {
           $files = scandir($dirNameDump);
           $i = 1;
           foreach ($files as $f) {
               if ($f != "." && $f != ".." && $f != "example.ini" && (preg_match("/\.dump/", $f))) {
                       if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                           array_push($needFilesList1, $f);
                           array_push($countFileList, $f);
                           array_push($fileType, 'dump');
                           array_push($allPath, "/dump/");
                           $serialNumberss = explode("_", $f);
                           $serialNumber = $serialNumberss[0];
                           array_push($allSerialNumber, $serialNumber);
                           $modelId = $device->getModelIdBySerialNumber($serialNumber);
                           $modelName = $device->getModelNameByID($modelId[0]->model_id);
                           array_push($allModelName, $modelName[0]->name);
                           $fileListIsEmpty = false;
                           $i++;
                       }
                   }
               }
           }

       if (file_exists($dirNamePutConfigs)) {
           $files = scandir($dirNamePutConfigs);
           $i = 1;
           foreach ($files as $f) {
               if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                   if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                           array_push($needFilesList1, $f);
                           array_push($countFileList, $f);
                           array_push($fileType, 'config');
                           array_push($allPath, "/putConfigs/");
                           $serialNumberss = explode("_", $f);
                           $serialNumber = $serialNumberss[0];
                           array_push($allSerialNumber, $serialNumber);
                           $modelId = $device->getModelIdBySerialNumber($serialNumber);
                           $modelName = $device->getModelNameByID($modelId[0]->model_id);
                           array_push($allModelName, $modelName[0]->name);
                           $fileListIsEmpty = false;
                           $i++;
                       }
                   }
               }
           }

       if (file_exists($dirNameFirmware)) {
           $root = $dirNameFirmware;
           $iter = new RecursiveIteratorIterator(
               new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
               RecursiveIteratorIterator::SELF_FIRST,
               RecursiveIteratorIterator::CATCH_GET_CHILD
           );
           $paths = array($root);
           foreach ($iter as $path => $dir) {
               if ($dir->isDir()) {
                   $paths[] = $path;
               }
           }
           for ($a = 0; $a < count($paths); $a++) {
               $files = scandir($paths[$a]);
               $i = 1;
               foreach ($files as $f) {
                   if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {
                       $filepath = explode("ACS/",$paths[$a]);

                       $modelsPath = substr($filepath[1],3);
                       $modelId = explode("/", $modelsPath);
                       $modelNames = $device->getModelNameByID($modelId[1]);
                       if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                               array_push($needFilesList1, $f);
                               array_push($countFileList, $f);
                               array_push($fileType, 'bin');
                               array_push($allPath, "/".$filepath[1]);
                               array_push($fullPath, $paths[$a]);
                               $modelsCount = $device->getAllModelsCount();
                               $models = $device->getAllModels();

                               $modName = $modelNames[0]->name;

                               for ($k = 0; $k < $modelsCount[0]->count; $k++) {
                                   if ($modName == $models[$k]->name){
                                       array_push($allModelName, $models[$k]->name);
                                   }
                               }
                               $fileListIsEmpty = false;
                               $i++;
                       }
                       if ($searchVal != ""){
                           if (stristr($modelNames[0]->name, $searchVal) && !stristr($f, $searchVal)){
                               array_push($needFilesList1, $f);
                               array_push($countFileList, $f);
                               array_push($fileType, 'bin');
                               array_push($allPath, "/".$filepath[1]);
                               array_push($fullPath, $paths[$a]);
                               $modelsCount = $device->getAllModelsCount();
                               $models = $device->getAllModels();

                               $modName = $modelNames[0]->name;

                               for ($k = 0; $k < $modelsCount[0]->count; $k++) {
                                   if ($modName == $models[$k]->name){
                                       array_push($allModelName, $models[$k]->name);
                                   }
                               }
                               $fileListIsEmpty = false;
                               $i++;
                           }

                       }
                   }
               }
           }
       }

       if (file_exists($dirNameConfigs)) {
           $files = scandir($dirNameConfigs);
           $i = 1;
           foreach ($files as $file) {
               if ($file != "." && $file != ".."){
                   $filePhat = scandir($dirNameConfigs . "/" . $file);
                   foreach ($filePhat as $f) {
                       $modelName = $device->getModelNameByID($file);

                       if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                           if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                                   array_push($needFilesList1, "/" . $file . "/" . $f);
                                   array_push($countFileList, $f);
                                   array_push($fileType, 'config');
                                   array_push($allPath, "/config/" . $file);
                                   array_push($allSerialNumber, "");
                                   array_push($allModelName, $modelName[0]->name);
                                   $fileListIsEmpty = false;
                                   $i++;
                               }

                           if ($searchVal != "" && stristr($modelName[0]->name, $searchVal) && !stristr($f, $searchVal)){
                               array_push($needFilesList1, "/" . $file . "/" . $f);
                               array_push($countFileList, $f);
                               array_push($fileType, 'config');
                               array_push($allPath, "/config/" . $file);
                               array_push($allSerialNumber, "");
                               array_push($allModelName, $modelName[0]->name);
                               $fileListIsEmpty = false;
                               $i++;
                           }
                           } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                               if ($searchVal != "" && stristr($f, $searchVal) || $searchVal == "") {
                                   array_push($needFilesList1, "/" . $file . "/" . $f);
                                   array_push($fileType, 'config');
                                   array_push($allPath, "/config/" . $file);
                                   array_push($allModelName, "");
                                   $fileListIsEmpty = false;
                                   $i++;
                               }
                               if ($searchVal != "" && stristr($modelName[0]->name, $searchVal) && !stristr($f, $searchVal)){
                                   array_push($needFilesList1, "/" . $file . "/" . $f);
                                   array_push($fileType, 'config');
                                   array_push($allPath, "/config/" . $file);
                                   array_push($allModelName, "");
                                   $fileListIsEmpty = false;
                                   $i++;
                               }
                            }
                       }
                   }
               }
           }


       $FilteredModels = array();
       $FilteredSerialNumbers = array();
       $FilteredTypes = array();
       $FilteredModels = array_unique($allModelName);
       $FilteredSerialNumbers = array_unique($allSerialNumber);
       $FilteredTypes = array_unique($fileType);

       $limit = PagingConstants::$clientsCount;
       $offset = ($page - 1) * $limit;

       $page = 1;
       $limit = $rowCountFile = $fileCount;
       $offset = ($page - 1) * $limit;

       $needFilesList = array_slice($needFilesList1, $offset, $limit);

       $pagesCount = Paging::getPagesCount(count($needFilesList1), $limit);


       include $_SESSION['APPPATH'].'views/content/admin/filteredFiles.php';
   }





if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
    if (isset($_SESSION['logged_in'])) {
        try{
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);

            $searchVal = $_POST['searchVal'];
            $fileCount = $userSettings->rowCountFile;
            $filesTableColumns = $userSettings->filesTableColumns;

            define('BASEPATH', $_SESSION['BASEPATH']);

            getAllSearchedFile($searchVal,$filesTableColumns,$fileCount);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}