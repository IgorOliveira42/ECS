<?php

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
    $_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";

    include $_SESSION['APPPATH'] . 'models/JWT/JWT.php';
    include $_SESSION['APPPATH'] . 'models/xor/xor.php';
    include $_SESSION['APPPATH'] . 'actions/api/token.php';
    if(!class_exists("ModelUser")) {
        include $_SESSION['APPPATH'] . 'models/modelUser.php';
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            $result =  "false";
            if(isset($_COOKIE['timeOut'])) {
                if (isset($_COOKIE['timeOut']) && isset($_COOKIE['loggedInUser'])) {
                    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
                        $result = "true";
                    }
                } else {
                    $result = "true";
                }
            }
            if(isset($_COOKIE['token'])) {
                $token = $_COOKIE['token'];
                if($token != '') {
                    $login = token::check_token($token);
                    if($login!=false) {
                        $user = new ModelUser();
                        $userExist = $user->checkUserIdExist($login);
                        if(empty($userExist)) {
                            unset($_COOKIE['token']);
                            setcookie('token', null, -1, '/');
                            $result = "true";
                        }
                    } else {
                        unset($_COOKIE['token']);
                        setcookie('token', null, -1, '/');
                        $result = "true";
                    }
                } else {
                    unset($_COOKIE['token']);
                    setcookie('token', null, -1, '/');
                    $result = "true";
                }
            } else {
                $result = "true";
            }
            echo $result;
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
