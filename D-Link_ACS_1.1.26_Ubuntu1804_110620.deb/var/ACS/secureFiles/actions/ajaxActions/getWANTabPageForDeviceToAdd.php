<?php
function viewWanParamsToAdd($serialN, $connType,$devStatus,$havePerms){

    include $_SESSION['APPPATH'].'models/modelParams.php';

    $modParams = new ModelParams();
    $connIndexArr = $modParams->getConnIndexOfDeviceBySerial($serialN);
    $taggedNatVlan = $modParams->getTaggedNatVlans($serialN); 
    $connIndex = 1;
//    $version = $_POST['version'];
    if(!empty($connIndexArr)){
        $connIndex = $connIndexArr[0]->conn_index;
    } else {$connIndex = 1;}

    $deviceStatus = $devStatus;
    $havPerms = $havePerms;
    $allParams = $modParams->getAllWanParams($serialN);
    if($allParams){
        $macAddress = $allParams[0]->mac_address;
    } else {
        $macAddress='';
    }
    if ($connType == "Static") {
//        $indexFromStaticPar = $modParams->getIndexFromWanStaticParamsToAdd($serialN);
//        if (!$indexFromStaticPar) {
//            $indexFromDynamicPar = $modParams->getIndexFromWanDynamicParamsToAdd($serialN);
//            if ($indexFromDynamicPar) {
//                $params = array(
////                    "flagl" => array("flagl", "addStaticWan"),
////                    "index" => array("index", "%d"),
//                    "flagl" => array("flagl", "setStaticWan"),
//                    "index" => array("index", $indexFromDynamicPar[0]->num_index),
//                    "name"=>array("Name", ""),
//                    "mtu" => array("MaxMTUSize", 1500),
//                    "mac" => array("MACAddress", /*$serialN*/ $indexFromDynamicPar[0]->mac_address),
//                    "ip" => array("ExternalIPAddress", ''),
//                    "netmask" => array("SubnetMask", ''),
//                    "gateway" => array("DefaultGateway", ''),
////                    "dns" => array("DNSServers", ''),
//                    "primaryDns" => array("DNSServers", ''),
//                    "secondaryDns" => array("DNSServers", ''),
//                    "enablePing" => array("X_DLINK_PingEnabled", 1),
//                    "enableNat" => array("NATEnabled", 1),
//                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
//                    "enable" => array("Enable",0),
//                    "exist" => "0",
//                    "valueChange"=>0,
//                    "numIndex"=>0,
//                    "interfaceType" => array("internet", "-1"),
//                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.%d.")
//                    );
//            } else {
                $params = array(
                    "flagl" => array("flagl", "addStaticWan"),
//                    "index" => array("index", 1),
                    "index" => array("index", "%d"),
                    "name"=>array("Name", ""), 
                    "mtu" => array("MaxMTUSize", 1500), 
                    "mac" => array("MACAddress",  /*$serialN*/ $macAddress), 
                    "ip" => array("ExternalIPAddress", ''), 
                    "netmask" => array("SubnetMask", ''), 
                    "gateway" => array("DefaultGateway", ''), 
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1), 
                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
                    "enable" => array("Enable",1),
                    "exist" => "0",
                    "valueChange"=>0,
                    "numIndex"=>0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.1.")
                    );
//            }
//        } else {
//            $params = array(
////                "flagl" => array("flagl", "addStaticWan"),
//                "flagl" => array("flagl", "setStaticWan"),
//                "index" => array("index", $indexFromStaticPar[0]->num_index),
//                "name"=>array("Name", ""),
//                "mtu" => array("MaxMTUSize", 1500),
//                "mac" => array("MACAddress", /*$serialN*/ $indexFromStaticPar[0]->mac_address),
//                "ip" => array("ExternalIPAddress", ''),
//                "netmask" => array("SubnetMask", ''),
//                "gateway" => array("DefaultGateway", ''),
////                "dns" => array("DNSServers", ''),
//                "primaryDns" => array("DNSServers", ''),
//                "secondaryDns" => array("DNSServers", ''),
//                "enablePing" => array("X_DLINK_PingEnabled", 1),
//                "enableNat" => array("NATEnabled", 1),
//                "enableIGMP" => array("X_COM_IGMPEnabled", $indexFromStaticPar[0]->igmp_multicast),
//                "enable" => array("Enable",0),
//                "exist" => "0",
//                "valueChange"=>0,
//                "numIndex"=>0,
//                "interfaceType" => array("internet", "-1"),
//                "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.".$indexFromStaticPar[0]->num_index.".")
//                );
//        }
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanStatic.php';
    } else if ($connType == "Static_IPv6"){
        $indexFromStaticPar = $modParams->getIndexFromWanStaticIPv6ParamsToAdd($serialN);
//        if (!$indexFromStaticPar) {

                $params = array(
                    "flagl" => array("flagl", "addStaticIPv6Wan"),
//                    "index" => array("index", 1),
                    "index" => array("index", "%d"),
                    "name"=>array("Name", ""),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress",  /*$serialN*/ $macAddress),
                    "ip" => array("ExternalIPAddress", ''),
                    "prefix" => array("Prefix", ''),
                    "netmask" => array("SubnetMask", ''),
                    "gateway" => array("DefaultGateway", ''),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSPrim", ''),
                    "secondaryDns" => array("DNSSec", ''),
                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
                    "enable" => array("Enable",1),
//                    "enablePing" => array("X_DLINK_PingEnabled",0),
                    "exist" => "0",
                    "valueChange"=>0,
                    "numIndex"=>0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.1.")
                );

//        } else {
//            $params = array(
////                "flagl" => array("flagl", "addStaticWan"),
//                "flagl" => array("flagl", "setStaticIPv6Wan"),
//                "index" => array("index", $indexFromStaticPar[0]->num_index),
//                "name"=>array("Name", ""),
//                "mtu" => array("MaxMTUSize", 1500),
//                "mac" => array("MACAddress", /*$serialN*/ $indexFromStaticPar[0]->mac_address),
//                "ip" => array("ExternalIPAddress", ''),
//                "netmask" => array("SubnetMask", ''),
//                "gateway" => array("DefaultGateway", ''),
////                "dns" => array("DNSServers", ''),
//                "primaryDns" => array("DNSPrim", ''),
//                "secondaryDns" => array("DNSSec", ''),
//                "enableIGMP" => array("X_COM_IGMPEnabled", $indexFromStaticPar[0]->igmp_multicast),
//                "enable" => array("Enable",0),
//                "enablePing" => array("X_DLINK_PingEnabled",0),
//                "exist" => "0",
//                "valueChange"=>0,
//                "numIndex"=>0,
//                "interfaceType" => array("internet", "-1"),
//                "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.".$indexFromStaticPar[0]->num_index.".")
//            );
//        }
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanStaticV6.php';
    }else if ($connType == "DHCP") {
        $indexFromDynamicPar = $modParams->getIndexFromWanDynamicParamsToAdd($serialN);

//        if (!$indexFromDynamicPar) {
//            $indexFromStaticPar = $modParams->getIndexFromWanStaticParamsToAdd($serialN);
//            if ($indexFromStaticPar) {
//                $params = array(
////                    "index" => array("index", "%d"),
////                    "flagl" => array("flagl", "addDynamicWan"),
//                    "index" => array("index", $indexFromStaticPar[0]->num_index),
//                    "flagl" => array("flagl", "setDynamicWan"),
//                    "name"=>array("Name", ""),
//                    "mtu" => array("MaxMTUSize", 1500),
//                    "mac" => array("MACAddress", /*$serialN*/ $indexFromStaticPar[0]->mac_address),
////                    "dns" => array("DNSServers", ''),
//                    "primaryDns" => array("DNSServers", ''),
//                    "secondaryDns" => array("DNSServers", ''),
//                    "enablePing" => array("X_DLINK_PingEnabled", 1),
//                    "enableNat" => array("NATEnabled", 1),
//                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
////                    "enableDns" => array("DNSOverrideAllowed", 0),
//                    "enableDns" => array("DNSOverrideAllowed", 1),
//                    "enable" => array("Enable",0),
//                    "exist" => "0",
//                    "ip"=>"",
//                    "valueChange"=>0,
//                    "numIndex"=>0,
//                    "interfaceType" => array("internet", "-1"),
//                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.%d.")
//                    );
//            } else {
//                $params = array(
////                    "index" => array("index", 1),
//                    "index" => array("index", "%d"),
//                    "flagl" => array("flagl", "addDynamicWan"),
//                    "name"=>array("Name", ""),
//                    "mtu" => array("MaxMTUSize", 1500),
//                    "mac" => array("MACAddress", /*$serialN*/ $macAddress),
////                    "dns" => array("DNSServers", ''),
//                    "primaryDns" => array("DNSServers", ''),
//                    "secondaryDns" => array("DNSServers", ''),
//                    "enablePing" => array("X_DLINK_PingEnabled", 1),
//                    "enableNat" => array("NATEnabled", 1),
//                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
////                    "enableDns" => array("DNSOverrideAllowed", 0),
//                    "enableDns" => array("DNSOverrideAllowed", 1),
//                    "enable" => array("Enable",0),
//                    "exist" => "0",
//                    "ip"=>"",
//                    "valueChange"=>0,
//                    "numIndex"=>0,
//                    "interfaceType" => array("internet", "-1"),
//                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANPPPConnection.1.")
//                    );
//            }
//        } else {
        $params = array(
//                    "index" => array("index", 1),
                    "index" => array("index", "%d"),
                    "flagl" => array("flagl", "addDynamicWan"),
                    "name"=>array("Name", ""),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress", /*$serialN*/ $macAddress),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSServers", ''),
                    "secondaryDns" => array("DNSServers", ''),
                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableNat" => array("NATEnabled", 1),
                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
//                    "enableDns" => array("DNSOverrideAllowed", 0),
                    "enableDns" => array("DNSOverrideAllowed", 1),
                    "enable" => array("Enable",1),
                    "exist" => "0",
                    "ip"=>"",
                    "valueChange"=>0,
                    "numIndex"=>0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANPPPConnection.1.")
                    );
//        }
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanDynamic.php';
        
    }else if ($connType == "DHCP_IPv6") {
        $indexFromDynamicPar = $modParams->getIndexFromWanDynamicIPv6ParamsToAdd($serialN);

//        if (!$indexFromDynamicPar) {
                $params = array(
//                    "index" => array("index", 1),
                    "index" => array("index", "%d"),
                    "flagl" => array("flagl", "addDynamicIPv6Wan"),
                    "name"=>array("Name", ""),
                    "mtu" => array("MaxMTUSize", 1500),
                    "mac" => array("MACAddress", /*$serialN*/ $macAddress),
//                    "dns" => array("DNSServers", ''),
                    "primaryDns" => array("DNSPrim", ''),
                    "secondaryDns" => array("DNSSec", ''),
                    "Slaac" => array("DefaultGateway", ''),
//                    "enablePing" => array("X_DLINK_PingEnabled", 1),
                    "enableIGMP" => array("X_COM_IGMPEnabled", 0),
//                    "enableDns" => array("DNSOverrideAllowed", 0),
                    "enableDns" => array("DNSOverrideAllowed", 1),
                    "enableSlaac" => array("SLAAC", 1),
                    "enable" => array("Enable",1),
                    "exist" => "0",
                    "ip"=>"",
                    "valueChange"=>0,
                    "numIndex"=>0,
                    "interfaceType" => array("internet", "-1"),
                    "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANPPPConnection.1.")
                );
//        } else {
//            $params = array(
////                "index" => array("index", "%d"),
////                "flagl" => array("flagl", "addDynamicWan"),
//                "index" => array("index", $indexFromDynamicPar[0]->num_index),
//                "flagl" => array("flagl", "setDynamicIPv6Wan"),
//                "name"=>array("Name", ""),
//                "mtu" => array("MaxMTUSize", 1500),
//                "mac" => array("MACAddress", /*$serialN*/ $indexFromDynamicPar[0]->mac_address),
////                "dns" => array("DNSServers", ''),
//                "primaryDns" => array("DNSServers", ''),
//                "secondaryDns" => array("DNSServers", ''),
//                "Slaac" => array("DefaultGateway", ''),
//                "enablePing" => array("X_DLINK_PingEnabled", 1),
//                "enableIGMP" => array("X_COM_IGMPEnabled", $indexFromDynamicPar[0]->igmp_multicast),
////                "enableDns" => array("DNSOverrideAllowed", 0),
//                "enableDns" => array("DNSOverrideAllowed", 1),
//                "enableSlaac" => array("SLAAC", 1),
//                "enable" => array("Enable",0),
//                "exist" => "0",
//                "ip"=>"",
//                "valueChange"=>0,
//                "numIndex"=>0,
//                "interfaceType" => array("internet", "-1"),
//                "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService","InternetGatewayDevice.WANDevice.".$connIndex.".WANConnectionDevice.1.WANIPConnection.%d.")
//            );
//        }
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanDynamic_IPv6.php';

    } else if ($connType == "PPPoE") {
        $params = array(
            "index" => array("index", "%d"), 
            "name" => array("Name", ''), 
            "mac" => array("MACAddress",  /*$serialN*/ $macAddress), 
            "username" => array("Username", ''), 
            "password" => array("Password", ''), 
            "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
            "mru" => array("MaxMRUSize", 1492), 
            "ppp_lcp_echo" => array("PPPLCPEcho", 30),
            "ppp_lcp_retry" => array("PPPLCPEchoRetry", 3),
            "enablePing" => array("X_DLINK_PingEnabled", 1),
            "enableNat" => array("NATEnabled", 1), 
            "serviceName" => array("PPPoEServiceName", ''),
            "enable" => array("Enable",1),
            "exist" => "0",
            "valueChange"=>0,
            "numIndex"=>0,
            "interfaceType" => array("internet", "-1"),
            "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.%d.")
            );
        $toDoForPPPOE ='addPPPWan';
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanPPP.php';
        
    } else if ($connType == "PPPoE_v6") {
        $params = array(
            "index" => array("index", "%d"),
            "name" => array("Name", ''),
            "mac" => array("MACAddress",  /*$serialN*/ $macAddress),
            "Slaac" => array("DefaultGateway", ''),
            "enablePing" => array("X_DLINK_PingEnabled", 1),
            "username" => array("Username", ''),
            "password" => array("Password", ''),
            "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'),
            "mtu" => array("MaxMTUSize", 1500),
            "primaryDns" => array("DNSServers", ''),
            "secondaryDns" => array("DNSServers", ''),
            "ppp_lcp_echo" => array("PPPLCPEcho", 30),
            "ppp_lcp_retry" => array("PPPLCPEchoRetry", 3),
            "enableDns" => array("DNSOverrideAllowed", 1),
            "enableNat" => array("NATEnabled", 1),
            "enableSlaac" => array("SLAAC", 1),
            "serviceName" => array("PPPoEServiceName", ''),
            "enable" => array("Enable",1),
            "exist" => "0",
            "valueChange"=>0,
            "numIndex"=>0,
            "interfaceType" => array("internet", "-1"),
            "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.%d.")
        );
        $toDoForPPPOE ='addPPPWan';
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanPPP_IPv6.php';

    } else if ($connType == "L2TP") {
        $params = array(
            "index" => array("index", "%d"), 
            "name" => array("Name", ''), 
            "mac" => array("MACAddress",  /*$serialN*/ $macAddress), 
            "username" => array("Username", ''), 
            "password" => array("Password", ''), 
            "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
            "mru" => array("MaxMRUSize", 1456), 
            "ppp_lcp_echo" => array("PPPLCPEcho", 30),
            "ppp_lcp_retry" => array("PPPLCPEchoRetry", 3),
            "enablePing" => array("X_DLINK_PingEnabled", 1),
            "enableNat" => array("NATEnabled", 1), 
            "serviceName" => array("PPPoEServiceName", ''),
            "enable" => array("Enable",1),
            "exist" => "0",
            "valueChange"=>0,
            "numIndex"=>0,
            "interfaceType" => array("internet", "-1"),
            "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.%d.")
            );
        $toDoForPPPOE ='addPPPWan';
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanL2TP.php';
        
    } else if ($connType == "PPTP") {
        $params = array(
            "index" => array("index", "%d"), 
            "name" => array("Name", ''), 
            "mac" => array("MACAddress",  /*$serialN*/ $macAddress), 
            "username" => array("Username", ''), 
            "password" => array("Password", ''), 
            "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'), 
            "mru" => array("MaxMRUSize", 1456), 
            "ppp_lcp_echo" => array("PPPLCPEcho", 30),
            "ppp_lcp_retry" => array("PPPLCPEchoRetry", 3),
            "enablePing" => array("X_DLINK_PingEnabled", 1),
            "enableNat" => array("NATEnabled", 1), 
            "serviceName" => array("PPPoEServiceName", ''),
            "enable" => array("Enable",1),
            "exist" => "0",
            "valueChange"=>0,
            "numIndex"=>0,
            "interfaceType" => array("internet", "-1"),
            "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.%d.")
            );
        $toDoForPPPOE ='addPPPWan';
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanPPTP.php';
    } else if($connType == "PPPoEDualStack") {
        $params = array(
            "index" => array("index", "%d"),
            "name" => array("Name", ''),
            "mac" => array("MACAddress",  /*$serialN*/ $macAddress),
            "Slaac" => array("DefaultGateway", ''),
            "enablePing" => array("X_DLINK_PingEnabled", 1),
            "username" => array("Username", ''),
            "password" => array("Password", ''),
            "ppp_auth_protocol" => array("PPPAuthenticationProtocol", 'AUTO'),
            "mru" => array("MaxMRUSize", 1492),
            "mtu" => array("MaxMTUSize", 1500),
            "primaryDns" => array("DNSPrim", ''),
            "secondaryDns" => array("DNSSec", ''),
            "ppp_lcp_echo" => array("PPPLCPEcho", 30),
            "ppp_lcp_retry" => array("PPPLCPEchoRetry", 3),
            "enableDns" => array("DNSOverrideAllowed", 0),
            "enableNat" => array("NATEnabled", 1),
            "enableSlaac" => array("SLAAC", 1),
            "serviceName" => array("PPPoEServiceName", ''),
            "enable" => array("Enable",1),
            "exist" => "0",
            "valueChange"=>0,
            "numIndex"=>0,
            "interfaceType" => array("internet", "-1"),
            "defconn"=>array("InternetGatewayDevice.Layer3Forwarding.DefaultConnectionService", "InternetGatewayDevice.WANDevice." . $connIndex . ".WANConnectionDevice.1.WANPPPConnection.%d.")
        );
        $toDoForPPPOE ='addPPPDualStackWan';
        $toAddConnect = 'true';
        include $_SESSION['APPPATH'].'views/content/admin/wanPPPDualStack.php';
    }
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
        $serialN = $_POST['serialNumber'];
        $actionName = $_POST['actionName'];
        $deviceStatus = $_POST['devStatus'];
        $havPerms = $_POST['havPermissions'];

        //    $_SESSION['activeWanTab']=$actionName;
        try{
            viewWanParamsToAdd($serialN, $actionName,$deviceStatus,$havPerms);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }  

    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
