<?php

function getAllFilteredFile($model,$type,$filesTableColumns,$page,$fileCount)
{
    include $_SESSION['APPPATH'] . 'models/device.php';
    include $_SESSION['APPPATH'] . 'util/pagingConstants.php';
    include $_SESSION['APPPATH'] . 'util/paging.php';

    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }

    $dev = new Device();

    $dirNameLogUpload = $_SESSION['REALPATH'] . "/" . "logUpload";
    $dirNameDump = $_SESSION['REALPATH'] . "/" . "dump";
    $dirNamePutConfigs = $_SESSION['REALPATH'] . "/" . "putConfigs";
    $dirNameConfigs = $_SESSION['REALPATH'] . "/" . "config";
    $dirNameFirmware = $_SESSION['REALPATH'] . "/" . "fw";
    $fullPath = array();

    array_push($fullPath, $dirNameLogUpload);
    array_push($fullPath, $dirNameDump);
    array_push($fullPath, $dirNamePutConfigs);
    array_push($fullPath, $dirNameConfigs);

    if(is_dir($dirNameFirmware)) {
        $root = $dirNameFirmware;
        $iter = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST,
            RecursiveIteratorIterator::CATCH_GET_CHILD
        );
        $paths = array($root);
        foreach ($iter as $path => $dir) {
            if ($dir->isDir()) {
                $paths[] = $path;
            }
        }
        for ($a = 0; $a < count($paths); $a++) {
            array_push($fullPath, $paths[$a]);
        }
    }

    $needFilesList1 = array();
    $fileType = array();
    $allSerialNumber = array();
    $allModelName = array();
    $allPath = array();
    $fileListIsEmpty = true;

    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    $userSettings->fileFilter = array( 'model' => $model, 'type' => $type);
    $userSettings->filesTableColumns = array('n' => $filesTableColumns->n, 'fN' => $filesTableColumns->fN, 'sN' => $filesTableColumns->sN, 'modN' => $filesTableColumns->modN, 'fSize' => $filesTableColumns->fSize,'type'=>$filesTableColumns->type);
    $userSettings->rowCountFile = $fileCount;

    setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7), '/');

    if ($model != '0' && $type == '0') {

        $modelId = $dev->getModelIdByModel($model);

        for ($k = 0; $k < count($fullPath); $k++) {
            $path = $fullPath[$k];
            if (file_exists($path)) {
                $files = scandir($path);
                $i = 1;

                foreach ($files as $file) {
                    if (file_exists($path . "/" . $file . "/") && $file != '.' && $file != '..' && preg_match("/config/", $path)){
                        $filePhat = scandir($path . "/" . $file);
                        for ($j = 0; $j < count($modelId); $j++){

                            if (isset($modelId[$j]->id) && $file == $modelId[$j]->id){
                                $filePhat = scandir($dirNameConfigs . "/" . $file);

                                foreach ($filePhat as $f) {
                                    if ($f != "." && $f != ".." && (preg_match("/_config.tar.gz/", $f) || preg_match("/tar.gz/", $f))) {
                                        array_push($needFilesList1, "/" . $file . "/" . $f);
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/config/" . $file);
                                        array_push($allSerialNumber, "");
                                        array_push($allModelName, $model);
                                        $fileListIsEmpty = false;
                                        $i++;
                                    }
                                }
                            }
                        }
                    }else{
                        for ($j = 0; $j < count($modelId); $j++) {
                            $serialNumbers = $dev->getSerialNumberByModelId($modelId[$j]->id);
                            for ($i = 0; $i < count($serialNumbers); $i++) {
                                $serialNumber = $serialNumbers[$i]->serial_number;
                                $serial = "/$serialNumber/";
                                if (preg_match($serial, $file) == 1) {
                                    array_push($needFilesList1, $file);
                                    if (preg_match("/\.log/", $file) || preg_match("/_custom_log.tar.gz/", $file)) {
                                        array_push($fileType, 'log');
                                        array_push($allPath, "/logUpload/");
                                    } else if (preg_match("/\.dump/", $file)) {
                                        array_push($fileType, 'dump');
                                        array_push($allPath, "/dump/");
                                    } else if (preg_match("/_config.tar.gz/", $file)) {
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/putConfigs/");
                                    }
                                    $serialNumberss = explode("_", $file);
                                    $serialNumber1 = $serialNumberss[0];
                                    array_push($allSerialNumber, $serialNumber1);
                                    array_push($allModelName, $model);
                                    $fileListIsEmpty = false;
                                    $i++;
                                }
                            }
                        }

                        $filepath = explode("ACS/",$fullPath[$k]);
                        $modelsPath = substr($filepath[1],3);
                        $modelId1 = explode("/", $modelsPath);

                        if (preg_match("/.bin/", $file)) {
                            for ($q = 0; $q < count($modelId);$q++){
                                if ($modelId[$q]->id == $modelId1[1]){
                                    $modelNames = $dev->getModelNameByID($modelId1[1]);
                                    $modName = $modelNames[0]->name;

                                    array_push($needFilesList1, $file);
                                    array_push($fileType, 'bin');
                                    array_push($allPath, "/".$filepath[1]);
                                    array_push($allModelName, $modName);
                                }
                            }
                        }
                    }
                }
            }
        }
    } else if ($model == '0' && $type != '0') {
        if ($type == 'log') {
            if (file_exists($dirNameLogUpload)) {
                $files = scandir($dirNameLogUpload);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f)) {
                        array_push($needFilesList1, $f);
                        array_push($fileType, 'log');
                        array_push($allPath, "/logUpload/");
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }
        } else if ($type == 'dump') {
            if (file_exists($dirNameDump)) {
                $files = scandir($dirNameDump);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/\.dump/", $f) && ($f != "example.ini")) {
                        array_push($fileType, 'dump');
                        array_push($allPath, "/dump/");
                        array_push($needFilesList1, $f);
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }
        } else if ($type == 'bin') {
            if (is_dir($dirNameFirmware)) {
                if (file_exists($dirNameFirmware)) {
                    $root = $dirNameFirmware;
                    $iter = new RecursiveIteratorIterator(
                        new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                        RecursiveIteratorIterator::SELF_FIRST,
                        RecursiveIteratorIterator::CATCH_GET_CHILD
                    );
                    $paths = array($root);
                    foreach ($iter as $path => $dir) {
                        if ($dir->isDir()) {
                            $paths[] = $path;
                        }
                    }
                    for ($a = 0; $a < count($paths); $a++) {
                        $files = scandir($paths[$a]);
                        $i = 1;
                        foreach ($files as $f) {
//                            $undefinedModel = true;

                            if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {
                                array_push($needFilesList1, $f);
                                array_push($fileType, 'bin');
                                $filepath = explode("ACS/",$paths[$a]);

                                $modelsPath = substr($filepath[1],3);
                                $modelId = explode("/", $modelsPath);
                                $modelNames = $dev->getModelNameByID($modelId[1]);
                                $modName = $modelNames[0]->name;

                                array_push($allPath, "/".$filepath[1]);
                                $modelsCount = $dev->getAllModelsCount();
                                $models = $dev->getAllModels();
                                array_push($allModelName, $modName);

                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
        } else if ($type == 'config') {
            if (file_exists($dirNamePutConfigs)) {
                $files = scandir($dirNamePutConfigs);
                $i = 1;
                foreach ($files as $f) {
                    if (preg_match("/_config.tar.gz/", $f)) {
                        array_push($fileType, 'config');
                        array_push($allPath, "/putConfigs/");
                        array_push($needFilesList1, $f);
                        $serialNumberss = explode("_", $f);
                        $serialNumber1 = $serialNumberss[0];
                        array_push($allSerialNumber, $serialNumber1);
                        $modelId = $dev->getModelIdBySerialNumber($serialNumber1);
                        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                        array_push($allModelName, $modelName[0]->name);
                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }

            if (file_exists($dirNameConfigs)) {
                $files = scandir($dirNameConfigs);
                $i = 1;
                foreach ($files as $file) {
                    if ($file != "." && $file != ".."){
                        $filePhat = scandir($dirNameConfigs . "/" . $file);
                        foreach ($filePhat as $f) {
                            if ((preg_match("/_config.tar.gz/", $f) || preg_match("/tar.gz/", $f))) {
                                array_push($needFilesList1, "/" . $file . "/" . $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/config/" . $file);
                                array_push($allSerialNumber, "");
                                $modelName = $dev->getModelNameByID($file);
                                array_push($allModelName, $modelName[0]->name);
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }
                }
            }
        }
    } else if ($model != '0'  && $type != '0') {
        $modelId = $dev->getModelIdByModel($model);
        for ($k = 0; $k < count($fullPath); $k++) {
            $path = $fullPath[$k];
            if (file_exists($path)) {
                $files = scandir($path);
                $i = 1;

                foreach ($files as $f) {
                    if (file_exists($path . "/" . $f . "/") && $f != '.' && $f != '..' && preg_match("/config/", $path)){
                        $filePhat = scandir($path . "/" . $f);
                        for ($j = 0; $j < count($modelId); $j++){
                            if ($f == $modelId[$j]->id){
                                $filePhat = scandir($dirNameConfigs . "/" . $f);
                                foreach ($filePhat as $file) {
                                    if ($file != "." && $file != ".." && (preg_match("/_config.tar.gz/", $file) || preg_match("/tar.gz/", $file)) && $type == 'config') {
                                        array_push($needFilesList1, "/" . $f . "/" . $file);
                                        array_push($fileType, 'config');
                                        array_push($allPath, "/config/" . $f);
                                        array_push($allSerialNumber, "");
                                        array_push($allModelName, $model);
                                        $fileListIsEmpty = false;
                                        $i++;
                                    }
                                }
                            }
                        }
                    }

                    for ($j = 0; $j < count($modelId); $j++) {
                        $serialNumbers = $dev->getSerialNumberByModelId($modelId[$j]->id);
                        for ($i = 0; $i < count($serialNumbers); $i++) {
                            $serialNumber = $serialNumbers[$i]->serial_number;
                            $serial = "/$serialNumber/";
                            if ((preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f)) && $type == 'log' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($fileType, 'log');
                                array_push($allPath, "/logUpload/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $fileListIsEmpty = false;
                                $i++;
                            } else if ((preg_match("/\.dump/", $f) && $f != "example.ini") && $type == 'dump' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($fileType, 'dump');
                                array_push($allPath, "/dump/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $fileListIsEmpty = false;
                                $i++;
                            } else if (preg_match("/_config.tar.gz/", $f) && $type == 'config' && preg_match($serial, $f) == 1) {
                                array_push($needFilesList1, $f);
                                array_push($fileType, 'config');
                                array_push($allPath, "/putConfigs/");
                                $serialNumberss = explode("_", $f);
                                $serialNumber1 = $serialNumberss[0];
                                array_push($allSerialNumber, $serialNumber1);
                                array_push($allModelName, $model);
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }

                    $filepath = explode("ACS/",$fullPath[$k]);
                    $modelsPath = substr($filepath[1],3);
                    $modelId1 = explode("/", $modelsPath);

                    if (preg_match("/.bin/", $f) && $type == 'bin') {
                        for ($q = 0; $q < count($modelId);$q++){
                            if ($modelId[$q]->id == $modelId1[1]){
                                array_push($needFilesList1, $f);
                                array_push($fileType, 'bin');
                                array_push($allPath, "/".$filepath[1]);
                                $modelNames = $dev->getModelNameByID($modelId1[1]);
                                $modName = $modelNames[0]->name;

                                array_push($allModelName, $modName);
                                $fileListIsEmpty = false;
                                $i++;
                            }
                        }
                    }

//                    $filepath = explode("ACS/",$fullPath[$k]);
//                    $modelsPath = substr($filepath[1],3);
//                    $modelId1 = explode("/", $modelsPath);
//
//                    if (preg_match("/.bin/", $f) && $type == 'bin') {
//                        for ($q = 0; $q <= count($modelId);$q++){
//                            if ($modelId[$q]->id == $modelId1[0]){
//                                array_push($needFilesList1, $f);
//                                array_push($countFileList, $f);
//                                array_push($fileType, 'bin');
//                                array_push($allPath, "/".$filepath[1]);
//                                $modelNames = $dev->getModelNameByID($modelId1[0]);
//                                $modName = $modelNames[0]->name;
//                                $hwVersion = $modelNames[0]->hw_version;
//                                array_push($allModelName, $modName);
//                                array_push($allHwVersion, $hwVersion);
//                                $fileListIsEmpty = false;
//                                $i++;
//                            }
//                        }
//                    }
//


                }
            }
        }
    } else if ($model == '0'  && $type == '0') {
        if (file_exists($dirNameLogUpload)) {
            $files = scandir($dirNameLogUpload);
            $i = 1;
            foreach ($files as $f) {
                if ($f != "." && $f != ".." && (preg_match("/\.log/", $f) || preg_match("/_custom_log.tar.gz/", $f))) {
                    array_push($needFilesList1, $f);
                    array_push($fileType, 'log');
                    array_push($allPath, "/logUpload/");
                    $serialNumberss = explode("_", $f);
                    $serialNumber = $serialNumberss[0];
                    array_push($allSerialNumber, $serialNumber);
                    $modelId = $dev->getModelIdBySerialNumber($serialNumber);
                    $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                    array_push($allModelName, $modelName[0]->name);
                    $fileListIsEmpty = false;
                    $i++;
                }
            }
        }

        if (file_exists($dirNameDump)) {
            $files = scandir($dirNameDump);
            $i = 1;
            foreach ($files as $f) {
                if ($f != "." && $f != ".." && $f != "example.ini" && (preg_match("/\.dump/", $f))) {
                    array_push($needFilesList1, $f);
                    array_push($fileType, 'dump');
                    array_push($allPath, "/dump/");
                    $serialNumberss = explode("_", $f);
                    $serialNumber = $serialNumberss[0];
                    array_push($allSerialNumber, $serialNumber);
                    $modelId = $dev->getModelIdBySerialNumber($serialNumber);
                    $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                    array_push($allModelName, $modelName[0]->name);
                    $fileListIsEmpty = false;
                    $i++;
                }
            }
        }

        if (file_exists($dirNamePutConfigs)) {
            $files = scandir($dirNamePutConfigs);
            $i = 1;
            foreach ($files as $f) {
                if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                    array_push($needFilesList1, $f);
                    array_push($fileType, 'config');
                    array_push($allPath, "/putConfigs/");
                    $serialNumberss = explode("_", $f);
                    $serialNumber = $serialNumberss[0];
                    array_push($allSerialNumber, $serialNumber);
                    $modelId = $dev->getModelIdBySerialNumber($serialNumber);
                    $modelName = $dev->getModelNameByID($modelId[0]->model_id);
                    array_push($allModelName, $modelName[0]->name);
                    $fileListIsEmpty = false;
                    $i++;
                }
            }
        }

        if (is_dir($dirNameFirmware) && file_exists($dirNameFirmware)) {
            $root = $dirNameFirmware;
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($root, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST,
                RecursiveIteratorIterator::CATCH_GET_CHILD
            );
            $paths = array($root);
            foreach ($iter as $path => $dir) {
                if ($dir->isDir()) {
                    $paths[] = $path;
                }
            }
            for ($a = 0; $a < count($paths); $a++) {
                $files = scandir($paths[$a]);
                $i = 1;
                foreach ($files as $f) {
//                    $undefinedModel = true;
                    if ($f != "." && $f != ".." && preg_match("/.bin/", $f)) {
                        array_push($needFilesList1, $f);
                        array_push($fileType, 'bin');
                        $filepath = explode("ACS/",$paths[$a]);
                        array_push($allPath, "/".$filepath[1]);
                        $modelsCount = $dev->getAllModelsCount();
                        $models = $dev->getAllModels();

                        $modelsPath = substr($filepath[1],3);
                        $modelId = explode("/", $modelsPath);
                        $modelNames = $dev->getModelNameByID($modelId[1]);
                        $modName = $modelNames[0]->name;
                        array_push($allModelName, $modName);

                        $fileListIsEmpty = false;
                        $i++;
                    }
                }
            }
        }

        if (file_exists($dirNameConfigs)) {
            $files = scandir($dirNameConfigs);
            $i = 1;
            foreach ($files as $file) {
                if ($file != "." && $file != ".."){
                    $filePhat = scandir($dirNameConfigs . "/" . $file);
                    foreach ($filePhat as $f) {
                        if ($f != "." && $f != ".." && preg_match("/_config.tar.gz/", $f)) {
                            array_push($needFilesList1, "/" . $file . "/" . $f);
                            array_push($fileType, 'config');
                            array_push($allPath, "/config/" . $file);
                            array_push($allSerialNumber, "");
                            $modelName = $dev->getModelNameByID($file);
                            array_push($allModelName, $modelName[0]->name);
                            $fileListIsEmpty = false;
                            $i++;
                        } elseif ($f != "." && $f != ".." && preg_match("/tar.gz/", $f)){
                            array_push($needFilesList1, "/" . $file . "/" . $f);
                            array_push($fileType, 'config');
                            array_push($allPath, "/config/" . $file);
                            array_push($allModelName, "");
                            $fileListIsEmpty = false;
                            $i++;
                        }
                    }
                }
            }
        }


    }

    $limit = $rowCountFile = $fileCount;
    $offset = ($page - 1) * $limit;

    $needFilesList = array_slice($needFilesList1, $offset, $limit);
    $fileType = array_slice($fileType,$offset,$limit);
    $allModelName = array_slice($allModelName,$offset,$limit);
    $allSerialNumber = array_slice($allSerialNumber,$offset,$limit);
    $pagesCount = Paging::getPagesCount(count($needFilesList1), $limit);

    include $_SESSION['APPPATH'] . 'views/content/admin/filteredFiles.php';
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
    if (isset($_SESSION['logged_in'])) {
        try{
            $model = $_POST['model'];
            $types = $_POST['type'];
            $cookie = $_POST['cooki_array'];
            $fileCount = $_POST['fileCount'];

            if (isset($_POST['page'])){
                $page = $_POST['page'];
            }else{
                $page = 1;

            }

            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);

            if (!empty($fileCount) && $fileCount != ''){
                $userSettings->rowCountFile = $fileCount;
            }

            if(!empty($cookie) && $cookie != ''){
                $n = $cookie[0];
                $fN = $cookie[1];
                $sN = $cookie[2];
                $modN = $cookie[3];
                $fSize = $cookie[4];
                $type = $cookie[5];

                $fields = array('n' => $n, 'fN' => $fN, 'sN' => $sN, 'modN' => $modN, 'fSize' => $fSize,'type'=>$type);
                $userSettings->filesTableColumns = (object)$fields;
            }
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');

            if(property_exists($userSettings, 'filesTableColumns')){
                $filesTableColumns = $userSettings->filesTableColumns;
            }

            if(property_exists($userSettings, 'rowCountFile')){
                $fileCount = $userSettings->rowCountFile;
            }

            define('BASEPATH', $_SESSION['BASEPATH']);

            getAllFilteredFile($model,$types,$filesTableColumns,$page,$fileCount);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}