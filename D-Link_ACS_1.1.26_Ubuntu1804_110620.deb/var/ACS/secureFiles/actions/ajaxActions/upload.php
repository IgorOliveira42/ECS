<?php
//if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
    
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);
        if(!class_exists("Device")){ require_once $_SESSION['APPPATH'].'models/device.php';}
        require_once $_SESSION['APPPATH'].'models/fwConfigFile.php';
        require_once $_SESSION['APPPATH'] . 'models/modelUser.php';
        
        $uploadType = $_POST['uploadType'];

        if(isset($_POST['model'])){
            $model = $_POST['model'];
            
        } else if(isset($_POST['newModel']) && isset($_POST['hwVersion'])){
            $newModel = $_POST['newModel'];
            $hwVersion = $_POST['hwVersion'];
            
            $device = new Device();
            $ifExist = $device->getModelByNameAndHWVersion($newModel,$hwVersion);

            if($ifExist){
                $model = $ifExist[0]->id;
            }else {
                $model = $device->addNewModelAndHWVersion($newModel, $hwVersion);
            }
        }

        $lang = $_SESSION['lang'];
        $newname ='';
        $newnameCSV = '';
        $newnameFileCSV = '';
        $newNameForDB='';
        if(isset($_POST['version'])) {
            $version = $_POST['version'];
        } else {
            $version='';
        }
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
	
	$user = new ModelUser();
	$ip = $user->getIp()[0];
	$port = $user->getPort()[0];
         if ((!empty($_FILES["uploaded_file"])) && ($_FILES['uploaded_file']['error'] == 0)) {

            $filename = basename($_FILES['uploaded_file']['name']);
            $size = $_FILES["uploaded_file"]["size"];
            $DIRECTORY_SEPARATOR = '/';
            $dirName = "";
//            $protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === true ? 'https://' : 'http://';
            $protocol = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off') || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
            if ($uploadType == "uploadConfig"){

                $filenameTar = explode('.tar.gz',$filename);
                $filenameGz = explode('.gz',$filename);
                if ($filenameTar[0] != ""){
                    $filename = str_replace(' ', '', $filenameTar[0]);
                    $filename = $filename.'.tar.gz';
                } else if ($filenameGz[0] != "") {
                    $filename = str_replace(' ', '', $filenameGz[0]);
                    $filename = $filename.'.gz';
                }
                $dirName = "config";
                $newname = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "config" . $DIRECTORY_SEPARATOR . $model . $DIRECTORY_SEPARATOR . $filename;
                $newNameForDB = /*$protocol . $ip->settings_value . ":" . $port->settings_value . */"/config" . "/" . $model . "/" . $filename;
            } else if($uploadType == "uploadFW"){
                $filenameBin = explode('.bin',$filename);
                if ($filenameBin[0] != ""){
                    $filename = str_replace(' ', '', $filenameBin[0]);
                    $filename = $filename.'.bin';
                }
                $dirName = "fw";
                $newname = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "fw" . $DIRECTORY_SEPARATOR . $model . $DIRECTORY_SEPARATOR . $version . $DIRECTORY_SEPARATOR . $filename;
                $newNameForDB = /*$protocol . $ip->settings_value . ":" . $port->settings_value . */"/fw" . "/" . $model . "/" .  str_replace(' ', '%20', $version) . "/" . $filename;
                //$newNameForDB = "http://" . $_SERVER['HTTP_HOST'] . ':' . $_SERVER['SERVER_PORT']."/fw" . "/" . $model . "/" . $version . "/" . $filename;
            } else if($uploadType == "uploadTarif"){
                $dirName = "tarif";
//                $newname = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR .  "tarif" . $DIRECTORY_SEPARATOR . $filename;
                $newname = $_SESSION['REALPATH']  .  "tarif" . $DIRECTORY_SEPARATOR . $_POST['tarifName'] . ".ini";
                $newNameForDB = $protocol . $ip->settings_value . ":" . $port->settings_value . "/tarif" . "/" .  $_POST['tarifName'] . ".ini";
            } else if($uploadType=="uploadDescription"){
                $dirName = "description";
                $newname = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "description" . $DIRECTORY_SEPARATOR . $filename;
                //$newNameForDB = "http://" . $ip->settings_value . ":" . $port->settings_value . "/description" . "/" .  $filename;
            }else if ($uploadType=="UploadCSV") {
                $dirName = "CSV";
                $newname = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "CSV" . $DIRECTORY_SEPARATOR . $filename;
                $path_parts = pathinfo($newname);
                if($path_parts['extension']=="xlsx" || $path_parts['extension']=="XLSX") {
                    $newnameCSV = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "CSV" . $DIRECTORY_SEPARATOR . "file";
                } else {
                    $newnameFileCSV = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . "CSV" . $DIRECTORY_SEPARATOR . "file.csv";
                }
                if ($dirName == "CSV") {
                    $dir = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . $dirName;
                    if (!is_dir($dir)) {
                        if(mkdir($dir, 0777, true)){
                            $_SESSION['uploadedError'] = $ini_array['cannot_create_dir'];
                        } else {
                            echo -1;
                            exit();
                        }
                    }
                }

            }


            if ($dirName == "config") {
                if (!file_exists($newname)) {
                    $dir = $_SESSION['REALPATH'] . $dirName . $DIRECTORY_SEPARATOR . $model;
                    if (!is_dir($dir)) {

                        if(!mkdir($dir, 0777, true)){
                            $_SESSION['uploadedError'] = $ini_array['cannot_create_dir'];
                            exit();
                        } 
                    } 
//                    else {
//                        $it = new RecursiveDirectoryIterator($dir);
//                        $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
//                        foreach ($files as $file) {
//                            if ($file->getFilename() === '.' || $file->getFilename() === '..') {
//                                continue;
//                            }
//                            if ($file->isDir()) {
//                            } else {
//                                unlink($file->getRealPath());
//                            }
//                        }
//                    }
                }
            } else if ($dirName == "fw"){
                if (!file_exists($newname)) {
                    $dir = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . $dirName . $DIRECTORY_SEPARATOR . $model . $DIRECTORY_SEPARATOR . $version;
                    if (!is_dir($dir)) {
                        if(!mkdir($dir, 0777, true)){
                            $_SESSION['uploadedError'] = $ini_array['cannot_create_dir'];
                            exit();
                        } 
                    } else {
                        $it = new RecursiveDirectoryIterator($dir);
                        $files = new RecursiveIteratorIterator($it,
                            RecursiveIteratorIterator::CHILD_FIRST);
                        foreach ($files as $file) {
                            if ($file->getFilename() === '.' || $file->getFilename() === '..') {
                                continue;
                            }
                            if ($file->isDir()) {
                            } else {
                                unlink($file->getRealPath());
                            }
                        }
                    }
                }
            }  else if ($dirName == "tarif"){
                $dir = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . $dirName;
                if (!is_dir($dir)) {
                    if(mkdir($dir, 0777, true)){
                        $_SESSION['uploadedError'] = $ini_array['cannot_create_dir'];
                        exit();
                    }
                }
            } else if($dirName=='description'){
                $dir = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . $dirName;
                if (!is_dir($dir)) {
                    if(mkdir($dir, 0777, true)){
                        $_SESSION['uploadedError'] = $ini_array['cannot_create_dir'];
                        exit();
                    }
                }
            }
            if ($uploadType == "uploadConfig") {
		$files = explode(PHP_EOL, shell_exec('tar -ztvf ' . $_FILES['uploaded_file']['tmp_name'] . ' 2> /dev/null'));
		$hasConfigJson = preg_grep("/^.*tmp\/etc\/default\/config.json$/", $files);
//		if (empty($hasConfigJson)) {
//		    $_SESSION['uploadedError'] = $ini_array['config_file_foramt'];
//		    exit();
//		}
	    }
            if (!file_exists($newname)) {
                if ((move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $newname))) {
                    $configFile = new FwConfigFile();
                    $res = false;
                    if ($uploadType == "uploadConfig") {
//                        $modelConfigs = $configFile->getAllConfigsOfTheModel($model);
//
//                        if ($modelConfigs) {
//                            $res = $configFile->updateConfig($model, $size, $newNameForDB, $filename);
//                        } else {
                            $res = $configFile->addConfig($model, $size, $newNameForDB, $filename);
//                        }

                    } else if ($uploadType == "uploadFW") {
                        $modelFws = $configFile->getAllFWsOfTheModel($model, $version);

                        if ($modelFws) {
                            $res = $configFile->updateFW($model, $version, $size, $newNameForDB, $filename);
                        } else {
                            $res = $configFile->addFW($model, $version, $size, $newNameForDB, $filename);
                        }
                    } else if ($uploadType == "uploadTarif") {

                        $tarifName = $_POST['tarifName'];
                        $tarifDesc = $_POST['tarifDesc'];
                        $res = $configFile->addTarif( $newname, $tarifName,$tarifDesc);

                    } else if($uploadType=="uploadDescription"){

                        $descName = $_POST['tarifName'];
                        $res = $configFile->addDescription($newname, $descName,$model,$version);
                    } else if ($uploadType == "UploadCSV") {
                        if($newnameCSV != '') {
                            convertXlsxToCsv($newname, $newnameCSV);
                            unlink($newname);
                        } else {
                            rename($newname, $newnameFileCSV);
                        }
                        $res = true;
                    }
                    if ($res) {
                        if($uploadType != "UploadCSV") {
                            $_SESSION['uploadedSuccess'] = $ini_array['upload_success'];
                        }
                    } else {
                        $_SESSION['uploadedError'] = $ini_array['upload_failed'];
                    }
                } else {
                    $_SESSION['uploadedError'] = $ini_array['upload_failed'];
                }
            } else {
                if($uploadType != "UploadCSV") {
                    $_SESSION['uploadedError'] = $ini_array['upload_file_exist'];
                } else{
                    move_uploaded_file($_FILES['uploaded_file']['tmp_name'], $newname);
                    if($newnameCSV != '') {
                        convertXlsxToCsv($newname, $newnameCSV);
                        unlink($newname);
                    } else {
                        rename($newname, $newnameFileCSV);
                    }
                }
            }
        } else if ($_FILES['uploaded_file']['error'] == 1) {
            $_SESSION['uploadedError'] = $_FILES['uploaded_file']['size'] . " size more than in php.ini";
        } else if ($_FILES['uploaded_file']['error'] == 2) {
            $_SESSION['uploadedError'] = $_FILES['uploaded_file']['size'] . " size more than in php file";
        } else if ($_FILES['uploaded_file']['error'] == 3) {
            $_SESSION['uploadedError'] = " partially uploaded";
        } else if ($_FILES['uploaded_file']['error'] == 4) {
            $_SESSION['uploadedError'] = " no file uploaded ";
        } else if ($_FILES['uploaded_file']['error'] == 5) {
            $_SESSION['uploadedError'] = " no tmp file";
        } else if ($_FILES['uploaded_file']['error'] == 6) {
            $_SESSION['uploadedError'] = " can't write ";
        } else {
            $_SESSION['uploadedError'] = $ini_array['choose_file'];
        }

    } else {
        $result = "logged_out";
        echo $result;
    }

    function convertXlsxToCsv($newname, $newnameCSV) {
        require_once $_SESSION['APPPATH'] . 'models/PHPExcel-1.8/Classes/PHPExcel.php';
        $fileType = PHPExcel_IOFactory::identify($newname);
        $objReader = PHPExcel_IOFactory::createReader($fileType);
        $objPHPExcel = $objReader->load($newname);

        $writer = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV');
        $writer->setDelimiter(",");
        $writer->setEnclosure("");
        foreach ($objPHPExcel->getWorksheetIterator() as $workSheetIndex => $worksheet)
        {
            $objPHPExcel->setActiveSheetIndex($workSheetIndex);
            $writer->save($newnameCSV .".csv");
            echo "file saved";
        }
    }
//} else {
//    exit('No direct script access allowed');
//}


