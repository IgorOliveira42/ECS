<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {

        include $_SESSION['APPPATH'] . 'util/utils.php';
        //$startEndIp=$_POST['checkedIp'];
        $startIp=$_POST['checkedSIp'];
        $endIp=$_POST['checkedEIp'];
        $ip=$_POST['ipAddress'];
        $mask=$_POST['netMask'];
        //$ss=Utils::checkStartEndIp($ip,$mask,$startIp, $endIp);
        $ss=Utils::checkStartEndIpTempate($ip,$mask,$startIp, $endIp);
        echo $ss;
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}