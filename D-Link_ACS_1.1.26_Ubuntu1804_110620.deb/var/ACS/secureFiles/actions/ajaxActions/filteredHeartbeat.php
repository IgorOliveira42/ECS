<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }

    function cidrToRange($cidr) {
        $range = array();
        $pos = strpos($cidr, "/");
        if($pos) {
            $count = substr_count($cidr, '/');
            if($count > 1) {
                return false;
            } else {
                $cidr = explode('/', $cidr);
                if($cidr[1] > 32) {
                    return false;
                }
                $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
                $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
                return $range;
            }
        } else {
            return $pos;
        }
    }

    if (isset($_SESSION['logged_in'])) {
        try {
            define('BASEPATH', $_SESSION['BASEPATH']);

            require_once $_SESSION['APPPATH'] . 'models/device.php';
            $dev = new Device();

            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }
            $searchType = '';
            $type = $_POST['searchType'];
            $getDevLastTime=array();
            $searchedVal=$_POST['searchVal'];
            if($searchedVal!=''){
                if($type=='ip')
                {
                    if($searchedVal != '') {
                        $ipMask = cidrToRange($searchedVal);
                        if($ipMask) {
                            $searchType = "ipmask";
                            $searchedVal = array();
                            $searchedVal[0] = $ipMask[0];
                            $searchedVal[1] = $ipMask[1];
                        }
                    }
                    $getDevLastTime = $dev->getDevWithIntervalByIp($searchedVal, $searchType);

                }elseif ($type=='model'){
                    $getDevLastTime = $dev->getDevWithIntervalByModelName($searchedVal);
                } elseif ($type=='group'){
                    $getDevLastTime = $dev->getDevWithIntervalByGroupName($searchedVal);
                } elseif ($type=='clients'){
                    $getDevLastTime = $dev->getDevWithIntervalByClientInfo($searchedVal);
                }
            }else{
                $getDevLastTime = $dev->getDevWithInterval();
            }


            /*----------------------for heartbeat diagram----------------------*/
            $HeartINT = $dev->getDevHeartInter()[0]->settings_value;
            $HeartWAR = $dev->getDevHeartWar()[0]->settings_value;
            $HeartERR = $dev->getDevHeartErr()[0]->settings_value;

            $statusHeartbeath = array();
            $nameHeartbeath = array();
            $colorHeartbeath = array();

            $getDevicesStatusOfSuccess = 0;
            $getDevicesStatusOfWeting = 0;
            $getDevicesStatusOfError = 0;
            $CurrentTime = strtotime(date("M d Y H:i:s")) / 60;

if(count($getDevLastTime)>0) {
    for ($i = 0; $i < count($getDevLastTime); $i++) {
        $DeviceLastInfTime = strtotime($getDevLastTime[$i]->last_inform_time) / 60;
        $lastInfTime = $CurrentTime - $DeviceLastInfTime;
        if ($lastInfTime < ($HeartINT + $HeartWAR)) {
            $getDevicesStatusOfSuccess += 1;
        } else if ($lastInfTime >= ($HeartINT + $HeartWAR) && $lastInfTime < ($HeartWAR + $HeartERR + $HeartINT)) {
            $getDevicesStatusOfWeting += 1;
        } else if ($lastInfTime >= ($HeartWAR + $HeartERR + $HeartINT)) {
            $getDevicesStatusOfError += 1;
        }
    }

    array_push($statusHeartbeath, $getDevicesStatusOfSuccess);
    array_push($statusHeartbeath, $getDevicesStatusOfWeting);
    array_push($statusHeartbeath, $getDevicesStatusOfError);
    array_push($nameHeartbeath, "Success");
    array_push($nameHeartbeath, "Waiting");
    array_push($nameHeartbeath, "Error");
    array_push($colorHeartbeath, "#3DAD6A");
    array_push($colorHeartbeath, "#FFA500");
    array_push($colorHeartbeath, "#AD3D40");

    /*-------------------------------------------------------------*/

    /* -----------------------end heartbeat status diagram-----------------------*/
}

            include $_SESSION['APPPATH'] . 'views/content/admin/filteredHeartbeat.php';
        } catch (\Exception $e) {

            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}