<?php
function getAllFilteredUsersByPage($page)
{
    include  $_SESSION['APPPATH'].'models/modelUser.php';
    include  $_SESSION['APPPATH'].'util/pagingConstants.php';
//    require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//    require_once $_SESSION['APPPATH']."actions/api/token.php";

    $limit = PagingConstants::$activityCount;
    $offset = ($page - 1) * $limit;

    $user = new ModelUser();
    $adminsCountArr = $user->getAdminsCount();
    $adminsCount = (int)$adminsCountArr[0]->count;
    $users = $user->getAllUsersByPage($limit, $offset);
    $userGroups=$user->getAllUserGroups();
    $allUsersCount = $user->getAllUsersCount();
//    $groupss = $user->getGroupsFromUserGroup();
    $groupss = $user->getGroupsForUserGroup();
    $ungrouped = $user->getUngrouped();
    $ungroup=false;

    for($i=0;$i<count($users);$i++){
        $groupList=$user->getGroupsSelectedUser($users[$i]->id);
        $username = $users[$i]->username;
        if(!$groupList){
            $groupList=array();
            $ungroup = false;
        }
        for($j=0; $j<count($groupList); $j++) {
            if($groupList[$j]->default==1){
                $ungroup = true;
                break;
            } else {
                $ungroup = false;
            }
        }
        $users[$i] = (object) array_merge((array)$users[$i], array( 'groupList' => $groupList));
        $users[$i] = (object) array_merge((array)$users[$i], array( 'ungrouped' => $ungroup));
        $groupN = $users[$i]->groupList;
        $uncheckedArray = array();
        for($k = 0; $k < count($groupN); $k++) {
            array_push($uncheckedArray, $groupN[$k]->id);
        }
        $uncheckedGroups = $user->getUncheckedGroups($uncheckedArray);
        $users[$i] = (object) array_merge((array)$users[$i], array( 'uncheckedGroups' => $uncheckedGroups));
    }
//    for($i=0;$i<count($users);$i++){
//        $username = $users[$i]->username;
//        $token = token::create_token($username);
//        $users[$i] = (object) array_merge((array)$users[$i], array( 'token' => $token));
//    }
//    $groupss =$user->getGroupsFromUserGroup();

    $usersCount = $allUsersCount[0]->count;
    if ($usersCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($usersCount % $limit == 0) {
            $pagesCount = $usersCount / $limit;
        } else {
            $pagesCount = ($usersCount / $limit - ($usersCount % $limit) * (1 / $limit)) + 1;
        }
    }
    
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    include $_SESSION['APPPATH'].'views/content/admin/filteredUsers.php';
    return true;
}

function getDeletedUser($page){
    include  $_SESSION['APPPATH'].'models/modelUser.php';
    include  $_SESSION['APPPATH'].'util/pagingConstants.php';

    $limit = PagingConstants::$activityCount;
    $offset = ($page - 1) * $limit;

    $user = new ModelUser();
    $adminsCountArr = $user->getAdminsCount();
    $adminsCount = (int)$adminsCountArr[0]->count;
    $users = $user->getAllDeletedUsers($limit, $offset);
    $userGroups=$user->getAllUserGroups();
//    $groupss =$user->getGroupsFromUserGroup();
    $groupss = $user->getGroupsForUserGroup();
    $ungrouped = $user->getUngrouped();
    $allUsersCount = $user->getAllDeletedUsersCount();
    for($i=0;$i<count($users);$i++){
        $groupList=$user->getGroupsSelectedUser($users[$i]->id);
        $username = $users[$i]->username;
        if(!$groupList){
            $groupList=array();
            $ungroup = false;
        }
        for($j=0; $j<count($groupList); $j++) {
            if($groupList[$j]->default==1){
                $ungroup = true;
                break;
            } else {
                $ungroup = false;
            }
        }
        $users[$i] = (object) array_merge((array)$users[$i], array( 'groupList' => $groupList));
        $users[$i] = (object) array_merge((array)$users[$i], array( 'ungrouped' => $ungroup));
        $groupN = $users[$i]->groupList;
        $uncheckedArray = array();
        for($k = 0; $k < count($groupN); $k++) {
            array_push($uncheckedArray, $groupN[$k]->id);
        }
        $uncheckedGroups = $user->getUncheckedGroups($uncheckedArray);
        $users[$i] = (object) array_merge((array)$users[$i], array( 'uncheckedGroups' => $uncheckedGroups));
    }
    $usersCount = $allUsersCount[0]->count;
    if ($usersCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($usersCount % $limit == 0) {
            $pagesCount = $usersCount / $limit;
        } else {
            $pagesCount = ($usersCount / $limit - ($usersCount % $limit) * (1 / $limit)) + 1;
        }
    }

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    include $_SESSION['APPPATH'].'views/content/admin/filteredUsers.php';
    return true;
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            if(isset($_POST['actionName']) && $_POST['actionName']=="deletedUser") {
                define('BASEPATH', $_SESSION['BASEPATH']);
                if(isset($_POST['page'])){
                    $page = $_POST['page'];
                } else {
                    $page = 1;
                }
                getDeletedUser($page);
            } else if(isset($_POST['actionName']) && $_POST['actionName']=="AllUsers") {
                define('BASEPATH', $_SESSION['BASEPATH']);
                if(isset($_POST['page'])){
                    $page = $_POST['page'];
                } else {
                    $page = 1;
                }
                getAllFilteredUsersByPage($page);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
