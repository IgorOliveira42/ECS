<?php
function checkIsDeviceWait($deviceID, $action,$dev)
{
    $deviceStatus = $dev->getDeviceStatusById($deviceID, $action);
    return $deviceStatus[0]->count;
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();
            $deviceID = $_POST['deviceID'];
            $deviceStatuses = array();

            if(isset($_POST['actionName']) && $_POST['actionName'] == 'getStatuses'){
                $statuses = $dev->getDevicesStatusesById($deviceID);
                foreach ($statuses as $status){
                    $deviceStatuses[$status->id] = $status->last_status;
                }
            }else{
                $action = $_POST['action'];
                $status = checkIsDeviceWait($deviceID, $action,$dev);
                echo $status;
            }

            echo json_encode($deviceStatuses);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $status = "logged_out";
        echo $status;
    }
} else {
    exit('No direct script access allowed');
}