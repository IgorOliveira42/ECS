<div id="files">
<?php

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
    require_once $_SESSION['APPPATH'] . "util/usersConstants.php";

//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
$lang = $_SESSION['lang'];
//  echo $lang;
$ini_array = array();
$path = '';

switch($lang){
    case "en":
        $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        break;
    case "ru":
        $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        break;
    default:
        $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        break;
}

//$ini_array = parse_ini_file($path);

function GetMessageText($message, $language){
    $path = '';
    global $ini_array;
    switch($language)
    {
        case "en":
            $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            break;
        case "ru":
            $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/russian/english/message_lang.ini');

            break;
        default:
            $ini_array =parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            break;
    }
    return $ini_array[''];
    //GetFileCont($path);
}


function ShowLogFiles($dirName1, $macAddress, $page, $devId){ ?>

    <script>
        ForLogFiles();
    </script>
    <?php
    $permissionsArray = $_SESSION['permissions'];

    $dirName =  $_SESSION['REALPATH']."/".$dirName1;
    $needFilesList = array();
    $fileListIsEmpty = true;
    $limit = 5;
    $pagesCount = 1;
    global $ini_array;
    $dev=new Device();
    $modelId=$dev->getModelNameByDevId($devId);
    $modelName = $dev->getModelNameByID($modelId[0]->model_id);
    if(file_exists($dirName)){
        $files = scandir($dirName);
        global $lang;
        $pattern = "/$macAddress/";
        $i = 1;
        foreach ($files as $f){
            if($f !="." && $f !=".." && preg_match($pattern, $f) == 1 && preg_match("/\.log/", $f)){
                array_push($needFilesList, $f);
                $fileListIsEmpty = false;
                $i++;
            }
        }
    }
    $needFilesList = array_reverse($needFilesList);
    $pagesCount = ceil(($i - 1)/5);
    if($fileListIsEmpty!=true) {
        echo '  <table class="table table-condensed table-bordered file-list logFiles table-style" id="logfile">';
        echo '  <thead>
            <tr>';
            if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                echo '<th style="width:5%">
                <input type="checkbox" class="fieids allFields" id="all_fields">
                </th>';
            }
                echo '<th style="width: 5%;">#</th>
                <th>'.$ini_array['files_list'].'</th>
                <th>'.$ini_array['file_size'].'</th>
                <th>'.$ini_array['model'].'</th>';
                if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                        && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                        && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                    echo '<th class="actionWidth">' . $ini_array['action'] . '</th>';
                }
            echo '</tr>
            </thead>';
        echo '<tbody class="forFieldsCheck">';
        if($page==1) {
            for ($j = 1; $j <= ($page * $limit); $j++) {
                echo '<tr>';
                if(isset($needFilesList[$j - 1])) {
                    if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                        && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                        && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                        echo '<td>';
                        echo '<input type="checkbox" class="fieids">';
                        echo '</td>';
                    }
                    echo '<td>' . $j . '</td>';
                    echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                    echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                    echo '<td> '.$modelName[0]->name.'</td>';
                    if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                        && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                        && in_array(UsersConstants::$monitoring, $permissionsArray)) {

                        echo '<td>     
                               <a class="removeFiles" title=' . $ini_array['remove'] . '>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value=' . $dirName . "/" . $needFilesList[$j - 1] . '></a>
                    </td>';
                    }
                }
                echo '</tr>';
            }
        } else {
            for ($j = (($page-1)*$limit+1); $j <= ($page * $limit); $j++) {
                echo '<tr>';
                if(isset($needFilesList[$j - 1])) {
                    if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                        && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                        && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                        echo '<td><input type="checkbox" class="fieids"></td>';
                    }
                    echo '<td>' . $j . '</td>';
                    echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                    echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                    echo '<td>'.$modelName[0]->name.'</td>';
                    if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                        && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                        && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                        echo '<td>
                     <a class="removeFiles" title=' . $ini_array['remove'] . '>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value=' . $dirName . "/" . $needFilesList[$j - 1] . '></a>
                       
                    </td>';
                    }
                }
                echo '</tr>';
            }
        }
    }

    if($fileListIsEmpty==true){
        echo '  <table class="table table-condensed table-bordered file-list logFiles fileTable table-style" id="logfile">';
        echo '  <thead>
            <tr>
                <th style="width: 10%;">#</th>
                <th>'.$ini_array['files_list'].'</th>
            </tr>
            </thead>';
        echo '<tbody>';
        echo '<tr>';
        echo '<td></td><td><h4>'.$ini_array['dev_file_list_is_empty'].'</h4></td>';
        echo '</tr>';
    }

    echo ' </tbody>
           </table>';
         if($fileListIsEmpty!=true) {
             echo '<div class="second_pagination">';
             echo '<div class="col-lg-3 trash-select" >
                   <a  class="trash20 trashStyle"><i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>';
             echo $ini_array['delete_selected'] .'</a>';
             echo '</div>';
             Pagination::paging($pagesCount, $page, 'eachLogFile');
             echo '</div>';
         }
}

    function ShowCustomLogFiles($dirName1, $macAddress, $page, $devId){ ?>
    <script>
        ForCustomLogFiles();
    </script>
    <?php
    $permissionsArray = $_SESSION['permissions'];
        $dirName =  $_SESSION['REALPATH']."/".$dirName1;
        $needFilesList = array();
        $fileListIsEmpty = true;
        $limit = 5;
        $pagesCount = 1;
        global $ini_array;
        $dev=new Device();
        $modelId=$dev->getModelNameByDevId($devId);
        $modelName = $dev->getModelNameByID($modelId[0]->model_id);
        if(file_exists($dirName)){
            $files = scandir($dirName);
            global $lang;
            $pattern = "/$macAddress/";
            $i = 1;
            foreach ($files as $f){
                $f_path = $_SESSION['BASEPATH'].'logUpload/'.$f;
                if($f !="." && $f !=".." && preg_match($pattern, $f) == 1 && preg_match("/_custom_log.tar.gz/", $f)){
                    array_push($needFilesList, $f);
                    $fileListIsEmpty = false;
                    $i++;
                }
            }
        }
        $needFilesList = array_reverse($needFilesList);
        $pagesCount = ceil(($i - 1)/5);
        if($fileListIsEmpty!=true) {
            echo '  <table class="table table-condensed table-bordered file-list customLogFiles table-style" id="customLogfile">';
            echo '  <thead>
            <tr>';
                        if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                            echo '<th style="width:5%">
                <input type="checkbox" class="fieids allFields" id="all_fields">
                </th>';
                        }
                echo '<th style="width: 5%;">#</th>
                <th>'.$ini_array['files_list'].'</th>
                <th>'.$ini_array['file_size'].'</th>
                <th>'.$ini_array['model'].'</th>';
            if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                echo '<th class="actionWidth">'.$ini_array['action'].'</th>';
             }
            echo '</tr>
            </thead>';
            echo '<tbody class="forFieldsCheck">';
            if($page==1) {
                for ($j = 1; $j <= ($page * $limit); $j++) {
                    echo '<tr>';
                    if(isset($needFilesList[$j - 1])) {
                        if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                            && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                            && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                            echo '<td><input type="checkbox" class="fieids"></td>';
                        }
                        echo '<td>' . $j . '</td>';
                        echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                        echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                        echo '<td>'.$modelName[0]->name.'</td>';
                        if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                            && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                            && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                            echo '<td>
                                <a class="removeFiles" title=' . $ini_array['remove'] . '>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value=' . $dirName . "/" . $needFilesList[$j - 1] . '></a>
                    </td>';
                        }
                    }
                    echo '</tr>';
                }
            } else {
                for ($j = (($page-1)*$limit+1); $j <= ($page * $limit); $j++) {
                    echo '<tr>';
                    if(isset($needFilesList[$j - 1])) {
                        if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                            && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                            && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                            echo '<td><input type="checkbox" class="fieids"></td>';
                        }
                        echo '<td>' . $j . '</td>';
                        echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                        echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                        echo '<td>'.$modelName[0]->name.'</td>';
                        if(in_array(UsersConstants::$userPermission, $permissionsArray) && in_array(UsersConstants::$devicePermission, $permissionsArray)
                            && in_array(UsersConstants::$groupPermission, $permissionsArray) && in_array(UsersConstants::$clientPermission, $permissionsArray)
                            && in_array(UsersConstants::$monitoring, $permissionsArray)) {
                            echo '<td>
                                <a class="removeFiles" title=' . $ini_array['remove'] . '>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value=' . $dirName . "/" . $needFilesList[$j - 1] . '></a>
                    </td>';
                        }
                    }
                    echo '</tr>';
                }
            }
        }

        if($fileListIsEmpty==true){
            echo '  <table class="table table-condensed table-bordered file-list customLogFiles fileTable table-style" id="customLogfile">';
            echo '  <thead>
            <tr>
                <th style="width: 10%;">#</th>
                <th>'.$ini_array['files_list'].'</th>
            </tr>
            </thead>';
            echo '<tbody>';
            echo '<tr>';
            echo '<td></td><td><h4>'.$ini_array['dev_file_list_is_empty'].'</h4></td>';
            echo '</tr>';
        }

        echo ' </tbody>
           </table>';
             if($fileListIsEmpty!=true) {
                 echo '<div class="second_pagination">';
                 Pagination::paging($pagesCount, $page, 'eachCustomLogFile');
                 echo '<div class="col-lg-3 trash-select" >
                   <a  class="trash20 trashStyle"><i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>';
                 echo $ini_array['delete_selected'] .'</a>';
                 echo '</div>';
             }
    }
    
    function ShowDumpFiles($dirName1, $macAddress, $page, $devId){ ?>
    <script>
        ForDumpFiles();
    </script>
    <?php
    $permissionsArray = $_SESSION['permissions'];
        $dirName =  $_SESSION['REALPATH']."/".$dirName1;
        $needFilesList = array();
        $fileListIsEmpty = true;
        $limit = 5;
        $pagesCount = 1;
        global $ini_array;
        $dev=new Device();
        $modelId=$dev->getModelNameByDevId($devId);
        $modelName=$dev->getModelNameByID($modelId[0]->model_id);

        if(file_exists($dirName)){
            $files = scandir($dirName);
            global $lang;
            $pattern = "/$macAddress/";
            $i = 1;
            foreach ($files as $f){
                if($f !="." && $f !=".." && preg_match($pattern, $f) == 1 && preg_match("/\.dump/", $f)){
                    array_push($needFilesList, $f);
                    $fileListIsEmpty = false;
                    $i++;
                }
            }
        }
        $needFilesList = array_reverse($needFilesList);
    $pagesCount = ceil(($i - 1)/5);
    if($fileListIsEmpty!=true) {
        echo '  <table class="table table-condensed table-bordered file-list dumpFiles table-style" id="dumpfile">';
        echo '  <thead>
                <tr>
                    <th style="width:5%">
                    <input type="checkbox" class="fieids allFields" id="all_fields">
                    </th>
                    <th style="width: 5%;">#</th>
                    <th>'.$ini_array['files_list'].'</th>
                    <th>'.$ini_array['file_size'].'</th>
                    <th>'.$ini_array['model'].'</th>
                    <th class="actionWidth">'.$ini_array['action'].'</th>
                </tr>
                </thead>';
        echo '<tbody class="forFieldsCheck">';
        if($page==1) {
            for ($j = 1; $j <= ($page * $limit); $j++) {
                echo '<tr>';
                if(isset($needFilesList[$j - 1])) {
                    echo '<td><input type="checkbox" class="fieids"></td>';
                    echo '<td>' . $j . '</td>';
                    echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                    echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                    echo '<td>'.$modelName[0]->name.'</td>';
                    echo '<td>
                            <a class="removeFiles" title='. $ini_array['remove'].'>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value='.$dirName."/".$needFilesList[$j - 1] .'></a>
                    </td>';
                }
                echo '</tr>';
            }
        } else {
            for ($j = (($page-1)*$limit+1); $j <= ($page * $limit); $j++) {
                echo '<tr>';
                if(isset($needFilesList[$j - 1])) {
                    echo '<td><input type="checkbox" class="fieids"></td>';
                    echo '<td>' . $j . '</td>';
                    echo '<td class="filelist-log"><a href="javascript:void(0);" class="showFileCont">' . $needFilesList[$j - 1] . '</a></td>';
                    echo '<td>'.filesize($dirName."/".$needFilesList[$j - 1]).'</td>';
                    echo '<td>'.$modelName[0]->name.'</td>';
                    echo '<td>
                            <a class="removeFiles" title='. $ini_array['remove'].'>
                                <i class="fa fa-trash-o"></i>
                                <input type="hidden" name="removeLog"   value='.$dirName."/".$needFilesList[$j - 1] .'></a>
                    </td>';
                }
                echo '</tr>';
            }
        }
    }

        if($fileListIsEmpty==true){
            echo '  <table class="table table-condensed table-bordered file-list dumpFiles fileTable table-style" id="dumpfile">';
            echo '  <thead>
                <tr>
                    <th style="width: 10%;">#</th>
                    <th>'.$ini_array['files_list'].'</th>
                </tr>
                </thead>';
            echo '<tbody>';
            echo '<tr>';
            echo '<td></td><td><h4>'.$ini_array['dev_file_list_is_empty'].'</h4></td>';
            echo '</tr>';
        }

        echo ' </tbody>
               </table>';
     if($fileListIsEmpty!=true) {
         echo '<div class="second_pagination">';
         Pagination::paging($pagesCount, $page, 'eachDumpFile');
         echo '<div class="col-lg-3 trash-select" >
               <a  class="trash20 trashStyle"><i class="iconStyle fa fa-trash-o" aria-hidden="true"></i>';
         echo $ini_array['delete_selected'] .'</a>';
         echo '</div>';
     }
}


function ShowFileContent($fileName1) {
    if (session_id() == '') {
        session_start();
    }
    //$file = file_get_contents($fileName);
    $fileName = $_SESSION['REALPATH']."/".$fileName1;
    $text = file($fileName);
    foreach ($text as $rowNum => $row){
        echo " $row <br>";
    }
}

function DeleteLogFile($path, $dirPath){
    if (file_exists($path)) {
        if(unlink($path)){
            if (preg_match("/config/", $dirPath)) {
                if(isset($_POST['fileNameForDb'])){
                    include $_SESSION['APPPATH'].'models/modelClient.php';
                    delDir($dirPath);
                    $fileNameForDb = $_POST['fileNameForDb'];
                    $client = new ModelClient();
                    $result = $client -> deleteConfigFile($fileNameForDb);
                    if ($result){
                        echo 'true';
                    }
                }
            }elseif (preg_match("/fw/", $dirPath)){
                delDir($dirPath);
            }
            echo 'true';
        }else {
            echo 'false';
        }
    }
}

function delDir($dir) {
    $files = glob( $dir . '*', GLOB_MARK );
    foreach( $files as $file ){
        if( substr( $file, -1 ) == '/' )
            delDir( $file );
        else
            unlink( $file );
    }
    rmdir( $dir );
}

function DeleteAllFiles($fileNames){
    for ($i = 0; $i < count($fileNames); $i++) {
        if (file_exists($fileNames[$i])) {
            if (unlink($fileNames[$i])) {
                echo 'true';
            } else {
                echo 'false';
            }
        }
    }
}
    

if (session_id() == '') {
    session_start();
}
    
$fileName="";
$functionName="";
$dirName="";
$macAddress="";
$message="";
$language="";
$page = "";
$dirPath = "";

if(isset($_POST['fileName'])){$fileName = $_POST['fileName'];}
if(isset($_POST['functionName'])){$functionName = $_POST['functionName'];}
if(isset($_POST['dirName'])){$dirName = $_POST['dirName'];}
if(isset($_POST['macAddress'])){$macAddress = $_POST['macAddress'];}
if(isset($_POST['message'])){$message = $_POST['message'];}
if(isset($_POST['language'])){$language = $_POST['language'];}
if(isset($_POST['page'])){$page = $_POST['page'];}else{$page=1;}
if(isset($_POST['devId'])){$devId = $_POST['devId'];}
if(isset($_POST['dirPath'])){$dirPath = $_POST['dirPath'];}


try{
    require_once $_SESSION['APPPATH'].'views/content/admin/pagination.php';
    include $_SESSION['APPPATH'].'models/device.php';

    switch($functionName)
    {
        case "showLogFiles":
            ShowLogFiles($dirName,$macAddress, $page, $devId);
            break;
        case "showCustomLogFiles":
            ShowCustomLogFiles($dirName,$macAddress, $page, $devId);
            break;
        case "ShowFunc":
            ShowLogFiles($dirName,$macAddress,  $page, $devId);
            break;
        case "showDumpFiles":
            ShowDumpFiles($dirName,$macAddress, $page, $devId);
            break;
        case "GetFileContent":
            ShowFileContent($dirName."/".$fileName);
            break;
        case "removeLogFile":
            DeleteLogFile($fileName,$dirPath);
            break;
        case "removeAllFile":
            DeleteAllFiles($fileName);
            break;
        case "DeleteSomeLogFiles":
            DeleteAllFiles($fileName);
            break;
        case "DeleteSomeCustomLogFiles":
            DeleteAllFiles($fileName);
            break;
        case "DeleteSomeDumpFiles":
            DeleteAllFiles($fileName);
            break;

        case "GetMessageText":

            break;
    }
}catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    }  
} else {
    exit('No direct script access allowed');
}
?>

</div>	  


