<?php
function getLastDiagnosticStatus($deviceId,$pingName){
    include $_SESSION['APPPATH'].'models/modelParams.php';

    $modParams = new ModelParams();
    $params = $modParams-> getLastActivityStatus($deviceId,$pingName);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"";
}
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            if (!class_exists("ActionNamesConstants")) {
                include $_SESSION['APPPATH'] . 'util/actionNamesConstants.php';
            }

            $deviceId = $_POST['deviceID'];
            $pingName = $_POST['pingName'];
            if($pingName == 'diagnostic'){
                $status = getLastDiagnosticStatus($deviceId,ActionNamesConstants::$diagnostic);
            } else if($pingName == 'tracert'){
                $status = getLastDiagnosticStatus($deviceId,ActionNamesConstants::$tracert);
            } else if($pingName == 'uploadDiagnostics'){
                $status = getLastDiagnosticStatus($deviceId,ActionNamesConstants::$uploadDiagnostics);
            } else if($pingName == 'downloadDiagnostics'){
                $status = getLastDiagnosticStatus($deviceId,ActionNamesConstants::$downloadDiagnostics);
            }

            echo $status;
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}