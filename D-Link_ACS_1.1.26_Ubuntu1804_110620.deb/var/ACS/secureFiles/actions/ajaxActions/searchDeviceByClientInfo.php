<?php

function searchDevicesByClientId($page,$clientId, $devCount, $modelID,$groupID,$templ,$fwVersion,$sortedVal){
    require_once $_SESSION['APPPATH'].'models/device.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $group_ID = $_SESSION['group_id'];
        }
    }

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $dev = new Device();
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();

    if($group_ID == 'Group manager' || $group_ID == 'Group Viewer') {
        if ($modelID == 0) {
            $devices =array();
            $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
            $countGroups = count($groupList);
            if($groupID == 0){
                $devices = $dev->searchDevicesByClientIdByGroup($groupList, $countGroups, $clientId,$devCount, $offset,$sortedVal);
                $allDevCount = $dev->getAllActiveDevicesByClientIdByGroup($groupList, $countGroups, $clientId);
//                if ($allDevCount > $limit) {
//                    for($i=0; $i<$limit; $i++) {
//                        $devices[$i] = $devices1[$i];
//                    }
//                } else {
//                    $devices = $devices1;
//                }
//                $devices = $dev->searchDevicesByClientIdByGroup($group_ID, $clientId, $devCount, $offset);
//                $allDeviceCount = $dev->getAllActiveDevicesByClientIdByGroup($group_ID, $clientId);
            } else {
                $devices = $dev->searchDevicesByClientIdGroup($groupID,$clientId, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdGroup($groupID,$clientId);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if($groupID == 0){
                $devices = $dev->searchDevicesByClientIdModelID($clientId, $modelID, $devCount, $offset,$fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdModelID($clientId, $modelID,$fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesByClientIdModelIDGroupID($clientId, $modelID,$groupID, $devCount, $offset,$fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdModelIDGroupID($clientId, $modelID,$groupID,$fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
    } else {
        if ($modelID == 0) {
            if($groupID == 0){
                $devices = $dev->searchDevicesByClientId($clientId, $devCount, $offset,$sortedVal);
//                var_dump($devices);
                $allDeviceCount = $dev->getAllActiveDevicesByClientId($clientId);
            } else {
                $devices = $dev->searchDevicesByClientIdGroup($groupID,$clientId, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdGroup($groupID,$clientId);
            }
        } else {
            if($groupID == 0){
                $devices = $dev->searchDevicesByClientIdModelID($clientId, $modelID, $devCount, $offset,$fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdModelID($clientId, $modelID,$fwVersion);
            } else {
                $devices = $dev->searchDevicesByClientIdModelIDGroupID($clientId, $modelID,$groupID, $devCount, $offset,$fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllActiveDevicesCountByClientIdModelIDGroupID($clientId, $modelID,$groupID,$fwVersion);
            }
        }
        $allDevCount = $allDeviceCount[0]->count;
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    
//    $allDevCount = $allDeviceCount[0]->count;
    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {
        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    
    $allTemplates = $templ->getAllTemplates();
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }

    //added  custom sort by ip

    if ($sortedVal != '') {
        $sortedValVar = trim(explode(":", $sortedVal)[0]);
        $sortBy = trim(explode(":", $sortedVal)[1]);
    } else {
        $sortedValVar = "last_inform_time";
        $sortBy = "DESC";
    }
    if ($sortedValVar == 'ip') {
        $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
    }




    include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
    
//    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
//    return true;
}

function searchDevicesByClientInfo($firstName, $surName, $address, $email, $devCount, $modelID,$groupID,$templ,$fwVersion)
{
    include $_SESSION['APPPATH'].'models/device.php';

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $dev = new Device();
    $page = 1;
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();
    if ($modelID == 0) {
        if($groupID == 0){
            $devices = $dev->searchDevicesByClientInfo($firstName, $surName, $address, $email, $devCount, $offset);
            $allDeviceCount = $dev->getAllDevicesCountByClientInfo($firstName, $surName, $address, $email);
        } else {
            $devices = $dev->searchDevicesByClientInfoGroup($groupID,$firstName, $surName, $address, $email, $devCount, $offset);
            $allDeviceCount = $dev->getAllDevicesCountByClientInfoGroup($groupID,$firstName, $surName, $address, $email);
        }
    } else {
        if($groupID == 0){
            $devices = $dev->searchDevicesByClientInfoModelID($firstName, $surName, $address, $email, $modelID, $devCount, $offset,$fwVersion);
            $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelID($firstName, $surName, $address, $email, $modelID,$fwVersion);
        } else {
            $devices = $dev->searchDevicesByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelID,$groupID, $devCount, $offset,$fwVersion);
            $allDeviceCount = $dev->getAllDevicesCountByClientInfoModelIDGroupID($firstName, $surName, $address, $email, $modelID,$groupID,$fwVersion);
        }
    }
    $groups = $dev->getAllGroups();
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    
    $allDevCount = $allDeviceCount[0]->count;
    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {

        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    
    $allTemplates = $templ->getAllTemplates();
    
    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
    return true;
}


if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
if (isset($_SESSION['logged_in'])) {
    try{
	require_once $_SESSION['APPPATH'].'util/utils.php';
        require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
        $templ = new ModelTemplates();
        define('BASEPATH', $_SESSION['BASEPATH']);
        $devCount = $_POST['devCount'];
        $modelID = $_POST['modelID'];
        $groupID = $_POST['groupID'];
        $fwVersion = $_POST['fwVersion'];
        $sortedVal=$_POST['sortedVal'];
        if(isset($_POST['clientId']) ){
            $clientId = $_POST['clientId'];
            $page = $_POST['page'];
            searchDevicesByClientId($page,$clientId, $devCount, $modelID,$groupID,$templ,$fwVersion,$sortedVal);
        } else {
            $firstName = $_POST['firstName'];
            $surName = $_POST['surName'];
            $address = $_POST['address'];
            $email = $_POST['email'];
            searchDevicesByClientInfo($firstName, $surName, $address, $email, $devCount, $modelID,$groupID,$templ,$fwVersion);
        }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}
