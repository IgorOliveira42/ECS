
<?php

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'models/device.php';

            define('BASEPATH', $_SESSION['BASEPATH']);
            $groupID = $_POST['groupId'];
            $dev = new Device();
            $limitDev = 10;

//            function cidrToRange($cidr) {
//                $range = array();
//                $cidr = explode('/', $cidr);
//                $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
//                $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
//                return $range;
//            }
            function cidrToRange($cidr) {
                $range = array();
                $pos = strpos($cidr, "/");
                if($pos) {
                    $count = substr_count($cidr, '/');
                    if($count > 1) {
                        return false;
                    } else {
                        $cidr = explode('/', $cidr);
                        if($cidr[1] > 32) {
                            return false;
                        }
                        $range[0] = long2ip((ip2long($cidr[0])) & ((-1 << (32 - (int)$cidr[1]))));
                        $range[1] = long2ip((ip2long($range[0])) + pow(2, (32 - (int)$cidr[1])) - 1);
                        return $range;
                    }
                } else {
                    return $pos;
                }
            }

            if (!isset($_POST['searchVal'])){
                $searchValue = '';
            }else{
                $searchValue = $_POST['searchVal'];
            }

            if (!isset($_POST['devInfo'])){
                $devInfo = '';
            }else{
                $devInfo = $_POST['devInfo'];
            }

            if (!isset($_POST['model'])){
                $model = '';
            }else{
                $model = $_POST['model'];
            }

            if (!isset($_POST['ip_mask'])){
                $ip_mask = '';
            }else{
                $ip_mask = $_POST['ip_mask'];
                $ipMask = cidrToRange($ip_mask);
                $filterIpMaskStart = $ipMask[0];
                $filterIpMaskEnd = $ipMask[1];
            }

            if (!isset($_POST['firmware'])){
                $firmware = '';
            }else{
                $firmware= $_POST['firmware'];
            }

            if (!isset($_POST['manufacturer'])){
                $manufacturer = '';
            }else{
                $manufacturer = $_POST['manufacturer'];
            }


            if (!isset($_POST['numDev'])){
                $numDev = 0;
            }else{
                $numDev = $_POST['numDev'];
            }
            $ipMaskStart = 0;
            $ipMaskEnd = 0;
            if($searchValue == "ip") {
                if($devInfo != '') {
                    $ipMask = cidrToRange($devInfo);
                    if($ipMask) {
                        $ipMaskStart = $ipMask[0];
                        $ipMaskEnd = $ipMask[1];
                    }
                }
            }


            $devices = array();

                if($searchValue == "ip" && $groupID != '') {
                    $devices = $dev->searchDeviceByIpForGroup($devInfo, $groupID,$limitDev, $numDev, $ipMaskStart, $ipMaskEnd);
                    if (count($devices)>0){
                        include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';

                    }else{
                        $data = 1;
                        echo $data;
                        return false;
                    }
                } elseif ($searchValue == "serial" && $groupID != ''){
                    $devices = $dev->searchDeviceBySerialForGroup( $devInfo, $groupID,$limitDev, $numDev);
                    if (count($devices)>0){
                        include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';

                    }else{
                        $data = 1;
                        echo $data;
                        return false;
                    }
                } elseif ($searchValue == "mac" && $groupID != ''){
                    $devices = $dev->searchDeviceByMacForGroup($devInfo, $groupID,$limitDev, $numDev);
                    if (count($devices)>0){
                        include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';

                    }else{
                        $data = 1;
                        echo $data;
                        return false;
                    }
                } elseif ($groupID != '') {
                    $devices = $dev->filterDeviceByIpMaskModelFwManufForGroup($model,$filterIpMaskStart,$filterIpMaskEnd,$firmware,$manufacturer,$groupID,$limitDev,$numDev);
                    if (count($devices)>0){
                        include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';
                    } else {
                        $data = 1;
                        echo $data;
                        return false;
                    }
                }

            if($searchValue == "ip" && $groupID == '') {
                $ungroupedDevices = $dev->searchDeviceByIpForGroup($devInfo, '', $limitDev, $numDev, $ipMaskStart, $ipMaskEnd);
                if (count($ungroupedDevices)>0){
                    include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';
                }else{
                    $data = 1;
                    echo $data;
                    return false;
                }
            } elseif ($searchValue == "serial" && $groupID == ''){
                $ungroupedDevices = $dev->searchDeviceBySerialForGroup($devInfo, '',$limitDev, $numDev);
                if (count($ungroupedDevices)>0){
                    include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';
                }else{
                    $data = 1;
                    echo $data;
                    return false;
                }
            } elseif ($searchValue == "mac" && $groupID == ''){
                $ungroupedDevices = $dev->searchDeviceByMacForGroup($devInfo, '',$limitDev, $numDev);
                if (count($ungroupedDevices)>0){
                    include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';
                }else{
                    $data = 1;
                    echo $data;
                    return false;
                }
            } elseif ($groupID == '') {
                $ungroupedDevices = $dev->filterDeviceByIpMaskModelFwManufForGroup($model,$filterIpMaskStart,$filterIpMaskEnd,$firmware,$manufacturer,'',$limitDev,$numDev);
                if (count($ungroupedDevices)>0){
                    include $_SESSION['APPPATH'].'views/content/admin/devicesForGroup.php';
                }else{
                    $data = 1;
                    echo $data;
                    return false;
                }
            }



//            if(is_array($devices)){
//
//                for ($i = 0; $i < count($devices); $i++){
//                    $k = $i + 1 + $numDev;
//                    echo '<tr class="eachDev backColor" >';
////                    echo '<tr class="eachDev backColor" draggable="  . if (in_array(UsersConstants::$groupPermission, $_SESSION[\'permissions\'])) {echo \'true\'; } . " ondragstart="drag(event,' . $ungroupedDevices[$j]->id . ', ' . -1 . ')" . if (in_array(UsersConstants::$groupPermission, $_SESSION[\'permissions\'])) { onclick="clickMy(event, \'\')" }. >';
//                        echo '<td><input type="checkbox" class="fields"></td>';
//                        echo '<td>' . $k . '</td>';
//                        echo '<td>' . $devices[$i]->serial_number . '</td>';
//                        echo '<td>' . $devices[$i]->mac . '</td>';
//                        echo '<td>' . $devices[$i]->manufacture . '</td>';
//                        echo '<td>' . $devices[$i]->name . '</td>';
//                        echo '<td>' . $devices[$i]->ip . '</td>';
//                        echo '<td>' . $devices[$i]->port . '</td>';
//
//
//                        echo '</tr>';
//                }
//
//            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
?>
