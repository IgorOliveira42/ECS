<?php

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'] . 'models/device.php';
            require_once $_SESSION['APPPATH'] . 'util/pagingConstants.php';
            $groupID = '';
            if (isset($_SESSION['permissions'])) {
                $permissionsArray = $_SESSION['permissions'];
                if(isset($_SESSION['group_id'])) {
                    $groupID = $_SESSION['group_id'];
                }
            }
            $dev = new Device();
            if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
                $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
                $groups = $groupList;
            } else {
                $groups = $dev->getAllGroups();
            }

            if(isset($_POST['getDevices']) && $_POST['getDevices'] == 'true'){
                $groupId = $_POST['groupID'];
                $page = $_POST['page'];

//                $dev = new Device();
                $limit = PagingConstants::$clientsCount;
                $offset = ($page - 1) * $limit;
                $devices1 = $dev->getDevicesByGroup($groupId, $limit, $offset, '');

                $allDevicesCountByGroupID = $dev->getAllDevicesCountByGroup($groupId);
                if (is_array($allDevicesCountByGroupID)) {
                    $devsCount = $allDevicesCountByGroupID[0]->count;
                } else {
                    $devsCount = 0;
                }
                if ($devsCount < $limit) {
                    $pagesCount = 1;
                } else {

                    if ($devsCount % $limit == 0) {
                        $pagesCount = $devsCount / $limit;
                    } else {
                        $pagesCount = ($devsCount / $limit - ($devsCount % $limit) * (1 / $limit)) + 1;
                    }
                }
                include $_SESSION['APPPATH'] . 'views/content/admin/groupDevices.php';

            }elseif (isset($_POST['getDevices']) && $_POST['getDevices'] == 'false') {
                $devicesByGroup = array();
//                $dev = new Device();
                $groupId = $_POST['groupID'];
                $hasDevice = true;

                for($i = 0; $i < count($groupId); $i++){
                    $devices = $dev->getDevicesByGroup($groupId[$i], '', '','');
                    if(empty($devices)){
                        $hasDevice = false;
                        break;
                    } else {
                        foreach ($devices as $device){
                            array_push($devicesByGroup, $device->id);
                        }
                    }
                }
                if($hasDevice){
                    echo json_encode($devicesByGroup);
                }else {
                    echo json_encode($hasDevice);
                }
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        echo json_encode('logged_out');
    }
} else {
    exit('No direct script access allowed');
}


