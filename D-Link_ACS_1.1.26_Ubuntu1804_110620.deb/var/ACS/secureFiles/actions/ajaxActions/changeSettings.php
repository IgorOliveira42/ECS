<?php
function writeAcsSettings($settings)
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $dataAttributes = array_map(function($value, $key) {
            return $key." = ".$value;
    }, array_values($settings), array_keys($settings));
    $settingsString = implode("\n", $dataAttributes);
    $rst = @file_put_contents($settingsFile, $settingsString, LOCK_EX);
    if ($rst) {
	return True;
    }
    return False;
}

function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

function checkDbConnect($databaseType, $databasePort, $databaseHost, $databaseName, $databaseUserName, $databasePassword) 
{
    try { 
	$driver = ':host=' . $databaseHost . ';port=' . $databasePort . ';dbname=' .
	    $databaseName;
	if ($databaseType == 'mysql') {
	    $conn = new PDO('mysql'.$driver, $databaseUserName, $databasePassword);
	} else if ($databaseType == 'postgresql') {
	    $conn = new PDO('pgsql'.$driver, $databaseUserName, $databasePassword);
	}
    } catch (PDOException $e) {
	return False;
    }
    return True;
}

if(isset($_POST['fromApp'])){

    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        include $_SESSION['APPPATH'] . 'sockets/createXML.php';
        include $_SESSION['APPPATH'] . 'sockets/connectTCP.php';
        if(!class_exists("ModelParams")){require_once  $_SESSION['APPPATH'] . 'models/modelParams.php';}

        $lang = $_SESSION['lang'];
        $ini_array='';
	if ($lang == 'en') {
	    $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/english/message_lang.ini');
	} else {
	    $ini_array = parse_ini_file( $_SESSION['APPPATH'].'language/russian/message_lang.ini');
	}
	$settings = array();
	$acsSettings = readAcsSettings();
	$settings['DatabaseType'] = $acsSettings['DatabaseType'];
	$settings['DatabasePort'] = $acsSettings['DatabasePort'];
	$settings['host'] = $acsSettings['host'];
	$settings['DatabaseName'] = $acsSettings['DatabaseName'];
	$settings['username'] = $acsSettings['username'];
	$settings['password'] = $acsSettings['password'];
	$settings['serverport'] = $_POST['serverport'];
	$settings['dev_usname'] = $_POST['dev_usname'];
	$settings['dev_pass'] = $_POST['dev_pass'];
//	$settings['auto_ref_time'] = $_POST['auto_ref_time'];
		$settings['stun_server_addr'] = $_POST['stun_server_addr'];
		$settings['stun_server_port'] = $_POST['stun_server_port'];
		$settings['SLAIP'] = $_POST['sla_ip'];
		$settings['SLAPort'] = $_POST['sla_port'];
		$rebootServer = $_POST['rebootServer'];
		if ($settings['dev_pass'] == "*****") {
            $settings['dev_pass'] = $acsSettings['dev_pass'];
        }
        $reportAddressAPI = $_POST['reportAddress'];
        $modParams = new ModelParams();
        $params = $modParams->insertUpdateReportAddressForAPI($reportAddressAPI);

//        $settings['stun_server_addr_2'] = $_POST['stun_server_addr_2'];
//        $settings['stun_server_port_2'] = $_POST['stun_server_port_2'];

//	$exitCode = trim(shell_exec("timeout 2 nc -vz " . $settings['host'] . " " . $settings['DatabasePort'] . " 2>&1 | grep -q '" . $settings['DatabaseType'] . "'; echo $?"));
//	if ($exitCode == 1) {
//	    $isConn = checkDbConnect($settings['DatabaseType'], $settings['DatabasePort'],
//            $settings['host'], $settings['DatabaseName'],
//            $settings['username'], $settings['password']);
//	    if ($isConn) {
        
		if (writeAcsSettings($settings)) {
		    if($rebootServer == "true") {
                $xml = CreateXML::createUpdateSettingsXML();
                $result = ConnectTCP::connectToGetData($xml);
                if ($result) {
                    echo 0;
                } else {
                    echo 3;
                }
            } else {
                echo 0;
            }
		} else {
		    echo 1;
		}
//	    } else {
//		echo 2;
//	    }
//	} else {
//	    echo 2;
//	}
   } else {
       echo "logged_out";
   }
} else {
    exit('No direct script access allowed');
}
