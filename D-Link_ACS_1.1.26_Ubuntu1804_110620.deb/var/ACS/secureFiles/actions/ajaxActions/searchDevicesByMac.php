<?php
function searchDevicesByMac($mac, $devCount, $modelID,$groupID,$fwVersion,$sortedVal)
{
    require_once $_SESSION['APPPATH'].'models/device.php';
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupName = $_SESSION['group_id'];
        }
    }
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $dev = new Device();
    $page = 1;
    $limit = $devCount;
    $offset = ($page - 1) * $devCount;
    $devicesIds = array();
    $devicesMACs = array();
    if($groupName == 'Group manager' || $groupName == 'Group Viewer') {
        $groupList = $dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups = count($groupList);
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacByGroups($groupList, $countGroups, $mac,$devCount,$offset,$sortedVal);
                $allDevCount = $dev->getAllDevicesCountByMacByGroups($groupList, $countGroups, $mac);
//                $allDevCount = $allDeviceCount[0]->count;
//                if ($allDevCount > $limit) {
//                    for($i=0; $i<$limit; $i++) {
//                        $devices[$i] = $devices1[$i];
//                    }
//                } else {
//                    $devices = $devices1;
//                }
            } else {
                $devices = $dev->searchDevicesByMacGroup($groupID, $mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacGroup($groupID, $mac);
                $allDevCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacModelID($mac, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelID($mac, $modelID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->searchDevicesByMacModelIDGroupID($mac, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelIDGroupID($mac, $modelID, $groupID, $fwVersion);
                $allDevCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
    } else {
        if ($modelID == 0) {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMac($mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMac($mac);
            } else {
                $devices = $dev->searchDevicesByMacGroup($groupID, $mac, $devCount, $offset,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacGroup($groupID, $mac);
            }
        } else {
            if ($groupID == 0) {
                $devices = $dev->searchDevicesByMacModelID($mac, $modelID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelID($mac, $modelID, $fwVersion);
            } else {
                $devices = $dev->searchDevicesByMacModelIDGroupID($mac, $modelID, $groupID, $devCount, $offset, $fwVersion,$sortedVal);
                $allDeviceCount = $dev->getAllDevicesCountByMacModelIDGroupID($mac, $modelID, $groupID, $fwVersion);
            }
        }
        $allDevCount = $allDeviceCount[0]->count;
        $groups = $dev->getAllGroups();
    }
    
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    $taskStatus = $dev->getTaskStatusDevisesByID($devicesIds);
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    

    if ($allDevCount < $devCount) {
        $pagesCount = 0;
    } else {

        if ($allDevCount % $devCount == 0) {
            $pagesCount = $allDevCount / $devCount;
        } else {
            $pagesCount = ($allDevCount / $devCount - ($allDevCount % $devCount) * (1 / $devCount)) + 1;
        }
    }
    
    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    if(property_exists($userSettings, 'devicesTableColumns')){
        $devicesTableColumns = $userSettings->devicesTableColumns;
    }
    if(count($devices)<$devCount) {
        $data = 2;
    } else {
        $data = 3;
    }

    //added  custom sort by ip
    if ($sortedVal != '') {
        $sortedValVar = trim(explode(":", $sortedVal)[0]);
        $sortBy = trim(explode(":", $sortedVal)[1]);
    } else {
        $sortedValVar = "last_inform_time";
        $sortBy = "ASC";
    }
    //   include $_SESSION['APPPATH'] . 'util/utils.php';
    if ($sortedValVar == 'ip') {
        $devices = Utils::sortDeviceIps($devices, $sortBy,$limit,$offset);
    }

    include $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
    
//    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
//    return true;
}


if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
	    require_once $_SESSION['APPPATH'].'util/utils.php';
            define('BASEPATH', $_SESSION['BASEPATH']);
            $mac = $_POST['serialNumber'];
            $devCount = $_POST['devCount'];
            $modelID = $_POST['modelID'];
            $groupID = $_POST['groupID'];
            $fwVersion = $_POST['fwVersion'];

            $sortedVal = $_POST['sortedVal'];
            searchDevicesByMac($mac, $devCount, $modelID,$groupID,$fwVersion,$sortedVal);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
