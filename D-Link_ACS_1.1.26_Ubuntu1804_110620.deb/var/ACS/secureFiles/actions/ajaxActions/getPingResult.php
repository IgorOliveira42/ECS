<?php
function getPingResult($modelParams,$devId,$host, $type, $index){
   
    //get ping result from db FailureCount and SuccessCount and gateway
    
//    $params = $modelParams->getPingResults($devId);
//    $params = $modelParams->getPingResultsForWan($devId, $index, $type);
    $params = $modelParams->getPingResultsForDiagnostic($devId, $index);

    $gateway = ''; $lost = ''; $min = ''; $max = ''; $average = '';
    if(is_array($params) && count($params) > 0){

        $failCount = $params[0]->received;
        $successCount = $params[0]->sent;
        $lost = 0;

        if($failCount + $successCount != 0 ){
            $lost = $failCount/($failCount + $successCount)*100;
        }

//        $min = $params[0]->minimum;
//        $max = $params[0]->maximum;
//        $average = $params[0]->average;
    }
    require_once $_SESSION['APPPATH']."views/content/admin/pingResultView.php";

//
//    if(is_array($host)){
//        for ($i = 0; $i < count($host); $i++) {
//            echo "</br><span>Ping statistics for ".$host[$i]." </span></br>"
//                ."<span>Lost ".$lost."% loss</span></br>".
//                "<span>Approximate round trip times in milli-seconds :</span></br>"
//                ."<span> Minimum = ".$min."ms, Maximum = ".$max."ms, Average = ".$average."ms</span></br>";
//        }
//    }else {
//        echo "<span>Ping statistics for ".$host." </span></br>"
//           ."<span>Lost ".$lost."% loss</span></br>".
//           "<span>Approximate round trip times in milli-seconds :</span></br>"
//           ."<span> Minimum = ".$min."ms, Maximum = ".$max."ms, Average = ".$average."ms</span>";
//    }
}

function getTracerResult($modelParams,$devId){
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    $results = $modelParams->getTracerResults($devId);
    
    require_once $_SESSION['APPPATH']."views/content/admin/tracerResultsView.php";
}

function getUploadDownloadResult($modelParams,$devId,$pingName, $type, $index){
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    $uploadDownload = array();
    $i = 0;
    $uploadResult = $modelParams->getUploadResultsForWan($devId, $index, $type);
    if(!empty($uploadResult)) {
        $rom_time = $uploadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->rom_time);
        $bom_time = $uploadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->bom_time);
        $eom_time = $uploadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->eom_time);
        $test_bytes_received = $uploadResult[0]->test_file_length == NULL ? 0 : $uploadResult[0]->test_file_length;
        $total_bytes_received = $uploadResult[0]->total_bytes_sent == NULL ? 0 : $uploadResult[0]->total_bytes_sent;
        $tcp_open_request_time = $uploadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_request_time);
        $tcp_open_response_time = $uploadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($uploadResult[0]->tcp_open_response_time);

        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
        $responseTime = $eom_time - $rom_time;
        $requestRound = $bom_time - $rom_time;

        if(($eom_time - $bom_time) != 0){
            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
        }

        if(($eom_time - $bom_time) != 0){
            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
        }
        $uploadDownload[$i] = array(
            'type' => 'Upload',
            'handshakeRound'=> $handshakeRound,
            'responseTime' => $responseTime,
            'requestRound' => $requestRound,
            'responseThroughput' => $responseThroughput,
            'interfaceThroughput' => $interfaceThroughput
        );
        $i++;
    }


    $downloadResult = $modelParams->getDownloadResultsForWan($devId, $index, $type);
    if(!empty($downloadResult)) {
        $rom_time = $downloadResult[0]->rom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->rom_time);
        $bom_time = $downloadResult[0]->bom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->bom_time);
        $eom_time = $downloadResult[0]->eom_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->eom_time);
        $test_bytes_received = $downloadResult[0]->test_bytes_received == NULL ? 0 : $downloadResult[0]->test_bytes_received;
        $total_bytes_received = $downloadResult[0]->total_bytes_received == NULL ? 0 : $downloadResult[0]->total_bytes_received;
        $tcp_open_request_time = $downloadResult[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_request_time);
        $tcp_open_response_time = $downloadResult[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($downloadResult[0]->tcp_open_response_time);

        $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
        $responseTime = $eom_time - $rom_time;
        $requestRound = $bom_time - $rom_time;

        if(($eom_time - $bom_time) != 0){
            $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
        }

        if(($eom_time - $bom_time) != 0){
            $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
        }
        $uploadDownload[$i] = array(
            'type' => 'Download',
            'handshakeRound'=> $handshakeRound,
            'responseTime' => $responseTime,
            'requestRound' => $requestRound,
            'responseThroughput' => $responseThroughput,
            'interfaceThroughput' => $interfaceThroughput
        );
        $i++;
    }
    /*if($pingName == 'uploadDiagnostics'){
        $results = $modelParams->getUploadDiagnosticResults($devId);
        $handshakeRound = 0;
        $responseTime = 0;
        $requestRound = 0;
        $responseThroughput = 0;
        $interfaceThroughput = 0;
        
        if($results && !empty($results)){
            $rom_time = $results[0]->rom_time == NULL ? 0 : convertUnixTimestamp($results[0]->rom_time);
            $bom_time = $results[0]->bom_time == NULL ? 0 : convertUnixTimestamp($results[0]->bom_time);
            $eom_time = $results[0]->eom_time == NULL ? 0 : convertUnixTimestamp($results[0]->eom_time);
            $test_file_length = $results[0]->test_file_length == NULL ? 0 : $results[0]->test_file_length;
            $total_bytes_sent = $results[0]->total_bytes_sent == NULL ? 0 : $results[0]->total_bytes_sent;
            $tcp_open_request_time = $results[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($results[0]->tcp_open_request_time);
            $tcp_open_response_time = $results[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($results[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;
            
            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_file_length / ($eom_time - $bom_time);
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_sent) / ($eom_time - $bom_time);
            }
        }
                
    }else if($pingName == 'downloadDiagnostics') {
        $results = $modelParams->getDownloadDiagnosticResults($devId);
        $handshakeRound = 0;
        $responseTime = 0;
        $requestRound = 0;
        $responseThroughput = 0;
        $interfaceThroughput = 0;
        
        if($results && !empty($results)){
            $rom_time = $results[0]->rom_time == NULL ? 0 : convertUnixTimestamp($results[0]->rom_time);
            $bom_time = $results[0]->bom_time == NULL ? 0 : convertUnixTimestamp($results[0]->bom_time);
            $eom_time = $results[0]->eom_time == NULL ? 0 : convertUnixTimestamp($results[0]->eom_time);
            $test_bytes_received = $results[0]->test_bytes_received == NULL ? 0 : $results[0]->test_bytes_received;
            $total_bytes_received = $results[0]->total_bytes_received == NULL ? 0 : $results[0]->total_bytes_received;
            $tcp_open_request_time = $results[0]->tcp_open_request_time == NULL ? 0 : convertUnixTimestamp($results[0]->tcp_open_request_time);
            $tcp_open_response_time = $results[0]->tcp_open_response_time == NULL ? 0 : convertUnixTimestamp($results[0]->tcp_open_response_time);

            $handshakeRound = $tcp_open_response_time - $tcp_open_request_time;
            $responseTime = $eom_time - $rom_time;
            $requestRound = $bom_time - $rom_time;
           
            if(($eom_time - $bom_time) != 0){
                $responseThroughput = 8 * $test_bytes_received / ($eom_time - $bom_time);
            }

            if(($eom_time - $bom_time) != 0){
                $interfaceThroughput = 8 * ($total_bytes_received) / ($eom_time - $bom_time);
            }
        }
    }*/
        
    require_once $_SESSION['APPPATH']."views/content/admin/uploadDownloadResultsView.php";
}

function convertUnixTimestamp($time){
    date_default_timezone_set("UTC");

    $date = DateTime::createFromFormat('Y-m-d\TH:i:s.u', $time);
    $seconds = $date->getTimestamp()*1000000 + intval($date->format("u"));
    
    return $seconds;
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);
        require_once $_SESSION['APPPATH'].'models/modelParams.php';
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
        try{
            $modelParams = new ModelParams();
            if(isset($_POST['diagnosticName'])) {
                $diagnosticName = $_POST['diagnosticName'];
                $page = $_POST['page'];
                $devId = $_POST['deviceID'];
                $limit = 10;
                $offset = ($page - 1) * $limit;
                if($diagnosticName == 'ping') {
                    $getAllPingDiagnostic = $modelParams->getPingResultsForDiagnostic($devId, $limit, $offset);
                    $getPingDiagnosticCount = $modelParams->getPingResultsCountForDiagnostic($devId)[0]->count;
                    if ($getPingDiagnosticCount < $limit) {
                        $pagesCountPing = 1;
                    } else {
                        if ($getPingDiagnosticCount % $limit == 0) {
                            $pagesCountPing = $getPingDiagnosticCount / $limit;
                        } else {
                            $pagesCountPing = ($getPingDiagnosticCount / $limit - ($getPingDiagnosticCount % $limit) * (1 / $limit)) + 1;
                        }
                    }
                    require_once $_SESSION['APPPATH']."views/content/admin/pingResultView.php";
                } else if($diagnosticName == 'tracert') {
                    $getTracertResult = $modelParams->getTracerResults($devId, $limit, $offset);
                    $resultTracerCount = $modelParams->getAllTracerResults($devId)[0]->count;
                    if ($resultTracerCount < $limit) {
                        $pagesCountTracert = 1;
                    } else {
                        if ($resultTracerCount % $limit == 0) {
                            $pagesCountTracert = $resultTracerCount / $limit;
                        } else {
                            $pagesCountTracert = ($resultTracerCount / $limit - ($resultTracerCount % $limit) * (1 / $limit)) + 1;
                        }
                    }
                    require_once $_SESSION['APPPATH']."views/content/admin/tracerResultsView.php";
                }
            } else {
                $pingName = $_POST['pingName'];
                $devId = $_POST['deviceID'];
                $host = $_POST['host'];
                $type = $_POST['connectionType'];
                $index = $_POST['index'];

                if ($pingName == 'diagnostic') {
                    getPingResult($modelParams, $devId, $host, $type, $index);
                } else if ($pingName == 'tracert') {
                    getTracerResult($modelParams, $devId);
                } else if ($pingName == 'uploadDiagnostics' || $pingName == 'downloadDiagnostics') {
                    getUploadDownloadResult($modelParams, $devId, $pingName, $type, $index);
                }
            }


        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}
