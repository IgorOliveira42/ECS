<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            include $_SESSION['APPPATH'].'models/modelClient.php';
            $mac = $_POST['mac'];
            $client = new ModelClient();
            $macExistsCount = $client->checkMacExist($mac);
            $maxExistInDevices = $client->checkMacExistInDevices($mac);
            if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {
                echo 'false';
            } else {
                echo 'true';
            }
        }catch (\Exception $e){
           error_log($e->getMessage());
           header('HTTP/1.1 500 Internal Server Error');
           header("Status: 500 Internal Server Error");
           exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
