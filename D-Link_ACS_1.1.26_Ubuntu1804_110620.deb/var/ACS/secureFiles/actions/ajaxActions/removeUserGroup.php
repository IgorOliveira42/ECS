<?php
if(isset($_POST['fromApp']))  {
if (session_id() == '') {
    session_start();
}

//if(isset($_SESSION['timeOut'])){
//    if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_SESSION['timeOut'])) {
//        echo "logged_out";
//        exit();
//    }
//}

if (isset($_SESSION['logged_in'])) {
    try{
        define('BASEPATH', $_SESSION['BASEPATH']);
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
        include $_SESSION['APPPATH'].'models/modelUser.php';
        include $_SESSION['APPPATH'].'util/usersConstants.php';
        $user = new ModelUser();
        $userGrId = $_POST["userGroupID"];
        $permissionsCount=$_POST['permissionsCount'];
        $needRemove=false;
        if($permissionsCount==UsersConstants::$permissionsCount){
            $allUserGroups=$user->getAllUserGroups();
            $arr=array();
            foreach($allUserGroups as $allUserGroup){
                if($allUserGroup->id!=$userGrId){
                    $checking=$user->haveMaxPermissionsCountGroupId($allUserGroup->id,UsersConstants::$permissionsCount);
                    $arr[]=$checking;
                    if($checking[0]->res=='true'){
                        $usersCount=$user->checkHavingActiveUsers($allUserGroup->id);
                        if($usersCount[0]->count>0){
                              $needRemove=true;
                        }
                    }
                }
            }
        } else {
            $needRemove=true;
        }
        if($needRemove){
	    $usersCountForGroup = $user->getUsersCountForGroup($userGrId);
	    $usersCountForGroup = $usersCountForGroup[0]->count;
	    if ($usersCountForGroup == 0) {
		$result = $user->removeUserGroup($userGrId);
	    } else {
		echo $ini_array['group_has_users_msg'];
	    }
        } else {
            echo $ini_array['last_group_msg'];
        }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}
