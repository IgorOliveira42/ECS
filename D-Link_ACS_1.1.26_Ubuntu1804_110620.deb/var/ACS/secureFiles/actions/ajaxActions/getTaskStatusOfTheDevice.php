<?php
function getTaskStatus($deviceId,$task,$modParams){
   
    $params = $modParams-> getLastActivityStatusByDevId($deviceId,$task);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"-1";
}

function getTaskStatusForSet($deviceId,$task,$modParams){
    
    $params = $modParams-> getLastActivityStatusByOperationType($deviceId,$task);
    $lastActivity = $modParams-> getLastActivityofList($deviceId);
    $activities = $_SESSION['activityStatus'];
    if(is_array($params) && count($params) > 0){
        if($params[0]->id == $lastActivity[0]->id){
            $isSetId = false;
            if(array_key_exists($params[0]->id, $activities) && $activities[$params[0]->id] == 2 && 2 == $params[0]->operation_status){
                $isSetId = true;
            }

            if($isSetId){
                return "2";
            }else {
                if(!array_key_exists($params[0]->id, $activities)){
                    $_SESSION['activityStatus'][$params[0]->id] = $params[0]->operation_status;
                }elseif (array_key_exists($params[0]->id, $activities) && $activities[$params[0]->id] != $params[0]->operation_status) {
                    $_SESSION['activityStatus'][$params[0]->id] = $params[0]->operation_status;
                }

                return $params[0]->operation_status;
            }
        }else {
           return "-1"; 
        }
    }else {
        return "-1";
    }
//    return is_array($params) && count($params) > 0 ? $params[0]->operation_status : "-1";
}

function getLastTaskStatus($deviceId,$modParams){
    $params = $modParams-> getLastActivityofList($deviceId);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"-1";
}

function getLastTaskId($deviceId,$modParams){
    $params = $modParams-> getLastActivityofList($deviceId);
    return is_array($params) && count($params)>0 ? $params[0]->id : "-1";
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);
        require_once $_SESSION['APPPATH'].'models/modelParams.php';
        $modParams = new ModelParams();
        
        $deviceId = $_POST['deviceID'];
        $taskName = $_POST['taskName'];
        try{
            if($taskName == 'tabs'){
                $status = getLastTaskId($deviceId,$modParams);
                echo $status;
            }else if($taskName != 'refreshButton'){
                $status = getTaskStatus($deviceId,$taskName,$modParams);
                echo $status;
            }else if($taskName == "'set'" || $taskName == "'autoRefresh'"){
                if(!isset($_SESSION['activityStatus'])){
                    $activities = array();
                    $_SESSION['activityStatus'] = $activities;
                } 
                $status = getTaskStatusForSet($deviceId,$taskName,$modParams);
                echo $status;

            }elseif ($taskName == 'refreshButton') {
                $status = getLastTaskStatus($deviceId,$modParams);
                echo $status;
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }   
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}