<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') { session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }

            require_once $_SESSION['APPPATH'].'models/device.php';
            require_once $_SESSION['APPPATH'].'models/modelParams.php';
            $modParams = new ModelParams();
            $dev = new Device();

            if(isset($_POST['forEditing']) && $_POST['forEditing'] == 'true'){
                $deviceID = $_POST['deviceID'];
                $vlanId = $_POST['vlanId'];
                $vlanType = $_POST['vlanType'];
                $busyPorts = array();
                $portsNumIndex = array();

                $availablePorts = getAvailablePorts($deviceID, $dev);
                $vlanParam = $modParams->getVlanParam($vlanId);

                if($vlanParam[0]->ports){
                    foreach ($vlanParam[0]->ports as $port){
                        $busyPorts[$port->vlan_port_name.$port->vlan_port_number.'busy'] = (int)$port->vlan_port_number;
                    }

                    foreach ($vlanParam[0]->ports as $port){
                        $portsNumIndex[$port->vlan_port_name.$port->vlan_port_number.'numIndex'] = (int)$port->num_index;
                    }
                }

                $vlanParam[0]->allPorts = array_merge($availablePorts,$busyPorts,$portsNumIndex);
                ksort($vlanParam[0]->allPorts);

                include $_SESSION['APPPATH'].'views/content/admin/vlanEditPageForDevice.php';

            }else if(isset($_POST['forName']) && $_POST['forName'] == 'true'){
                $deviceID = $_POST['deviceID'];
                $vlanName = $_POST['bridgeName'];
                $ifExist = 'false';

                $vlansNames = $modParams->getAllVlanNames($deviceID);
                foreach ($vlansNames as $vlanNames){
                    if($vlanNames->vlan_name == $vlanName){
                        $ifExist = 'true';
                        break;
                    }
                }
                echo $ifExist;
            } else {
                $deviceID = $_POST['deviceID'];
                $vlanId = $_POST['vlanId'];
                $ifExist = 'false';

                $vlansIds = $modParams->getAllVlanIds($deviceID);
                foreach ($vlansIds as $vlanid){
                    if($vlanid->vlan_id == $vlanId){
                        $ifExist = 'true';
                        break;
                    }
                }
                echo $ifExist;
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}

function getAvailablePorts($deviceID,$dev){
    
    $lanPortsCount = $dev->getLanPorts($deviceID);
    $wlanPortsCount = $dev->getWlanPorts($deviceID);
    $availablePorts = array();
    $lanPorts = array();
    $wlanPorts = array();
    
    if($lanPortsCount[0]->count && $lanPortsCount[0]->count > 0){
        for($i = 1; $i <= $lanPortsCount[0]->count; $i++){
            $lanPorts['LAN'.$i] = $i;
        }
    }
    
    if($wlanPortsCount[0]->count && $wlanPortsCount[0]->count > 0){
        for($i = 1; $i <= $wlanPortsCount[0]->count; $i++){
            $wlanPorts['WLAN'.$i] = $i;
        }
    }
    
    $allPorts = array_merge($lanPorts,$wlanPorts);
    $ports = $dev->getAllVlanPorts($deviceID);
    
    if(is_array($ports) && !empty($ports)){
        foreach ($ports as $port){
            $portsArray[$port->vlan_port_name.$port->vlan_port_number] = (int)$port->vlan_port_number;
        }
        $availablePorts = array_diff_key($allPorts, $portsArray);
        return $availablePorts;
        
    }else {
        return $allPorts;
    }
}