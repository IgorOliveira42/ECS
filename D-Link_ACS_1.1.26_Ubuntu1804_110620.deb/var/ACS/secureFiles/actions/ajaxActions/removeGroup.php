<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    if (isset($_SESSION['logged_in'])) {
        try{
            $groupID = $_POST['groupID'];
            include $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();
            if(!is_array($groupID)) {
                $result = $dev->removeGroup($groupID);
            } else {
                $result = $dev->removeGroupsOfGroup($groupID);
            }
            if (!$result) {
                echo 'false';
            } else {
                echo 'true';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
