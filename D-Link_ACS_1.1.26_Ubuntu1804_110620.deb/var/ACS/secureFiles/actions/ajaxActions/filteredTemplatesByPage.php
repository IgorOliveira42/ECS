<?php
function getTemplatesByPage($page){
    include  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $limit = 5;
    $offset = ($page - 1) * $limit;

    $mTemplates = new ModelTemplates();
    $templates = $mTemplates->getAllTemplatesList($limit,$offset);
    $allTemplatesCount = $mTemplates->getAllTemplatesCount();
    $devCount = $allTemplatesCount[0]->count;
    if ($devCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($devCount % $limit == 0) {
            $pagesCount = $devCount / $limit;
        } else {
            $pagesCount = ($devCount / $limit - ($devCount % $limit) * (1 / $limit)) + 1;
        }
    }

    include  $_SESSION['APPPATH'].'views/content/admin/filteredTemplates.php';
}

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $page = $_POST['page'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getTemplatesByPage($page);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}