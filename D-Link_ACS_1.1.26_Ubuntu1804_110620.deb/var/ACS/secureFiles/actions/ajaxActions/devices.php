<?php

function devicesByModel($modelId, $groupId, $devicesCount,$fwVersion,$templ,$devicesTableColumns){
    require_once $_SESSION['APPPATH'].'models/device.php';

    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        if(isset($_SESSION['group_id'])) {
            $groupID = $_SESSION['group_id'];
        }
    }

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $dev = new Device();
    $page = 1;
    $offset = ($page - 1) * $devicesCount;
    $limit = $devicesCount;
    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
        $groupList=$dev->getGroupsSelectedUser($_SESSION['userID']);
        $countGroups=count($groupList);
        if ($modelId == 0) {
            if ($groupId == 0) {
                $devices = array();
//                $devices = $dev->getDevicesByGroupId($groupId, $devicesCount, $offset);
//                $allDeviceCount = $dev->getAllDevicesCountByGroupID($groupId);
                $devices1 = $dev->getDevicesByGroups($groupList, $countGroups,"");
                $devCount = $dev->getAllDevicesCountByGroups($groupList, $countGroups);
                if ($devCount > $limit) {
                    for($i=0; $i<$limit; $i++) {
                        $devices[$i] = $devices1[$i];
                    }
                } else {
                    $devices = $devices1;
                }
            } else {
                $devices = $dev->getDevicesByGroup($groupId, $devicesCount, $offset,"");
                $allDeviceCount = $dev->getAllDevicesCountByGroup($groupId);
                $devCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupId == 0) {
                $devices = $dev->getDevicesByModelByGroupID($groupList, $countGroups, $modelId, $devicesCount, $offset, $fwVersion,"");
                $allDeviceCount = $dev->getAllDevicesCountByModelForGroups($groupList, $countGroups, $modelId, $fwVersion);
                $devCount = $allDeviceCount;
            } else {
                $devices = $dev->getDevicesByModelGroup($modelId, $groupId, $devicesCount, $offset, $fwVersion,"");
                $allDeviceCount = $dev->getAllDevicesCountByModelGroup($modelId, $groupId, $fwVersion);
                $devCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $groupList;
    } else {
        if ($modelId == 0) {
            if ($groupId == 0) {
                $devices = $dev->getDevices($devicesCount, $offset,"");
                $allDeviceCount = $dev->getAllDevicesCount();
                $devCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->getDevicesByGroup($groupId, $devicesCount, $offset,"");
                $allDeviceCount = $dev->getAllDevicesCountByGroup($groupId);
                $devCount = $allDeviceCount[0]->count;
            }
        } else {
            if ($groupId == 0) {
                $devices = $dev->getDevicesByModel($modelId, $devicesCount, $offset, $fwVersion,"");
                $allDeviceCount = $dev->getAllDevicesCountByModel($modelId, $fwVersion);
                $devCount = $allDeviceCount[0]->count;
            } else {
                $devices = $dev->getDevicesByModelGroup($modelId, $groupId, $devicesCount, $offset, $fwVersion,"");
                $allDeviceCount = $dev->getAllDevicesCountByModelGroup($modelId, $groupId, $fwVersion);
                $devCount = $allDeviceCount[0]->count;
            }
        }
        $groups = $dev->getAllGroups();
    }
//    $devCount = $allDeviceCount[0]->count;
    $devicesIds = array();
    $devicesMACs = array();
    foreach ($devices as $device){
        array_push($devicesIds, $device->id);
        array_push($devicesMACs, $device->mac);
    }
    Utils::getDevicesClientsNames($devices, $devicesIds, $dev);
    

    if ($devCount < $devicesCount) {
        $pagesCount = 1;
    } else {

        if ($devCount % $devicesCount == 0) {
            $pagesCount = $devCount / $devicesCount;
        } else {
            $pagesCount = ($devCount / $devicesCount - ($devCount % $devicesCount) * (1 / $devicesCount)) + 1;
        }
    }
    if($pagesCount<=1) {
        $data = 2;
    } else {
        $data = 3;
    }
    $allTemplates = $templ->getAllTemplates();
    require_once $_SESSION['APPPATH'].'views/content/admin/devicesTable1.php';
}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'util/utils.php';
            require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
            $templ = new ModelTemplates();
            define('BASEPATH', $_SESSION['BASEPATH']);
            $modelId = $_POST['modelId'];
            $groupId = $_POST['groupId'];
            $fwVersion = $_POST['fwVersion'];
            $cookie = $_POST['cooki_array'];
            $devCount = intval($_POST['devCount']);
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            if ($devCount != 0) {
    //	    $_SESSION['rowCount'] = $devCount;
                $userSettings->rowCount = $devCount;
            }
            if(!empty($cookie) && $cookie != ''){
                $n = $cookie[0];
                $sN = $cookie[1];
                $mac = $cookie[2];
                $mF = $cookie[3];
                $clientName = $cookie[4];
                $port = $cookie[5];
                $devId = $cookie[6];
//                $mN = $cookie[4];
//                $clientName = $cookie[5];
//                $ip = $cookie[6];
//                $port = $cookie[7];
//                $devId = $cookie[8];
                $fields = array('n' => $n, 'sN' => $sN, 'mF' => $mF, 'port' => $port, /*'ip' => $ip, 'mN' => $mN,*/'mac' => $mac,'clientName'=>$clientName, 'dI'=>$devId);
                $userSettings->devicesTableColumns = (object)$fields;
            }
            if(property_exists($userSettings, 'devicesTableColumns')){
                $devicesTableColumns = $userSettings->devicesTableColumns;
            }
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
            devicesByModel($modelId, $groupId, $devCount,$fwVersion,$templ,$devicesTableColumns);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
