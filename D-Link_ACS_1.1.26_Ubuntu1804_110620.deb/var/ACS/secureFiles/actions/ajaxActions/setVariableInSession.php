<?php

if(isset($_POST['fromApp'])){
    if (session_id() == ''){session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $checked = json_decode($_POST['checked']);
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            $action = $_POST["action"];
            if($action == "devStatus") {
                $userSettings->checkDevicesStatus = $checked;
            } else if ($action == "SlaStatus") {
                $userSettings->SlaStatus = $checked;
            }
//            if ($checked){
    //            if(isset($_SESSION["checkDevicesStatus"])){
    //                $_SESSION["checkDevicesStatus"] = true;
    //            }
//                $userSettings->checkDevicesStatus = true;
//            }else {
    //            if(isset($_SESSION["checkDevicesStatus"])){
    //                $_SESSION["checkDevicesStatus"] = false;
    //            }
//                $userSettings->checkDevicesStatus = false;
//            }
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
            echo json_encode('true');
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    }else {
        echo json_encode('logged_out');
    }
}