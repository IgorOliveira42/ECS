<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            include $_SESSION['APPPATH'].'models/modelUser.php';
//            include $_SESSION['APPPATH'].'models/modelClient.php';
            if(isset($_POST['email'])) {
                $email = $_POST['email'];
            } else {
                $email = '';
            }
            if(isset($_POST['userName'])) {
                $userName = $_POST['userName'];
            } else {
                $userName = '';
            }
            if(isset($_POST['oldEmail'])) {
                $oldEmail = $_POST['oldEmail'];
            }else {
                $oldEmail='';
            }
            if(isset($_POST['oldUserName'])) {
                $oldUserName = $_POST['oldUserName'];
            } else {
                $oldUserName='';
            }

            if ($userName != '' && $oldUserName != $userName) {
                $user = new ModelUser();
                $existsCount = $user->checkUserNameExist($userName);

                if($existsCount) {
                    if ($existsCount[0]->status == 2) {
                        echo '2';
                        return false;
                    } else if ($existsCount[0]->status == 1) {
                        echo '1';
                        return false;
                    }
                }
            }

            if ($email != '' && $oldEmail != $email) {
                $client = new ModelUser();
                $existsCount = $client->checkEmailExist($email);
                if ($existsCount && $existsCount[0]->status == 1) {
                    echo $ini_array['email_exist'];
                    return false;
                }elseif($existsCount && $existsCount[0]->status == 2) {
                    echo $ini_array['email_exist'];
                    return false;
                }
            }

        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
