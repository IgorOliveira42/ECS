<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            require_once $_SESSION['APPPATH'].'models/device.php';
            $modelId = $_POST['modelId'];
            $groupId = $_POST['groupId'];
            $fwVersion = $_POST['fwVersion'];
            $dev = new Device();
            $devIds = $dev->getDeviceIsdByModelGroup($modelId, $groupId, $fwVersion);
            $deviceIdArray = array();
            foreach ($devIds as $id) {
                array_push($deviceIdArray,$id->id);
            }
            echo implode(",",$deviceIdArray);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
