<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    function strpos_all($haystack, $needle) {
        $offset = 0;
        $allpos = array();
        while (($pos = strpos($haystack, $needle, $offset)) !== FALSE) {
            $offset   = $pos + 1;
            $allpos[] = $pos;
        }
        return $allpos;
    }
    
if (isset($_SESSION['logged_in'])) {
    try{
        define('BASEPATH', $_SESSION['BASEPATH']);
        include $_SESSION['APPPATH'].'models/modelClient.php';
        include $_SESSION['APPPATH'].'util/pagingConstants.php';
        $page = 1;
        $limit = PagingConstants::$clientsCount;
        $offset = ($page - 1) * $limit;
        $client = new ModelClient();
        $clientInfo = $_POST["clientInfo"];
        $searchVal = $_POST["searchVal"];

        $indexes = strpos_all($clientInfo, "%");
        $reversed = array_reverse($indexes);
        $arrayClientInfor = str_split($clientInfo,1);

        for($i=0; $i< count($reversed); $i++) {
            array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
        }
        $stringClientInfor = implode('',$arrayClientInfor);
        $clientInfo = $stringClientInfor;

        if ($searchVal == 'firstName') {
            $clients = $client->searchClientByFirstName(trim($clientInfo), $limit, $offset);
            $allSearchedClientsCount = $client->getAllClientsCountByFirstName(trim($clientInfo));
            $clientsCount = $allSearchedClientsCount[0]->count;
        } else if ($searchVal == 'surName') {
            $clients = $client->searchClientBySurName(trim($clientInfo), $limit, $offset);
            $allSearchedClientsCount = $client->getAllClientsCountBySurName(trim($clientInfo));
            $clientsCount = $allSearchedClientsCount[0]->count;
        } else if ($searchVal == 'patronymicName') {
            $clients = $client->searchClientByPatName(trim($clientInfo), $limit, $offset);
            $allSearchedClientsCount = $client->getAllClientsCountByPatName(trim($clientInfo));
            $clientsCount = $allSearchedClientsCount[0]->count;
        } else if ($searchVal == 'contractNumber') {
            $clients = $client->searchClientByContNum(trim($clientInfo), $limit, $offset);
            $allSearchedClientsCount = $client->getAllClientsCountByClientInfo(trim($clientInfo));
            $clientsCount = $allSearchedClientsCount[0]->count;
        }

//        $clients = $client->searchClients(trim($clientInfo), $limit, $offset);
//        $allSearchedClientsCount = $client->getAllClientsCountByClientInfo(trim($clientInfo));
//        $clientsCount = $allSearchedClientsCount[0]->count;
        if ($clientsCount < $limit) {
            $pagesCount = 1;
        } else {
            if ($clientsCount % $limit == 0) {
                $pagesCount = $clientsCount / $limit;
            } else {
                $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
            }
        }


        $sortedVal = "first_name";


        $action = "fromClientsView";
        include $_SESSION['APPPATH'].'views/content/admin/searchedClients.php';
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 

} else {
    $result = "logged_out";
    echo $result;
}
} else {
    exit('No direct script access allowed');
}