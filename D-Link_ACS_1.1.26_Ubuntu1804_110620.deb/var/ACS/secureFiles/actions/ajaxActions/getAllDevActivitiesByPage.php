<?php
    function getAllWebTasksByDevIDByPage($deviceID, $page)
    {
        include $_SESSION['APPPATH'].'models/modelWebTask.php';
        include $_SESSION['APPPATH'].'util/pagingConstants.php';

        $limit = PagingConstants::$activityCount;
        $offset = ($page - 1) * $limit;

        $webTask = new ModelWebTask();
//        $activities = $webTask->getAllWebTaskByDevIdAndPage($deviceID, $limit, $offset);
        $activities = $webTask->getAllWebTaskByDevIdAndPageExcludeItem($deviceID, $limit, $offset,"'create_port', 'select_interface'");

//        $allActivitiesCount = $webTask->getAllWebTasksCountByDevId($deviceID);
        $allActivitiesCount = $webTask->getAllWebTasksCountByDevIdExcludeItem($deviceID,"'create_port', 'select_interface'");
        $activitiesCount = $allActivitiesCount[0]->count;
        if ($activitiesCount < $limit) {
            $pagesCount = 1;
        } else {

            if ($activitiesCount % $limit == 0) {
                $pagesCount = $activitiesCount / $limit;
            } else {
                $pagesCount = ($activitiesCount / $limit - ($activitiesCount % $limit) * (1 / $limit)) + 1;
            }
        }


        foreach ($activities as  $activity){
            if(trim($activity->type_name)=='getSelectedParams'){
                $tabName=Utils::getTabnameINActivity($activity->xml);
                $tabN=array($activity->type_name,$tabName);
                $activity->type_name=$tabN;

            } else {
                $tabN=array($activity->type_name,"");
                $activity->type_name=$tabN;
            }
        }
        include  $_SESSION['APPPATH'].'views/content/admin/deviceActivities.php';

        return true;
    }

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $page = $_POST['page'];
            $devId = $_POST['deviceID'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getAllWebTasksByDevIDByPage($devId, $page);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }  
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}


