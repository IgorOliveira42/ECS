<?php
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }

    function strpos_all($haystack, $needle) {
        $offset = 0;
        $allpos = array();
        while (($pos = strpos($haystack, $needle, $offset)) !== FALSE) {
            $offset   = $pos + 1;
            $allpos[] = $pos;
        }
        return $allpos;
    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
           define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/modelClient.php';
            include $_SESSION['APPPATH'].'util/pagingConstants.php';
            $firstName = '';
            $surName = '';
            $patName = '';
            $contNum = '';
            $address = '';
            $email = '';
            $page = 0;
            if (isset($_POST['firstName'])) {
                $firstName = $_POST['firstName'];
                $indexes = strpos_all($firstName, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($firstName,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $firstName = $stringClientInfor;
            }
            if (isset($_POST['surName'])) {
                $surName = $_POST['surName'];
                $indexes = strpos_all($surName, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($surName,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $surName = $stringClientInfor;
            }
            if (isset($_POST['patName'])) {
                $patName = $_POST['patName'];
                $indexes = strpos_all($patName, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($patName,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $patName = $stringClientInfor;
            }
            if (isset($_POST['contNum'])) {
                $contNum = $_POST['contNum'];
                $indexes = strpos_all($contNum, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($contNum,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);
                $contNum = $stringClientInfor;
            }
            if (isset($_POST['address'])) {
                $address = $_POST['address'];
                $indexes = strpos_all($address, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($address,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);

                $address = $stringClientInfor;
            }
            if (isset($_POST['email'])) {
                $email = $_POST['email'];
                $indexes = strpos_all($email, "%");
                $reversed = array_reverse($indexes);
                $arrayClientInfor = str_split($email,1);

                for($i=0; $i< count($reversed); $i++) {
                    array_splice($arrayClientInfor, $reversed[$i], 0, "\\");
                }
                $stringClientInfor = implode('',$arrayClientInfor);

                $email = $stringClientInfor;
            }
            if (isset($_POST['page'])) {
                $page = $_POST['page'];
            }
            $limit = PagingConstants::$clientsCount;
            $offset = ($page - 1) * $limit;
            $client = new ModelClient();
            if($firstName == '' && $surName == '' && $patName == '' && $contNum == '' && $address == '' && $email == '') {
                $clients = $client->getAllClients($limit, $offset);
                $allClientsCount = $client->getAllClientsCount();
            }  else if($firstName != '' && $surName == '' && $patName == '' && $contNum == '' && $address == '' && $email == ''){
                $clients = $client->searchClientByFirstName($firstName, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByFirstName($firstName);
            } else if($surName != '' && $firstName == '' && $patName == '' && $contNum == '' && $address == '' && $email == '') {
                $clients = $client->searchClientBySurName($surName, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountBySurName($surName);
            } else if($patName != '' && $firstName == '' && $surName == '' && $contNum == '' && $address == '' && $email == ''){
                $clients = $client->searchClientByPatName($patName, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByPatName($patName);
            } else if($contNum != '' && $firstName == '' && $surName == '' && $patName == '' && $address == '' && $email == ''){
                $clients = $client->searchClientByContNum($contNum, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByClientInfo($contNum);
            }else if($contNum == '' && $firstName == '' && $surName == '' && $patName == '' && $address != '' && $email == ''){
                $clients = $client->searchClientByAddress($address, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByAddress($address);
            }else if($contNum == '' && $firstName == '' && $surName == '' && $patName == '' && $address == '' && $email != ''){
                $clients = $client->searchClientByEmail($email, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByEmail($email);
            }else {
                $clients = $client->searchClientByFirstSur($firstName, $surName, $patName, $contNum, $address, $email, $limit, $offset);
                $allClientsCount = $client->getAllClientsCountByFirstNSurNPatNConN($firstName, $surName, $patName, $contNum, $address, $email);
            }
            $clientsCount = $allClientsCount[0]->count;
            if ($clientsCount < $limit) {
                $pagesCount = 1;
            } else {
                if ($clientsCount % $limit == 0) {
                    $pagesCount = $clientsCount / $limit;
                } else {
                    $pagesCount = ($clientsCount / $limit - ($clientsCount % $limit) * (1 / $limit)) + 1;
                }
            }

            if(!isset($_POST['needTarif'])){
                $action = "fromSaleVies";
            } else {
                $action = '';
            }

//            // for connecting tarifs
//            include  $_SESSION['APPPATH'].'models/modelTemplates.php';
//            $templ=new ModelTemplates();
//            $allTemplates=$templ->getAllTemplates();

            include $_SESSION['APPPATH'].'views/content/admin/searchedClients.php';
            
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}