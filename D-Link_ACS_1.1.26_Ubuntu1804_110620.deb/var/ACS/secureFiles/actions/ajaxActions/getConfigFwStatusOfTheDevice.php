<?php
function getTaskStatus($deviceId,$task,$fileID){
    include $_SESSION['APPPATH'].'models/fwConfigFile.php';

    $fwModel = new FwConfigFile();
    $params = $fwModel-> getLastFwConfigStatusByDevIdFileName($deviceId,$task,$fileID);
    return is_array($params) && count($params)>0 ? $params[0]->operation_status:"-1";
}
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'util/actionNamesConstants.php';
            $deviceId = $_POST['deviceID'];
            $taskName=$_POST['taskName'];
            $fileID=$_POST['fileId'];
            $ss = getTaskStatus($deviceId,$taskName,$fileID);
            echo $ss;
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        echo 'logged_out';
    }
} else {
    exit('No direct script access allowed');
}