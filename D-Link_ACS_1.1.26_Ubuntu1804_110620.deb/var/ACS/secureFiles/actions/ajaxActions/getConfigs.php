<?php

function deviceConfigs($deviceID)
{
    include $_SESSION['APPPATH'].'models/device.php';
    $dev = new Device();
    $configs = $dev->getDeviceConfigs($deviceID);
    $filtredConfigs = array();

    for($i = 0; $i < count($configs); $i++){
        $fullPath =  parse_url($configs[$i]->path);
//        $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
        $filePath = realpath(getcwd() . '/../../..' . str_replace('%20', ' ', $fullPath['path']));
        if (file_exists($filePath)) {
            array_push($filtredConfigs, $configs[$i]);
        }
    }

    include $_SESSION['APPPATH'].'views/content/admin/update_config.php';
    return true;

}

function  removeConfigs($deviceID,$configId)
{
    include $_SESSION['APPPATH'].'models/device.php';
    $dev = new Device();
    $configs = $dev->getDeviceConfigs($deviceID);

    for($i = 0; $i < count($configs); $i++){
        if($configs[$i]->id == $configId){
            $fullPath =  parse_url($configs[$i]->path);
        }
    }

    $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
    if (file_exists($filePath)) {
        if(unlink($filePath)){
            $dev->removeConfig($configId);
            echo 'true';
        }else {
            echo 'false';
        }
    }
    echo false;
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            $deviceID = $_POST['deviceID'];
            $action = $_POST['actionName'];

            if($action == 'getConfigs'){
                deviceConfigs($deviceID);
            }

            if($action == 'removeConfig' && isset($_POST['configId'])){
                $configId = $_POST['configId'];
                removeConfigs($deviceID,$configId);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
