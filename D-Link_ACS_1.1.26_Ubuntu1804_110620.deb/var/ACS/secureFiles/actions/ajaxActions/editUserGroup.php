<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $grId = $_POST['groupId'];
            $grName = $_POST['groupName'];
//            $groupName = $_POST['userGroupName'];
            $lang = $_POST['lang'];
            $hour = $_POST['hour'] == '' ? 0 : $_POST['hour'];
            $minute = $_POST['minute'] == '' ? 0 : $_POST['minute'];
            $timeOut = ($hour*60 + $minute)*60;
            $language = $lang == '' ? '' : $lang;
            $permissions = $_POST['permissionsList'];
            include $_SESSION['APPPATH'].'models/modelUser.php';
                $user = new ModelUser();
                $result= $user->editUserGroup($grId,$grName,$language,$permissions,$timeOut);
            if (!$result) {
                echo 'false';
            } else {
                echo 'true';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}