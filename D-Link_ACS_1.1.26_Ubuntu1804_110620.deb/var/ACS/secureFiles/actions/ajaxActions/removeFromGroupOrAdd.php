<?php
if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $action = $_POST['action'];
            $deviceIDString = $_POST['deviceID'];
            $changeTemplate = $_POST['changeTemplate'];
            if(is_string($deviceIDString)) {
                $deviceIDArray = explode(',',$deviceIDString);
            } else {
                $deviceIDArray = $deviceIDString;
            }

            include $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();
            $result = '';
            if($action == 'remove'){
                for($i = 0; $i < count($deviceIDArray); $i++){
                    $result = $dev->removeDeviceFromGroup($deviceIDArray[$i],$changeTemplate);
                }
            }else if($action == 'add'){
                $groupID = $_POST['groupID'];

                for($i = 0; $i < count($deviceIDArray); $i++){
                    $result = $dev->addDeviceToGroup($deviceIDArray[$i],$groupID);
                }
            }
            if (!$result) {
                echo 'false';
            } else {
                echo 'true';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}