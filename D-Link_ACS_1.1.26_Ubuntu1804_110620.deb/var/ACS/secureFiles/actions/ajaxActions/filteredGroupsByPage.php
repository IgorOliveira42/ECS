<?php
function getGroupsByPage($page){
    require_once $_SESSION['APPPATH'].'models/device.php';
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';

    $limit = 5;
    $offset = ($page - 1) * $limit;


    $dev = new Device();
    $groups = $dev->getGroups($limit, $offset);
    
    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();
    
    $allGroupsArray = $dev->getAllGroups();

    $devCount = count($allGroupsArray);
    if ($devCount < $limit) {
        $pagesCount = 1;
    } else {

        if ($devCount % $limit == 0) {
            $pagesCount = $devCount / $limit;
        } else {
            $pagesCount = ($devCount / $limit - ($devCount % $limit) * (1 / $limit)) + 1;
        }
    }
    include $_SESSION['APPPATH'].'views/content/admin/filteredGroups.php';

}


if(isset($_POST['fromApp'])){
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $page = $_POST['page'];
            define('BASEPATH', $_SESSION['BASEPATH']);
            getGroupsByPage($page);
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}