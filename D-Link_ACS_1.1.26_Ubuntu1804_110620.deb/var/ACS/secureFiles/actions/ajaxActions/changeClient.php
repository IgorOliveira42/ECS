<?php

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    if (isset($_SESSION['logged_in'])) {
        try{
            $clName = trim($_POST['clientName']);
            $clSName = trim($_POST['clientSurName']);
            $clAddress = trim($_POST['clientAddress']);
            $clEmail = trim($_POST['clientEmail']);
            $clPatName = trim($_POST['clientPatName']);
            $clContNumber = trim($_POST['clientContNumber']);
            $clID = $_POST['cID'];

            include $_SESSION['APPPATH'] . "models/modelClient.php";
            $client = new ModelClient();
            $result = $client->changeClient($clName, $clSName, $clAddress, $clEmail, $clPatName, $clContNumber, $clID);
            if (!$result) {
                echo 'false';
            } else {
                echo 'true';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}
