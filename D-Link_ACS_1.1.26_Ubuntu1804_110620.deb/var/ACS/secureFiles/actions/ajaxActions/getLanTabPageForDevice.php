<?php

function getLanParams($deviceSerial)
{
    $modParams = new ModelParams();
    $params = $modParams->getLanParams($deviceSerial);
    return $params;
}


function getConnectedDevices($deviceId,$type)
{
    if(!class_exists("ModelParams")){require_once  $_SESSION['APPPATH'] . 'models/modelParams.php';}
    $modParams = new ModelParams();
    $params = $modParams->getDevicesToConnectInRouter($deviceId,$type);
    return $params;
}

function getLanV6Params($deviceSerial)
{
    $modParams = new ModelParams();
    $params = $modParams->getLanV6Params($deviceSerial);
    return $params;
}

function after($symbol, $inthat)
{
    if (!is_bool(strpos($inthat, $symbol)))
        return substr($inthat, strpos($inthat,$symbol)+strlen($symbol));
};

function before($symbol, $inthat)
{
    return substr($inthat, 0, strpos($inthat, $symbol));
};

function getLanIpV4TabPage($serialN, $devStatus, $havPer){
    $deviceStatus = $devStatus;
    $havePerms = $havPer;
    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    if (isset($_SESSION['lang'])) {
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
    }
        $paramsFromModel = getLanParams($serialN);
        if ($paramsFromModel) {
            $connectedDevices = getConnectedDevices($paramsFromModel[0]->device_id,'LAN');

            $params = array("ipAddr" => array("IPRouters", $paramsFromModel[0]->ip_routers),
                "netmask" => array("SubnetMask", $paramsFromModel[0]->subnet_mask),
                "mode" => array("DHCPServerEnable", $paramsFromModel[0]->dhcp_server_enable),
                "dns-relay" => array("DHCPRelay", $paramsFromModel[0]->dhcp_relay),
                "startIp" => array("MinAddress", $paramsFromModel[0]->min_address),
                "endIP" => array("MaxAddress", $paramsFromModel[0]->max_address),
                "leaseTime" => array("DHCPLeaseTime", ($paramsFromModel[0]->dhcp_lease_time)),
//                "externalDHCP" => array("X_DLINK_DHCPExternalServerIPAddress", ($paramsFromModel[0]->ext_dhcp_server_ip)),
                "valueChange"=>$paramsFromModel[0]->value_change);
        } else {
            $connectedDevices = array();
            $params = array("ipAddr" => array("IPRouters", ''),
                "netmask" => array("SubnetMask", ''),
                "mode" => array("DHCPServerEnable", ''),
                "dns-relay" => array("DHCPRelay", ''),
                "startIp" => array("MinAddress", ''),
                "endIP" => array("MaxAddress", ''),
//                "externalDHCP" => array("X_DLINK_DHCPExternalServerIPAddress", ''),
                "leaseTime" => array("DHCPLeaseTime", 0),"valueChange"=>0,
                "valueChange"=>'');
        }

        require_once $_SESSION['APPPATH'].'views/content/admin/lanIpV4PageForDevice.php';
        }

function getLanIpV6TabPage($serialN, $devStatus, $havPer){
    $deviceStatus = $devStatus;
    $havePerms = $havPer;
    $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    if (isset($_SESSION['lang'])) {
        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
        }
    }
    $paramsFromModel = getLanV6Params($serialN);
    if ($paramsFromModel) {

        $prefix = after('/', $paramsFromModel[0]->ip_v6);
        $ip = before('/', $paramsFromModel[0]->ip_v6);


        $connectedDevices = getConnectedDevices($paramsFromModel[0]->device_id,'LAN');

        $params = array("ip_v6" => array("ip_v6", $ip),
            "prefix" => array("prefix", $prefix),
            "dhcp_mode" => array("dhcp_mode", $paramsFromModel[0]->dhcp_mode),
            "dhcp_lease_time" => array("dhcp_lease_time", $paramsFromModel[0]->dhcp_lease_time*60),
            "startIp" => array("MinAddress", $paramsFromModel[0]->min_address),
            "endIP" => array("MaxAddress", $paramsFromModel[0]->max_address),
            "dhcp_enable" => array("dhcp_enable", $paramsFromModel[0]->dhcp_enable),
            "dhcp_enable_pd" => array("dhcp_enable_pd", ($paramsFromModel[0]->dhcp_enable_pd))
        );
    } 

    require_once $_SESSION['APPPATH'].'views/content/admin/lanIpV6PageForDevice.php';
}

if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }


    if (isset($_SESSION['logged_in'])) {

        try{

            define('BASEPATH', $_SESSION['BASEPATH']);

            include $_SESSION['APPPATH'].'models/modelParams.php';
            if(isset($_POST['devStatus'])) {
                $devStatus = $_POST['devStatus'];
            }
            if(isset($_POST['havPermissions'])) {
                $havPer = $_POST['havPermissions'];
            }
            $serialN = $_POST['serialNumber'];
            $devId = $_POST['deviceID'];
            $lanIpType = $_POST['lanIpType'];
            if ($lanIpType == 'ipV4') {
                getLanIpV4TabPage($serialN, $devStatus, $havPer);
            } if($lanIpType=='ipV6') {
                getLanIpV6TabPage($serialN, $devStatus, $havPer);
            }


        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}

