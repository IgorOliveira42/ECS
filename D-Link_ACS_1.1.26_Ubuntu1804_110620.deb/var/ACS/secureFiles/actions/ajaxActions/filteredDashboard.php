<?php
if (isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
    if (isset($_SESSION['logged_in'])) {
        try {
            define('BASEPATH', $_SESSION['BASEPATH']);

            require_once $_SESSION['APPPATH'] . 'models/device.php';
            $dev = new Device();

            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
            }
            $countDev = array();
            $nameModel = array();
            $hwVersionModel = array();
            $model = array();

            $modelName = $_POST['modelName'];

            if ($modelName != '') {
                $allRegDevCount=$_POST['allRegDevCount'];
                $models= $dev->getModelIdByLikeName(trim($modelName));
                if(count($models)>0){
                    $x=0;
                    for ($i = 0; $i < count($models); $i++) {
                        $index = $models[$i]->id;
                        $count = $dev->getDevicesByModels($index);
                        if ($count[0]->count > 0) {
                            $name = $dev->getAllModelsName($index);
                            $countDev[$x] = $count[0]->count;
                            $nameModel[$x] = $name[0]->name;
                            $hwVersionModel[$x] = $name[0]->hw_version;
                            $a = array($nameModel[$x] ." - ". $hwVersionModel[$x] , $countDev[$x]);
                            array_push($model, $a);
                            $x++;
                        }
                    }
//                    $countDev[$x] = $allRegDevCount-$count[0]->count;
//                    $nameModel[$x] = $ini_array['other'];
//                    $hwVersionModel[$x] = '';

                    $resulta = count($countDev);

                    $resultName = count($nameModel);

                } else {
                    $resulta = 0;

                    $resultName = 0;
                }
            } else {
                $models = $dev->getAllModelsId();
                $x=0;
                $modelsCount = $dev->getAllModelsCount();
                for ($i = 0; $i < $modelsCount[0]->count; $i++) {
                    $index = $models[$i]->id;
                    $count = $dev->getDevicesByModels($index);
                    if ($count[0]->count > 0) {
                        $name = $dev->getAllModelsName($index);
                        $countDev[$x] = $count[0]->count;
                        $nameModel[$x] = $name[0]->name;
                        $hwVersionModel[$x] = $name[0]->hw_version;
                        $a = array($nameModel[$x] ." - ". $hwVersionModel[$x] , $countDev[$x]);
                        array_push($model, $a);
                        $x++;
                    }
                }
                $resulta = count($countDev);
                $resultName = count($nameModel);
            }
            $result =  json_encode($model);
            echo $result;
//            include $_SESSION['APPPATH'] . 'views/content/admin/filteredDashboard.php';


        } catch (\Exception $e) {
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}