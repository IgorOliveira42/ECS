<?php


function addSaleChoosedClient($tarifID,$groupId,$clientID, $mac, $modelId, $modelName, $modelHwVersion, $newNameForDB, $size, $fileName)
{
    if(!class_exists("ModelClient")){include $_SESSION['APPPATH'].'models/modelClient.php';}
    if(!class_exists("Device")){include $_SESSION['APPPATH'].'models/device.php';}
    $actionName = '';
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $client = new ModelClient();
    $macExistsCount = $client->checkMacExist($mac);
    $maxExistInDevices = $client->checkMacExistInDevices($mac);
    
    if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {

        $device = new Device();
        $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);
        
        if($model){
            $modelName = '';
        }
        
        $result = $client->addSaleChoosedClient($tarifID,$groupId,$clientID, $mac, $modelId, $modelName,$modelHwVersion, $newNameForDB, $size, $fileName);

        if (!$result) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['clientID'] = $clientID;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actionName = "sale";
        } else {

            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
            $actionName = "clients";
        }
    } else {
        $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
        $_SESSION['clientID'] = $clientID;
        $_SESSION['modelID'] = $modelId;
        $_SESSION['mac'] = $mac;
        $actionName = 'sale';
    }
    return $actionName;
}

function addSale($tarifID,$groupId,$firstName, $surName, $address, $email, $mac, $modelId, $modelName,$modelHwVersion, $newNameForDB, $size, $fileName)
{
    if(!class_exists("ModelClient")){include $_SESSION['APPPATH'].'models/modelClient.php';}
    if(!class_exists("Device")){include $_SESSION['APPPATH'].'models/device.php';}

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $client = new ModelClient();
    if ($email != "") {
        $existsCount = $client->checkEmailExist($email);
        if ($existsCount && $existsCount[0]->status == 1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['email_exist'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName='sale';
        
        }elseif($existsCount && $existsCount[0]->status == 2) {
            
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['email_exist_del_status'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName='sale';
            
        }else {
            $macExistsCount = $client->checkMacExist($mac);
            $maxExistInDevices = $client->checkMacExistInDevices($mac);
            
            if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {
                
                $device = new Device();
                $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);

                if($model){
                    $modelName = '';
                }
                
                $result1 = $client->addSale($tarifID,$groupId,$firstName, $surName, $address, $email, $mac, $modelId, $modelName,$modelHwVersion, $newNameForDB, $size, $fileName);
                
                if (!$result1) {
                    $_SESSION['failed_sale'] = $ini_array['adding_failed'];
                    $_SESSION['firstName'] = $firstName;
                    $_SESSION['surName'] = $surName;
                    $_SESSION['address'] = $address;
                    $_SESSION['email'] = $email;
                    $_SESSION['modelID'] = $modelId;
                    $_SESSION['mac'] = $mac;
                    $actName='sale';
                } else {
                    $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
                    $actName='clients';
                }
            } else {
                $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
                $_SESSION['firstName'] = $firstName;
                $_SESSION['surName'] = $surName;
                $_SESSION['address'] = $address;
                $_SESSION['email'] = $email;
                $_SESSION['modelID'] = $modelId;
                $_SESSION['mac'] = $mac;
                $actName='sale';
            }
        } 
    } else {
        $macExistsCount = $client->checkMacExist($mac);
        $maxExistInDevices = $client->checkMacExistInDevices($mac);
        
        if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {
            
            $device = new Device();
            $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);

            if($model){
                $modelName = '';
            }
            
            $result1 = $client->addSale($tarifID,$groupId,$firstName, $surName, $address, $email, $mac, $modelId, $modelName, $modelHwVersion, $newNameForDB, $size, $fileName);
            
            if (!$result1) {
                $_SESSION['failed_sale'] = $ini_array['adding_failed'];
                $_SESSION['firstName'] = $firstName;
                $_SESSION['surName'] = $surName;
                $_SESSION['address'] = $address;
                $_SESSION['email'] = $email;
                $_SESSION['modelID'] = $modelId;
                $_SESSION['mac'] = $mac;
                $actName='sale';
            } else {
                $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
                $actName='clients';
            }
        } else {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName='sale';
        }
    }
    return $actName;
}

function addWlan($pass , $con_type, $mac, $connectionName)
{
    if(!class_exists("ModelClient")){include $_SESSION['APPPATH'].'models/modelClient.php';}
    
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $client = new ModelClient();
    
    $ifExist = $client->checkConnTypeExist($mac, $con_type);
    
    if($ifExist){
        $result1 = $client->editWlan_model($pass, $con_type, $mac, $connectionName);
        
        if (!$result1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['passName'] = $pass;
            $_SESSION['mac'] = $mac;
            $_SESSION['con_type'] = $con_type;
            $_SESSION['connection_name'] = $connectionName;
            $actName = 'sale';

        } else {
            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
    //                    $actName='clients';
        }
    }else {
        $result1 = $client->addWlan_model($pass , $con_type, $mac, $connectionName);
    
        if (!$result1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['passName'] = $pass;
            $_SESSION['mac'] = $mac;
            $_SESSION['con_type'] = $con_type;
            $_SESSION['connection_name'] = $connectionName;
            $actName = 'sale';

        } else {
            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
    //                    $actName='clients';
        }
    }
    
    return $result1;
}

function addLoginPass($login, $pass , $con_type, $mac, $connectionName) {
    if(!class_exists("ModelClient")){include $_SESSION['APPPATH'].'models/modelClient.php';}
    
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }
    
    $client = new ModelClient();
    
    $ifExist = $client->checkConnTypeExist($mac, $con_type);
    
    if($ifExist){
        $result1 = $client->editLoginPass_model($login, $pass, $con_type, $mac, $connectionName);
        
        if (!$result1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['userName'] = $login;
            $_SESSION['passName'] = $pass;
            $_SESSION['mac'] = $mac;
            $_SESSION['con_type'] = $con_type;
            $_SESSION[connection_name] = $connectionName;
            $actName='sale';
        } else {
            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
    //                    $actName='clients';
        }
    } else {
        
        $result1 = $client->addLoginPass_model($login, $pass , $con_type, $mac, $connectionName);
    
        if (!$result1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['userName'] = $login;
            $_SESSION['passName'] = $pass;
            $_SESSION['mac'] = $mac;
            $_SESSION['con_type'] = $con_type;
            $_SESSION[connection_name] = $connectionName;
            $actName='sale';
        } else {
            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
    //                    $actName='clients';
        }
    }
    
    
    return $result1;
}

function addSaleChoosedClientWithoutConfig($tarifID,$groupId,$clientID, $mac, $modelId, $modelName,$modelHwVersion){

    if(!class_exists("ModelClient")){include $_SESSION['APPPATH'].'models/modelClient.php';}
    if(!class_exists("Device")){include $_SESSION['APPPATH'].'models/device.php';}

    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $client = new ModelClient();
    $macExistsCount = $client->checkMacExist($mac);
    $maxExistInDevices = $client->checkMacExistInDevices($mac);

    if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {

        $device = new Device();
        $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);
        
        if($model){
            $modelName = '';
        }
        
        $result = $client->addSaleChoosedClientWithouthConfig($tarifID,$groupId,$clientID, $mac, $modelId, $modelName,$modelHwVersion);

        if (!$result) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'];
            $_SESSION['clientID'] = $clientID;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName='sale';
        } else {

            $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
            $actName='clients';
        }
    } else {
        $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
        $_SESSION['clientID'] = $clientID;
        $_SESSION['modelID'] = $modelId;
        $_SESSION['mac'] = $mac;
        $actName='sale';
    }
    return $actName;
}


function addSaleWithoutConfig($tarifID,$groupId,$firstName, $surName, $patronymicName, $contractNumber, $address, $email, $mac, $modelId, $modelName, $modelHwVersion){

    if(!class_exists("ModelClient")){ include $_SESSION['APPPATH'].'models/modelClient.php'; }
    if(!class_exists("Device")){include $_SESSION['APPPATH'].'models/device.php';}
    
    $actName = '';
    $lang = $_SESSION['lang'];
    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    $client = new ModelClient();
    if ($email != "") {
        $existsCount = $client->checkEmailExist($email);
        if ($existsCount && $existsCount[0]->status == 1) {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['email_exist'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['address'] = $address;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName ='sale';
        
        }elseif($existsCount && $existsCount[0]->status == 2) {
            
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['email_exist_del_status'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName = 'sale';
            
        }else {
            
            $macExistsCount = $client->checkMacExist($mac);
            $maxExistInDevices = $client->checkMacExistInDevices($mac);
            
            if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {
                
                $device = new Device();
                $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);

                if($model){
                    $modelName = '';
                }
                
                $result1 = $client->addSaleWithoutConfig($tarifID,$groupId,$firstName, $surName, $patronymicName, $contractNumber, $address, $email, $mac, $modelId, $modelName,$modelHwVersion);
                
                if (!$result1) {
                    $_SESSION['failed_sale'] = $ini_array['adding_failed'];
                    $_SESSION['firstName'] = $firstName;
                    $_SESSION['surName'] = $surName;
                    $_SESSION['patronymicName'] = $patronymicName;
                    $_SESSION['contractNumber'] = $contractNumber;
                    $_SESSION['address'] = $address;
                    $_SESSION['email'] = $email;
                    $_SESSION['modelID'] = $modelId;
                    $_SESSION['mac'] = $mac;
                    $actName='sale';
                } else {
                    $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
                    $actName='clients';
                }
            } else {
                $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
                $_SESSION['firstName'] = $firstName;
                $_SESSION['surName'] = $surName;
                $_SESSION['address'] = $address;
                $_SESSION['patronymicName'] = $patronymicName;
                $_SESSION['contractNumber'] = $contractNumber;
                $_SESSION['email'] = $email;
                $_SESSION['modelID'] = $modelId;
                $_SESSION['mac'] = $mac;
                $actName='sale';
            }
        } 
    } else {
        $macExistsCount = $client->checkMacExist($mac);
        $maxExistInDevices = $client->checkMacExistInDevices($mac);
        
        if ($macExistsCount[0]->count == 0 && $maxExistInDevices[0]->count == 0) {
            
            $device = new Device();
            $model = $device->getModelByNameAndHWVersion($modelName,$modelHwVersion);

            if($model){
                $modelName = '';
            }
            
            $result1 = $client->addSaleWithoutConfig($tarifID,$groupId,$firstName, $surName, $patronymicName, $contractNumber, $address, $email, $mac, $modelId, $modelName,$modelHwVersion);
            
            if (!$result1) {
                $_SESSION['failed_sale'] = $ini_array['adding_failed'];
                $_SESSION['firstName'] = $firstName;
                $_SESSION['surName'] = $surName;
                $_SESSION['patronymicName'] = $patronymicName;
                $_SESSION['contractNumber'] = $contractNumber;
                $_SESSION['address'] = $address;
                $_SESSION['email'] = $email;
                $_SESSION['modelID'] = $modelId;
                $_SESSION['mac'] = $mac;
                $actName='sale';
            } else {
                $_SESSION['sale_succeed'] = $ini_array['sale_succeed'];
                $actName='clients';
            }
        } else {
            $_SESSION['failed_sale'] = $ini_array['adding_failed'] . '. ' . $ini_array['mac_exist'];
            $_SESSION['firstName'] = $firstName;
            $_SESSION['surName'] = $surName;
            $_SESSION['patronymicName'] = $patronymicName;
            $_SESSION['contractNumber'] = $contractNumber;
            $_SESSION['address'] = $address;
            $_SESSION['email'] = $email;
            $_SESSION['modelID'] = $modelId;
            $_SESSION['mac'] = $mac;
            $actName='sale';
        }
    }
    return $actName;
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') { session_start(); }
    
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            if (isset($_POST['actionName']) && $_POST['actionName'] == "checkConnection") {
                if (!class_exists("ModelClient")) {
                    include $_SESSION['APPPATH'] . 'models/modelClient.php';
                }
                    $mac = $_POST['mac'];
                    $con_type = $_POST['con_type'];
                    $client = new ModelClient();
                    $ifExist = $client->checkConnTypeExist($mac, $con_type);
                    if ($ifExist) {
                        echo 1;
                        return false;
                    }
            }
            $DIRECTORY_SEPARATOR = '/';
            define('BASEPATH', $_SESSION['BASEPATH']);
            $lang = $_SESSION['lang'];

            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }
            $addOrChoose = '';

            if(isset($_POST['addOrChoose'])){
                $addOrChoose = $_POST['addOrChoose'];
            }

            $pptp = '';
            $newModelName = '';
            $modelHwVersion = '';
            $modelId = 0;
            $groupId = 0;
            $modelName = '';
            $mac = $_POST['mac'];
            $userName = '';
            $password = '';
            $newNameForDB = '';
            $size = 0;
            $fileName = '';

            if (isset($_POST['forCheckPptp'])) {
                $pptp = $_POST['forCheckPptp'];
            } else {
                $pptp = '';
            }

            if (isset($_POST['tarifId'])) {
                $tarifID = $_POST['tarifId'];
            } else {
                $tarifID = 0;
            }

            if (isset($_POST['newModel'])) {
                $newModelName = $_POST['newModel'];
            } else {
                $newModelName = '';
            }

            if (isset($_POST['hwVersion'])) {
                $modelHwVersion = $_POST['hwVersion'];
            } else {
                $modelHwVersion = '';
            }

            if (isset($_POST['modelId'])) {
                $modelId = $_POST['modelId'];
            } else {
                $modelId = '';
            }

            if(isset($_POST['groupId'])){
                $groupId = $_POST['groupId'];
            }



            if ($mac != "") {
                //start upload
                if ($newModelName == '') {
                    include $_SESSION['APPPATH'].'models/device.php';
                    $devv = new Device();
                    $modd = $devv->getModelNameByID($modelId);
                    if($modd){
                        $modelName = $modd[0]->name;
                        $modelHwVersion = $modd[0]->hw_version;
                    }

                } else {
                    $modelName = $newModelName;
                }
            } else  if ($addOrChoose == 'choose') {
                $clientID = $_POST['clientID'];
                $_SESSION['failed_sale'] = $ini_array['mac_required_fields'];

            } else {
                if(isset($_POST['login'])){
                    $firstName = $_POST['login'];
                }
                if(isset($_POST['surName'])){
                    $surName = $_POST['surName'];
                }
                if(isset($_POST['address'])){
                    $address = $_POST['address'];
                }
                if(isset($_POST['email'])){
                    $email = $_POST['email'];
                }

                $_SESSION['failed_sale'] = $ini_array['mac_required_fields'];
            }

            $hasPPPTP = false;
            if ($pptp != '') {
                $hasPPPTP = true;
                $userName = $_POST['username'];
                $password = $_POST['password'];

            } else {
                $userName = '';
                $password = '';
            }

            if($hasPPPTP){
                if ((!empty($_FILES["prototype_file"])) && ($_FILES['prototype_file']['error'] == 0)) {
                    $fileName = basename($_FILES['prototype_file']['name']);
                    $allPath = $_SESSION['REALPATH']. "personal_config" . $DIRECTORY_SEPARATOR . $modelName;
                    $newFile = $allPath . $DIRECTORY_SEPARATOR . $fileName;
                    if (!is_dir($allPath)) {
                        mkdir($allPath, 0777, true);
                    } else {
                        $it = new RecursiveDirectoryIterator($allPath);
                        $files = new RecursiveIteratorIterator($it, RecursiveIteratorIterator::CHILD_FIRST);
                        foreach ($files as $file) {
                            if ($file->getFilename() === '.' || $file->getFilename() === '..') {
                                continue;
                            }
                            if ($file->isDir()) {
                            } else {
                                unlink($file->getRealPath());
                            }
                        }
                    }

                    if ((move_uploaded_file($_FILES['prototype_file']['tmp_name'], $newFile))) {
                        //zip
                        chmod($newFile, 0666);
                        $handle = fopen($newFile, 'r');
                        $configJson = $_SESSION['APPPATH']."actions/tmp/etc/default/config.json";

                        if(!file_exists($configJson)){
                            touch($configJson);
                        }

                        chmod($configJson, 0777);
                        $handle1 = fopen($_SESSION['APPPATH']."actions/tmp/etc/default/config.json", 'w');
                        if ($handle === false) {
                            echo "ERROR";
                        }
                        $flag = 0;
                        while (!feof($handle)) {
                            $buffer = fgets($handle);
                            if (strstr($buffer, "\"password") && $flag == 0) {
                                $str = sprintf("      \"password\": \"%s\",", $password) . "\n";
                                fwrite($handle1, $str);
                            } else if (strstr($buffer, "\"username") && $flag == 0) {
                                $str = sprintf("      \"username\": \"%s\",", $userName) . "\n";
                                fwrite($handle1, $str);
                                $flag = 1;
                            } else {
                                fwrite($handle1, $buffer);
                            }
                        }
                        $forZip = $_SESSION['REALPATH'] . $DIRECTORY_SEPARATOR . $mac . ".tar.gz";
                        system("tar -zcvf $forZip tmp", $result);
                        //end zip

                        include $_SESSION['APPPATH'] . 'models/modelUser.php';
                        $user = new ModelUser();
                        $ip = $user->getIp()[0];
                        $port = $user->getPort()[0];
                        $newNameForDB = "http://" . $ip->settings_value . ":" . $port->settings_value . '/' . $mac . ".tar.gz";
                        $size = filesize($forZip);

                    } else {
                        $_SESSION['failed_sale'] = $ini_array['upload_failed'] . ' ' . $_FILES['prototype_file']['error'];
                    }
                } else {
                    $_SESSION['failed_sale'] = $ini_array['config_prototype'];
                }
            }



            if ($addOrChoose == 'choose') {
                if(isset($_POST['clientID'])){
                    $clientID = $_POST['clientID'];
                }else {
                    $clientID = '';
                }


                if ($clientID == '') {
                    $_SESSION['failed_sale'] = $ini_array['select_client'];

                } else {
                    if($hasPPPTP){
                        $resSale = addSaleChoosedClient($tarifID,$groupId,$clientID, $mac, $modelId, $modelName, $modelHwVersion, $newNameForDB, $size, $fileName);
        //                header("Location: /index.php?controlName=$resSale");
                        header( 'Location: '.BASEPATH.$resSale );
                        exit(); 

                    }else {
                        $resSale = addSaleChoosedClientWithoutConfig($tarifID,$groupId,$clientID, $mac, $modelId, $modelName, $modelHwVersion);
        //                header("Location: /index.php?controlName=$resSale");
                        header( 'Location: '.BASEPATH.$resSale );
                        exit(); 
                    }
                }

            } else {
                if(isset($_POST['firstName'])){
                    $firstName = $_POST['firstName'];
                }
                if(isset($_POST['surName'])){
                    $surName = $_POST['surName'];
                }
                if(isset($_POST['patronymicName'])){
                    $patronymicName = $_POST['patronymicName'];
                }
                if(isset($_POST['contractNumber'])){
                    $contractNumber = $_POST['contractNumber'];
                }
                if(isset($_POST['address'])){
                    $address = $_POST['address'];
                }
                if(isset($_POST['email'])){
                    $email = $_POST['email'];
                }

                if(isset($_POST['ssid'])){
                    $ssid = $_POST['ssid'];
                }else {
                    $ssid = '';
                }

                if(isset($_POST['login'])){
                    $login = $_POST['login'];
                }else {
                    $login = '';
                }

                if(isset($_POST['pass'])){
                    $pass =  $_POST['pass'];
                }else{
                    $pass = '';
                }

                if(isset($_POST['con_type'])){
                    $con_type = $_POST['con_type'];
                }else{
                    $con_type = '';
                }

                if(isset($_POST['connection_name'])){
                    $connectionName = $_POST['connection_name'];
                }else{
                    $connectionName = '';
                }

                if(isset($_POST['email'])){
                    $email = $_POST['email'];
                }else{
                    $email = '';
                }

                if(isset($_POST['contractNumber'])){
                    $contractNumber = $_POST['contractNumber'];
                }else{
                    $contractNumber = '';
                }


//                if(isset($_POST['newSsidName']) && isset($_POST['passNewSSIDName'])){
//                    $resSale = addWlan($_POST['passNewSSIDName'], 6, $mac, $_POST['newSsidName'])
//                    ?>
<!--                    --><?php
//
//                    if (is_array($resSale)) {
//                        echo "true";
//                    } else {
//                        echo "false";
//                    }
//                    //                    $_SESSION['addPassStatus'] = $resSale;
//                    return;
//                }

                if($ssid != "" && $pass != ""){
                    $resSale = addWlan($pass, $con_type, $mac, $ssid)
                        ?>
                        <?php

                        if (is_array($resSale)) {
                            echo 'true';
                        } else {
                            echo "false";
                        }
        //                    $_SESSION['addPassStatus'] = $resSale;
                        return;
                }

                if($login != "" && $pass != "") {
                    $resSale = addLoginPass($login, $pass , $con_type, $mac, $connectionName)
                            ?>
                            <?php
        //                    $_SESSION['addPassStatus'] = $resSale;
                            if (is_array($resSale)) {
                                echo "true";
                            } else {
                                echo "false";
                            }
                            return;
                }


                if ($firstName != "" && $surName != "") {
                    if ($email != "") {
                        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            if($hasPPPTP){
                              $resSale = addSale($tarifID,$groupId,$firstName, $surName, $address, $email, $mac, $modelId, $modelName, $modelHwVersion, $newNameForDB, $size, $fileName);
        //                        header("Location: /index.php?controlName=$resSale");
                                header( 'Location: '.BASEPATH.$resSale );
                                exit();

                            } else {
                               $resSale = addSaleWithoutConfig($tarifID,$groupId,$firstName, $surName, $patronymicName, $contractNumber, $address, $email, $mac, $modelId, $modelName, $modelHwVersion);
        //                       header("Location: /index.php?controlName=$resSale");
                                header( 'Location: '.BASEPATH.$resSale );
                                exit();  

                            }
                        } else {
                            $_SESSION['failed_sale'] = $ini_array['invalid_email'];
        //                    header("Location: /index.php");
                            header( 'Location: '.BASEPATH);
                            exit();
                        }
                    } else {
                        if($hasPPPTP){
                          $resSale = addSale($tarifID,$groupId,$firstName, $surName, $address, $email, $mac, $modelId, $modelName, $modelHwVersion, $newNameForDB, $size, $fileName);
        //                    header("Location: /index.php?controlName=$resSale");
                            header( 'Location: '.BASEPATH.$resSale );
                            exit(); 

                        } else {
                         $resSale = addSaleWithoutConfig($tarifID,$groupId,$firstName, $surName, $patronymicName, $contractNumber, $address, $email, $mac, $modelId, $modelName, $modelHwVersion);
        //                    header("Location: /index.php?controlName=$resSale");
                            header( 'Location: '.BASEPATH.$resSale );
                            exit();    
                        }
                    }
                } else {
                    $_SESSION['failed_sale'] = $ini_array['sale_required_fields'];

                }
            }
    }catch (\Exception $e){
        error_log($e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        header("Status: 500 Internal Server Error");
        exit();
    } 
    } else {
    //    header("Location: /index.php?controlName=login");
        header( 'Location: '.BASEPATH.'login' );
        exit(); 
    }

} else {
    exit('No direct script access allowed');
}
