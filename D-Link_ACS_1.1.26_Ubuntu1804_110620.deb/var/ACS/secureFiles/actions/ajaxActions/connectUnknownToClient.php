<?php
if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            $clientID = $_POST['clientID'];
            $devID = $_POST['devID'];
            $tarifID = $_POST['templateID'];
            $groupID = $_POST['groupID'];
            include $_SESSION['APPPATH'].'models/modelClient.php';
            $client = new ModelClient();
            if(is_array($devID)) {
                $update = $client->connectUnknownToClientByGroups($devID, $clientID, $tarifID, $groupID);
            } else {
                $update = $client->connectUnknownToClient($devID, $clientID, $tarifID, $groupID);

            }

            if ($update) {
                echo 'true';
            } else {
                echo 'false';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}



