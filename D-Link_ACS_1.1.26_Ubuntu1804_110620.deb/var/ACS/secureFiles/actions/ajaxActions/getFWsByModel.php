<?php
function deviceFWsByModel($modelID,$dev){
    
    $fws = $dev->getDeviceFWsByModel($modelID);
    $deviceIDList = $dev->getDevicesIdByModel($modelID);
    $filtredFws = array();
    for($i = 0; $i < count($fws); $i++){
        $fullPath =  parse_url($fws[$i]->firmware_path);
       // $filePath = realpath(getcwd() . '/../../..' . $fullPath['path']);
        $filePath = realpath(getcwd() . '/../../..' . str_replace('%20', ' ', $fullPath['path']));
        if (file_exists($filePath)) {
            array_push($filtredFws, $fws[$i]);
        }
    }
    unset($_SESSION['groupDevicesList']);
    $_SESSION['groupDevicesList'] = $deviceIDList;
    require_once $_SESSION['APPPATH'].'views/content/admin/update_fw_group.php';
}

function getFWsByModel($modelID,$forFWFilter,$dev,$groupId){
    $firmwares = $dev->getFirmwaresVersionByModel($modelID,$groupId);
    
    if($forFWFilter){
        $data = '';
        if (is_array($firmwares) && !empty($firmwares)) {
            foreach ($firmwares as $fw) {
               $data .= '<option value="'. $fw->firmware .'">'. $fw->firmware .'</option>';
            } 
        } 

        echo $data;
    }else {
        require_once $_SESSION['APPPATH'].'views/content/admin/update_fw_group_by_FWversion.php';
    }
    
}

if(isset($_POST['fromApp'])){
    if (session_id() == '') {session_start();}
//    if(isset($_COOKIE['timeOut'])){
//        if (isset($_COOKIE['LAST_ACTIVITY']) && (time() - $_COOKIE['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//            echo "logged_out";
//            exit();
//        }
//    }
    
    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            require_once $_SESSION['APPPATH'].'models/device.php';
            $dev = new Device();

            $modelID = $_POST['modelID'];
            $groupId =  isset($_POST['groupId']) ? $_POST['groupId'] : '';
            $getFirmware = $_POST['getFirmware'];
            $forFWFilter = isset($_POST['forFWFilter']) ? $_POST['forFWFilter'] : FALSE;
            
            if($getFirmware == 'true'){
                deviceFWsByModel($modelID,$dev);
            }elseif ($getFirmware == 'false') {
                getFWsByModel($modelID,$forFWFilter,$dev,$groupId);
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        } 
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}