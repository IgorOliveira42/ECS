<?php
if(isset($_POST['fromApp'])){
    if (session_id() == ''){session_start();}

    $lang = $_SESSION['lang'];

    if ($lang == 'en') {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
    } else {
        $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
    }

    if (isset($_SESSION['logged_in'])) {
        try{
            define('BASEPATH', $_SESSION['BASEPATH']);
            include $_SESSION['APPPATH'].'models/fwConfigFile.php';

            include $_SESSION['APPPATH'] . 'models/modelTemplates.php';
            $modelTempl = new ModelTemplates();
            $id=$_POST['tarifID'];
            $tarifName = $_POST['tarifName'];
            $tarifDesc = $_POST['description'];
            $DIRECTORY_SEPARATOR = "/";
            $foldername = $_SESSION['REALPATH'] . '/tarif';
            if(!is_dir($foldername)){mkdir($foldername, 0777, true);}

            $oldPath = '';
            $templ = $modelTempl->getTemplateById($id);
            $oldPath = $templ[0]->path;
            if(file_exists($oldPath)) {
                if ($tarifName !== 'null') {
                    $fileName = $foldername . $DIRECTORY_SEPARATOR . $tarifName . '.ini';
                } else {
                    $fileName = $oldPath;
                }

                if ($tarifDesc !== 'null') {
                    $res = $modelTempl->updateTarifById($id, $tarifName, $fileName, $tarifDesc);
                    if ($tarifName !== 'null') {
                        unlink($oldPath);
                    }
                }
                $content = '';
                if ($tarifName !== 'null') {
                    if (!rename($oldPath, $fileName)) {
                        return false;
                    }

                    $res = $modelTempl->updateTarifById($id, $tarifName, $fileName, $tarifDesc);
                }
            } else {
                echo 'false';
            }
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }
} else {
    exit('No direct script access allowed');
}