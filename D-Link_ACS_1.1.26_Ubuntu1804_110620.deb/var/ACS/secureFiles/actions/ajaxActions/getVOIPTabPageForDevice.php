<?php

if(isset($_POST['fromApp'])) {
    if (session_id() == '') {
        session_start();
    }

    function devInfoByID($deviceID,$dev)
    {
        $device = $dev->devInfoByID($deviceID);

        return $device;
    }

    function getVoipParamsforEdit($deviceSerial, $voipnumIndex)
    {
        include_once $_SESSION['APPPATH'].'models/modelParams.php';
        $modParams = new ModelParams();
        $params = $modParams->getVoipParamsforEdit($deviceSerial, $voipnumIndex);
        return $params;
    }

    function getVoipParams($deviceSerial)
    {
        include_once $_SESSION['APPPATH'].'models/modelParams.php';
        $modParams = new ModelParams();
        $params = $modParams->getVoipParams($deviceSerial);
        return $params;
    }

    function getVoipLineParams($deviceSerial, $voipnumIndex)
    {
        include_once $_SESSION['APPPATH'].'models/modelParams.php';
        $modParams = new ModelParams();
        $params = $modParams->getVoipLineParams($deviceSerial, $voipnumIndex);
        return array_reverse($params);
    }


    if (isset($_SESSION['logged_in'])) {
        define('BASEPATH', $_SESSION['BASEPATH']);


        $lang = $_SESSION['lang'];
        if ($lang == 'en') {
            $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
        } else {
            $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
        }


//        $_SESSION['activeWanTab'] = $actionName;
        try{
            $editVoip = 1;
            $deviceStatus = $_POST['devStatus'];
            $isRunningRefresh = 'false';
            $havePerms = $_POST['havPermissions'];
            $deviceID = $_POST['deviceID'];
            $serialN = $_POST['serialNumber'];
            $voipnumIndex = $_POST['voipnumIndex'];
            require_once $_SESSION['APPPATH'] . 'models/device.php';
            $dev = new Device();
            $device = devInfoByID($deviceID, $dev);
            $voipParams = getVoipParams($serialN);
            $voipParamsforEdit = getVoipParamsforEdit($serialN, $voipnumIndex);
            $voipLineParamsArray = getVoipLineParams($serialN, $voipnumIndex);
            require_once $_SESSION['APPPATH'].'views/content/admin/voipPageForDevice.php';
        }catch (\Exception $e){
            error_log($e->getMessage());
            header('HTTP/1.1 500 Internal Server Error');
            header("Status: 500 Internal Server Error");
            exit();
        }
    } else {
        $result = "logged_out";
        echo $result;
    }

} else {
    exit('No direct script access allowed');
}
?>