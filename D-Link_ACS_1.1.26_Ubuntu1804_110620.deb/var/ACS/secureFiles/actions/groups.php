<?php

function getAllGroups(){
    require_once $_SESSION['APPPATH'].'models/device.php';
    require_once $_SESSION['APPPATH'].'util/paging.php';
    require_once  $_SESSION['APPPATH'].'models/modelTemplates.php';
    $permissionsArray = array();
    if (isset($_SESSION['permissions'])) {
        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
        $permissionsArray = $_SESSION['permissions'];
        $groupID = $_SESSION['group_id'];
    }
    $page = 1;
    $limit = 5;
    $offset = ($page - 1) * $limit;

    $dev = new Device();
    if($groupID == 'Group manager' || $groupID == 'Group Viewer') {
        $groups = $dev->getGroupsOfUser($_SESSION['userID'], $limit, $offset);
//        $allGroupsArray = $dev->getAllGroups();

        $devCount = count($groups);
        $ungrouped = $dev->getUnGroupsOfUser($_SESSION['userID'], $limit, $offset);

//        $pagesCount = 1;
    } else {
        $groups = $dev->getGroups($limit, $offset);
        $ungrouped =  $dev->getUnGrouped($limit, $offset);
        $allGroupsArray = $dev->getAllGroups();

        $devCount = count($allGroupsArray);

    }
    $pagesCount = Paging::getPagesCount($devCount,$limit);
    $templ = new ModelTemplates();
    $allTemplates = $templ->getAllTemplates();

    include $_SESSION['APPPATH'].'views/tiles/admin/groups_view.php';
}
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        getAllGroups();
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}