<?php
if (session_id() == '') {
    session_start();
}
if (isset($_SESSION['logged_in'])) {
    try{
        require_once $_SESSION['APPPATH'].'util/pagingConstants.php';

        $page = 1;
        $limit = PagingConstants::$activityCount;
        $offset = ($page - 1) * $limit;

        $user = new ModelUser();
//        $grous = $user->getGroups();
//        $groupFromUserGroup = $user->getGroupsFromUserGroup();
        $adminGroupCount = $user->getAdminGroupsCount()[0]->count;
        $usersGroups = $user->getAllUsersGroupsByPage($limit, $offset);

        for($i=0;$i<count($usersGroups);$i++){
            $permissionsList=$user->getPermissionsByGroupId($usersGroups[$i]->id);
            if(!$permissionsList){
                $permissionsList=array();
            }
            $usersGroups[$i] = (object) array_merge((array)$usersGroups[$i], array( 'permissionsList' => $permissionsList));
        }

        $allUsersGroupsCount = $user->getAllUsersGroupsCount();

        $usersGroupsCount = $allUsersGroupsCount[0]->count;

        require_once $_SESSION['APPPATH'].'util/paging.php';

        $pagesCount = Paging::getPagesCount($usersGroupsCount,$limit);

        require_once $_SESSION['APPPATH'].'views/tiles/admin/users_groups_view.php';
    } catch (\Exception $e) {
        throw new \Exception($e);
    }
} else {
    require_once 'secureFiles/actions/login.php';
}
