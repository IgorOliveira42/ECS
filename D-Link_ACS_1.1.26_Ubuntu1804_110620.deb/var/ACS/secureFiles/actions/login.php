<?php
if (version_compare(phpversion(), '5.4.0', '<')) {
     if(session_id() == '') {
        session_start();
     }
 }else {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
 }

if(!isset($_SESSION['BASEPATH'])){
    $site_url = '';
    if (isset($_SERVER['HTTP_HOST'])) {
        $site_url = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ? 'https' : 'http';
        $site_url .= '://' . $_SERVER['HTTP_HOST'];
        $site_url .= str_replace('secureFiles/actions/'.basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    } else {
        $site_url = 'http://localhost/'.str_replace('secureFiles/actions/'.basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);;
    }
    $_SESSION['BASEPATH'] = $site_url;
//    define('BASEPATH', $_SESSION['BASEPATH']);
    if(!defined('BASEPATH')){define('BASEPATH', $_SESSION['BASEPATH']);}
}

$_SESSION['APPPATH'] = dirname(__FILE__) . "/../";
if(!defined('BASEPATH')){define('BASEPATH', $_SESSION['BASEPATH']);}

try{
    if(isset($_POST['login']) && isset($_POST['password'])){

        require_once $_SESSION['APPPATH']."models/modelUser.php";
        require_once $_SESSION['APPPATH']."util/usersConstants.php";

        $username = $_POST['login'];
        $password = $_POST['password'];
        if ($username != '' && $password != "") {
            $user = new ModelUser();
            $result = $user->login($username, $password);
            if ($result) {
                $userStatus = $result[0]->status;
                if(trim($userStatus) == UsersConstants::$activeStatus){
//                    shell_exec('find '.getcwd().'/session -name sess_* -cmin +11520 | xargs -i rm {}');
                    $_SESSION['logged_in'] = $username;
                    $userSettings = array('loggedIn'=>true);
                    $userSettings['checkDevicesStatus'] = getUserSettings($username, 'checkDevicesStatus', false);
                    $userSettings['SlaStatus'] = getUserSettings($username, 'SlaStatus', '');
                    $userSettings['rowCount'] = getUserSettings($username, 'rowCount', 10);
                    $userSettings['rowCountFile'] = getUserSettings($username, 'rowCountFile', 10);
                    $columns = array('n' => 1, 'sN' => 1,'mF' => 1,'port' => 1,/*'ip' => 1,'mN' => 1,*/'mac' => 0, 'clientName' => 0, 'dI' => 1);
                    $columnsFile = array('n' => 1, 'fN' => 1, 'sN' => 1, 'modN' => 1, 'fSize' => 1,'type'=>1);
                    $userSettings['devicesTableColumns'] = getUserSettings($username, 'devicesTableColumns', $columns);
                    $userSettings['filesTableColumns'] = getUserSettings($username, 'filesTableColumns', $columnsFile);
                    $actFilter = array('mac' => 0, 'model' => 0, 'task' => 0, 'status' => -1, 'createTime' => '', 'selectTime' => 0);
                    $filFilter = array('mac' => 0, 'model' => 0, 'type' => 0);
                    $userSettings['activityFilter'] = getUserSettings($username, 'activityFilter', $actFilter);
                    $userSettings['fileFilter'] = getUserSettings($username, 'fileFilter', $filFilter);

                    $group = $user->getUserGroupById($result[0]->group_id);
//                    if (isset($_SESSION['lang'])) {
                        if($group[0]->default_language == "en"){
                            //$_SESSION['lang'] = "en";
                            $_COOKIE['lang'] = "en";
                            $_SESSION['lang'] = $_COOKIE['lang'];
                        }elseif ($group[0]->default_language == "ru") {
                            //$_SESSION['lang'] = "ru";
                            $_COOKIE['lang'] = "ru";
                            $_SESSION['lang'] = $_COOKIE['lang'];
                        }elseif (!$group[0]->default_language) {
                            //$_SESSION['lang'] = "en";
                            $_COOKIE['lang'] = "en";
                            $_SESSION['lang'] = $_COOKIE['lang'];
                        }
//                    }

                    if($group[0]->time_out != NULL && $group[0]->time_out != '0'){
                        $timeOut = $group[0]->time_out;
                        $userSettings['timeOut'] = getUserSettings($username, 'timeOut', $timeOut);
//                        $_SESSION['timeOut'] = $timeOut;
                        setcookie('timeOut', $timeOut, time() + (86400 * 7),'/');
                        setcookie('loggedInUser', $username, time() + $timeOut,'/');
                        setcookie($username, json_encode($userSettings), time() + (86400 * 7),'/');
                    }else {
                        setcookie('loggedInUser', $username, time() + (86400 * 7),'/');
                        setcookie($username, json_encode($userSettings), time() + (86400 * 7),'/');
                    }
                    
                    $permissionsArray = array();
                    $user = new ModelUser();
    //                $username = $_SESSION['logged_in'];
                    $permissions = $user->getPermissionsByUsername($username);
                    if($permissions){
                        for($ii = 0; $ii < count($permissions); $ii++){
                            $permissionsArray[] = $permissions[$ii]->name;
                        }
                    }
                    $_SESSION['permissions'] = $permissionsArray;

                    if(!class_exists('UsersConstants')){require_once $_SESSION['APPPATH']."util/usersConstants.php";}
                    $permissionsArray = $_SESSION['permissions'];

                    if(count($permissionsArray) > 0){
                        if(in_array(UsersConstants::$devicePermission,$permissionsArray) || in_array(UsersConstants::$monitoring,$permissionsArray)){
                                header( 'Location: '.BASEPATH.'forDevices' );  die();

                        } else if(in_array(UsersConstants::$clientPermission,$permissionsArray)){ 
                                header( 'Location: '.BASEPATH.'clients' );  die();

                        } else if(in_array(UsersConstants::$groupPermission,$permissionsArray)){ 
                                header( 'Location: '.BASEPATH.'groups' );  die();

                        } else if(in_array(UsersConstants::$userPermission,$permissionsArray)){ 
                                header( 'Location: '.BASEPATH.'users' );  die();
                        }
                    } else {  
                        header( 'Location: '.BASEPATH.'unknownUserType' );  die();
                    } 
                } else {
                    $_SESSION['invalid_msg'] = 'user_deleted'; 
                    require_once  $_SESSION['APPPATH'].'views/tiles/login_view.php';
                }
            } else {
                $_SESSION['invalid_msg'] = 'msg'; 
                require_once  $_SESSION['APPPATH'].'views/tiles/login_view.php';

            }
        } else {
            $_SESSION['invalid_msg'] = 'user_pass_required';
            require_once  $_SESSION['APPPATH'].'views/tiles/login_view.php';
        }  

    }else{
        require_once  $_SESSION['APPPATH'].'views/tiles/login_view.php';
    }
} catch (\Exception $e) {
    error_log($e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    header("Status: 500 Internal Server Error");
    require_once 'secureFiles/views/content/admin/error500.php';
    exit();
}

function getUserSettings($username,$property,$value){
    $cookieNmae = str_replace(".", "_", $_SESSION['logged_in']);
    if(isset($_COOKIE[$cookieNmae])){
        $userDefaultSettings = json_decode($_COOKIE[$cookieNmae]);
        if(!property_exists($userDefaultSettings, $property)){
            $property = $value;
        }else {
            $property = $userDefaultSettings->$property;
        }
    }else {
        $property = $value;
    }
    
    return $property;
}
