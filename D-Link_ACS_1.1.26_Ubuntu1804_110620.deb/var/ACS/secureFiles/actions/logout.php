<?php
if (session_id() == '') {
    session_start();
}

if(!isset($_SESSION['BASEPATH'])){
    if (session_id() == '') {
        session_start();
    }
    $site_url='';
    if (isset($_SERVER['HTTP_HOST'])) {
        $site_url = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ? 'https' : 'http';
        $site_url .= '://' . $_SERVER['HTTP_HOST'];
        $site_url .= str_replace('secureFiles/actions/'.basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
    } else {
        $site_url = 'http://localhost/'.str_replace('secureFiles/actions/'.basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);;
    }
    $_SESSION['BASEPATH']=$site_url;
}

if (isset($_SESSION['logged_in'])) {
    $basepath = $_SESSION['BASEPATH'];
    $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
    $userSettings = json_decode($_COOKIE[$cookie_name]);
    $userSettings->loggedIn = false;
    if(isset($userSettings->timeOut)){
        unset($userSettings->timeOut);
    }
    unset($_COOKIE['timeOut']);
    setcookie('timeOut', null, -1, '/');
    unset($_COOKIE['token']);
    setcookie('token', null, -1, '/');
    setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');

    session_unset();
    session_destroy();
    header( 'Location: '.$basepath.'login' );
    die();
} else {
    $basepath = $_SESSION['BASEPATH'];
    session_unset();
    session_destroy();
    header( 'Location: '.$basepath.'login' );
    die();
}
