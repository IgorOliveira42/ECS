<?php
//$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//require_once $_SESSION['APPPATH']."models/xor/xor.php";
//require_once $_SESSION['APPPATH']."actions/api/token.php";
//include $_SESSION['APPPATH'] . 'models/device.php';
//
//function checkToken($token) {
//    if($token != '') {
//        $login = token::check_token($token);
//        if($login!=false) {
//            $user = new ModelUser();
//            $userExist = $user->checkUserIdExist($login);
//            if(empty($userExist)) {
//                $result = array("result" => 'Invalid token');
//                echo json_encode($result);
//                return false;
//            } else {
//                $permissions = $user->getPermissionsByUserId($login);
//                if(count($permissions)==5) {
//                    $userID = $login;
//                    return $userID;
//                } else {
//                    $result = array("result" => 'User is not Administrator');
//                    echo json_encode($result);
//                    return false;
//                }
//            }
//        } else {
//            $result = array("result" => 'Invalid token');
//            echo json_encode($result);
//            return false;
//        }
//    } else {
//        $result = array("result" => 'Invalid token');
//        echo json_encode($result);
//        return false;
//    }
//}
//
//try {
//    if (isset($_POST['method']) && !empty($_POST['method'])) {
//        $userID = '';
//        $action = trim($_POST['method']);
//        if (session_id() == '') {
//            session_start();
//        }
//        if (isset($_POST['token'])) {
//            $token = trim($_POST['token']);
//            $tokenExist = checkToken($token);
//            if ($tokenExist == false) {
//                return false;
//            } else {
//                $userID = $tokenExist;
//            }
//        } else {
//            $result = array("result" => "false");
//            echo json_encode($result);
//            return false;
//        }
//    }
//
//    switch ($action) {
//        case 'getDevices':
//            $dev = new Device();
//            $devices = $dev->getAllDevices();
//            echo json_encode($devices);
//            return true;
//            break;
//
//        default:
//            $result = array("result" => 'Undefined method');
//            echo json_encode($result);
//            break;
//    }
//
//} catch (\Exception $e){
//    error_log($e->getMessage());
//    header('HTTP/1.1 500 Internal Server Error');
//    header("Status: 500 Internal Server Error");
//    exit();
//}