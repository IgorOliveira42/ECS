<?php
$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
require_once $_SESSION['APPPATH']."models/xor/xor.php";
if(!class_exists("ModelUser")) {
    require_once $_SESSION['APPPATH'] . "models/modelUser.php";
}

class  token
{
    public static function create_token($username)
    {
        $key = "acsdlink";
        $array = array("login" => $username);

        $jwt = JWT::encode($array, $key);

        $token=XorEncryptor::encrypt($jwt);
        $token=strtr($token, ',', '=');

        return $token;
    }

    public static function check_token($token)
    {
        $key = "acsdlink";

        $decrypt=XorEncryptor::decrypt($token);
        try {

            $login = JWT::decode($decrypt, $key, array('HS256'));
            $user = new ModelUser();
            $userData = $user->getUserIDByName($login->login);
            if(!empty($userData)) {
                $userID = $userData[0]->id;
                return $userID;
            } else {
                return false;
            }
        }
        catch(Exception $e)
        {
            $login =false;
        }
        return $login;
    }
}