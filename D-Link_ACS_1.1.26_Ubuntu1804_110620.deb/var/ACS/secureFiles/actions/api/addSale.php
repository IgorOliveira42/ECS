<?php
//$_SESSION['APPPATH'] = dirname(__FILE__) . "/../../";
//require_once $_SESSION['APPPATH']."models/JWT/JWT.php";
//require_once $_SESSION['APPPATH']."models/xor/xor.php";
//require_once $_SESSION['APPPATH']."actions/api/token.php";
//include  $_SESSION['APPPATH'].'models/modelClient.php';
//
//
//function checkToken($token) {
//    if($token != '') {
//        $login = token::check_token($token);
//        if($login!=false) {
//            $user = new ModelUser();
//            $userExist = $user->checkUserIdExist($login);
//            if(empty($userExist)) {
//                return false;
//            } else {
//                return $login;
//            }
//        } else {
//            return false;
//        }
//    }
//}
//
//try {
//    if (isset($_POST['method']) && !empty($_POST['method'])) {
//        $userID = '';
//        $action = trim($_POST['method']);
//        if (session_id() == '') {
//            session_start();
//        }
//        if (isset($_POST['token'])) {
//            $token = trim($_POST['token']);
//            $tokenExist = checkToken($token);
//            if ($tokenExist == false) {
//                $result = array("result" => 'Invalid token');
//                echo json_encode($result);
//                return false;
//            } else {
//                $userID = $tokenExist;
//            }
//        } else {
//            $result = array("result" => "false");
//            echo json_encode($result);
//            return false;
//        }
//    }
//
//    switch ($action) {
//        case 'addDeviceFromSale':
//            if(isset($_POST['serial_number']) && isset($_POST['model_name']) && isset($_POST['client_id'])) {
//                $serial = $_POST['serial_number'];
//                $modelName = $_POST['model_name'];
//                $client_id = $_POST['client_id'];
//                if($serial != '' && $modelName != '' && $client_id != '') {
//                    $client = new ModelClient();
//
//                    $clientExist = $client->checkClientExist($client_id);
//                    if(empty($clientExist)) {
//                        $result = array("result" => "Client does not exist");
//                        echo json_encode($result);
//                        return false;
//                    }
//                    $macExistsCount = $client->checkMacExist($serial);
//                    $maxExistInDevices = $client->checkMacExistInDevices($serial);
//                    if ($macExistsCount[0]->count != 0 || $maxExistInDevices[0]->count != 0) {
//                        $result = array("result" => "Serial number already exist");
//                        echo json_encode($result);
//                        return false;
//                    }
//                    $modelExistsCount = $client->checkModelExist($modelName);
//                    if ($modelExistsCount[0]->count == 0) {
//                        $result = array("result" => "Model does not exist");
//                        echo json_encode($result);
//                        return false;
//                    } else {
//                        $model = $client->getModelNameByName($modelName);
//                    }
//                    $result = $client->addSaleChoosedClientWithouthConfig('-1','-1', $client_id, $serial, $model[0]->id, '', $model[0]->hw_version);
//                    $result = array("result" => $result);
//                } else {
//                    $result = array("result" => "false11");
//                }
//            } else {
//                $result = array("result" => "false1");
//            }
//            echo json_encode($result);
//            break;
//        default:
//            $result = array("result" => 'Undefined method');
//            echo json_encode($result);
//            break;
//    }
//
//} catch (\Exception $e){
//    error_log($e->getMessage());
//    header('HTTP/1.1 500 Internal Server Error');
//    header("Status: 500 Internal Server Error");
//    exit();
//}