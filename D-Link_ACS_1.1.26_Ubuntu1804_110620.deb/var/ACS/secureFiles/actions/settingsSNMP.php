<?php
if (session_id() == '') {
    session_start();
}

if (isset($_SESSION['lang'])) {
    $lang = $_SESSION['lang'];
}
if ($lang == '' || $lang == 'en') {
    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/english/message_lang.ini');
} else {
    $ini_array = parse_ini_file($_SESSION['APPPATH'] . 'language/russian/message_lang.ini');
}


// TODO the function need to move global spase.
function readAcsSettings()
{
    $settingsFile = '/etc/acs/config/acs.conf';
    $content = file_get_contents($settingsFile);
    $contentArray = explode("\n", $content);
    $settingsArray = array();
    foreach($contentArray as $setting)
    {
        list($key, $value) = explode('=', $setting, 2) + array(NULL, NULL);
        if ($value !== NULL)
        {
            $settingsArray[trim($key)] = trim($value);
        }
    }
    return $settingsArray;
}

$SNMP_SERVER_IP = '127.0.0.1';
$SNMP_SERVER_PORT = '30008';
$INI_DIR = 'description/snmp';
$SNMP_PASSWORD = readAcsSettings()['password'];
$SNMP_USER = readAcsSettings()['username'];;
$SNMP_DB_NAME = 'SNMP';

function checkSNPServerIsUnreachable() 
{
    global $SNMP_SERVER_IP;
    global $SNMP_SERVER_PORT;
    $ch = curl_init("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if (curl_errno($ch) == 7) {
        error_log("(SNMP Server): $SNMP_SERVER_IP:$SNMP_SERVER_PORT Destination Host Unreachable");
        require_once 'secureFiles/views/content/admin/error500.php';
        exit(1);
    } 
}

checkSNPServerIsUnreachable();

function iniFileGeneration($data) 
{
    $output = "";
    foreach($data as $sectionName => $itemsOfSection)
    {
        $output .= "[$sectionName]\n";
        foreach($itemsOfSection as $vals)
        {
            foreach($vals as $key => $val ) 
            {
                $output .= "$key = $val\n";
            }
        }
    }
    return $output;
}


function sendConfigToSNMPServer($url, $data)
{
    $data_string = json_encode($data);                                                                                   
    $ch = curl_init($url);                                                                      
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                                  
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
        'Content-Type: application/json',                                                                                
        'Accept: application/json',
		'Content-Length: ' . strlen($data_string))                                                                       
    );      
    $response = curl_exec($ch);
    return $response;
}

function getJSONStructureMathod11($startIP, $endIP) 
{
    $data = array();
    $data['Method'] = 11;
    $data['Type'] = 1;
    //$data['IPrange'] = $ip;
    $data['startIP'] = $startIP;
    $data['endIP'] = $endIP;
    return $data;
}

function getJSONStructureMathod13($id) 
{ 
        $data = array();
        $data['Method'] = 13;
        $data['Type'] = 1;
        $data['id'] = $id;
        return $data;
}


function processingData($method) 
{

	if(empty($_POST['version'] and !strcmp($_POST['version'], '3')) ) {
	    $data = array( 'Method' => $method
		     	   , 'Type' => 1
                     	   , "version" => $_POST['version']
                           , 'community' => $_POST['community']
                           , 'ip' => $_POST['ip']
                     	   , 'Descriptor' => $_POST['descriptor']
		        );

    } else {
	    $data = array(    'Method' => $method
		                , 'Type' => 1
                        , "version" => $_POST['version']
                        , 'community' => $_POST['community']
                        , 'ip' => $_POST['ip']
			            , 'Descriptor' => $_POST['descriptor']
			            , 'authProtocol' => $_POST['authProtocolVersion'] // TODO the authProtocolVersion  need change to authProtocol
			            , 'privProtocol' => $_POST['privProtocolVersion'] // TODO the privProtocolVersion  need change to privProtocolVersion
			            , 'passwordAuth' => $_POST['passwordAuth']
			            , 'passwordPriv' => $_POST['passwordPriv']
                        , 'encript' => $_POST['encript']
                        , 'userName'  => $_POST['userName']
			 );
    }
    // method 6 for edit, should be id of row to update
    if($method == 6)
    {
	    if(isset($_POST['DevID']))
	    {
   	    	$data['id'] = $_POST['DevID'];
	    } else {
		error_log("The 'DevID' key of POST variable not exists");
		require_once 'secureFiles/views/content/admin/error500.php';
	    }

    }
   return $data;
    
}

function getFileName() 
{
    $array = explode('.', $_FILES['file']['name']);
    $extension = end($array);
    $fileName = $_POST['ip'] . ".$extension";
    return $fileName;
}

function getJSONStructureMethod8($path, $name) 
{
    $path = realpath($path);
    $data = array( 'Method' => 8
                  ,'Type'  => 1
                  , 'Path' => $path
                  , 'Name' => $name
                 );
    return $data;
    
}

function getJSONStructureMethod12($path, $name) 
{
    $data = array( 'Method' => 12 
                  ,'Type'  => 1
                  , 'Path' => $path
                  , 'Name' => $name
                 );
    return $data;
}

/**
 * @param $id
 * @return array
 *  deprecated
 */
function getJSONStructureMathod7D($id)
{
    $data = array( 'Method' => 7
                  ,'Type'  => 1
                  ,'id' => $id
                 );
    return $data;
}

function getJSONStructureMethod7($id)
{
    if($id != '') {
        $data = array( 'Method' => 7
        ,'Type'  => 1
        ,'id' => $id
        );
    } else {
        $data = array('Method' => 7
        , 'Type' => 1
        );
    }
    return $data;
}


$actionKey = "action";
if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'addSwitch')
{
    $data = processingData(5);
    echo sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data);
    exit(0);		
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'scan')
{
    $data = getJSONStructureMathod7D($_POST['id']);
    $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
    if($rData['Result'] == 1) {
        echo json_encode(array('status' => "ok"));
    } else {
        echo json_encode(array('status' => "error"));
    }
    exit(0);		
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'SpecificDevicesScan')
{
    // {"Method":7,"Type":1,"id":[1,14,4,7]}
    $data = getJSONStructureMethod7($_POST['id']);
    $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data), true);
    if($rData['Result'] == 1) {
        echo json_encode(array('status' => "ok"));
    } else {
        echo json_encode(array('status' => "error"));
    }
    exit(0);
}



function sendFileToClient($file)
{
    if (file_exists($file))
    {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    } else {
        error_log("The $file: No such file or directory");
        require_once 'secureFiles/views/content/admin/error500.php';
    }
}



if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'downloadDescriptor')
{
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }
    foreach($dbh->query(" SELECT * FROM  `tb_descriptor` WHERE id = $_POST[id]") as $row)
    {
        sendFileToClient($row['descriptor'] . '/' . $row['desc_name']);   
    }
    exit(0);		
}

function getMathod12()
{

    // TODO need to add validator in id field.
    $data = array( 'Method' => 12
                 , 'Type' => 1
                 , 'id' => $_POST['id']
             );
    return $data;
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'removeDescriptor')
{
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }

    $count = $dbh->query(" SELECT count(*) as count  FROM  `tb_devices` WHERE descript_id = $_POST[id]");
    $data_array = $count->fetchAll();

    if ($data_array[0]['count'] == 0) {
        $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", getMathod12()), true);
        if ($rData['Result'] == 1) {
            foreach ($dbh->query(" SELECT * FROM  `tb_descriptor` WHERE id = $_POST[id]") as $row) {
                unlink($row['descriptor'] . '/' . $row['desc_name']);
            }
        }

    } else {
        echo 'false';
    }
    exit(0);
}



if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'addDescriptor')
{
    global $INI_DIR;
    if(!is_dir($INI_DIR))
    {
        if( !mkdir($INI_DIR, 0777, true) ) {
            error_log("permission denied to create $INI_DIR directory");
            echo "permission denied to create $INI_DIR directory";
            exit(1);
        }
    } 
     
    if(isset($_FILES['file']))
    {
        $fileName = $_FILES['file']['name'];
        $tmpName = $_FILES['file']['tmp_name'];
	$pathAndFile = $INI_DIR . "/$fileName";
	if(file_exists($pathAndFile)) 
	{
		echo json_encode(array('status' => 'error', 'result'=> $ini_array['FileExists'], 'title' => $ini_array['Warning']));
    		exit(0);
		
	}
        $jSONStructureMethod7 = getJSONStructureMethod8($INI_DIR, $fileName);
        $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $jSONStructureMethod7), true);
        if($rData['Result'] == 1) {
            move_uploaded_file($tmpName, $pathAndFile);
        }
    }
    echo json_encode(array('status' => "ok"));
    exit(0);
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'updateDescriptor')
{
    print_r($_POST);
    print_r($_FILES);
    if(!is_dir($INI_DIR))
    {
        mkdir($INI_DIR, 0777, true);
    } 
    if(isset($_FILES['file']))
    {
        $fileName = $_FILES['file']['name'];
        $tmpName = $_FILES['file']['tmp_name'];
        $pathAndFile = $INI_DIR . "/$fileName";
        $jSONStructureMethod12 = getJSONStructureMethod12($INI_DIR, $fileName);
        $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $jSONStructureMethod12), true);
        print_r($rData);
        if($rData['Result'] == 1) {
            $filePathRemove = $INI_DIR . "/$_POST[oldFileName]";
            unlink($filePathRemove);
            move_uploaded_file($tmpName, $pathAndFile);
        }
    }  
    exit(0);
    
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'checkStatus')
{
        if(isset($_POST['id'])) {
            $id = $_POST['id'];
            $jSONStructureMethod13 = getJSONStructureMathod13($id);
            $rData = json_decode(sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $jSONStructureMethod13), true);
            if($rData['Result'] == 1) {
                echo json_encode(array('status' => "enable"));
            } else {
                echo json_encode(array('status' => "disable"));
            }
        }
        exit(0);		
}


if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'updatedSwitchSetting') {
    $data = processingData(6);
    echo sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data);
    exit(0);
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'getDescriptions') {
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }
    foreach($dbh->query(" SELECT * FROM  `tb_descriptor`") as $row)
    {
        echo "<option value='$row[id]' tId='$row[id]'>" . basename($row['desc_name']) . "</option>";
    }
    exit(0);		

}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'getAllSwitches') {
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }
    $stmt = $dbh->prepare(" SELECT * FROM  `tb_devices`");
    $stmt->execute();
    if($stmt->rowCount() >= 1) {
        echo "<div class=\"switchesForScan\">";
        foreach ($dbh->query(" SELECT * FROM  `tb_devices`") as $row) {
            echo "<input type=\"checkbox\" class=\"switches\" id='$row[id]' value='$row[id]' tId='$row[id]'>" . "    " . basename($row['IP']) . "</br>";
        }
        echo "</div>";
    }
    exit(0);

}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'getDescriptionsForTable') {
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("error");
    }
    $index = 1;
    foreach($dbh->query(" SELECT * FROM  `tb_descriptor`") as $row)
    {
        $fileDescripterName = basename($row['desc_name']);
        echo "<tr tIdT='$row[id]'>";
            echo "<td> <input type=\"checkbox\" class=\"fieids\"> </td>";
            echo "<td class='indexDescriptor' > $index </td>";
            echo "<td tIdT='$row[id]'>" . basename($row['desc_name']) . "</td>";
                    // below a tage remove from below td tag
                    // <a class='showEditForm sun1 editDescriptor' tid='$row[id]' title='$ini_array[edit]' data-toggle='collapse' data-target='#editIniDescription$index'><i class='fa fa-fw fa-sun-o'></i></a>
            echo"<td>
                    <a  class='remTempl sun1' title='$ini_array[download]'><i class='fa fa-fw fa-download fa-download-ini' tIdT='$row[id]' style='padding-left: 0'></i></a>
                    <a class='remTempl sun1 ' title='$ini_array[remove]' ><i class='fa fa-fw fa-trash-o remove_raw_ini' tIdT='$row[id]' index='$index' style='padding-left: 0'></i></a>

                </td> ";
           echo "</tr>";
        $index++;
    }
    echo "<script> </script>";
    exit(0);		

}


if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'find') {
    if( isset($_POST['startIP']) and isset($_POST['endIP']) ) {
        $data = getJSONStructureMathod11($_POST['startIP'], $_POST['endIP']); 
        echo sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data);
    } else {
        error_log("KeyError: The 'startIP' or 'endIP' keys doesn't exist in \$_POST variable");
    }
    exit(0);
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'removeSwitch') {
    $id = $_POST['id'];
    $data = array( 'Method' => 9 
                  , 'Type' => 1
                  , 'id' => $id
                 );
    echo sendConfigToSNMPServer("http://$SNMP_SERVER_IP:$SNMP_SERVER_PORT", $data);
    exit(0);
}

if(isset($_POST[$actionKey]) && $_POST[$actionKey] === 'getDev') {
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("error");
    }
    $index = 1;
    foreach($dbh->query(" SELECT tb_devices.id, name, IP, dev_status , version, community, desc_name  FROM `tb_devices` INNER JOIN tb_descriptor on `descript_id` = tb_descriptor.id ") as $row) {
        echo "<tr tid='$row[id]' devid=$row[id] id='trHeIndex$index' index='$index'>";
        echo "<td> <input type=\"checkbox\" class=\"fieidss\"> </td>";
                echo "<td class='indexDevices' > $index</td>";         // index
                echo "<td id='ip$index'> $row[IP] </td>";             // IP Address
                echo "<td id='ip$index'> $row[name] </td>";             // name
                echo "<td> $row[version] </td>";        // version
                echo "<td> $row[community] </td>";      // community 
                echo "<td> " . basename($row['desc_name']) ."</td>";
                echo "<td>";
                    
               echo "<a style='cursor:pointer' tid='$row[id]' ";
               echo  $row['dev_status'] == 1 ? "class='online sw_status'>" : "class='offline sw_status'>";
               echo  "<i class='fa fa-circle custom-circle'></i></a></td>
                <td>
                    <a class='remTempl sun1' title='$ini_array[refresh_button]'><i class='fa fa-fw fa-refresh' style='padding-left: 0'></i></a>
                    <a class='showEditForm sun1 editSwitch' tid='$row[id]' title='$ini_array[edit]' data-toggle='collapse' data-target='#editsettSNMP$index'><i class='fa fa-fw fa-sun-o'></i></a>
                    <a class='remTempl sun1 ' title='$ini_array[remove]' ><i class='fa fa-fw fa-trash-o removeRAW'
					devID='$row[id]' ipID='ip$index' index='$index' style='padding-left: 0'></i></a>
                </td> ";
       echo "</tr>";
       $index++; // increment
    }
    exit(0);
}


function getAction($url) 
{
    $tmpAction = explode("/", $url);
    $data = array();
    foreach($tmpAction as $val) {
        if(!empty($val)) {
            $data[] = $val;
        }
    }
    if(0 == sizeof($data)) return "";
    $action = preg_replace('/\?.*/', '', $data[sizeof($data)-1]);
    return $action;

}


function showSwitchEditPage() 
{
    global $SNMP_DB_NAME;
    global $SNMP_USER;
    global $SNMP_PASSWORD;
    global $ini_array;
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }
    $index = 1;
    if(!isset($_POST['id'])) return;
    $id = $_POST['id'];
    $isVisableAddtionalFileds = "for_all_display_none";
    foreach($dbh->query(" SELECT * FROM `tb_devices` WHERE `id`='$id'") as $row) {
       // ------------------edit--------------------------------------------------------
        echo " <div class='container-fluid create-tarif'  style='height: 80px;'> ";
        echo "    <button class='btn btn-primary' id='backSettingsSNMP1'> $ini_array[back_settings_SNMP]</button>";
        echo " </div>";
        echo "        <div class='col-sm-14'>";
        echo "            <form id='formEditSNMP$index' class='updateSettingsSNMPEdit' method='post' enctype='multipart/form-data' >";
        echo "              <input type='hidden' name='action' value='updatedSwitchSetting'/>
                            <div  class='col-sm-14 settingsDiv'>
                                <div class='col-sm-5'>
                                    <div class='settingsContent'>
                                        <label>$ini_array[ip]:</label> <span class=\"errorMessage\">*</span><br/>
                                        <input type='text' name='ip' id='ip' value='$row[IP]'/>
                                        <input type='hidden' name='DevID' id='DevID' value='$row[id]'/>
                                    </div>";
       echo "
                                    <div class='settingsContent'>
                                        <label>$ini_array[version]: </label> <br />
                                        <label class='selectLabel'>
                                            <select v3='editSettingsSNMPpart$index'  id='SNMP_version' name='version' class='settingsSelect SNMPsettingsSelect editVersionSelect''>";
                                                foreach(array('1', '2c', /*'2u',*/  '3') as $optionVal) {
                                                    if($optionVal === $row['version']) {
                                                        if( $row['version'] == '3') {
                                                            $disableEncypt="";
                                                            $opacitiEncypt = "opacity: 1";
//                                                            $isVisableAddtionalFileds = "for_all_display_block";
                                                        } else {
//                                                            $opacitiEncypt = "opacity: 0.5";
                                                            $disableEncypt="disabled";
                                                        }
                                                        echo "<option selected='selected' >$optionVal</option>";
                                                    } else {
                                                        echo "<option>$optionVal</option>";
                                                    }
                                                }
       echo "                                </select>
                                        </label>
                                    </div>
                                    <div class='settingsContent'>
                                        <label>$ini_array[community]: </label> <span class=\"errorMessage\">*</span><br />
                                        <input type='text' name='community' id='community' value='$row[community]'/>
                                    </div>

                                    <div class='settingsContent'>
                                        <label> $ini_array[description]: </label> <br />
                                        <label class='selectLabel'>
                                        <select name='descriptor' class='settingsSelect SNMPsettingsSelect versionSelect' id='selectDescriptor'>";
                                        // TODO need to implement show discriptor
                                        foreach($dbh->query(" SELECT * FROM `tb_descriptor`") as $dis) {
                                            if($row['descript_id'] === $dis['id']) {
                                                echo "<option tid='$dis[id]' value='$dis[id]' selected='selected' > ".  basename($dis['desc_name']) . "</option>";
                                            } else {
                                                echo "<option tid='$dis[id]'> ".  basename($dis['desc_name']) . "</option>";
                                            }
                                        }
      echo "                            </select>
                                        </label>
                                    </div>
                                    </div>
                                                    <div class=\"col-sm-5\" id=\"settingsSNMPpart2\">
   
                    <div class=\"settingsContent\">
                                        <label> $ini_array[enter_username]:</label> <span class=\"errorMessage\">*</span> <br/>
                                        <input type='text' name='userName' id='userName' value='' readonly disabled/>
                                    </div>
                                       <div class=\"settingsContent\">
                        <label> $ini_array[auth_protocol]: </label> <br />
                        <label class=\"selectLabel\">
                            <select id='authProtocol' name=\"authProtocolVersion\" class=\"settingsSelect SNMPsettingsSelect\" disabled>
                                <option>MD5</option>
                                <option>SHA</option>
                            </select>
                        </label>
                    </div>
                    <div class=\"settingsContent\">
                        <label>$ini_array[enter_password] : <span class=\"errorMessage\">*</span> </label> <br/>
                        <input type=\"password\" name=\"passwordAuth\" id=\"passAuth\" value=\"\" readonly disabled/>
                    </div>
                    <div class=\"settingsContent\">
                        <label> $ini_array[priv_protocol] : </label> <br />
                        <label class=\"selectLabel\">
                            <select id='privProtocol' name=\"privProtocolVersion\" class=\"settingsSelect SNMPsettingsSelect\" disabled>
                                <option value='DES'>DES</option>
                                <option value='none'>none</option>
                            </select>
                        </label>
                    </div>
                    <div class=\"settingsContent privProtocolDiv\">
                        <label>$ini_array[enter_password] :  <span class=\"errorMessage\">*</span> </label> <br/>
                        <input type=\"password\"  name=\"passwordPriv\" id=\"passPriv\" value=\"\" readonly disabled/>
                    </div>

                </div>";
//                                            if( $row['version'] == '3') {
//                                            foreach ($dbh->query(" SELECT * FROM `tb_snmpv3` WHERE `device_id`='$id'") as $sec) {
//                                                echo "                         <div class='col-sm-5 $isVisableAddtionalFileds' id = 'editSettingsSNMPpart$index' > ";
//
//      echo "                               <div class='settingsContent' >
//                                        <label > $ini_array[enter_password]: </label > <span class=\"errorMessage\">*</span><br/>
//                                        <input type='password' name='password' id='passSNMP' value='' readonly/ >
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[enter_username] :</label> <span class=\"errorMessage\">*</span><br/>
//                                        <input type='text' name='secname' id='secname' value='$sec[secname]'/>
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[Security_Level] :</label> <span class=\"errorMessage\">*</span><br/>
//                                        <input type='text' name='seclevel' id='seclevel' value='$sec[seclevel]'/>
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[Authentication_Protocol] :</label> <span class=\"errorMessage\">*</span> <br/>
//                                        <input type='text' name='autopro' id='autopro' value='$sec[autoprot]'/>
//                                    </div> ";
//        echo "                          </div>";
//                                           } } else {
//
//        echo "                         <div class='col-sm-5 $isVisableAddtionalFileds' id = 'editSettingsSNMPpart$index' >
//
//                                    <div class='settingsContent' >
//                                        <label > $ini_array[enter_password]: </label > <span class=\"errorMessage\">*</span><br/>
//                                        <input type='password' name='password' id='passSNMP' value='' readonly/ >
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[enter_username] :</label> <span class=\"errorMessage\">*</span><br/>
//                                        <input type='text' name='secname' id='secname' value=''/>
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[Security_Level] :</label> <span class=\"errorMessage\">*</span><br/>
//                                        <input type='text' name='seclevel' id='seclevel' value=''/>
//                                    </div>
//
//                                    <div class='settingsContent'>
//                                        <label>$ini_array[Authentication_Protocol] :</label> <span class=\"errorMessage\">*</span> <br/>
//                                        <input type='text' name='autopro' id='autopro' value=''/>
//                                    </div>
//                                  </div>";
//
//                                            }

        echo"                      </div>
                            <div style='margin-bottom: 40px' class='col-sm-12'>
                                <button type='button' selfFormID='formEditSNMP$index' class='btn btn-primary settingsApply buttonApply settingsApplyForEdit'>$ini_array[apply]</button>
                                <button type='reset' id='cancelSettingsSNMP$index' class='btn btn-primary settingsApply'>$ini_array[cancel]</button>
                            </div>
                        </form>
                    </div>
            ";
                                        $index++; // increment

    }


}

function updatedDescription() 
{
    global $SNMP_DB_NAME; 
    global $SNMP_USER;
    global $SNMP_PASSWORD;
    global $ini_array;
    try {
        $dbh = new PDO("mysql:host=localhost;dbname=$SNMP_DB_NAME", $SNMP_USER, $SNMP_PASSWORD);
    } catch(PDOException $e) {
        error_log($e->getMessage());
        die("Error: " . $e->getMessage());
    }
    $index = 1;
    if(!isset($_POST['id'])) return;
    $id = $_POST['id'];
    foreach($dbh->query(" SELECT * FROM  `tb_descriptor` WHERE `id`='$id'") as $row)
    {
        $fileDescripterName = basename($row['descriptor']);
       // ------------------edit start--------------------------------------------------------
        echo "              <div class='col-sm-14'>";
        echo "                  <div class='col-sm-12 settingsDiv'>";
        echo "                      <form name='updateDescriptor' id='updateDescriptor$index' method='post' enctype='multipart/form-data'>";
        echo "                          <input type='hidden' name='action' value='updateDescriptor'/>";
        echo "                          <input type='hidden' name='oldFileName' value='$fileDescripterName' />";
        echo "                          <fieldset class='fieldsetSettingsSNMP'>";
        echo "                          <legend>Descriptor</legend>";
        echo "                          <div class='settingsContent'>";
        echo "                              <label>$ini_array[choose_file] :</label> <span class=\"errorMessage\">*</span> <br/>";
        echo "                              <input id='updateUploadFileSNMP$index' class='editUploadInput' value='$fileDescripterName' name='uploadFile' placeholder='$ini_array[file_name]' readOnly/>";
        echo "                              <div class='fileUpload btn btn-primary'>";
        echo "                              <span>$ini_array[choose]</span>";
        echo "                              <input inputID='updateUploadFileSNMP$index' name='uploaded_file' id='updateUploadBtnSNMP$index' type='file' class='upload inputFileUpdateDescriptor' />";
        echo "                          </div>";
        echo"                               <div id=\"edit_file_error\" class=\"error_message for_all_display_none\">  $ini_array[error_message_required] </div>";
        echo "                  </div>";
        echo "          <div>";
        echo "          <button type='button' inputFileID='updateUploadBtnSNMP$index' formID='updateDescriptor$index' id='uploadSNMPDescriptor$index' class='btn btn-primary settingsApply updateDiscriptor'>$ini_array[upload_diagnostic]</button>";
       // ------------------edit end--------------------------------------------------------
        $index++;
    }
    echo "<script> </script>";
    exit(0);		

}


if (isset($_SESSION['logged_in'])) {
    $userName = $_SESSION['logged_in'];
    $action = getAction($_SERVER['REQUEST_URI']);
    switch($action) {
    case "settingsSNMP":
        include $_SESSION['APPPATH'].'views/tiles/admin/settingsSNMP_view.php';
        break;
    case "updatedDescription":
        updatedDescription();
        break;
    case "updatedSwitch":
        showSwitchEditPage();
        break;
    }
} else {
    require_once 'secureFiles/actions/login.php';
}
