<?php

if (version_compare(phpversion(), '5.4.0', '<')) {
    if(session_id() == '') {
       session_start();
    }
}else {
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
}

//var_dump($_SESSION['group_id']);
if(isset($_COOKIE['timeOut'])){
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > $_COOKIE['timeOut'])) {
//        if(session_id() != '') {
//            session_unset();
////            session_destroy();
//        }
        $userSettings = json_decode($_COOKIE[$_SESSION['logged_in']]);
        setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        $userSettings->loggedIn = false;
        if(isset($userSettings->timeOut)){
            unset($userSettings->timeOut);
        }
        unset($_COOKIE['timeOut']);
        setcookie('timeOut', null, -1, '/');
        unset($_COOKIE['token']);
        setcookie('token', null, -1, '/');
        setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        if(session_id() != '') {
            session_unset();
        }
    }  else {
        if(isset($_COOKIE['loggedInUser']) && isset($_SESSION['logged_in'])){
            $cookie_name = str_replace(".", "_", $_SESSION['logged_in']);
            $userSettings = json_decode($_COOKIE[$cookie_name]);
            setcookie('timeOut', $_COOKIE['timeOut'], time() + (86400 * 7),'/');
            setcookie('loggedInUser', $_SESSION['logged_in'], time() + $_COOKIE['timeOut'],'/');
            setcookie($_SESSION['logged_in'], json_encode($userSettings), time() + (86400 * 7),'/');
        }
    }
    $_SESSION['LAST_ACTIVITY'] = time();
//        setcookie('LAST_ACTIVITY', time());
}

$site_url = '';
if (isset($_SERVER['HTTP_HOST'])) {
    $site_url = isset($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) == 'on' ? 'https' : 'http';
    $site_url .= '://' . $_SERVER['HTTP_HOST'];
    $site_url .= str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
} else {
    $site_url = 'http://localhost/';
}

if(!defined('BASEPATH')){define('BASEPATH', $site_url);}

if (isset($_SESSION['lang'])) {
    if ($_SESSION['lang'] != 'en' && $_SESSION['lang'] != 'ru') {
        $_SESSION["lang"] = "en";
    }
} else {
    $_SESSION['lang']='en';
}

function downloadFile($file){
    if (file_exists($file))
    {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
    } else {
        error_log("The $file: No such file or directory");
        require_once 'secureFiles/views/content/admin/error500.php';
    }
}

if(isset($_GET['authorization'])) {
    if (isset($_POST['token'])) {
        $app_path = "secureFiles";
        $app_path = realpath($app_path).'/';
        require_once $app_path . "models/JWT/JWT.php";
        require_once $app_path . "models/xor/xor.php";
        require_once $app_path . "actions/api/token.php";
        $token = trim($_POST['token']);
        $actual_link = "." . $_SERVER['REQUEST_URI'];
        if ($token != '') {
            $login = token::check_token($token);
            if ($login != false) {
                if (!isset($_POST['actionName'])){
                    header('Content-type: text/xml');
                    readfile($actual_link);
                    return;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    } else{
        $app_path = "secureFiles";
        $app_path = realpath($app_path).'/';
        require_once $app_path . "models/device.php";

        $device = new Device();

        $tokenFname = $_GET['authorization'];
        $idArray = explode("/",$tokenFname);
        $fileId = end($idArray);
        $config = $device->getConfig($fileId);

        if(isset($config[0]->config_path) && !empty($config[0]->config_path) && $config[0]->config_path != '') {
            $fName = $config[0]->config_path;
            $file = $_SERVER['DOCUMENT_ROOT'] . $fName;
        } else {
            $file = $_SERVER['DOCUMENT_ROOT'] . "/putConfigs/" . $fileId;
        }
        downloadFile($file);
    }
}


if(!isset($_COOKIE['loggedInUser']) || !isset($_COOKIE['token'])){
    unset($_SESSION['logged_in']);
    unset($_SESSION['timeOut']);
    if (isset($_SESSION['lang'])) {
        if ($_SESSION['lang'] != 'en' && $_SESSION['lang'] != 'ru') {
            $_SESSION["lang"] = "en";
        }
    } else {
        $_SESSION['lang']='en';
    }

//    require_once 'secureFiles/actions/login.php';
    require_once 'secureFiles/actions/api/login.php';
}else {
    /*------------------for TR Tree--------------------*/

    /*-------------------end--------------------------*/

    $loggedInUserName = $_COOKIE['loggedInUser'];
    $loggedInUserName1 = str_replace(".", "_", $_COOKIE['loggedInUser']);
    if(isset($_COOKIE[$loggedInUserName1])){
        $userSettings = json_decode($_COOKIE[$loggedInUserName1]);

        if($userSettings->loggedIn){    
            $_SESSION['logged_in'] = $loggedInUserName;
            $_SESSION["BASEPATH"] = BASEPATH;
            $realPath = dirname(__FILE__);
            $_SESSION["REALPATH"] = $realPath;

            $app_path = "secureFiles";
            $app_path = realpath($app_path).'/';
            $_SESSION['APPPATH'] = $app_path;
            
            # site_type must be 'main' or 'armentel'
            $_SESSION['site_type'] = parse_ini_file($_SESSION['APPPATH'] . 'resource/site_type.ini')['site_type'];

            if(!class_exists('Utils')){require_once $_SESSION['APPPATH']."util/utils.php";}
            require_once $_SESSION['APPPATH']."models/modelUser.php";
            try {
                $user = new ModelUser();
                $_SESSION['userID'] = $user->getUserIDByName($loggedInUserName)[0]->id;
                $group_id = $user->getGroupByUsername($loggedInUserName);
                $permissions = $user->getPermissionsByUsername($loggedInUserName);
            } catch (Exception $e) {
                error_log($e->getMessage());
                header('HTTP/1.1 500 Internal Server Error');
                header("Status: 500 Internal Server Error");
                require_once 'secureFiles/actions/error500.php';
            }
            
            $permissionsArray = array();
            if($permissions){
                for($ii = 0; $ii < count($permissions); $ii++){
                   $permissionsArray[] = $permissions[$ii]->name;
                }
            }
            $_SESSION['group_id'] = $group_id[0]->name;
            $_SESSION['permissions'] = $permissionsArray;

            $controllName = "";
            $routes = explode('/', $_SERVER['REQUEST_URI']);
            if (!empty($routes[1])) {
                $controllName = $routes[1];
                if($controllName == 'home'){
                    $controllName = Utils::getPermissions($permissionsArray);
                }

                if($controllName == 'login' && isset($_SESSION['logged_in'])){
                    $controllName = Utils::getPermissions($permissionsArray);
                }

                if($controllName == 'devInfo'){
                    $controllName = "eachDevInfo";
                }

            }else if(empty($routes[1]) && isset($_SESSION['lastPage']) && !isset($_GET['controlName']) && !isset($_POST['controlName'])){
//                $controllName = $_SESSION['lastPage'];
                $controllName = 'forDevices';

            }else if(empty($routes[1]) && !isset($_SESSION['lastPage']) && isset($_SESSION['logged_in'])){ 
                $controllName = Utils::getPermissions($permissionsArray);

            }else if(isset($_POST['controlName'])){
                $controllName = $_POST['controlName'];
                if($controllName == ''){
                    if(isset($_SESSION['lastPage'])){
                        $controllName = $_SESSION['lastPage'];
                    }else{ 
                        $controllName = "login";
                    }
                }

            } else if(isset($_SESSION['lastPage']) && $_SESSION['lastPage'] != ''){
                $controllName = $_SESSION['lastPage'];

            } else {
                $controllName = "login";
            }

            $lang = $_SESSION['lang'];
            if ($lang == 'en') {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/english/message_lang.ini');
            } else {
                $ini_array = parse_ini_file($_SESSION['APPPATH'].'language/russian/message_lang.ini');
            }

            $_SESSION['lastPage'] = $controllName;

            if($controllName == 'eachDevInfo'){
                if(isset($routes[2]) && $routes[2] != ''){
                    $devID = $routes[2];
                    $_SESSION['deviceId'] = $devID;

                }else if(isset($_SESSION['deviceId'])){
                    $devID = $_SESSION['deviceId'];
                }  else {
                    $devID = $_POST['devId'];
                    $_SESSION['deviceId'] = $devID;
                }
            }
            
            if($controllName == 'template'){
                if(isset($routes[2]) && $routes[2] != ''){
                    $tmpAction = $routes[2];
                }
                if(isset($routes[3]) && $routes[3] != ''){
                    $tmplId = $routes[3];
                }
            }

            if($controllName == 'profile'){
                if(isset($routes[2]) && $routes[2] != ''){
                    $profileAction = $routes[2];
                }

            }

            try{
                /*if($controllName=="logUpload")
                {
                     if (isset($_SESSION['logged_in'])) {
                         $_SESSION['lastPage'] = 'login';
                         header('HTTP/1.1 404 Not Found');
                         header("Status: 404 Not Found");
                         require_once 'secureFiles/actions/error404.php';
                     }
                }
                else
                {*/
                    if(file_exists('secureFiles/actions/'.$controllName.'.php')){
                        require_once $_SESSION['APPPATH'] . "util/usersConstants.php";
                        if($controllName=="forDevices" && (!in_array(UsersConstants::$devicePermission, $permissionsArray) && !in_array(UsersConstants::$monitoring, $permissionsArray))){
//                            $_SESSION['lastPage'] = 'forDevices';
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="clients" && (!in_array(UsersConstants::$clientPermission, $permissionsArray) && !in_array(UsersConstants::$monitoring, $permissionsArray))){
//                            $_SESSION['lastPage'] = 'forDevices';
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        }else if($controllName=="unknowns" && (!in_array(UsersConstants::$devicePermission, $permissionsArray) && !in_array(UsersConstants::$clientPermission, $permissionsArray ) || (!in_array(UsersConstants::$monitoring, $permissionsArray)))){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        }else if($controllName=="groups" && (!in_array(UsersConstants::$groupPermission, $permissionsArray) && !in_array(UsersConstants::$monitoring, $permissionsArray))){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        }else if($controllName=="sale" && (!in_array(UsersConstants::$groupPermission, $permissionsArray) && !in_array(UsersConstants::$clientPermission, $permissionsArray) ||  (!in_array(UsersConstants::$monitoring, $permissionsArray)))){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        }else if($controllName=="activity" && !in_array(UsersConstants::$devicePermission, $permissionsArray)){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="template" && !in_array(UsersConstants::$devicePermission, $permissionsArray)){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="users" && !in_array(UsersConstants::$userPermission, $permissionsArray)){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="userGroups" && !in_array(UsersConstants::$userPermission, $permissionsArray)){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="settings" && !in_array(UsersConstants::$userPermission, $permissionsArray)){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else if($controllName=="profile" && (!in_array(UsersConstants::$userPermission, $permissionsArray) || !in_array(UsersConstants::$devicePermission, $permissionsArray) || !in_array(UsersConstants::$groupPermission, $permissionsArray) || !in_array(UsersConstants::$clientPermission, $permissionsArray) || !in_array(UsersConstants::$monitoring, $permissionsArray))){
                            header('HTTP/1.1 404 Not Found');
                            header("Status: 404 Not Found");
                            require_once 'secureFiles/actions/error404.php';
                        } else {
                            require_once 'secureFiles/actions/'.$controllName.'.php';
                        }
                    } else if($controllName == '500') {
                        header('HTTP/1.1 500 Internal Server Error');
                        header("Status: 500 Internal Server Error");
                        require_once 'secureFiles/actions/error500.php';
                    } else {
                        $_SESSION['lastPage'] = 'forDevices';
                        header('HTTP/1.1 404 Not Found');
                        header("Status: 404 Not Found");
                        require_once 'secureFiles/actions/error404.php';
                    }
                //}

            } catch (\Exception $e) {
                error_log($e->getMessage());
                header('HTTP/1.1 500 Internal Server Error');
                header("Status: 500 Internal Server Error");
                require_once 'secureFiles/actions/error500.php';
            }
        }else {
//            require_once 'secureFiles/actions/login.php';
            require_once 'secureFiles/actions/api/login.php';
        }
    }  else {
//        require_once 'secureFiles/actions/login.php';
        require_once 'secureFiles/actions/api/login.php';
    }
}
?>
