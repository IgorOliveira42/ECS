#!/bin/bash

set +x
r='\033[31' #red
g='\033[92m' #green
e='\033[0m' #end color
b='\033[1m' #b

PASS=`cat /etc/acs/config/acs.conf 2>/dev/null | grep password | awk '{print $3}'`

if [[ -z $PASS ]]
then
echo -e $b"Can't find ACS configuration. Try to reinstall server."$e
exit 0
fi


echo ''
echo -e $b'Self diagnostic'$e

echo -e $g'System version:'$e
lsb_release -i -d -r -c
echo ''
D-Link_ACS -v

#Check db
my=`mysql -u root -p$PASS ACSServer -e 'select * from settings where id<4'`

#db
if [[ -z $my ]]
then
echo -e $b"WARNING: Problem with connection to DB. Correct settings in '/etc/acs/config/acs.conf' and restart D-Link_ACS"$e
exit 0
else echo -e $g"Connection to DB is OK"$e
fi

#Check DB password

mypass=`mysql -u root -p$PASS ACSServer -e 'select authentication_string from mysql.user where user="root"\G' | grep authentication_string | awk '{print $2}' | wc -m`
if [[ "$mypass" -le 1 ]]
	then
	echo -e $b"WARNING: Password for DB is not set (maybe first install of mysql). ACS will set new password for mysql root user"$e
	echo 'Setting password...'
	mysql -u root -p$PASS -e "update mysql.user set authentication_string=PASSWORD("\'$PASS\'"), plugin='mysql_native_password' where user='root'"
	echo 'Flushing privileges...'
	mysql -u root -p$PASS -e "flush privileges"
	echo 'Restarting mysql...'
	service mysql restart
	echo 'Restarting D-Link_ACS'
	service D-Link_ACS restart
else echo -e $g"DB password is set"$e
fi




#Check process
sleep 1
proc=`pidof D-Link_ACS`
if [[ -z $proc ]]
then
echo -e $b'WARNING: D-Link_ACS Service is not running. Trying to restart..'$e
sudo service D-Link_ACS restart
sleep 1
cat /var/log/syslog | grep ACS > /tmp/ACS.log
echo 'Logs are saved to /tmp/ACS.log'
fi

proc=`pidof D-Link_ACS`
if [[ -z $proc ]]
then
c_port=`cat /etc/acs/config/acs.conf | grep serverport | sed s/[^0-9]//g`
lock=`sudo netstat -nap | grep $c_port | awk '{print $7}'`
fi

if [[ ! -z $lock ]]
then
echo -e $b'Port' $c_port 'may be used by' $lock $e
fi

if [[ -z $proc ]]
then
echo -e $b"ERROR: D-Link_ACS is not started. Try to use 'sudo service D-Link_ACS restart' and check /var/log/syslog"$e
else echo -e $g"D-Link_ACS is running"$e
fi

#Check apache2
apache=`pidof apache2`
if [[ -z $apache ]]
then echo -e $b"ERROR: Apache2 server is not started. Try to use 'sudo service apache2 restart' and check /var/log/syslog"$e
else echo -e $g"Apache2 server is running"$e
fi


#Check STUN
stun=`pidof stunserver`
if [[ -z $stun ]]
then echo -e $b"WARNING: STUN Server is not ready. Try to use 'sudo service D-Link_ACS restart' and check /var/log/syslog"$e
else echo -e $g"STUN Server is running"$e
fi

#Check https
https=`pidof stunnel4`
if [[ -z $https ]]
then
echo -e $b"WARNING: Stunnel4 is not running. Trying to restart.."$e
sudo service stunnel4 restart
https=`pidof stunnel4`
fi
if [[ -z $https ]]
then echo -e $b"ERROR: HTTPS Server (stunnel4) is not ready. Try to use 'sudo service stunnel4 restart' and check /var/log/syslog"$e
else echo -e $g"HTTPS Server (stunnel4) is running"$e
fi

echo ''
echo 'Connection info:'
s_port=`cat /etc/stunnel/stunnel.conf | grep ACS -A1 | grep accept | sed s/[^0-9]//g`

a_port=`cat /etc/apache2/sites-enabled/ACS.conf | grep '<VirtualHost' | sed s/[^0-9]//g`
a_ip=`mysql -u root -p$PASS ACSServer -e 'select settings_value from settings where settings_name="web_ip"' 2>/dev/null | sed s/[^0-9.]//g`
echo -e 'WEB Server IP:port (GUI) ='$b $a_ip':'$a_port $e

a_ip=`echo $a_ip | sed s/' '//g`

c_port=`cat /etc/acs/config/acs.conf | grep serverport | sed s/[^0-9]//g`

echo ''
echo -e $b"INFO: You need to set followed parameters at CPE's settings"$e
echo -e "'ACS URL' for CPE (HTTP-connection) = "$b'http://'$a_ip':'$c_port$e
echo ' or'
echo -e "'ACS URL' for CPE (HTTPS-connection) = "$b'https://'$a_ip':'$s_port$e
echo ''
user=`cat /etc/acs/config/acs.conf | grep dev_usname | awk '{print $3}'`
pass=`cat /etc/acs/config/acs.conf | grep dev_pass | awk '{print $3}'`

echo -e "Connection Request username/password for CPE may be$b empty$e or "$b$user'/'$pass$e
echo "INFO: You may change them at page 'Settings' or in '/etc/acs/config/acs.conf' and restart ACS by 'sudo service D-Link_ACS restart'"
exit 0
